function WTAtest
%
% WTA tests with Munkres algorithm
%
dbstop if error
%% example 1
lethality   = [0.5 0.95 0.06 0.02 0.3];
pKill = 0.9*ones(size(lethality));
maxKV = 3;
reachMat    = [
    1.15  1.94  0.75  1.37  1.45
    1.92  1.23  1.14  1.84  0.57
    0.67  1.98  0.87  1.82  1.76
    0.83  0.47  1.53  1.62  1.31];
tic
[fAssign, fLeak] = optimalWTA(lethality,reachMat,pKill,maxKV)
toc

%% example 2
% lethality   = [0.1 0.01];
% pKill = [0.9 1];
% reachMat    = [
%     1 0
%     1 1];
% [fAssign, fLeak] = optimalWTA(lethality,reachMat,pKill,maxKV)
