function WTAtest
%
% WTA test with Munkres algorithm
%
lethality   = [0.5 0.6 0.3 0.8 0.6];
pKill = 0.9*ones(size(lethality));
maxKV = 3;
reachMat    = [
    1 1 1 1 1];
[fAssign, fLeak] = optimalWTA(lethality,reachMat,pKill,maxKV)
