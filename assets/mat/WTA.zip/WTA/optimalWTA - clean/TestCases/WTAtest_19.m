function WTAtest
%
% WTA test with Munkres algorithm
%
lethality   = [0.08 0.56 0.9 0.08 0.24 0.65];
pKill = 0.9*ones(size(lethality));
maxKV = 3;
reachMat    = [
    0 0 0 0 0 0 
0 0 1 1 1 0 
0 1 0 0 0 0 
0 0 0 0 0 1 
1 0 0 0 0 1 
0 1 1 0 1 0 
0 1 0 0 0 1 
1 0 0 1 0 1 
0 0 1 0 1 1];
[fAssign, fLeak] = optimalWTA(lethality,reachMat,pKill,maxKV)
