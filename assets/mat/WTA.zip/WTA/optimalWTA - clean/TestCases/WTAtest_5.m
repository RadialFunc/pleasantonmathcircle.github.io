function WTAtest
%
% WTA test with Munkres algorithm
%
lethality   = [0.08 0.9 0.05 0.07 0.06];
pKill = 0.9*ones(size(lethality));
maxKV = 3;
reachMat    = [
    1 0 1 1 1
    0 1 0 1 1
    1 1 1 0 0];
[fAssign, fLeak] = optimalWTA(lethality,reachMat,pKill,maxKV)
