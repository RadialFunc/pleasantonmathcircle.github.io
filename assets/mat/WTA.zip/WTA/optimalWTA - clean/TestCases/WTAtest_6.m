function WTAtest
%
% WTA test with Munkres algorithm
%
lethality   = [0.7 0.6 0.8 0.5 0.9];
pKill = 0.9*ones(size(lethality));
maxKV = 3;
reachMat    = [
    0 0 1 0 1
    0 1 0 1 0
    1 0 1 0 0];
[fAssign, fLeak] = optimalWTA(lethality,reachMat,pKill,maxKV)
