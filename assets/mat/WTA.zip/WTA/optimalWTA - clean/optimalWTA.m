function [fAssign, fLeak] = optimalWTA(lethality,reachMat,pKill,maxKV)
% lethality is the vector of object lethalities
% reachMat is the reachability matrix
% pKill is the probability of a KV eliminating the object's lethality once
%       it has been assigned to that object
% maxKV is the maximum number of KVs allowed to assign to a single object
%
% fAssign is the (#KV x #Ojb) assignment matrix
% fLeak is the total lethality leakage for fAssign
%
% Author: G. Chiang
% Date: 3/29/2016
%
if nargin<3 %default pKill and maxKV
    pKill = 0.9*ones(size(lethality));
    maxKV = 3;
end
fAssign = zeros(size(reachMat));
Q = min(1,floor(reachMat));
goodInd = find(max(Q,[],2)); %exclude unassignable KVs from WTA
if isempty(goodInd)
    fLeak = sum(lethality);
    return
end
Q2 = Q(goodInd,:);
aKV = min(maxKV,sum(Q2,1));
[costMat,objPTR] = costPrep(lethality,aKV,pKill,Q);
[a,b]=munkres(costMat);
for i = 1:length(goodInd)
    if a(i)
        fAssign(goodInd(i),objPTR(a(i))) = 1;
    end
end
% Remove the KVs that have been WRONGLY assigned
[wrongI, wrongJ] = find(fAssign==1 & Q==0);
for i = 1:length(wrongI)
    fAssign( wrongI(i), wrongJ(i) ) = 0;
end
fLeak = computeLeakage(lethality,sum(fAssign,1),pKill);
return