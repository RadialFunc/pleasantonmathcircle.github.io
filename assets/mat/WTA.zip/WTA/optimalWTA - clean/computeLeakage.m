function [pLeakage, leakageVector] = computeLeakage(lethality, KVsAssigned, pKill)
% lethality is the vector of object lethalities
% KVsAssigned is a vector that indicates how many KVs have been assigned
%       to each object
% pKill is the probability of a KV eliminating the object's lethality once
%       it has been assigned to that object
%
% leakageVector is the leakage from each object computed as
%     leakageVector(i) =  lethality(i) * (1.0 - pKill(i)) ^ KVsAssigned(i)
%
% pLeakage is the leakage (or probability of leakage) computed as
%     pLeakage = sum(  leakageVector  )
%
% Author: G. Chiang
% Date: 3/29/2016
%

leakageVector = lethality(:) .* ( 1.0 - pKill(:) ) .^ KVsAssigned(:);

% make leakageVector a row vector.
pLeakage      = sum( leakageVector );
leakageVector = leakageVector(:)';

return
