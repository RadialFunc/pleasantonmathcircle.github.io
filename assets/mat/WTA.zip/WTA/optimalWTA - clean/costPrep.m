function [costMat,objPTR] = costPrep(lethality,aKV,pKill,Q)
% lethality is the vector of object lethalities
% aKV is the vector of total assignable KVs to each object
% pKill is the probability of a KV eliminating the object's lethality once
%       it has been assigned to that object
% Q is the binary reachability matrix
%
% costMat is the cost matrix for Munkres algorithm
% objPTR is a vector mapping costMat columns to object IDs
%
% Author: G. Chiang
% Date: 3/29/2016
%
S = [];
objPTR = [];
for i = 1:length(lethality)
    for j = 1:aKV(i)
        S = [S pKill(i)*lethality(i)*(1-pKill(i))^(j-1)*Q(:,i)];
        objPTR = [objPTR i];
    end
end
costMat = 1-S;
return