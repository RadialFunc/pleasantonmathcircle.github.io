%% Plot

load('data.mat');
load('times.mat');
load('desktop_cpp.mat');

threats = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
fullness = [0.1, 0.3, 0.5, 0.7, 0.9, 1];

for i = 1:length(threats)
    for j = 1:length(fullness)
        color(i, j, 1) = 0;
        color(i, j, 2) = 255;
        color(i, j, 3) = 0;
        if data(i, j) >= 1
            color(i, j, 1) = 0;
            color(i, j, 2) = 255;
            color(i, j, 3) = 0;
        end
    end
end

for i = 1:length(fullness)
    threats_X(:, i) = threats';
end
for i = 1:length(threats)    
    fullness_Y(i, :) = fullness;
end

COm(:, :, 1) = linspace(0.5, 1, length(threats))'*ones(size(fullness));
COm(:, :, 2) = sqrt(linspace(0, 0.2, length(threats)))'*sqrt(linspace(0, 0.2, length(fullness)));
COm(:, :, 3) = sqrt(linspace(0, 0.2, length(threats)))'*sqrt(linspace(0, 0.2, length(fullness)));

COc(:, :, 1) = linspace(0, 0.5, length(threats))'*ones(size(fullness));
COc(:, :, 2) = sqrt(linspace(0, 0.2, length(threats)))'*sqrt(linspace(0, 0.2, length(fullness)));
COc(:, :, 3) = ones(size(Cpp_time));

x = [10, 10; 100, 100];
y = [0.1, 1; 0.1, 1];
z = [0.250, 0.250; 0.250, 0.250];

figure
hold on
grid on
% surf(threats_X, fullness_Y, data, color, 'FaceAlpha', 0.5, 'EdgeColor', 'none')
surf(threats_X, fullness_Y, times, COm, 'FaceAlpha', 0.5, 'EdgeColor', 'none')
surf(threats_X, fullness_Y, desktop_cpp, 'FaceAlpha', 0.5, 'EdgeColor', 'none')
% surf(x, y, z, 'FaceAlpha', 0, 'LineStyle', '-.', 'EdgeColor', 'r', 'LineWidth', 2)
xlabel("Number of Threats")
ylabel("Reachability Matrix Fullness Percentage")
zlabel("Runtime [ sec ]")
% legend('SmartSat ZCU201 C++', 'Desktop MATLAB', 'Desktop C++', '250 ms limit')
legend('Desktop MATLAB', 'Desktop C++')
s = gca;
set(s, 'zscale', 'log')
xlim([10, 100])
ylim([0.1, 1])
title("WTA Runtime Comparison between SmartSat ZCU201 C++ vs Desktop C++ vs Desktop MATLAB")
title("WTA Runtime Comparison between Desktop C++ vs Desktop MATLAB")


figure
hold on
grid on
plot(threats, data(:, 3), 'g')
set(gca, 'yscale', 'log')
plot(threats, matlab_time(:, 3), 'r')
plot(threats, Cpp_time(:, 3), 'b')
plot([10, 100], [0.250, 0.250], 'r-.', 'LineWidth', 2)
xlabel("Number of Threats")
ylabel("Runtime [ sec ]")
legend('SmartSat ZCU201 C++', 'Desktop MATLAB', 'Desktop C++', '250 ms limit')
title("WTA Runtime Comparison, Slice at 50% Reachability Fullness")