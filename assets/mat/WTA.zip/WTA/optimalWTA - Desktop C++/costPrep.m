function [costMat,objPTR] = costPrep(lethality,aKV,pKill,Q)
% lethality is the vector of object lethalities
% aKV is the vector of total assignable KVs to each object
% pKill is the probability of a KV eliminating the object's lethality once
%       it has been assigned to that object
% Q is the binary reachability matrix
%
% costMat is the cost matrix for Munkres algorithm
% objPTR is a vector mapping costMat columns to object IDs
%
% Author: G. Chiang
% Date: 3/29/2016
%
[nrQ,~] = size(Q);  % Matlab coder
smak = sum(aKV);
objPTR = zeros(1, smak);
S = zeros(nrQ, smak);

kp = 0;
for i = 1:length(lethality)
    for j = 1:aKV(i)
        kp = kp + 1;                                                % Matlab coder
        S(:, kp) = pKill(i)*lethality(i)*(1-pKill(i))^(j-1)*Q(:,i); % Matlab coder
        objPTR(kp) = i;                                             % Matlab coder
    end
end
costMat = 1-S;
return