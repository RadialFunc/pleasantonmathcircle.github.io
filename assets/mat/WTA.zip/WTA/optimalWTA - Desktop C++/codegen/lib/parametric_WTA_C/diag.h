//
// File: diag.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 09-Dec-2020 15:02:49
//
#ifndef DIAG_H
#define DIAG_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "parametric_WTA_C_types.h"

// Function Declarations
extern void diag(const boolean_T v_data[], const int v_size[2], boolean_T
                 d_data[], int d_size[1]);

#endif

//
// File trailer for diag.h
//
// [EOF]
//
