//
// File: trace.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 09-Dec-2020 15:02:49
//

// Include Files
#include "rt_nonfinite.h"
#include "parametric_WTA_C.h"
#include "trace.h"

// Function Definitions

//
// Arguments    : const double a_data[]
//                const int a_size[2]
// Return Type  : double
//
double trace(const double a_data[], const int a_size[2])
{
  double t;
  int i12;
  int k;
  t = 0.0;
  i12 = a_size[0];
  for (k = 0; k < i12; k++) {
    t += a_data[k + a_size[0] * k];
  }

  return t;
}

//
// File trailer for trace.cpp
//
// [EOF]
//
