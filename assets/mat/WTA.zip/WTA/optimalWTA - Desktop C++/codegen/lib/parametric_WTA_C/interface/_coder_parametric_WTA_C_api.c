/*
 * File: _coder_parametric_WTA_C_api.c
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 09-Dec-2020 15:02:49
 */

/* Include Files */
#include "tmwtypes.h"
#include "_coder_parametric_WTA_C_api.h"
#include "_coder_parametric_WTA_C_mex.h"

/* Variable Definitions */
emlrtCTX emlrtRootTLSGlobal = NULL;
emlrtContext emlrtContextGlobal = { true,/* bFirstTime */
  false,                               /* bInitialized */
  131467U,                             /* fVersionInfo */
  NULL,                                /* fErrorFunction */
  "parametric_WTA_C",                  /* fFunctionName */
  NULL,                                /* fRTCallStack */
  false,                               /* bDebugMode */
  { 2045744189U, 2170104910U, 2743257031U, 4284093946U },/* fSigWrd */
  NULL                                 /* fSigMem */
};

/* Function Definitions */

/*
 * Arguments    : int32_T nlhs
 * Return Type  : void
 */
void parametric_WTA_C_api(int32_T nlhs)
{
  (void)nlhs;

  /* Invoke the target function */
  parametric_WTA_C();
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void parametric_WTA_C_atexit(void)
{
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  mexFunctionCreateRootTLS();
  st.tls = emlrtRootTLSGlobal;
  emlrtEnterRtStackR2012b(&st);
  emlrtLeaveRtStackR2012b(&st);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
  parametric_WTA_C_xil_terminate();
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void parametric_WTA_C_initialize(void)
{
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  mexFunctionCreateRootTLS();
  st.tls = emlrtRootTLSGlobal;
  emlrtClearAllocCountR2012b(&st, false, 0U, 0);
  emlrtEnterRtStackR2012b(&st);
  emlrtFirstTimeR2012b(emlrtRootTLSGlobal);
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void parametric_WTA_C_terminate(void)
{
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  st.tls = emlrtRootTLSGlobal;
  emlrtLeaveRtStackR2012b(&st);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}

/*
 * File trailer for _coder_parametric_WTA_C_api.c
 *
 * [EOF]
 */
