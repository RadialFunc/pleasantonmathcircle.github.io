//
// File: munkres.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 09-Dec-2020 15:02:49
//
#ifndef MUNKRES_H
#define MUNKRES_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "parametric_WTA_C_types.h"

// Function Declarations
extern void munkres(emxArray_real_T *costMat, double assignment[10], double
                    *cost);

#endif

//
// File trailer for munkres.h
//
// [EOF]
//
