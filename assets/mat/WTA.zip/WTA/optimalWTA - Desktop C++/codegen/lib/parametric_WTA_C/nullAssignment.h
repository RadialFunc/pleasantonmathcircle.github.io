//
// File: nullAssignment.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 09-Dec-2020 15:02:49
//
#ifndef NULLASSIGNMENT_H
#define NULLASSIGNMENT_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "parametric_WTA_C_types.h"

// Function Declarations
extern void b_nullAssignment(emxArray_real_T *x, const emxArray_boolean_T *idx);
extern void nullAssignment(emxArray_real_T *x, const emxArray_boolean_T *idx);

#endif

//
// File trailer for nullAssignment.h
//
// [EOF]
//
