//
// File: trace.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 09-Dec-2020 15:02:49
//
#ifndef TRACE_H
#define TRACE_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "parametric_WTA_C_types.h"

// Function Declarations
extern double trace(const double a_data[], const int a_size[2]);

#endif

//
// File trailer for trace.h
//
// [EOF]
//
