//
// File: parametric_WTA_C.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 09-Dec-2020 15:02:49
//
#ifndef PARAMETRIC_WTA_C_H
#define PARAMETRIC_WTA_C_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "parametric_WTA_C_types.h"

// Function Declarations
extern void parametric_WTA_C();

#endif

//
// File trailer for parametric_WTA_C.h
//
// [EOF]
//
