/*
 * File: _coder_parametric_WTA_C_mex.h
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 09-Dec-2020 15:02:49
 */

#ifndef _CODER_PARAMETRIC_WTA_C_MEX_H
#define _CODER_PARAMETRIC_WTA_C_MEX_H

/* Include Files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "_coder_parametric_WTA_C_api.h"

/* Function Declarations */
extern void mexFunction(int32_T nlhs, mxArray *plhs[], int32_T nrhs, const
  mxArray *prhs[]);
extern emlrtCTX mexFunctionCreateRootTLS(void);

#endif

/*
 * File trailer for _coder_parametric_WTA_C_mex.h
 *
 * [EOF]
 */
