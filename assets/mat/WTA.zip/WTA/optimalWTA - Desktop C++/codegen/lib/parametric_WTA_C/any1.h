//
// File: any1.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 09-Dec-2020 15:02:49
//
#ifndef ANY1_H
#define ANY1_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "parametric_WTA_C_types.h"

// Function Declarations
extern void any(const emxArray_boolean_T *x, emxArray_boolean_T *y);
extern void b_any(const emxArray_boolean_T *x, boolean_T y[10]);
extern boolean_T c_any(const emxArray_boolean_T *x);

#endif

//
// File trailer for any1.h
//
// [EOF]
//
