//
// File: power.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 09-Dec-2020 15:02:49
//
#ifndef POWER_H
#define POWER_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "parametric_WTA_C_types.h"

// Function Declarations
extern void power(const int a_size[1], const double b_data[], const int b_size[1],
                  double y_data[], int y_size[1]);

#endif

//
// File trailer for power.h
//
// [EOF]
//
