/* 
 * File: _coder_parametric_WTA_C_info.h 
 *  
 * MATLAB Coder version            : 4.1 
 * C/C++ source code generated on  : 09-Dec-2020 15:02:49 
 */

#ifndef _CODER_PARAMETRIC_WTA_C_INFO_H
#define _CODER_PARAMETRIC_WTA_C_INFO_H
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo();
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties();

#endif
/* 
 * File trailer for _coder_parametric_WTA_C_info.h 
 *  
 * [EOF] 
 */
