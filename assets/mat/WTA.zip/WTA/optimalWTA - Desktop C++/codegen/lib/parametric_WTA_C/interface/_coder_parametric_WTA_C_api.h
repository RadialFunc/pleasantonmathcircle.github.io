/*
 * File: _coder_parametric_WTA_C_api.h
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 09-Dec-2020 15:02:49
 */

#ifndef _CODER_PARAMETRIC_WTA_C_API_H
#define _CODER_PARAMETRIC_WTA_C_API_H

/* Include Files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include <stddef.h>
#include <stdlib.h>
#include "_coder_parametric_WTA_C_api.h"

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

/* Function Declarations */
extern void parametric_WTA_C(void);
extern void parametric_WTA_C_api(int32_T nlhs);
extern void parametric_WTA_C_atexit(void);
extern void parametric_WTA_C_initialize(void);
extern void parametric_WTA_C_terminate(void);
extern void parametric_WTA_C_xil_terminate(void);

#endif

/*
 * File trailer for _coder_parametric_WTA_C_api.h
 *
 * [EOF]
 */
