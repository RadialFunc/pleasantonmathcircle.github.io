//
// File: parametric_WTA_C_initialize.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 09-Dec-2020 15:02:49
//

// Include Files
#include "rt_nonfinite.h"
#include "parametric_WTA_C.h"
#include "parametric_WTA_C_initialize.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void parametric_WTA_C_initialize()
{
  rt_InitInfAndNaN(8U);
}

//
// File trailer for parametric_WTA_C_initialize.cpp
//
// [EOF]
//
