//
// File: parametric_WTA_C_terminate.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 09-Dec-2020 15:02:49
//

// Include Files
#include "rt_nonfinite.h"
#include "parametric_WTA_C.h"
#include "parametric_WTA_C_terminate.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void parametric_WTA_C_terminate()
{
  // (no terminate code required)
}

//
// File trailer for parametric_WTA_C_terminate.cpp
//
// [EOF]
//
