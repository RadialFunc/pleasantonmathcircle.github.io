//
// File: munkres.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 09-Dec-2020 15:02:49
//

// Include Files
#include "rt_nonfinite.h"
#include <cmath>
#include <string.h>
#include "parametric_WTA_C.h"
#include "munkres.h"
#include "parametric_WTA_C_emxutil.h"
#include "trace.h"
#include "diag.h"
#include "sum.h"
#include "nullAssignment.h"
#include "bsxfun.h"
#include "all.h"
#include "any1.h"
#include "mpower.h"
#include "log10.h"

// Function Declarations
static void outerplus(emxArray_real_T *M, const emxArray_real_T *x, const
                      emxArray_real_T *y, double *minval, emxArray_real_T *rIdx,
                      emxArray_real_T *cIdx);

// Function Definitions

//
// Arguments    : emxArray_real_T *M
//                const emxArray_real_T *x
//                const emxArray_real_T *y
//                double *minval
//                emxArray_real_T *rIdx
//                emxArray_real_T *cIdx
// Return Type  : void
//
static void outerplus(emxArray_real_T *M, const emxArray_real_T *x, const
                      emxArray_real_T *y, double *minval, emxArray_real_T *rIdx,
                      emxArray_real_T *cIdx)
{
  int i10;
  emxArray_real_T *b_M;
  int nx;
  int ii;
  emxArray_boolean_T *b_x;
  double b_y;
  int i11;
  emxArray_int32_T *i;
  emxArray_int32_T *j;
  int idx;
  int jj;
  int exitg1;
  boolean_T exitg2;
  boolean_T guard1 = false;
  *minval = rtInf;
  i10 = M->size[1];
  emxInit_real_T(&b_M, 1);
  for (nx = 0; nx < i10; nx++) {
    ii = M->size[0];
    b_y = y->data[nx];
    i11 = b_M->size[0];
    b_M->size[0] = ii;
    emxEnsureCapacity_real_T(b_M, i11);
    for (i11 = 0; i11 < ii; i11++) {
      b_M->data[i11] = M->data[i11 + M->size[0] * nx] - (x->data[i11] + b_y);
    }

    ii = b_M->size[0];
    for (i11 = 0; i11 < ii; i11++) {
      M->data[i11 + M->size[0] * nx] = b_M->data[i11];
    }

    i11 = M->size[0];
    ii = M->size[0];
    if (ii <= 2) {
      i11 = M->size[0];
      if (i11 == 1) {
        b_y = M->data[M->size[0] * nx];
      } else if ((M->data[M->size[0] * nx] > M->data[1 + M->size[0] * nx]) ||
                 (rtIsNaN(M->data[M->size[0] * nx]) && (!rtIsNaN(M->data[1 +
                    M->size[0] * nx])))) {
        b_y = M->data[1 + M->size[0] * nx];
      } else {
        b_y = M->data[M->size[0] * nx];
      }
    } else {
      if (!rtIsNaN(M->data[M->size[0] * nx])) {
        idx = 1;
      } else {
        idx = 0;
        jj = 2;
        do {
          exitg1 = 0;
          ii = M->size[0];
          if (jj <= ii) {
            if (!rtIsNaN(M->data[(jj + M->size[0] * nx) - 1])) {
              idx = jj;
              exitg1 = 1;
            } else {
              jj++;
            }
          } else {
            exitg1 = 1;
          }
        } while (exitg1 == 0);
      }

      if (idx == 0) {
        b_y = M->data[M->size[0] * nx];
      } else {
        b_y = M->data[(idx + M->size[0] * nx) - 1];
        ii = idx + 1;
        for (jj = ii; jj <= i11; jj++) {
          if (b_y > M->data[(jj + M->size[0] * nx) - 1]) {
            b_y = M->data[(jj + M->size[0] * nx) - 1];
          }
        }
      }
    }

    if ((!(*minval < b_y)) && (!rtIsNaN(b_y))) {
      *minval = b_y;
    }
  }

  emxFree_real_T(&b_M);
  emxInit_boolean_T(&b_x, 2);
  i10 = b_x->size[0] * b_x->size[1];
  b_x->size[0] = M->size[0];
  b_x->size[1] = M->size[1];
  emxEnsureCapacity_boolean_T(b_x, i10);
  ii = M->size[0] * M->size[1];
  for (i10 = 0; i10 < ii; i10++) {
    b_x->data[i10] = (M->data[i10] == *minval);
  }

  nx = b_x->size[0] * b_x->size[1];
  emxInit_int32_T(&i, 1);
  emxInit_int32_T(&j, 1);
  if (nx == 0) {
    i->size[0] = 0;
    j->size[0] = 0;
  } else {
    idx = 0;
    i10 = i->size[0];
    i->size[0] = nx;
    emxEnsureCapacity_int32_T(i, i10);
    i10 = j->size[0];
    j->size[0] = nx;
    emxEnsureCapacity_int32_T(j, i10);
    ii = 1;
    jj = 1;
    exitg2 = false;
    while ((!exitg2) && (jj <= b_x->size[1])) {
      guard1 = false;
      if (b_x->data[(ii + b_x->size[0] * (jj - 1)) - 1]) {
        idx++;
        i->data[idx - 1] = ii;
        j->data[idx - 1] = jj;
        if (idx >= nx) {
          exitg2 = true;
        } else {
          guard1 = true;
        }
      } else {
        guard1 = true;
      }

      if (guard1) {
        ii++;
        if (ii > b_x->size[0]) {
          ii = 1;
          jj++;
        }
      }
    }

    if (nx == 1) {
      if (idx == 0) {
        i->size[0] = 0;
        j->size[0] = 0;
      }
    } else if (1 > idx) {
      i->size[0] = 0;
      j->size[0] = 0;
    } else {
      i10 = i->size[0];
      i->size[0] = idx;
      emxEnsureCapacity_int32_T(i, i10);
      i10 = j->size[0];
      j->size[0] = idx;
      emxEnsureCapacity_int32_T(j, i10);
    }
  }

  emxFree_boolean_T(&b_x);
  i10 = rIdx->size[0];
  rIdx->size[0] = i->size[0];
  emxEnsureCapacity_real_T(rIdx, i10);
  ii = i->size[0];
  for (i10 = 0; i10 < ii; i10++) {
    rIdx->data[i10] = i->data[i10];
  }

  emxFree_int32_T(&i);
  i10 = cIdx->size[0];
  cIdx->size[0] = j->size[0];
  emxEnsureCapacity_real_T(cIdx, i10);
  ii = j->size[0];
  for (i10 = 0; i10 < ii; i10++) {
    cIdx->data[i10] = j->data[i10];
  }

  emxFree_int32_T(&j);
}

//
// MUNKRES   Munkres (Hungarian) Algorithm for Linear Assignment Problem.
//
//  [ASSIGN,COST] = munkres(COSTMAT) returns the optimal column indices,
//  ASSIGN assigned to each row and the minimum COST based on the assignment
//  problem represented by the COSTMAT, where the (i,j)th element represents the cost to assign the jth
//  job to the ith worker.
//
//  Partial assignment: This code can identify a partial assignment is a full
//  assignment is not feasible. For a partial assignment, there are some
//  zero elements in the returning assignment vector, which indicate
//  un-assigned tasks. The cost returned only contains the cost of partially
//  assigned tasks.
// Arguments    : emxArray_real_T *costMat
//                double assignment[10]
//                double *cost
// Return Type  : void
//
void munkres(emxArray_real_T *costMat, double assignment[10], double *cost)
{
  emxArray_boolean_T *r1;
  int i2;
  int idx;
  emxArray_boolean_T *r2;
  int m;
  int trueCount;
  emxArray_int32_T *ii;
  int jj;
  emxArray_real_T *minR;
  double bigM;
  emxArray_int32_T *j;
  emxArray_boolean_T *r3;
  emxArray_boolean_T *validCol;
  boolean_T validRow[10];
  double nRows;
  double nCols;
  double n;
  emxArray_int32_T *r4;
  int b_n;
  emxArray_real_T *dMat;
  signed char ii_data[10];
  emxArray_int32_T *b_ii;
  int i3;
  unsigned int dMat_idx_0;
  emxArray_real_T *minC;
  emxArray_real_T *varargin_1;
  boolean_T p;
  emxArray_boolean_T *zP;
  double uZr;
  emxArray_real_T *starZ;
  int exitg1;
  emxArray_boolean_T b_zP;
  int c_zP[1];
  emxArray_boolean_T *coverColumn;
  emxArray_boolean_T *coverRow;
  emxArray_real_T *primeZ;
  emxArray_real_T *rIdx;
  emxArray_real_T *cIdx;
  emxArray_uint32_T *cR;
  emxArray_uint32_T *cC;
  boolean_T exitg2;
  emxArray_boolean_T *z;
  emxArray_real_T *b_cIdx;
  emxArray_int32_T *r5;
  emxArray_int32_T *r6;
  emxArray_int32_T *r7;
  emxArray_int32_T *r8;
  emxArray_int32_T *r9;
  emxArray_int32_T *r10;
  emxArray_int32_T *r11;
  int tmp_size[1];
  emxArray_int32_T *r12;
  emxArray_int32_T *r13;
  emxArray_int32_T *r14;
  emxArray_boolean_T *x;
  int c_data[1];
  emxArray_boolean_T *b_starZ;
  emxArray_real_T *b_minR;
  emxArray_real_T *b_minC;
  emxArray_real_T *c_minC;
  unsigned int pass_data[10];
  signed char tmp_data[10];
  int b_tmp_size[2];
  boolean_T b_tmp_data[100];
  boolean_T guard1 = false;
  signed char c_tmp_data[10];
  int exitg3;
  signed char d_tmp_data[10];
  int costMat_size[2];
  double costMat_data[100];
  double uZc;
  int Step;
  boolean_T exitg4;

  //  This is vectorized implementation of the algorithm. It is the fastest
  //  among all Matlab implementations of the algorithm.
  //  Examples
  //  Example 1: a 5 x 5 example
  // {
  // [assignment,cost] = munkres(magic(5));
  // disp(assignment); % 3 2 1 5 4
  // disp(cost); %15
  // }
  //  Example 2: 400 x 400 random data
  // {
  // n=400;
  // A=rand(n);
  // tic
  // [a,b]=munkres(A);
  // toc                 % about 2 seconds
  // }
  //  Example 3: rectangular assignment with inf costs
  // {
  // A=rand(10,7);
  // A(A>0.7)=Inf;
  // [a,b]=munkres(A);
  // }
  //  Example 4: an example of partial assignment
  // {
  // A = [1 3 Inf; Inf Inf 5; Inf Inf 0.5];
  // [a,b]=munkres(A)
  // }
  //  a = [1 0 3]
  //  b = 1.5
  //  Reference:
  //  "Munkres' Assignment Algorithm, Modified for Rectangular Matrices",
  //  http://csclab.murraystate.edu/bob.pilgrim/445/munkres.html
  //  version 2.3 by Yi Cao at Cranfield University on 11th September 2011
  memset(&assignment[0], 0, 10U * sizeof(double));
  emxInit_boolean_T(&r1, 2);
  *cost = 0.0;
  i2 = r1->size[0] * r1->size[1];
  r1->size[0] = 10;
  r1->size[1] = costMat->size[1];
  emxEnsureCapacity_boolean_T(r1, i2);
  idx = costMat->size[0] * costMat->size[1];
  for (i2 = 0; i2 < idx; i2++) {
    r1->data[i2] = (costMat->data[i2] == costMat->data[i2]);
  }

  emxInit_boolean_T(&r2, 2);
  i2 = r2->size[0] * r2->size[1];
  r2->size[0] = 10;
  r2->size[1] = costMat->size[1];
  emxEnsureCapacity_boolean_T(r2, i2);
  idx = costMat->size[0] * costMat->size[1];
  for (i2 = 0; i2 < idx; i2++) {
    r2->data[i2] = (costMat->data[i2] < rtInf);
  }

  m = 10 * r1->size[1] - 1;
  trueCount = 0;
  for (idx = 0; idx <= m; idx++) {
    if (r1->data[idx] && r2->data[idx]) {
      trueCount++;
    }
  }

  emxInit_int32_T(&ii, 1);
  i2 = ii->size[0];
  ii->size[0] = trueCount;
  emxEnsureCapacity_int32_T(ii, i2);
  jj = 0;
  for (idx = 0; idx <= m; idx++) {
    if (r1->data[idx] && r2->data[idx]) {
      ii->data[jj] = idx + 1;
      jj++;
    }
  }

  emxInit_real_T(&minR, 1);
  i2 = minR->size[0];
  minR->size[0] = ii->size[0];
  emxEnsureCapacity_real_T(minR, i2);
  idx = ii->size[0];
  for (i2 = 0; i2 < idx; i2++) {
    minR->data[i2] = costMat->data[ii->data[i2] - 1];
  }

  bigM = sum(minR);
  b_log10(&bigM);
  bigM = mpower(10.0, std::ceil(bigM) + 1.0);
  m = 10 * r1->size[1] - 1;
  trueCount = 0;
  for (idx = 0; idx <= m; idx++) {
    if ((!r1->data[idx]) || (!r2->data[idx])) {
      trueCount++;
    }
  }

  emxInit_int32_T(&j, 1);
  i2 = j->size[0];
  j->size[0] = trueCount;
  emxEnsureCapacity_int32_T(j, i2);
  jj = 0;
  for (idx = 0; idx <= m; idx++) {
    if ((!r1->data[idx]) || (!r2->data[idx])) {
      j->data[jj] = idx + 1;
      jj++;
    }
  }

  idx = j->size[0] - 1;
  for (i2 = 0; i2 <= idx; i2++) {
    costMat->data[j->data[i2] - 1] = bigM;
  }

  emxInit_boolean_T(&r3, 2);

  //  costMat(costMat~=costMat)=Inf;
  //  validMat = costMat<Inf;
  i2 = r3->size[0] * r3->size[1];
  r3->size[0] = 10;
  r3->size[1] = r1->size[1];
  emxEnsureCapacity_boolean_T(r3, i2);
  idx = r1->size[0] * r1->size[1];
  for (i2 = 0; i2 < idx; i2++) {
    r3->data[i2] = (r1->data[i2] && r2->data[i2]);
  }

  emxInit_boolean_T(&validCol, 2);
  any(r3, validCol);
  i2 = r3->size[0] * r3->size[1];
  r3->size[0] = 10;
  r3->size[1] = r1->size[1];
  emxEnsureCapacity_boolean_T(r3, i2);
  idx = r1->size[0] * r1->size[1];
  for (i2 = 0; i2 < idx; i2++) {
    r3->data[i2] = (r1->data[i2] && r2->data[i2]);
  }

  b_any(r3, validRow);
  nRows = b_sum(validRow);
  nCols = c_sum(validCol);
  if ((nRows > nCols) || rtIsNaN(nCols)) {
    n = nRows;
  } else {
    n = nCols;
  }

  if (n != 0.0) {
    m = 10 * r1->size[1] - 1;
    trueCount = 0;
    for (idx = 0; idx <= m; idx++) {
      if (r1->data[idx] && r2->data[idx]) {
        trueCount++;
      }
    }

    emxInit_int32_T(&r4, 1);
    i2 = r4->size[0];
    r4->size[0] = trueCount;
    emxEnsureCapacity_int32_T(r4, i2);
    jj = 0;
    for (idx = 0; idx <= m; idx++) {
      if (r1->data[idx] && r2->data[idx]) {
        r4->data[jj] = idx + 1;
        jj++;
      }
    }

    b_n = r4->size[0];
    if (r4->size[0] <= 2) {
      if (r4->size[0] == 1) {
        bigM = costMat->data[r4->data[0] - 1];
      } else if (costMat->data[r4->data[0] - 1] < costMat->data[r4->data[1] - 1])
      {
        bigM = costMat->data[r4->data[1] - 1];
      } else {
        bigM = costMat->data[r4->data[0] - 1];
      }
    } else {
      bigM = costMat->data[r4->data[0] - 1];
      for (jj = 2; jj <= b_n; jj++) {
        if (bigM < costMat->data[r4->data[jj - 1] - 1]) {
          bigM = costMat->data[r4->data[jj - 1] - 1];
        }
      }
    }

    emxFree_int32_T(&r4);
    emxInit_real_T(&dMat, 2);
    bigM *= 10.0;
    i2 = dMat->size[0] * dMat->size[1];
    dMat->size[0] = (int)n;
    dMat->size[1] = (int)n;
    emxEnsureCapacity_real_T(dMat, i2);
    idx = (int)n * (int)n;
    for (i2 = 0; i2 < idx; i2++) {
      dMat->data[i2] = bigM;
    }

    trueCount = 0;
    for (idx = 0; idx < 10; idx++) {
      if (validRow[idx]) {
        trueCount++;
      }
    }

    jj = 0;
    for (idx = 0; idx < 10; idx++) {
      if (validRow[idx]) {
        ii_data[jj] = (signed char)(idx + 1);
        jj++;
      }
    }

    m = validCol->size[1] - 1;
    jj = 0;
    for (idx = 0; idx <= m; idx++) {
      if (validCol->data[idx]) {
        jj++;
      }
    }

    emxInit_int32_T(&b_ii, 2);
    i2 = b_ii->size[0] * b_ii->size[1];
    b_ii->size[0] = 1;
    b_ii->size[1] = jj;
    emxEnsureCapacity_int32_T(b_ii, i2);
    jj = 0;
    for (idx = 0; idx <= m; idx++) {
      if (validCol->data[idx]) {
        b_ii->data[jj] = idx + 1;
        jj++;
      }
    }

    idx = b_ii->size[1];
    for (i2 = 0; i2 < idx; i2++) {
      for (i3 = 0; i3 < trueCount; i3++) {
        dMat->data[i3 + dMat->size[0] * i2] = costMat->data[(ii_data[i3] + 10 *
          (b_ii->data[i2] - 1)) - 1];
      }
    }

    // *************************************************
    //  Munkres' Assignment Algorithm starts here
    // *************************************************
    // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    //    STEP 1: Subtract the row minimum from each row.
    // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    m = dMat->size[0] - 1;
    b_n = dMat->size[1];
    dMat_idx_0 = (unsigned int)dMat->size[0];
    i2 = minR->size[0];
    minR->size[0] = (int)dMat_idx_0;
    emxEnsureCapacity_real_T(minR, i2);
    for (idx = 0; idx <= m; idx++) {
      minR->data[idx] = dMat->data[idx];
    }

    for (jj = 2; jj <= b_n; jj++) {
      for (idx = 0; idx <= m; idx++) {
        bigM = dMat->data[idx + dMat->size[0] * (jj - 1)];
        p = ((!rtIsNaN(bigM)) && (rtIsNaN(minR->data[idx]) || (minR->data[idx] >
               bigM)));
        if (p) {
          minR->data[idx] = dMat->data[idx + dMat->size[0] * (jj - 1)];
        }
      }
    }

    emxInit_real_T(&minC, 2);
    emxInit_real_T(&varargin_1, 2);
    bsxfun(dMat, minR, varargin_1);
    m = varargin_1->size[0];
    b_n = varargin_1->size[1];
    dMat_idx_0 = (unsigned int)varargin_1->size[1];
    i2 = minC->size[0] * minC->size[1];
    minC->size[0] = 1;
    minC->size[1] = (int)dMat_idx_0;
    emxEnsureCapacity_real_T(minC, i2);
    for (jj = 0; jj < b_n; jj++) {
      minC->data[jj] = varargin_1->data[varargin_1->size[0] * jj];
      for (idx = 2; idx <= m; idx++) {
        uZr = minC->data[jj];
        bigM = varargin_1->data[(idx + varargin_1->size[0] * jj) - 1];
        if ((!rtIsNaN(bigM)) && (rtIsNaN(uZr) || (uZr > bigM))) {
          minC->data[jj] = varargin_1->data[(idx + varargin_1->size[0] * jj) - 1];
        }
      }
    }

    emxInit_boolean_T(&zP, 2);

    // **************************************************************************   
    //    STEP 2: Find a zero of dMat. If there are no starred zeros in its
    //            column or row start the zero. Repeat for each zero
    // ************************************************************************** 
    b_bsxfun(minC, minR, varargin_1);
    i2 = zP->size[0] * zP->size[1];
    zP->size[0] = dMat->size[0];
    zP->size[1] = dMat->size[1];
    emxEnsureCapacity_boolean_T(zP, i2);
    idx = dMat->size[0] * dMat->size[1];
    for (i2 = 0; i2 < idx; i2++) {
      zP->data[i2] = (dMat->data[i2] == varargin_1->data[i2]);
    }

    emxInit_real_T(&starZ, 1);
    i2 = starZ->size[0];
    starZ->size[0] = (int)n;
    emxEnsureCapacity_real_T(starZ, i2);
    idx = (int)n;
    for (i2 = 0; i2 < idx; i2++) {
      starZ->data[i2] = 0.0;
    }

    do {
      exitg1 = 0;
      jj = zP->size[0] * zP->size[1];
      b_zP = *zP;
      c_zP[0] = jj;
      b_zP.size = &c_zP[0];
      b_zP.numDimensions = 1;
      if (c_any(&b_zP)) {
        idx = 0;
        i2 = ii->size[0];
        ii->size[0] = 1;
        emxEnsureCapacity_int32_T(ii, i2);
        i2 = j->size[0];
        j->size[0] = 1;
        emxEnsureCapacity_int32_T(j, i2);
        m = 1;
        jj = 1;
        exitg2 = false;
        while ((!exitg2) && (jj <= zP->size[1])) {
          if (zP->data[(m + zP->size[0] * (jj - 1)) - 1]) {
            idx = 1;
            ii->data[0] = m;
            j->data[0] = jj;
            exitg2 = true;
          } else {
            m++;
            if (m > zP->size[0]) {
              m = 1;
              jj++;
            }
          }
        }

        if (idx == 0) {
          ii->size[0] = 0;
          j->size[0] = 0;
        }

        jj = ii->size[0];
        idx = ii->size[0];
        for (i2 = 0; i2 < idx; i2++) {
          tmp_size[i2] = ii->data[i2];
        }

        m = j->size[0];
        idx = j->size[0];
        for (i2 = 0; i2 < idx; i2++) {
          c_data[i2] = j->data[i2];
        }

        for (i2 = 0; i2 < m; i2++) {
          starZ->data[tmp_size[i2] - 1] = c_data[i2];
        }

        idx = zP->size[1];
        for (i2 = 0; i2 < idx; i2++) {
          for (i3 = 0; i3 < jj; i3++) {
            zP->data[(tmp_size[i3] + zP->size[0] * i2) - 1] = false;
          }
        }

        if (0 <= m - 1) {
          memcpy(&tmp_size[0], &c_data[0], (unsigned int)(m * (int)sizeof(int)));
        }

        idx = zP->size[0];
        for (i2 = 0; i2 < m; i2++) {
          for (i3 = 0; i3 < idx; i3++) {
            zP->data[i3 + zP->size[0] * (tmp_size[i2] - 1)] = false;
          }
        }
      } else {
        exitg1 = 1;
      }
    } while (exitg1 == 0);

    emxInit_boolean_T(&coverColumn, 2);
    emxInit_boolean_T(&coverRow, 1);
    emxInit_real_T(&primeZ, 1);
    emxInit_real_T(&rIdx, 1);
    emxInit_real_T(&cIdx, 1);
    emxInit_uint32_T(&cR, 1);
    emxInit_uint32_T(&cC, 2);
    emxInit_boolean_T(&z, 1);
    emxInit_real_T(&b_cIdx, 2);
    emxInit_int32_T(&r5, 1);
    emxInit_int32_T(&r6, 2);
    emxInit_int32_T(&r7, 1);
    emxInit_int32_T(&r8, 2);
    emxInit_int32_T(&r9, 1);
    emxInit_int32_T(&r10, 2);
    emxInit_int32_T(&r11, 1);
    emxInit_int32_T(&r12, 1);
    emxInit_int32_T(&r13, 2);
    emxInit_int32_T(&r14, 1);
    emxInit_boolean_T(&x, 2);
    emxInit_boolean_T(&b_starZ, 1);
    emxInit_real_T(&b_minR, 1);
    emxInit_real_T(&b_minC, 2);
    emxInit_real_T(&c_minC, 1);
    do {
      exitg1 = 0;

      // ************************************************************************** 
      //    STEP 3: Cover each column with a starred zero. If all the columns are 
      //            covered then the matching is maximum
      // ************************************************************************** 
      i2 = b_starZ->size[0];
      b_starZ->size[0] = starZ->size[0];
      emxEnsureCapacity_boolean_T(b_starZ, i2);
      idx = starZ->size[0];
      for (i2 = 0; i2 < idx; i2++) {
        b_starZ->data[i2] = (starZ->data[i2] > 0.0);
      }

      if (all(b_starZ)) {
        exitg1 = 1;
      } else {
        i2 = coverColumn->size[0] * coverColumn->size[1];
        coverColumn->size[0] = 1;
        coverColumn->size[1] = (int)n;
        emxEnsureCapacity_boolean_T(coverColumn, i2);
        idx = (int)n;
        for (i2 = 0; i2 < idx; i2++) {
          coverColumn->data[i2] = false;
        }

        m = starZ->size[0];
        for (idx = 0; idx < m; idx++) {
          if (starZ->data[idx] > 0.0) {
            coverColumn->data[(int)starZ->data[idx] - 1] = true;
          }
        }

        i2 = coverRow->size[0];
        coverRow->size[0] = (int)n;
        emxEnsureCapacity_boolean_T(coverRow, i2);
        idx = (int)n;
        for (i2 = 0; i2 < idx; i2++) {
          coverRow->data[i2] = false;
        }

        i2 = primeZ->size[0];
        primeZ->size[0] = (int)n;
        emxEnsureCapacity_real_T(primeZ, i2);
        idx = (int)n;
        for (i2 = 0; i2 < idx; i2++) {
          primeZ->data[i2] = 0.0;
        }

        b_n = coverColumn->size[1];
        m = (int)n - 1;
        trueCount = 0;
        for (idx = 0; idx <= m; idx++) {
          trueCount++;
        }

        i2 = r5->size[0];
        r5->size[0] = trueCount;
        emxEnsureCapacity_int32_T(r5, i2);
        jj = 0;
        for (idx = 0; idx <= m; idx++) {
          r5->data[jj] = idx + 1;
          jj++;
        }

        m = b_n - 1;
        trueCount = 0;
        for (idx = 0; idx <= m; idx++) {
          if (!coverColumn->data[idx]) {
            trueCount++;
          }
        }

        i2 = r6->size[0] * r6->size[1];
        r6->size[0] = 1;
        r6->size[1] = trueCount;
        emxEnsureCapacity_int32_T(r6, i2);
        jj = 0;
        for (idx = 0; idx <= m; idx++) {
          if (!coverColumn->data[idx]) {
            r6->data[jj] = idx + 1;
            jj++;
          }
        }

        m = (int)n - 1;
        trueCount = 0;
        for (idx = 0; idx <= m; idx++) {
          trueCount++;
        }

        i2 = r7->size[0];
        r7->size[0] = trueCount;
        emxEnsureCapacity_int32_T(r7, i2);
        jj = 0;
        for (idx = 0; idx <= m; idx++) {
          r7->data[jj] = idx + 1;
          jj++;
        }

        m = b_n - 1;
        trueCount = 0;
        for (idx = 0; idx <= m; idx++) {
          if (!coverColumn->data[idx]) {
            trueCount++;
          }
        }

        i2 = r8->size[0] * r8->size[1];
        r8->size[0] = 1;
        r8->size[1] = trueCount;
        emxEnsureCapacity_int32_T(r8, i2);
        jj = 0;
        for (idx = 0; idx <= m; idx++) {
          if (!coverColumn->data[idx]) {
            r8->data[jj] = idx + 1;
            jj++;
          }
        }

        i2 = b_minR->size[0];
        b_minR->size[0] = r5->size[0];
        emxEnsureCapacity_real_T(b_minR, i2);
        idx = r5->size[0];
        for (i2 = 0; i2 < idx; i2++) {
          b_minR->data[i2] = minR->data[r5->data[i2] - 1];
        }

        i2 = b_minC->size[0] * b_minC->size[1];
        b_minC->size[0] = 1;
        b_minC->size[1] = r6->size[1];
        emxEnsureCapacity_real_T(b_minC, i2);
        idx = r6->size[0] * r6->size[1];
        for (i2 = 0; i2 < idx; i2++) {
          b_minC->data[i2] = minC->data[r6->data[i2] - 1];
        }

        c_bsxfun(b_minR, b_minC, varargin_1);
        i2 = zP->size[0] * zP->size[1];
        zP->size[0] = r7->size[0];
        zP->size[1] = r8->size[1];
        emxEnsureCapacity_boolean_T(zP, i2);
        idx = r8->size[1];
        for (i2 = 0; i2 < idx; i2++) {
          jj = r7->size[0];
          for (i3 = 0; i3 < jj; i3++) {
            zP->data[i3 + zP->size[0] * i2] = (dMat->data[(r7->data[i3] +
              dMat->size[0] * (r8->data[i2] - 1)) - 1] == varargin_1->data[i3 +
              varargin_1->size[0] * i2]);
          }
        }

        b_n = zP->size[0] * zP->size[1];
        if (b_n == 0) {
          ii->size[0] = 0;
          j->size[0] = 0;
        } else {
          idx = 0;
          i2 = ii->size[0];
          ii->size[0] = b_n;
          emxEnsureCapacity_int32_T(ii, i2);
          i2 = j->size[0];
          j->size[0] = b_n;
          emxEnsureCapacity_int32_T(j, i2);
          m = 1;
          jj = 1;
          exitg2 = false;
          while ((!exitg2) && (jj <= zP->size[1])) {
            guard1 = false;
            if (zP->data[(m + zP->size[0] * (jj - 1)) - 1]) {
              idx++;
              ii->data[idx - 1] = m;
              j->data[idx - 1] = jj;
              if (idx >= b_n) {
                exitg2 = true;
              } else {
                guard1 = true;
              }
            } else {
              guard1 = true;
            }

            if (guard1) {
              m++;
              if (m > zP->size[0]) {
                m = 1;
                jj++;
              }
            }
          }

          if (b_n == 1) {
            if (idx == 0) {
              ii->size[0] = 0;
              j->size[0] = 0;
            }
          } else if (1 > idx) {
            ii->size[0] = 0;
            j->size[0] = 0;
          } else {
            i2 = ii->size[0];
            ii->size[0] = idx;
            emxEnsureCapacity_int32_T(ii, i2);
            i2 = j->size[0];
            j->size[0] = idx;
            emxEnsureCapacity_int32_T(j, i2);
          }
        }

        i2 = rIdx->size[0];
        rIdx->size[0] = ii->size[0];
        emxEnsureCapacity_real_T(rIdx, i2);
        idx = ii->size[0];
        for (i2 = 0; i2 < idx; i2++) {
          rIdx->data[i2] = ii->data[i2];
        }

        i2 = cIdx->size[0];
        cIdx->size[0] = j->size[0];
        emxEnsureCapacity_real_T(cIdx, i2);
        idx = j->size[0];
        for (i2 = 0; i2 < idx; i2++) {
          cIdx->data[i2] = j->data[i2];
        }

        do {
          exitg3 = 0;

          // ************************************************************************** 
          //    STEP 4: Find a noncovered zero and prime it.  If there is no starred 
          //            zero in the row containing this primed zero, Go to Step 5.   
          //            Otherwise, cover this row and uncover the column containing  
          //            the starred zero. Continue in this manner until there are no  
          //            uncovered zeros left. Save the smallest uncovered value and  
          //            Go to Step 6.
          // ************************************************************************** 
          i2 = z->size[0];
          z->size[0] = coverRow->size[0];
          emxEnsureCapacity_boolean_T(z, i2);
          idx = coverRow->size[0];
          for (i2 = 0; i2 < idx; i2++) {
            z->data[i2] = !coverRow->data[i2];
          }

          b_n = z->size[0];
          idx = 0;
          i2 = ii->size[0];
          ii->size[0] = z->size[0];
          emxEnsureCapacity_int32_T(ii, i2);
          m = 0;
          exitg2 = false;
          while ((!exitg2) && (m <= b_n - 1)) {
            if (z->data[m]) {
              idx++;
              ii->data[idx - 1] = m + 1;
              if (idx >= b_n) {
                exitg2 = true;
              } else {
                m++;
              }
            } else {
              m++;
            }
          }

          if (z->size[0] == 1) {
            if (idx == 0) {
              ii->size[0] = 0;
            }
          } else if (1 > idx) {
            ii->size[0] = 0;
          } else {
            i2 = ii->size[0];
            ii->size[0] = idx;
            emxEnsureCapacity_int32_T(ii, i2);
          }

          i2 = cR->size[0];
          cR->size[0] = ii->size[0];
          emxEnsureCapacity_uint32_T(cR, i2);
          idx = ii->size[0];
          for (i2 = 0; i2 < idx; i2++) {
            cR->data[i2] = (unsigned int)ii->data[i2];
          }

          i2 = x->size[0] * x->size[1];
          x->size[0] = 1;
          x->size[1] = coverColumn->size[1];
          emxEnsureCapacity_boolean_T(x, i2);
          idx = coverColumn->size[0] * coverColumn->size[1];
          for (i2 = 0; i2 < idx; i2++) {
            x->data[i2] = !coverColumn->data[i2];
          }

          b_n = x->size[1];
          idx = 0;
          i2 = b_ii->size[0] * b_ii->size[1];
          b_ii->size[0] = 1;
          b_ii->size[1] = x->size[1];
          emxEnsureCapacity_int32_T(b_ii, i2);
          m = 0;
          exitg2 = false;
          while ((!exitg2) && (m <= b_n - 1)) {
            if (x->data[m]) {
              idx++;
              b_ii->data[idx - 1] = m + 1;
              if (idx >= b_n) {
                exitg2 = true;
              } else {
                m++;
              }
            } else {
              m++;
            }
          }

          if (x->size[1] == 1) {
            if (idx == 0) {
              b_ii->size[0] = 1;
              b_ii->size[1] = 0;
            }
          } else if (1 > idx) {
            b_ii->size[1] = 0;
          } else {
            i2 = b_ii->size[0] * b_ii->size[1];
            b_ii->size[1] = idx;
            emxEnsureCapacity_int32_T(b_ii, i2);
          }

          i2 = cC->size[0] * cC->size[1];
          cC->size[0] = 1;
          cC->size[1] = b_ii->size[1];
          emxEnsureCapacity_uint32_T(cC, i2);
          idx = b_ii->size[0] * b_ii->size[1];
          for (i2 = 0; i2 < idx; i2++) {
            cC->data[i2] = (unsigned int)b_ii->data[i2];
          }

          i2 = rIdx->size[0];
          emxEnsureCapacity_real_T(rIdx, i2);
          idx = rIdx->size[0];
          for (i2 = 0; i2 < idx; i2++) {
            rIdx->data[i2] = cR->data[(int)rIdx->data[i2] - 1];
          }

          i2 = b_cIdx->size[0] * b_cIdx->size[1];
          b_cIdx->size[0] = 1;
          b_cIdx->size[1] = cIdx->size[0];
          emxEnsureCapacity_real_T(b_cIdx, i2);
          idx = cIdx->size[0];
          for (i2 = 0; i2 < idx; i2++) {
            b_cIdx->data[i2] = cC->data[(int)cIdx->data[i2] - 1];
          }

          uZr = 1.0;

          //  Matlab coder
          uZc = 1.0;

          //  Matlab coder
          Step = 6;
          exitg2 = false;
          while ((!exitg2) && (b_cIdx->size[1] != 0)) {
            uZr = rIdx->data[0];
            uZc = b_cIdx->data[0];
            primeZ->data[(int)rIdx->data[0] - 1] = b_cIdx->data[0];
            if (!(starZ->data[(int)rIdx->data[0] - 1] != 0.0)) {
              Step = 5;
              exitg2 = true;
            } else {
              coverRow->data[(int)rIdx->data[0] - 1] = true;
              coverColumn->data[(int)starZ->data[(int)rIdx->data[0] - 1] - 1] =
                false;
              bigM = rIdx->data[0];
              i2 = z->size[0];
              z->size[0] = rIdx->size[0];
              emxEnsureCapacity_boolean_T(z, i2);
              idx = rIdx->size[0];
              for (i2 = 0; i2 < idx; i2++) {
                z->data[i2] = (rIdx->data[i2] == bigM);
              }

              nullAssignment(rIdx, z);

              //  Matlab coder
              b_nullAssignment(b_cIdx, z);

              //  Matlab coder
              i2 = z->size[0];
              z->size[0] = coverRow->size[0];
              emxEnsureCapacity_boolean_T(z, i2);
              idx = coverRow->size[0];
              for (i2 = 0; i2 < idx; i2++) {
                z->data[i2] = !coverRow->data[i2];
              }

              b_n = z->size[0];
              idx = 0;
              i2 = ii->size[0];
              ii->size[0] = z->size[0];
              emxEnsureCapacity_int32_T(ii, i2);
              m = 0;
              exitg4 = false;
              while ((!exitg4) && (m <= b_n - 1)) {
                if (z->data[m]) {
                  idx++;
                  ii->data[idx - 1] = m + 1;
                  if (idx >= b_n) {
                    exitg4 = true;
                  } else {
                    m++;
                  }
                } else {
                  m++;
                }
              }

              if (z->size[0] == 1) {
                if (idx == 0) {
                  ii->size[0] = 0;
                }
              } else if (1 > idx) {
                ii->size[0] = 0;
              } else {
                i2 = ii->size[0];
                ii->size[0] = idx;
                emxEnsureCapacity_int32_T(ii, i2);
              }

              i2 = cR->size[0];
              cR->size[0] = ii->size[0];
              emxEnsureCapacity_uint32_T(cR, i2);
              idx = ii->size[0];
              for (i2 = 0; i2 < idx; i2++) {
                cR->data[i2] = (unsigned int)ii->data[i2];
              }

              jj = coverRow->size[0];
              m = jj - 1;
              trueCount = 0;
              for (idx = 0; idx <= m; idx++) {
                if (!coverRow->data[idx]) {
                  trueCount++;
                }
              }

              i2 = r11->size[0];
              r11->size[0] = trueCount;
              emxEnsureCapacity_int32_T(r11, i2);
              jj = 0;
              for (idx = 0; idx <= m; idx++) {
                if (!coverRow->data[idx]) {
                  r11->data[jj] = idx + 1;
                  jj++;
                }
              }

              bigM = minC->data[(int)starZ->data[(int)uZr - 1] - 1];
              jj = (int)starZ->data[(int)uZr - 1];
              i2 = z->size[0];
              z->size[0] = r11->size[0];
              emxEnsureCapacity_boolean_T(z, i2);
              idx = r11->size[0];
              for (i2 = 0; i2 < idx; i2++) {
                z->data[i2] = (dMat->data[(r11->data[i2] + dMat->size[0] * (jj -
                  1)) - 1] == minR->data[r11->data[i2] - 1] + bigM);
              }

              m = z->size[0] - 1;
              trueCount = 0;
              for (idx = 0; idx <= m; idx++) {
                if (z->data[idx]) {
                  trueCount++;
                }
              }

              i2 = r12->size[0];
              r12->size[0] = trueCount;
              emxEnsureCapacity_int32_T(r12, i2);
              jj = 0;
              for (idx = 0; idx <= m; idx++) {
                if (z->data[idx]) {
                  r12->data[jj] = idx + 1;
                  jj++;
                }
              }

              i2 = c_minC->size[0];
              c_minC->size[0] = r12->size[0];
              emxEnsureCapacity_real_T(c_minC, i2);
              idx = r12->size[0];
              for (i2 = 0; i2 < idx; i2++) {
                c_minC->data[i2] = cR->data[r12->data[i2] - 1];
              }

              i2 = rIdx->size[0];
              i3 = c_minC->size[0];
              jj = rIdx->size[0];
              rIdx->size[0] = i2 + i3;
              emxEnsureCapacity_real_T(rIdx, jj);
              idx = r12->size[0];
              for (i3 = 0; i3 < idx; i3++) {
                rIdx->data[i2 + i3] = cR->data[r12->data[i3] - 1];
              }

              //  Matlab coder
              bigM = d_sum(z);
              idx = b_cIdx->size[1];
              i2 = b_minC->size[0] * b_minC->size[1];
              b_minC->size[0] = 1;
              jj = (int)bigM;
              b_minC->size[1] = idx + jj;
              emxEnsureCapacity_real_T(b_minC, i2);
              for (i2 = 0; i2 < idx; i2++) {
                b_minC->data[i2] = b_cIdx->data[i2];
              }

              for (i2 = 0; i2 < jj; i2++) {
                b_minC->data[i2 + idx] = starZ->data[(int)uZr - 1];
              }

              i2 = b_cIdx->size[0] * b_cIdx->size[1];
              b_cIdx->size[0] = 1;
              b_cIdx->size[1] = b_minC->size[1];
              emxEnsureCapacity_real_T(b_cIdx, i2);
              idx = b_minC->size[0] * b_minC->size[1];
              for (i2 = 0; i2 < idx; i2++) {
                b_cIdx->data[i2] = b_minC->data[i2];
              }

              //  Matlab coder
            }
          }

          if (Step == 6) {
            //  ************************************************************************* 
            //  STEP 6: Add the minimum uncovered value to every element of each covered 
            //          row, and subtract it from every element of each uncovered column. 
            //          Return to Step 4 without altering any stars, primes, or covered lines. 
            // ************************************************************************** 
            m = coverRow->size[0] - 1;
            trueCount = 0;
            for (idx = 0; idx <= m; idx++) {
              if (!coverRow->data[idx]) {
                trueCount++;
              }
            }

            i2 = r9->size[0];
            r9->size[0] = trueCount;
            emxEnsureCapacity_int32_T(r9, i2);
            jj = 0;
            for (idx = 0; idx <= m; idx++) {
              if (!coverRow->data[idx]) {
                r9->data[jj] = idx + 1;
                jj++;
              }
            }

            b_n = coverColumn->size[1];
            m = b_n - 1;
            trueCount = 0;
            for (idx = 0; idx <= m; idx++) {
              if (!coverColumn->data[idx]) {
                trueCount++;
              }
            }

            i2 = r10->size[0] * r10->size[1];
            r10->size[0] = 1;
            r10->size[1] = trueCount;
            emxEnsureCapacity_int32_T(r10, i2);
            jj = 0;
            for (idx = 0; idx <= m; idx++) {
              if (!coverColumn->data[idx]) {
                r10->data[jj] = idx + 1;
                jj++;
              }
            }

            i2 = varargin_1->size[0] * varargin_1->size[1];
            varargin_1->size[0] = r9->size[0];
            varargin_1->size[1] = r10->size[1];
            emxEnsureCapacity_real_T(varargin_1, i2);
            idx = r10->size[1];
            for (i2 = 0; i2 < idx; i2++) {
              jj = r9->size[0];
              for (i3 = 0; i3 < jj; i3++) {
                varargin_1->data[i3 + varargin_1->size[0] * i2] = dMat->data
                  [(r9->data[i3] + dMat->size[0] * (r10->data[i2] - 1)) - 1];
              }
            }

            i2 = b_minR->size[0];
            b_minR->size[0] = r9->size[0];
            emxEnsureCapacity_real_T(b_minR, i2);
            idx = r9->size[0];
            for (i2 = 0; i2 < idx; i2++) {
              b_minR->data[i2] = minR->data[r9->data[i2] - 1];
            }

            i2 = b_minC->size[0] * b_minC->size[1];
            b_minC->size[0] = 1;
            b_minC->size[1] = r10->size[1];
            emxEnsureCapacity_real_T(b_minC, i2);
            idx = r10->size[0] * r10->size[1];
            for (i2 = 0; i2 < idx; i2++) {
              b_minC->data[i2] = minC->data[r10->data[i2] - 1];
            }

            outerplus(varargin_1, b_minR, b_minC, &bigM, rIdx, cIdx);
            m = b_n - 1;
            trueCount = 0;
            for (idx = 0; idx <= m; idx++) {
              if (!coverColumn->data[idx]) {
                trueCount++;
              }
            }

            i2 = r13->size[0] * r13->size[1];
            r13->size[0] = 1;
            r13->size[1] = trueCount;
            emxEnsureCapacity_int32_T(r13, i2);
            jj = 0;
            for (idx = 0; idx <= m; idx++) {
              if (!coverColumn->data[idx]) {
                r13->data[jj] = idx + 1;
                jj++;
              }
            }

            idx = r13->size[0] * r13->size[1];
            i2 = c_minC->size[0];
            c_minC->size[0] = idx;
            emxEnsureCapacity_real_T(c_minC, i2);
            for (i2 = 0; i2 < idx; i2++) {
              c_minC->data[i2] = minC->data[r13->data[i2] - 1] + bigM;
            }

            idx = c_minC->size[0];
            for (i2 = 0; i2 < idx; i2++) {
              minC->data[r13->data[i2] - 1] = c_minC->data[i2];
            }

            m = coverRow->size[0] - 1;
            trueCount = 0;
            for (idx = 0; idx <= m; idx++) {
              if (coverRow->data[idx]) {
                trueCount++;
              }
            }

            i2 = r14->size[0];
            r14->size[0] = trueCount;
            emxEnsureCapacity_int32_T(r14, i2);
            jj = 0;
            for (idx = 0; idx <= m; idx++) {
              if (coverRow->data[idx]) {
                r14->data[jj] = idx + 1;
                jj++;
              }
            }

            i2 = c_minC->size[0];
            c_minC->size[0] = r14->size[0];
            emxEnsureCapacity_real_T(c_minC, i2);
            idx = r14->size[0];
            for (i2 = 0; i2 < idx; i2++) {
              c_minC->data[i2] = minR->data[r14->data[i2] - 1] - bigM;
            }

            idx = c_minC->size[0];
            for (i2 = 0; i2 < idx; i2++) {
              minR->data[r14->data[i2] - 1] = c_minC->data[i2];
            }
          } else {
            exitg3 = 1;
          }
        } while (exitg3 == 0);

        // ************************************************************************** 
        //  STEP 5:
        //   Construct a series of alternating primed and starred zeros as
        //   follows:
        //   Let Z0 represent the uncovered primed zero found in Step 4.
        //   Let Z1 denote the starred zero in the column of Z0 (if any).
        //   Let Z2 denote the primed zero in the row of Z1 (there will always
        //   be one).  Continue until the series terminates at a primed zero
        //   that has no starred zero in its column.  Unstar each starred
        //   zero of the series, star each primed zero of the series, erase
        //   all primes and uncover every line in the matrix.  Return to Step 3. 
        // ************************************************************************** 
        i2 = z->size[0];
        z->size[0] = starZ->size[0];
        emxEnsureCapacity_boolean_T(z, i2);
        idx = starZ->size[0];
        for (i2 = 0; i2 < idx; i2++) {
          z->data[i2] = (starZ->data[i2] == uZc);
        }

        idx = 0;
        i2 = ii->size[0];
        ii->size[0] = 1;
        emxEnsureCapacity_int32_T(ii, i2);
        m = 0;
        exitg2 = false;
        while ((!exitg2) && (m <= z->size[0] - 1)) {
          if (z->data[m]) {
            idx = 1;
            ii->data[0] = m + 1;
            exitg2 = true;
          } else {
            m++;
          }
        }

        if (idx == 0) {
          ii->size[0] = 0;
        }

        i2 = rIdx->size[0];
        rIdx->size[0] = ii->size[0];
        emxEnsureCapacity_real_T(rIdx, i2);
        idx = ii->size[0];
        for (i2 = 0; i2 < idx; i2++) {
          rIdx->data[i2] = ii->data[i2];
        }

        //  Matlab coder
        starZ->data[(int)uZr - 1] = uZc;
        while (rIdx->size[0] != 0) {
          //  Matlab coder
          //  Matlab coder
          starZ->data[(int)rIdx->data[0] - 1] = 0.0;

          //  Matlab coder
          uZc = primeZ->data[(int)rIdx->data[0] - 1];

          //  Matlab coder
          uZr = rIdx->data[0];

          //  Matlab coder
          bigM = primeZ->data[(int)rIdx->data[0] - 1];
          i2 = z->size[0];
          z->size[0] = starZ->size[0];
          emxEnsureCapacity_boolean_T(z, i2);
          idx = starZ->size[0];
          for (i2 = 0; i2 < idx; i2++) {
            z->data[i2] = (starZ->data[i2] == bigM);
          }

          idx = 0;
          i2 = ii->size[0];
          ii->size[0] = 1;
          emxEnsureCapacity_int32_T(ii, i2);
          m = 0;
          exitg2 = false;
          while ((!exitg2) && (m <= z->size[0] - 1)) {
            if (z->data[m]) {
              idx = 1;
              ii->data[0] = m + 1;
              exitg2 = true;
            } else {
              m++;
            }
          }

          if (idx == 0) {
            ii->size[0] = 0;
          }

          i2 = rIdx->size[0];
          rIdx->size[0] = ii->size[0];
          emxEnsureCapacity_real_T(rIdx, i2);
          idx = ii->size[0];
          for (i2 = 0; i2 < idx; i2++) {
            rIdx->data[i2] = ii->data[i2];
          }

          //  Matlab coder
          starZ->data[(int)uZr - 1] = uZc;
        }
      }
    } while (exitg1 == 0);

    emxFree_real_T(&c_minC);
    emxFree_real_T(&b_minC);
    emxFree_real_T(&b_minR);
    emxFree_boolean_T(&b_starZ);
    emxFree_boolean_T(&x);
    emxFree_real_T(&varargin_1);
    emxFree_int32_T(&r14);
    emxFree_int32_T(&r13);
    emxFree_int32_T(&r12);
    emxFree_int32_T(&r11);
    emxFree_int32_T(&r10);
    emxFree_int32_T(&r9);
    emxFree_int32_T(&r8);
    emxFree_int32_T(&r7);
    emxFree_int32_T(&r6);
    emxFree_int32_T(&r5);
    emxFree_real_T(&b_cIdx);
    emxFree_boolean_T(&z);
    emxFree_uint32_T(&cC);
    emxFree_uint32_T(&cR);
    emxFree_real_T(&cIdx);
    emxFree_real_T(&rIdx);
    emxFree_real_T(&primeZ);
    emxFree_boolean_T(&coverRow);
    emxFree_boolean_T(&coverColumn);
    emxFree_boolean_T(&zP);
    emxFree_real_T(&dMat);

    //  Cost of assignment
    idx = 0;
    m = 0;
    exitg2 = false;
    while ((!exitg2) && (m < 10)) {
      if (validRow[m]) {
        idx++;
        ii_data[idx - 1] = (signed char)(m + 1);
        if (idx >= 10) {
          exitg2 = true;
        } else {
          m++;
        }
      } else {
        m++;
      }
    }

    b_n = validCol->size[1];
    idx = 0;
    i2 = b_ii->size[0] * b_ii->size[1];
    b_ii->size[0] = 1;
    b_ii->size[1] = validCol->size[1];
    emxEnsureCapacity_int32_T(b_ii, i2);
    m = 0;
    exitg2 = false;
    while ((!exitg2) && (m <= b_n - 1)) {
      if (validCol->data[m]) {
        idx++;
        b_ii->data[idx - 1] = m + 1;
        if (idx >= b_n) {
          exitg2 = true;
        } else {
          m++;
        }
      } else {
        m++;
      }
    }

    if (validCol->size[1] == 1) {
      if (idx == 0) {
        b_ii->size[0] = 1;
        b_ii->size[1] = 0;
      }
    } else if (1 > idx) {
      b_ii->size[1] = 0;
    } else {
      i2 = b_ii->size[0] * b_ii->size[1];
      b_ii->size[1] = idx;
      emxEnsureCapacity_int32_T(b_ii, i2);
    }

    i2 = minC->size[0] * minC->size[1];
    minC->size[0] = 1;
    minC->size[1] = b_ii->size[1];
    emxEnsureCapacity_real_T(minC, i2);
    idx = b_ii->size[0] * b_ii->size[1];
    for (i2 = 0; i2 < idx; i2++) {
      minC->data[i2] = b_ii->data[i2];
    }

    emxFree_int32_T(&b_ii);
    if (1.0 > nRows) {
      m = 0;
    } else {
      m = (int)nRows;
    }

    i2 = starZ->size[0];
    starZ->size[0] = m;
    emxEnsureCapacity_real_T(starZ, i2);
    for (idx = 0; idx < m; idx++) {
      if (starZ->data[idx] <= nCols) {
        assignment[ii_data[idx] - 1] = (unsigned int)minC->data[(int)starZ->
          data[idx] - 1];
      }
    }

    emxFree_real_T(&starZ);
    emxFree_real_T(&minC);
    jj = 0;
    trueCount = 0;
    for (idx = 0; idx < 10; idx++) {
      dMat_idx_0 = (unsigned int)assignment[idx];
      i2 = (int)dMat_idx_0;
      if (i2 > 0) {
        pass_data[jj] = dMat_idx_0;
        jj++;
        trueCount++;
      }
    }

    jj = 0;
    for (idx = 0; idx < 10; idx++) {
      if ((int)(unsigned int)assignment[idx] > 0) {
        tmp_data[jj] = (signed char)(idx + 1);
        jj++;
      }
    }

    if (0 <= trueCount - 1) {
      memcpy(&ii_data[0], &tmp_data[0], (unsigned int)(trueCount * (int)sizeof
              (signed char)));
    }

    i2 = r3->size[0] * r3->size[1];
    r3->size[0] = 10;
    r3->size[1] = r1->size[1];
    emxEnsureCapacity_boolean_T(r3, i2);
    idx = r1->size[0] * r1->size[1];
    for (i2 = 0; i2 < idx; i2++) {
      r3->data[i2] = (r1->data[i2] && r2->data[i2]);
    }

    b_tmp_size[0] = trueCount;
    b_tmp_size[1] = trueCount;
    for (i2 = 0; i2 < trueCount; i2++) {
      for (i3 = 0; i3 < trueCount; i3++) {
        b_tmp_data[i3 + trueCount * i2] = r3->data[(ii_data[i3] + 10 * ((int)
          (unsigned int)assignment[ii_data[i2] - 1] - 1)) - 1];
      }
    }

    diag(b_tmp_data, b_tmp_size, validRow, tmp_size);
    idx = tmp_size[0];
    for (i2 = 0; i2 < idx; i2++) {
      validRow[i2] = !validRow[i2];
    }

    m = tmp_size[0] - 1;
    trueCount = 0;
    for (idx = 0; idx <= m; idx++) {
      if (validRow[idx]) {
        trueCount++;
      }
    }

    jj = 0;
    for (idx = 0; idx <= m; idx++) {
      if (validRow[idx]) {
        c_tmp_data[jj] = (signed char)(idx + 1);
        jj++;
      }
    }

    for (i2 = 0; i2 < trueCount; i2++) {
      pass_data[c_tmp_data[i2] - 1] = 0U;
    }

    jj = 0;
    trueCount = 0;
    for (idx = 0; idx < 10; idx++) {
      bigM = assignment[idx];
      if ((int)(unsigned int)assignment[idx] > 0) {
        bigM = pass_data[jj];
        jj++;
      }

      if ((int)(unsigned int)bigM > 0) {
        trueCount++;
      }

      assignment[idx] = bigM;
    }

    jj = 0;
    for (idx = 0; idx < 10; idx++) {
      if ((int)(unsigned int)assignment[idx] > 0) {
        d_tmp_data[jj] = (signed char)(idx + 1);
        jj++;
      }
    }

    if (0 <= trueCount - 1) {
      memcpy(&ii_data[0], &d_tmp_data[0], (unsigned int)(trueCount * (int)sizeof
              (signed char)));
    }

    costMat_size[0] = trueCount;
    costMat_size[1] = trueCount;
    for (i2 = 0; i2 < trueCount; i2++) {
      for (i3 = 0; i3 < trueCount; i3++) {
        costMat_data[i3 + trueCount * i2] = costMat->data[(ii_data[i3] + 10 *
          ((int)(unsigned int)assignment[ii_data[i2] - 1] - 1)) - 1];
      }
    }

    *cost = trace(costMat_data, costMat_size);
  }

  emxFree_boolean_T(&r3);
  emxFree_int32_T(&ii);
  emxFree_int32_T(&j);
  emxFree_boolean_T(&r2);
  emxFree_boolean_T(&r1);
  emxFree_real_T(&minR);
  emxFree_boolean_T(&validCol);
}

//
// File trailer for munkres.cpp
//
// [EOF]
//
