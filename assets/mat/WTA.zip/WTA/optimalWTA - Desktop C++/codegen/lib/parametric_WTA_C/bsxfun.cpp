//
// File: bsxfun.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 09-Dec-2020 15:02:49
//

// Include Files
#include "rt_nonfinite.h"
#include "parametric_WTA_C.h"
#include "bsxfun.h"
#include "parametric_WTA_C_emxutil.h"

// Function Definitions

//
// Arguments    : const emxArray_real_T *a
//                const emxArray_real_T *b
//                emxArray_real_T *c
// Return Type  : void
//
void b_bsxfun(const emxArray_real_T *a, const emxArray_real_T *b,
              emxArray_real_T *c)
{
  int csz_idx_0;
  int csz_idx_1;
  int i6;
  int varargin_2;
  int bcoef;
  int i7;
  int k;
  csz_idx_0 = b->size[0];
  csz_idx_1 = a->size[1];
  i6 = c->size[0] * c->size[1];
  c->size[0] = csz_idx_0;
  c->size[1] = csz_idx_1;
  emxEnsureCapacity_real_T(c, i6);
  csz_idx_0 = (a->size[1] != 1);
  i6 = c->size[1] - 1;
  for (csz_idx_1 = 0; csz_idx_1 <= i6; csz_idx_1++) {
    varargin_2 = csz_idx_0 * csz_idx_1;
    bcoef = (b->size[0] != 1);
    i7 = c->size[0] - 1;
    for (k = 0; k <= i7; k++) {
      c->data[k + c->size[0] * csz_idx_1] = a->data[varargin_2] + b->data[bcoef *
        k];
    }
  }
}

//
// Arguments    : const emxArray_real_T *a
//                const emxArray_real_T *b
//                emxArray_real_T *c
// Return Type  : void
//
void bsxfun(const emxArray_real_T *a, const emxArray_real_T *b, emxArray_real_T *
            c)
{
  int csz_idx_0;
  int csz_idx_1;
  int i4;
  int varargin_2;
  int acoef;
  int bcoef;
  int i5;
  int k;
  csz_idx_0 = b->size[0];
  csz_idx_1 = a->size[0];
  if (csz_idx_0 < csz_idx_1) {
    csz_idx_1 = csz_idx_0;
  }

  if (b->size[0] == 1) {
    csz_idx_0 = a->size[0];
  } else if (a->size[0] == 1) {
    csz_idx_0 = b->size[0];
  } else if (a->size[0] == b->size[0]) {
    csz_idx_0 = a->size[0];
  } else {
    csz_idx_0 = csz_idx_1;
  }

  csz_idx_1 = a->size[1];
  i4 = c->size[0] * c->size[1];
  c->size[0] = csz_idx_0;
  c->size[1] = csz_idx_1;
  emxEnsureCapacity_real_T(c, i4);
  csz_idx_0 = (a->size[1] != 1);
  i4 = c->size[1] - 1;
  for (csz_idx_1 = 0; csz_idx_1 <= i4; csz_idx_1++) {
    varargin_2 = csz_idx_0 * csz_idx_1;
    acoef = (a->size[0] != 1);
    bcoef = (b->size[0] != 1);
    i5 = c->size[0] - 1;
    for (k = 0; k <= i5; k++) {
      c->data[k + c->size[0] * csz_idx_1] = a->data[acoef * k + a->size[0] *
        varargin_2] - b->data[bcoef * k];
    }
  }
}

//
// Arguments    : const emxArray_real_T *a
//                const emxArray_real_T *b
//                emxArray_real_T *c
// Return Type  : void
//
void c_bsxfun(const emxArray_real_T *a, const emxArray_real_T *b,
              emxArray_real_T *c)
{
  int csz_idx_0;
  int csz_idx_1;
  int i8;
  int varargin_3;
  int acoef;
  int i9;
  int k;
  csz_idx_0 = a->size[0];
  csz_idx_1 = b->size[1];
  i8 = c->size[0] * c->size[1];
  c->size[0] = csz_idx_0;
  c->size[1] = csz_idx_1;
  emxEnsureCapacity_real_T(c, i8);
  if ((c->size[0] != 0) && (c->size[1] != 0)) {
    csz_idx_0 = (b->size[1] != 1);
    i8 = c->size[1] - 1;
    for (csz_idx_1 = 0; csz_idx_1 <= i8; csz_idx_1++) {
      varargin_3 = csz_idx_0 * csz_idx_1;
      acoef = (a->size[0] != 1);
      i9 = c->size[0] - 1;
      for (k = 0; k <= i9; k++) {
        c->data[k + c->size[0] * csz_idx_1] = a->data[acoef * k] + b->
          data[varargin_3];
      }
    }
  }
}

//
// File trailer for bsxfun.cpp
//
// [EOF]
//
