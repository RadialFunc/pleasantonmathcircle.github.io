//
// File: power.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 09-Dec-2020 15:02:49
//

// Include Files
#include "rt_nonfinite.h"
#include "parametric_WTA_C.h"
#include "power.h"
#include "parametric_WTA_C_rtwutil.h"

// Function Definitions

//
// Arguments    : const int a_size[1]
//                const double b_data[]
//                const int b_size[1]
//                double y_data[]
//                int y_size[1]
// Return Type  : void
//
void power(const int a_size[1], const double b_data[], const int b_size[1],
           double y_data[], int y_size[1])
{
  signed char csz_idx_0;
  int nx;
  int k;
  if (a_size[0] <= b_size[0]) {
    csz_idx_0 = (signed char)a_size[0];
  } else {
    csz_idx_0 = (signed char)b_size[0];
  }

  y_size[0] = csz_idx_0;
  nx = csz_idx_0;
  for (k = 0; k < nx; k++) {
    y_data[k] = rt_powd_snf(0.099999999999999978, b_data[k]);
  }
}

//
// File trailer for power.cpp
//
// [EOF]
//
