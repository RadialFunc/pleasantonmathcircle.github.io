//
// File: any1.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 09-Dec-2020 15:02:49
//

// Include Files
#include "rt_nonfinite.h"
#include "parametric_WTA_C.h"
#include "any1.h"
#include "parametric_WTA_C_emxutil.h"

// Function Definitions

//
// Arguments    : const emxArray_boolean_T *x
//                emxArray_boolean_T *y
// Return Type  : void
//
void any(const emxArray_boolean_T *x, emxArray_boolean_T *y)
{
  unsigned int outsize_idx_1;
  int npages;
  int i2;
  int iy;
  int i;
  int a;
  int ix;
  boolean_T exitg1;
  boolean_T b0;
  outsize_idx_1 = (unsigned int)x->size[1];
  npages = y->size[0] * y->size[1];
  y->size[0] = 1;
  y->size[1] = (int)outsize_idx_1;
  emxEnsureCapacity_boolean_T(y, npages);
  i2 = (int)outsize_idx_1;
  for (npages = 0; npages < i2; npages++) {
    y->data[npages] = false;
  }

  npages = x->size[1];
  i2 = 1;
  iy = -1;
  for (i = 0; i < npages; i++) {
    a = i2 + 9;
    ix = i2;
    i2 += 10;
    iy++;
    exitg1 = false;
    while ((!exitg1) && (ix <= a)) {
      b0 = !x->data[ix - 1];
      if (!b0) {
        y->data[iy] = true;
        exitg1 = true;
      } else {
        ix++;
      }
    }
  }
}

//
// Arguments    : const emxArray_boolean_T *x
//                boolean_T y[10]
// Return Type  : void
//
void b_any(const emxArray_boolean_T *x, boolean_T y[10])
{
  int i;
  int iy;
  int i1;
  int j;
  int ix;
  boolean_T exitg1;
  boolean_T b1;
  for (i = 0; i < 10; i++) {
    y[i] = false;
  }

  i = (x->size[1] - 1) * 10;
  iy = -1;
  i1 = 0;
  for (j = 0; j < 10; j++) {
    i1++;
    i++;
    iy++;
    ix = i1;
    exitg1 = false;
    while ((!exitg1) && (ix <= i)) {
      b1 = !x->data[ix - 1];
      if (!b1) {
        y[iy] = true;
        exitg1 = true;
      } else {
        ix += 10;
      }
    }
  }
}

//
// Arguments    : const emxArray_boolean_T *x
// Return Type  : boolean_T
//
boolean_T c_any(const emxArray_boolean_T *x)
{
  boolean_T y;
  int ix;
  boolean_T exitg1;
  boolean_T b2;
  y = false;
  ix = 1;
  exitg1 = false;
  while ((!exitg1) && (ix <= x->size[0])) {
    b2 = !x->data[ix - 1];
    if (!b2) {
      y = true;
      exitg1 = true;
    } else {
      ix++;
    }
  }

  return y;
}

//
// File trailer for any1.cpp
//
// [EOF]
//
