//
// File: mpower.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 09-Dec-2020 15:02:49
//
#ifndef MPOWER_H
#define MPOWER_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "parametric_WTA_C_types.h"

// Function Declarations
extern double mpower(double a, double b);

#endif

//
// File trailer for mpower.h
//
// [EOF]
//
