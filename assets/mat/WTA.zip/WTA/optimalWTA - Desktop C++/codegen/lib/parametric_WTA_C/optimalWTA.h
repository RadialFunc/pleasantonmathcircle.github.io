//
// File: optimalWTA.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 09-Dec-2020 15:02:49
//
#ifndef OPTIMALWTA_H
#define OPTIMALWTA_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "parametric_WTA_C_types.h"

// Function Declarations
extern void optimalWTA(const double lethality_data[], const int lethality_size[2],
  const double reachMat_data[], const int reachMat_size[2], const int
  pKill_size[2], double fAssign_data[], int fAssign_size[2], double *fLeak,
  double *totalReach);

#endif

//
// File trailer for optimalWTA.h
//
// [EOF]
//
