//
// File: optimalWTA.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 09-Dec-2020 15:02:49
//

// Include Files
#include <string.h>
#include "rt_nonfinite.h"
#include "parametric_WTA_C.h"
#include "optimalWTA.h"
#include "sum.h"
#include "power.h"
#include "parametric_WTA_C_emxutil.h"
#include "munkres.h"
#include "parametric_WTA_C_rtwutil.h"

// Function Definitions

//
// lethality is the vector of object lethalities
//  reachMat is the reachability matrix
//  pKill is the probability of a KV eliminating the object's lethality once
//        it has been assigned to that object
//  maxKV is the maximum number of KVs allowed to assign to a single object
//
//  fAssign is the (#KV x #Ojb) assignment matrix
//  fLeak is the total lethality leakage for fAssign
//
//  Author: G. Chiang
//  Date: 3/29/2016
// Arguments    : const double lethality_data[]
//                const int lethality_size[2]
//                const double reachMat_data[]
//                const int reachMat_size[2]
//                const int pKill_size[2]
//                double fAssign_data[]
//                int fAssign_size[2]
//                double *fLeak
//                double *totalReach
// Return Type  : void
//
void optimalWTA(const double lethality_data[], const int lethality_size[2],
                const double reachMat_data[], const int reachMat_size[2], const
                int pKill_size[2], double fAssign_data[], int fAssign_size[2],
                double *fLeak, double *totalReach)
{
  signed char unnamed_idx_1;
  int loop_ub_tmp;
  int nx;
  int k;
  double maxval[10];
  double Q_data[1000];
  int xpageoffset;
  int idx;
  int i;
  boolean_T exitg1;
  signed char ii_data[10];
  int i1;
  double Q2_data[1000];
  double y_data[100];
  double aKV_data[100];
  double smak;
  emxArray_int8_T *objPTR;
  emxArray_real_T *S;
  unsigned int kp;
  emxArray_real_T *r0;
  boolean_T x_data[1000];
  boolean_T guard1 = false;
  int i_data[1000];
  signed char j_data[1000];
  int tmp_size[1];
  int y[1];
  int b_tmp_size[1];
  int b_lethality_size[1];
  emxArray_real_T b_lethality_data;
  double c_lethality_data[100];
  emxArray_real_T b_Q_data;
  unnamed_idx_1 = (signed char)reachMat_size[1];
  fAssign_size[0] = 10;
  fAssign_size[1] = unnamed_idx_1;
  loop_ub_tmp = 10 * unnamed_idx_1;
  if (0 <= loop_ub_tmp - 1) {
    memset(&fAssign_data[0], 0, (unsigned int)(loop_ub_tmp * (int)sizeof(double)));
  }

  nx = 10 * (signed char)reachMat_size[1];
  for (k = 0; k < nx; k++) {
    if ((1.0 < reachMat_data[k]) || rtIsNaN(reachMat_data[k])) {
      Q_data[k] = 1.0;
    } else {
      Q_data[k] = reachMat_data[k];
    }
  }

  nx = (signed char)reachMat_size[1];
  memcpy(&maxval[0], &Q_data[0], 10U * sizeof(double));
  for (xpageoffset = 2; xpageoffset <= nx; xpageoffset++) {
    for (i = 0; i < 10; i++) {
      if (maxval[i] < Q_data[i + 10 * (xpageoffset - 1)]) {
        maxval[i] = Q_data[i + 10 * (xpageoffset - 1)];
      }
    }
  }

  idx = 0;
  nx = 0;
  exitg1 = false;
  while ((!exitg1) && (nx < 10)) {
    if (maxval[nx] != 0.0) {
      idx++;
      ii_data[idx - 1] = (signed char)(nx + 1);
      if (idx >= 10) {
        exitg1 = true;
      } else {
        nx++;
      }
    } else {
      nx++;
    }
  }

  if (1 > idx) {
    idx = 0;
  }

  // exclude unassignable KVs from WTA
  if (idx == 0) {
    *totalReach = 0.0;

    //  Matlab coder
    nx = lethality_size[1];
    *fLeak = lethality_data[0];
    for (k = 2; k <= nx; k++) {
      *fLeak += lethality_data[k - 1];
    }
  } else {
    nx = (signed char)reachMat_size[1];
    for (i1 = 0; i1 < nx; i1++) {
      for (k = 0; k < idx; k++) {
        Q2_data[k + idx * i1] = Q_data[(ii_data[k] + 10 * i1) - 1];
      }
    }

    i1 = (signed char)reachMat_size[1];
    for (i = 0; i < i1; i++) {
      xpageoffset = i * idx;
      y_data[i] = Q2_data[xpageoffset];
      for (k = 2; k <= idx; k++) {
        y_data[i] += Q2_data[(xpageoffset + k) - 1];
      }
    }

    nx = (signed char)reachMat_size[1];
    for (k = 0; k < nx; k++) {
      if ((3.0 < y_data[k]) || rtIsNaN(y_data[k])) {
        aKV_data[k] = 3.0;
      } else {
        aKV_data[k] = y_data[k];
      }
    }

    //  lethality is the vector of object lethalities
    //  aKV is the vector of total assignable KVs to each object
    //  pKill is the probability of a KV eliminating the object's lethality once 
    //        it has been assigned to that object
    //  Q is the binary reachability matrix
    //
    //  costMat is the cost matrix for Munkres algorithm
    //  objPTR is a vector mapping costMat columns to object IDs
    //
    //  Author: G. Chiang
    //  Date: 3/29/2016
    //
    //  Matlab coder
    nx = (signed char)reachMat_size[1];
    smak = aKV_data[0];
    for (k = 2; k <= nx; k++) {
      smak += aKV_data[k - 1];
    }

    emxInit_int8_T(&objPTR, 2);
    i1 = objPTR->size[0] * objPTR->size[1];
    objPTR->size[0] = 1;
    nx = (int)smak;
    objPTR->size[1] = nx;
    emxEnsureCapacity_int8_T(objPTR, i1);
    for (i1 = 0; i1 < nx; i1++) {
      objPTR->data[i1] = 0;
    }

    emxInit_real_T(&S, 2);
    i1 = S->size[0] * S->size[1];
    S->size[0] = 10;
    S->size[1] = nx;
    emxEnsureCapacity_real_T(S, i1);
    nx *= 10;
    for (i1 = 0; i1 < nx; i1++) {
      S->data[i1] = 0.0;
    }

    kp = 0U;
    i1 = lethality_size[1];
    for (i = 0; i < i1; i++) {
      k = (int)aKV_data[i];
      for (xpageoffset = 0; xpageoffset < k; xpageoffset++) {
        kp++;

        //  Matlab coder
        smak = 0.9 * lethality_data[i] * rt_powd_snf(0.099999999999999978, (1.0
          + (double)xpageoffset) - 1.0);
        for (nx = 0; nx < 10; nx++) {
          S->data[nx + 10 * ((int)kp - 1)] = smak * Q_data[nx + 10 * i];
        }

        //  Matlab coder
        objPTR->data[(int)kp - 1] = (signed char)(1 + i);

        //  Matlab coder
      }
    }

    emxInit_real_T(&r0, 2);
    i1 = r0->size[0] * r0->size[1];
    r0->size[0] = 10;
    r0->size[1] = S->size[1];
    emxEnsureCapacity_real_T(r0, i1);
    nx = S->size[0] * S->size[1];
    for (i1 = 0; i1 < nx; i1++) {
      r0->data[i1] = 1.0 - S->data[i1];
    }

    emxFree_real_T(&S);
    munkres(r0, maxval, &smak);
    emxFree_real_T(&r0);
    for (i = 0; i < idx; i++) {
      if (maxval[i] != 0.0) {
        fAssign_data[(ii_data[i] + 10 * (objPTR->data[(int)maxval[i] - 1] - 1))
          - 1] = 1.0;
      }
    }

    emxFree_int8_T(&objPTR);

    //  Remove the KVs that have been WRONGLY assigned
    for (i1 = 0; i1 < loop_ub_tmp; i1++) {
      x_data[i1] = ((fAssign_data[i1] == 1.0) && (Q_data[i1] == 0.0));
    }

    idx = 0;
    nx = 1;
    xpageoffset = 1;
    exitg1 = false;
    while ((!exitg1) && (xpageoffset <= unnamed_idx_1)) {
      guard1 = false;
      if (x_data[(nx + 10 * (xpageoffset - 1)) - 1]) {
        idx++;
        i_data[idx - 1] = nx;
        j_data[idx - 1] = (signed char)xpageoffset;
        if (idx >= loop_ub_tmp) {
          exitg1 = true;
        } else {
          guard1 = true;
        }
      } else {
        guard1 = true;
      }

      if (guard1) {
        nx++;
        if (nx > 10) {
          nx = 1;
          xpageoffset++;
        }
      }
    }

    if (1 > idx) {
      idx = 0;
    }

    for (i = 0; i < idx; i++) {
      fAssign_data[(i_data[i] + 10 * (j_data[i] - 1)) - 1] = 0.0;
    }

    nx = unnamed_idx_1;
    for (i = 0; i < nx; i++) {
      xpageoffset = i * 10;
      y_data[i] = (signed char)fAssign_data[xpageoffset];
      for (k = 0; k < 9; k++) {
        y_data[i] += (double)(signed char)fAssign_data[(xpageoffset + k) + 1];
      }
    }

    //  lethality is the vector of object lethalities
    //  KVsAssigned is a vector that indicates how many KVs have been assigned
    //        to each object
    //  pKill is the probability of a KV eliminating the object's lethality once 
    //        it has been assigned to that object
    //
    //  leakageVector is the leakage from each object computed as
    //      leakageVector(i) =  lethality(i) * (1.0 - pKill(i)) ^ KVsAssigned(i) 
    //
    //  pLeakage is the leakage (or probability of leakage) computed as
    //      pLeakage = sum(  leakageVector  )
    //
    //  Author: G. Chiang
    //  Date: 3/29/2016
    //
    //  make leakageVector a row vector.
    tmp_size[0] = pKill_size[1];
    y[0] = unnamed_idx_1;
    power(tmp_size, y_data, y, aKV_data, b_tmp_size);
    b_lethality_size[0] = lethality_size[1];
    nx = lethality_size[1];
    for (i1 = 0; i1 < nx; i1++) {
      c_lethality_data[i1] = lethality_data[i1] * aKV_data[i1];
    }

    b_lethality_data.data = &c_lethality_data[0];
    b_lethality_data.size = &b_lethality_size[0];
    b_lethality_data.allocatedSize = 100;
    b_lethality_data.numDimensions = 1;
    b_lethality_data.canFreeData = false;
    *fLeak = sum(&b_lethality_data);
    for (i1 = 0; i1 < loop_ub_tmp; i1++) {
      Q_data[i1] = fAssign_data[i1] * reachMat_data[i1];
    }

    //  Matlab coder
    y[0] = loop_ub_tmp;
    b_Q_data.data = &Q_data[0];
    b_Q_data.size = &y[0];
    b_Q_data.allocatedSize = 1000;
    b_Q_data.numDimensions = 1;
    b_Q_data.canFreeData = false;
    *totalReach = sum(&b_Q_data);

    //  Matlab coder
  }
}

//
// File trailer for optimalWTA.cpp
//
// [EOF]
//
