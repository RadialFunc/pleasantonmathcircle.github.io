%% Calculations
load('logs.mat');
load('logss.mat');

means = mean(logs, 3);
stddev = std(logs, 0, 3);

runtimes = means(:);
[sorted, idx] = sort(runtimes);

stdlin = stddev(:);
stdlin = stdlin(idx);

over = means > 0.250;

%% Plotting
threats = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
fullness = [0.1, 0.3, 0.5, 0.7, 0.9, 1];
for i = 1:length(fullness)
    threats_X(:, i) = threats';
end
for i = 1:length(threats)
    fullness_Y(i, :) = fullness;
end

x = [10, 10; 100, 100];
y = [0.1, 1; 0.1, 1];
z = [0.250, 0.250; 0.250, 0.250];

figure
hold on
grid on
surf(threats_X, fullness_Y, means, 'FaceAlpha', 0.5, 'EdgeColor', 'none')
set(gca, 'zscale', 'log')
surf(x, y, z, 'FaceAlpha', 0, 'LineStyle', '-.', 'EdgeColor', 'r', 'LineWidth', 2)
plot3(threats_X(over), fullness_Y(over), means(over), 'r+', 'LineStyle', 'none', 'MarkerSize', 6)
xlim([10, 100])
ylim([0.1, 1])
legend('Data Means', '250 millisecond limit')
xlabel("Threats")
ylabel("Reachability Matrix Fullness")
zlabel("Runtime [ sec ]")
title("Mean of 11x60 Test Cases of WTA using SmartSat on ZCU102")

figure
hold on
grid on
surf(threats_X, fullness_Y, stddev, 'FaceAlpha', 0.5, 'EdgeColor', 'none')
set(gca, 'zscale', 'log')
xlabel("Threats")
ylabel("Reachability Matrix Fullness")
zlabel("Runtime Standard Deviation [ sec ]")
title("Standard Deviation of 60 Test Cases of WTA using SmartSat on ZCU102")

% figure
% hold on
% grid on
% plot(sorted, stdlin, ':', 'LineWidth', 2)
% l = lsline;
% l.LineWidth = 2;
% l.Color = 'r';
% xlabel("Average Runtime [ sec ]")
% ylabel("Standard Deviation [ sec ]")
% title("Runtimes vs Standard Deviations")