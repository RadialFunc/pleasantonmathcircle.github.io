%% Preamble
clear; clc; close all;

% you must create an empty .txt file on this path with the title "parametric_WTA.txt"
% running this script will overwrite that text file so save copies of sets
% you wish to keep!

time = 738086.6526; % modify this number to match the appendix of the desired set of .mat files

tab = "    ";

fileID = fopen('parametric_WTA.txt', 'w');

load(strcat('inputs_', num2str(time), '.mat'));
load(strcat('outputs_', num2str(time), '.mat'));
load(strcat('runtimes_', num2str(time), '.mat'));
load(strcat('params_', num2str(time), '.mat'));

%% Begin Write

fprintf(fileID, """""""\r\n", []);
fprintf(fileID, "@file test_WTA.py\r\n", []);
fprintf(fileID, "\r\n", []);
fprintf(fileID, "@copyright 2020 Lockheed Martin Corporation - All Rights Reserved\r\n", []);
fprintf(fileID, "\r\n", []);
fprintf(fileID, "@par Legal", []);
fprintf(fileID, "Lockheed Martin Proprietary Information\r\n", []);
fprintf(fileID, "Export Controlled Information - EAR99\r\n", []);
fprintf(fileID, "See LICENSE.md for license information\r\n", []);
fprintf(fileID, """""""\r\n", []);
fprintf(fileID, "from test.wta_common import class_setup\r\n", []);
fprintf(fileID, "from swte import large_banner, small_banner\r\n", []);
fprintf(fileID, "from tinker.test.swit import Swit\r\n", []);
fprintf(fileID, "\r\n", []);
fprintf(fileID, "\r\n", []);

fprintf(fileID, "class TestOptimalWTA(Swit):\r\n", []);
fprintf(fileID, "\t'''\r\n", []);
fprintf(fileID, "\tTest the WTA Algorithm\r\n", []);
fprintf(fileID, "\t'''\r\n", []);

fprintf(fileID, "\tdef initial_setup(self):\r\n", []);
fprintf(fileID, "\t\t'''\r\n", []);
fprintf(fileID, "\t\tPerforms class level setup\r\n", []);
fprintf(fileID, "\t\t'''\r\n", []);
fprintf(fileID, "\t\tlarge_banner(""Setting Up WTA Tests"")\r\n", []);
fprintf(fileID, "\t\tself.wta_domain = self.testbed.get_domains()[0]\r\n", []);
fprintf(fileID, "\t\tself.wta_commander = class_setup(self.testbed_name, self.wta_domain.get_name(),\r\n", []);
fprintf(fileID, "\t\t\t\t\t\t self.logger, self.wta_domain, self.sds_logger,\r\n", []);
fprintf(fileID, "\t\t\t\t\t\t self.tinker.get_file_server(), self.testbed_dist)\r\n", []);
fprintf(fileID, "\r\n", []);

fprintf(fileID, "\t\tdef final_teardown(self):\r\n", []);
fprintf(fileID, "\t\t'''\r\n", []);
fprintf(fileID, "\t\tPerforms class level tear down\r\n", []);
fprintf(fileID, "\t\t'''\r\n", []);
fprintf(fileID, "\t\tlarge_banner(""Tearing Down WTA Tests"")\r\n", []);
fprintf(fileID, "\t\ttimeout = 20\r\n", []);
fprintf(fileID, "\t\tself.wta_domain.get_app_manager().terminate_and_wait(""OptimalWTA"", timeout)\r\n", []);
fprintf(fileID, "\r\n", []);

%% Print Test Functions

for i = 1:length(threats)
    
    for j = 1:length(fullness)
       
        fprintf(fileID, "\tdef parametric_wta_%u_%.0f(self):\r\n", threats(i), 100*fullness(j));
        fprintf(fileID, "\t\t'''\r\n", []);
        fprintf(fileID, "\t\tASSUME: pKill = 0.9*ones(size(lethality))\r\n", []);
        fprintf(fileID, "\t\tASSUME: maxKV = 3\r\n", []);
        fprintf(fileID, "\t\t'''\r\n", []);
        fprintf(fileID, "\t\tsmall_banner(""Running parametric WTA test, %u threats, %.0f%% fullness"")\r\n", threats(i), 100*fullness(j));
        fprintf(fileID, "\r\n", []);
        fprintf(fileID, strcat("\t\t", repmat('#', [1, 15]), "\r\n"), []);
        fprintf(fileID, "\t\t# DEFINE INPUTS\r\n", []);
        fprintf(fileID, strcat("\t\t", repmat('#', [1, 15]), "\r\n"), []);
        
        leth = lethality{i};
%         fprintf(fileID, strcat("\t\tlethality = [", joincommas(lethality{i}, '%4.4f '), "]\r\n"), []);
        
        reachability = double(reachability_base{i} <= fullness(j));
        
        fprintf(fileID, "\t\treachMat = [", []);
        overhang = 12;
        for k = 1:length(reachability(:, 1))
            if k == 1 % first row
                fprintf(fileID, "%u, ", reachability(k, :));
                fprintf(fileID, "\r\n", []);
            elseif k == length(reachability(:, 1)) % last row
                fprintf(fileID, "\t\t", []);
                fprintf(fileID, repmat(' ', [1, overhang]), []);
                fprintf(fileID, strcat(joincommas(reachability(k, :), '%u '), "]\r\n"), []);
            else % in between rows
                fprintf(fileID, "\t\t", []);
                fprintf(fileID, repmat(' ', [1, overhang]), []);
                fprintf(fileID, "%u, ", reachability(k, :));
                fprintf(fileID, "\r\n", []);
            end
        end
        
        fprintf(fileID, "\r\n", []);
        fprintf(fileID, strcat("\t\t", repmat('#', [1, 16]), "\r\n"), []);
        fprintf(fileID, "\t\t# DEFINE OUTPUTS\r\n", []);
        fprintf(fileID, strcat("\t\t", repmat('#', [1, 16]), "\r\n"), []);
        
        fprintf(fileID, "\t\texpectedFLeak = %6.4f\r\n", fLeak_c{i, j});
        fprintf(fileID, "\t\texpectedTotalReach = %.0f \r\n", totalReach_c{i, j});
        fprintf(fileID, "\t\texpectedFAssign = [", []);
        overhang = 19;
        for k = 1:length(fAssign_c{i, j}(:, 1))
            if k == 1 % first row
                fprintf(fileID, "%u, ", fAssign_c{i, j}(k, :));
                fprintf(fileID, "\r\n", []);
            elseif k == length(fAssign_c{i, j}(:, 1)) % last row
                fprintf(fileID, "\t\t", []);
                fprintf(fileID, repmat(' ', [1, overhang]), []);
                fprintf(fileID, strcat(joincommas(fAssign_c{i, j}(k, :), '%u '), "]\r\n"), []);
            else % in between rows
                fprintf(fileID, "\t\t", []);
                fprintf(fileID, repmat(' ', [1, overhang]), []);
                fprintf(fileID, "%u, ", fAssign_c{i, j}(k, :));
                fprintf(fileID, "\r\n", []);
            end
        end
        fprintf(fileID, "\r\n", []);
        
        fprintf(fileID, "\t\t# Run Test\r\n", []);
        fprintf(fileID, "\t\tself.expect(self.wta_commander.test_WTA_Algorithm(lethality, reachMat, %u, %u, expectedFLeak, expectedTotalReach, expectedFAssign))\r\n",...
            length(reachability(:, 1)), threats(i));
        
        fprintf(fileID, "\r\n", []);
        
    end
    
end

%% End
fclose(fileID);

function str = joincommas(numarray, format)
    
    nums = sprintf(format, numarray);
    nums = strtrim(nums);
    sep = split(nums, ' ');
    str = join(sep, ', ');
    
end