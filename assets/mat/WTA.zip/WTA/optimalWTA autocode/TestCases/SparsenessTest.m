clear; clc; close all;
%%

% random number generator seed
rng(12345);

% these linear vectors are the inputs, they can be modified and the script
% will run
threats = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
fullness = [0.1, 0.3, 0.5, 0.7, 0.9, 1];

% these matrices are the outputs, holding the runtime for matlab and C++
matlab_time = zeros([length(threats), length(fullness)]);
Cpp_time = zeros([length(threats), length(fullness)]);

fAssign_m = cell(size(matlab_time));
fAssign_c = cell(size(Cpp_time));
fLeak_m = cell(size(matlab_time));
fLeak_c = cell(size(Cpp_time));
totalReach_m = cell(size(matlab_time));
totalReach_c = cell(size(Cpp_time));

% These are the X and Y coordinates for 3D plotting
threats_X = zeros(size(matlab_time));
fullness_Y = zeros(size(matlab_time));

COm(:, :, 1) = linspace(0.5, 1, length(threats))'*ones(size(fullness));
COm(:, :, 2) = sqrt(linspace(0, 0.2, length(threats)))'*sqrt(linspace(0, 0.2, length(fullness)));
COm(:, :, 3) = sqrt(linspace(0, 0.2, length(threats)))'*sqrt(linspace(0, 0.2, length(fullness)));

COc(:, :, 1) = linspace(0, 0.5, length(threats))'*ones(size(fullness));
COc(:, :, 2) = sqrt(linspace(0, 0.2, length(threats)))'*sqrt(linspace(0, 0.2, length(fullness)));
COc(:, :, 3) = ones(size(Cpp_time));

% max KVs that can be assigned to one target
maxKVs = 3;

addpath("../"); % this adds optimalWTA and the C++ optimalWTA to the path on Augusto's computer

% these loops populate the matrices for X and Y coordinates of the points
% to plot
for i = 1:length(fullness)
    threats_X(:, i) = threats';
end
for i = 1:length(threats)    
    fullness_Y(i, :) = fullness;
end

lethality = cell(size(threats));
reachability_base = cell(size(threats));
pKill = cell(size(threats));

%%
for i = 1:length(threats)
    
    disp(strcat("Threats: ", num2str(threats(i))))
    
    % for each number of threats, a lethality vector is generated for all
    % fullness cases
    lethality{i} = rand(1, threats(i));
    % pKill is always 0.9 here
    pKill{i} = 0.9*ones(size(lethality{i}));
    
    % for each number of threats, a random matrix is generated as a base
    % for the reachability
    reachability_base{i} = rand(10, threats(i));
    
    for j = 1:length(fullness)
    
        % this incorporates the current fullness percentage and creates the
        % desired reachability matrix from the base
        reachability = reachability_base{i} <= fullness(j);
        
        fAssign_m{i, j} = zeros(size(reachability));
        fLeak_m{i, j} = 0;
        totalReach_m{i, j} = 0;
        
        fAssign_c{i, j} = zeros(size(reachability));
        fLeak_c{i, j} = 0;
        totalReach_c{i, j} = 0;
        
        % these lines run optimalWTA in matlab and C++ and record the time
        % taken
        tic
        [fAssign_m{i, j}, fLeak_m{i, j}, totalReach_m{i, j}] = optimalWTA(lethality{i},reachability,pKill{i},maxKVs);
        matlab_time(i, j) = toc;
        tic
        [fAssign_c{i, j}, fLeak_c{i, j}, totalReach_c{i, j}] = optimalWTA_mex(lethality{i},double(reachability),pKill{i},maxKVs);
        Cpp_time(i, j) = toc;
        
    end
  
end

%% Plot

figure
hold on
grid on
surf(threats_X, fullness_Y, matlab_time, COm, 'FaceAlpha', 0.5, 'EdgeColor', 'none')
xlabel("Number of Threats")
ylabel("Reachability Matrix Fullness Percentage")
zlabel("Runtime [ sec ]")
s = gca;
set(s, 'zscale', 'log')
surf(threats_X, fullness_Y, Cpp_time, 'FaceAlpha', 0.5, 'EdgeColor', 'none')
legend('MATLAB', 'C++')
title('Computational Speed of WTA Algorithm, MATLAB vs C++')

%% save results

today = now;
save_str{1} = strcat('inputs_', num2str(today), '.mat');
save_str{2} = strcat('outputs_', num2str(today), '.mat');
save_str{3} = strcat('runtimes_', num2str(today), '.mat');
save_str{4} = strcat('params_', num2str(today), '.mat');

save(save_str{1}, 'pKill', 'maxKVs', 'lethality', 'reachability_base')
save(save_str{2}, 'fAssign_c', 'fLeak_c', 'totalReach_c', 'fAssign_m', 'fLeak_m', 'totalReach_m')
save(save_str{3}, 'matlab_time', 'Cpp_time')
save(save_str{4}, 'threats', 'fullness')
savefig(strcat('plot_', num2str(today), '.fig'))