//
// File: optimalWTA_initialize.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:56:32
//
#ifndef OPTIMALWTA_INITIALIZE_H
#define OPTIMALWTA_INITIALIZE_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "optimalWTA_types.h"

// Function Declarations
extern void optimalWTA_initialize();

#endif

//
// File trailer for optimalWTA_initialize.h
//
// [EOF]
//
