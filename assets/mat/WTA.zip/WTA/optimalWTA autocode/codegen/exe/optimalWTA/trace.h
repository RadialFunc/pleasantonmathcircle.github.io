//
// File: trace.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:56:32
//
#ifndef TRACE_H
#define TRACE_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "optimalWTA_types.h"

// Function Declarations
extern double trace(const emxArray_real_T *a);

#endif

//
// File trailer for trace.h
//
// [EOF]
//
