//
// File: mpower.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:56:32
//
#ifndef MPOWER_H
#define MPOWER_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "optimalWTA_types.h"

// Function Declarations
extern double mpower(double a, double b);

#endif

//
// File trailer for mpower.h
//
// [EOF]
//
