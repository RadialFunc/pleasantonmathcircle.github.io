//
// File: mpower.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:56:32
//

// Include Files
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "mpower.h"
#include "optimalWTA_rtwutil.h"

// Function Definitions

//
// Arguments    : double a
//                double b
// Return Type  : double
//
double mpower(double a, double b)
{
  return rt_powd_snf(a, b);
}

//
// File trailer for mpower.cpp
//
// [EOF]
//
