//
// File: optimalWTA_terminate.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:56:32
//

// Include Files
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "optimalWTA_terminate.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void optimalWTA_terminate()
{
  // (no terminate code required)
}

//
// File trailer for optimalWTA_terminate.cpp
//
// [EOF]
//
