//
// File: sum.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:56:32
//
#ifndef SUM_H
#define SUM_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "optimalWTA_types.h"

// Function Declarations
extern void b_sum(const emxArray_real_T *x, emxArray_real_T *y);
extern double c_sum(const emxArray_real_T *x);
extern double d_sum(const emxArray_boolean_T *x);
extern double e_sum(const emxArray_boolean_T *x);
extern double sum(const emxArray_real_T *x);

#endif

//
// File trailer for sum.h
//
// [EOF]
//
