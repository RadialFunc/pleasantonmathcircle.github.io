//
// File: optimalWTA.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:56:32
//

// Include Files
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "optimalWTA_emxutil.h"
#include "sum.h"
#include "munkres.h"
#include "floor.h"
#include "optimalWTA_rtwutil.h"

// Function Definitions

//
// lethality is the vector of object lethalities
//  reachMat is the reachability matrix
//  pKill is the probability of a KV eliminating the object's lethality once
//        it has been assigned to that object
//  maxKV is the maximum number of KVs allowed to assign to a single object
//
//  fAssign is the (#KV x #Ojb) assignment matrix
//  fLeak is the total lethality leakage for fAssign
//
//  Author: G. Chiang
//  Date: 3/29/2016
// Arguments    : const emxArray_real_T *lethality
//                const emxArray_real_T *reachMat
//                const emxArray_real_T *pKill
//                double maxKV
//                emxArray_real_T *fAssign
//                double *fLeak
//                double *totalReach
// Return Type  : void
//
void optimalWTA(const emxArray_real_T *lethality, const emxArray_real_T
                *reachMat, const emxArray_real_T *pKill, double maxKV,
                emxArray_real_T *fAssign, double *fLeak, double *totalReach)
{
  int subs_idx_0;
  int N;
  int i0;
  int b_N;
  emxArray_real_T *S;
  emxArray_real_T *Q;
  int idx;
  emxArray_real_T *goodInd;
  unsigned int kp;
  int nx;
  double smak;
  emxArray_int32_T *ii;
  boolean_T exitg1;
  emxArray_int32_T *r0;
  emxArray_int32_T *b_ii;
  emxArray_real_T *b_Q;
  emxArray_real_T *aKV;
  int i1;
  emxArray_real_T *varargin_2;
  emxArray_uint32_T *objPTR;
  emxArray_real_T *wrongJ;
  emxArray_boolean_T *x;
  emxArray_int32_T *j;
  boolean_T guard1 = false;
  subs_idx_0 = reachMat->size[0];
  N = reachMat->size[1];
  i0 = fAssign->size[0] * fAssign->size[1];
  fAssign->size[1] = N;
  fAssign->size[0] = subs_idx_0;
  emxEnsureCapacity_real_T(fAssign, i0);
  b_N = N * subs_idx_0;
  for (i0 = 0; i0 < b_N; i0++) {
    fAssign->data[i0] = 0.0;
  }

  emxInit_real_T(&S, 2);
  i0 = S->size[0] * S->size[1];
  S->size[1] = reachMat->size[1];
  S->size[0] = reachMat->size[0];
  emxEnsureCapacity_real_T(S, i0);
  b_N = reachMat->size[1] * reachMat->size[0];
  for (i0 = 0; i0 < b_N; i0++) {
    S->data[i0] = reachMat->data[i0];
  }

  b_floor(S);
  subs_idx_0 = S->size[0];
  N = S->size[1];
  emxInit_real_T(&Q, 2);
  i0 = Q->size[0] * Q->size[1];
  Q->size[1] = N;
  Q->size[0] = subs_idx_0;
  emxEnsureCapacity_real_T(Q, i0);
  N = subs_idx_0;
  for (idx = 0; idx < N; idx++) {
    b_N = Q->size[1];
    if (0 <= b_N - 1) {
      subs_idx_0 = idx + 1;
    }

    for (nx = 0; nx < b_N; nx++) {
      smak = S->data[nx + S->size[1] * (subs_idx_0 - 1)];
      if ((1.0 < smak) || rtIsNaN(smak)) {
        Q->data[nx + Q->size[1] * (subs_idx_0 - 1)] = 1.0;
      } else {
        Q->data[nx + Q->size[1] * (subs_idx_0 - 1)] = smak;
      }
    }
  }

  emxInit_real_T(&goodInd, 1);
  N = Q->size[0];
  b_N = Q->size[1];
  kp = (unsigned int)Q->size[0];
  i0 = goodInd->size[0];
  goodInd->size[0] = (int)kp;
  emxEnsureCapacity_real_T(goodInd, i0);
  if (Q->size[0] >= 1) {
    for (nx = 0; nx < N; nx++) {
      goodInd->data[nx] = Q->data[Q->size[1] * nx];
      for (idx = 2; idx <= b_N; idx++) {
        if (goodInd->data[nx] < Q->data[(idx + Q->size[1] * nx) - 1]) {
          goodInd->data[nx] = Q->data[(idx + Q->size[1] * nx) - 1];
        }
      }
    }
  }

  emxInit_int32_T(&ii, 1);
  nx = goodInd->size[0];
  idx = 0;
  i0 = ii->size[0];
  ii->size[0] = goodInd->size[0];
  emxEnsureCapacity_int32_T(ii, i0);
  N = 0;
  exitg1 = false;
  while ((!exitg1) && (N <= nx - 1)) {
    if (goodInd->data[N] != 0.0) {
      idx++;
      ii->data[idx - 1] = N + 1;
      if (idx >= nx) {
        exitg1 = true;
      } else {
        N++;
      }
    } else {
      N++;
    }
  }

  emxInit_int32_T(&r0, 1);
  emxInit_int32_T(&b_ii, 1);
  if (goodInd->size[0] == 1) {
    if (idx == 0) {
      ii->size[0] = 0;
    }
  } else {
    if (1 > idx) {
      b_N = 0;
    } else {
      b_N = idx;
    }

    i0 = r0->size[0];
    r0->size[0] = b_N;
    emxEnsureCapacity_int32_T(r0, i0);
    for (i0 = 0; i0 < b_N; i0++) {
      r0->data[i0] = i0;
    }

    b_N = r0->size[0];
    i0 = b_ii->size[0];
    b_ii->size[0] = b_N;
    emxEnsureCapacity_int32_T(b_ii, i0);
    for (i0 = 0; i0 < b_N; i0++) {
      b_ii->data[i0] = ii->data[r0->data[i0]];
    }

    i0 = ii->size[0];
    ii->size[0] = b_ii->size[0];
    emxEnsureCapacity_int32_T(ii, i0);
    b_N = b_ii->size[0];
    for (i0 = 0; i0 < b_N; i0++) {
      ii->data[i0] = b_ii->data[i0];
    }
  }

  i0 = goodInd->size[0];
  goodInd->size[0] = ii->size[0];
  emxEnsureCapacity_real_T(goodInd, i0);
  b_N = ii->size[0];
  for (i0 = 0; i0 < b_N; i0++) {
    goodInd->data[i0] = ii->data[i0];
  }

  // exclude unassignable KVs from WTA
  if (goodInd->size[0] == 0) {
    *totalReach = 0.0;

    //  Matlab coder
    *fLeak = sum(lethality);
  } else {
    emxInit_real_T(&b_Q, 2);
    b_N = Q->size[1];
    i0 = b_Q->size[0] * b_Q->size[1];
    b_Q->size[1] = b_N;
    b_Q->size[0] = goodInd->size[0];
    emxEnsureCapacity_real_T(b_Q, i0);
    N = goodInd->size[0];
    for (i0 = 0; i0 < N; i0++) {
      for (i1 = 0; i1 < b_N; i1++) {
        b_Q->data[i1 + b_Q->size[1] * i0] = Q->data[i1 + Q->size[1] * ((int)
          goodInd->data[i0] - 1)];
      }
    }

    emxInit_real_T(&aKV, 2);
    emxInit_real_T(&varargin_2, 2);
    b_sum(b_Q, varargin_2);
    kp = (unsigned int)varargin_2->size[1];
    i0 = aKV->size[0] * aKV->size[1];
    aKV->size[1] = (int)kp;
    aKV->size[0] = 1;
    emxEnsureCapacity_real_T(aKV, i0);
    N = varargin_2->size[1];
    for (idx = 0; idx < N; idx++) {
      smak = varargin_2->data[idx];
      if ((maxKV < smak) || rtIsNaN(smak)) {
        aKV->data[idx] = maxKV;
      } else {
        aKV->data[idx] = smak;
      }
    }

    emxInit_uint32_T(&objPTR, 2);

    //  lethality is the vector of object lethalities
    //  aKV is the vector of total assignable KVs to each object
    //  pKill is the probability of a KV eliminating the object's lethality once 
    //        it has been assigned to that object
    //  Q is the binary reachability matrix
    //
    //  costMat is the cost matrix for Munkres algorithm
    //  objPTR is a vector mapping costMat columns to object IDs
    //
    //  Author: G. Chiang
    //  Date: 3/29/2016
    //
    //  Matlab coder
    smak = sum(aKV);
    i0 = objPTR->size[0] * objPTR->size[1];
    b_N = (int)smak;
    objPTR->size[1] = b_N;
    objPTR->size[0] = 1;
    emxEnsureCapacity_uint32_T(objPTR, i0);
    for (i0 = 0; i0 < b_N; i0++) {
      objPTR->data[i0] = 0U;
    }

    i0 = S->size[0] * S->size[1];
    S->size[1] = b_N;
    S->size[0] = Q->size[0];
    emxEnsureCapacity_real_T(S, i0);
    b_N *= Q->size[0];
    for (i0 = 0; i0 < b_N; i0++) {
      S->data[i0] = 0.0;
    }

    kp = 0U;
    i0 = lethality->size[1];
    emxInit_real_T(&wrongJ, 1);
    for (nx = 0; nx < i0; nx++) {
      i1 = (int)aKV->data[nx];
      for (idx = 0; idx < i1; idx++) {
        kp++;

        //  Matlab coder
        smak = pKill->data[nx] * lethality->data[nx] * rt_powd_snf(1.0 -
          pKill->data[nx], (1.0 + (double)idx) - 1.0);
        b_N = Q->size[0];
        subs_idx_0 = wrongJ->size[0];
        wrongJ->size[0] = b_N;
        emxEnsureCapacity_real_T(wrongJ, subs_idx_0);
        for (subs_idx_0 = 0; subs_idx_0 < b_N; subs_idx_0++) {
          wrongJ->data[subs_idx_0] = smak * Q->data[nx + Q->size[1] * subs_idx_0];
        }

        N = wrongJ->size[0];
        for (subs_idx_0 = 0; subs_idx_0 < N; subs_idx_0++) {
          S->data[((int)kp + S->size[1] * subs_idx_0) - 1] = wrongJ->
            data[subs_idx_0];
        }

        //  Matlab coder
        objPTR->data[(int)kp - 1] = (unsigned int)(1 + nx);

        //  Matlab coder
      }
    }

    emxFree_real_T(&aKV);
    i0 = b_Q->size[0] * b_Q->size[1];
    b_Q->size[1] = S->size[1];
    b_Q->size[0] = S->size[0];
    emxEnsureCapacity_real_T(b_Q, i0);
    b_N = S->size[1] * S->size[0];
    for (i0 = 0; i0 < b_N; i0++) {
      b_Q->data[i0] = 1.0 - S->data[i0];
    }

    munkres(b_Q, varargin_2, &smak);
    i0 = goodInd->size[0];
    emxFree_real_T(&b_Q);
    for (nx = 0; nx < i0; nx++) {
      if (varargin_2->data[nx] != 0.0) {
        fAssign->data[((int)objPTR->data[(int)varargin_2->data[nx] - 1] +
                       fAssign->size[1] * ((int)goodInd->data[nx] - 1)) - 1] =
          1.0;
      }
    }

    emxFree_uint32_T(&objPTR);
    emxInit_boolean_T(&x, 2);

    //  Remove the KVs that have been WRONGLY assigned
    i0 = x->size[0] * x->size[1];
    x->size[1] = fAssign->size[1];
    x->size[0] = fAssign->size[0];
    emxEnsureCapacity_boolean_T(x, i0);
    b_N = fAssign->size[1] * fAssign->size[0];
    for (i0 = 0; i0 < b_N; i0++) {
      x->data[i0] = ((fAssign->data[i0] == 1.0) && (Q->data[i0] == 0.0));
    }

    nx = x->size[0] * x->size[1];
    emxInit_int32_T(&j, 1);
    if (nx == 0) {
      ii->size[0] = 0;
      j->size[0] = 0;
    } else {
      idx = 0;
      i0 = ii->size[0];
      ii->size[0] = nx;
      emxEnsureCapacity_int32_T(ii, i0);
      i0 = j->size[0];
      j->size[0] = nx;
      emxEnsureCapacity_int32_T(j, i0);
      N = 1;
      b_N = 1;
      exitg1 = false;
      while ((!exitg1) && (b_N <= x->size[1])) {
        guard1 = false;
        if (x->data[(b_N + x->size[1] * (N - 1)) - 1]) {
          idx++;
          ii->data[idx - 1] = N;
          j->data[idx - 1] = b_N;
          if (idx >= nx) {
            exitg1 = true;
          } else {
            guard1 = true;
          }
        } else {
          guard1 = true;
        }

        if (guard1) {
          N++;
          if (N > x->size[0]) {
            N = 1;
            b_N++;
          }
        }
      }

      if (nx == 1) {
        if (idx == 0) {
          ii->size[0] = 0;
          j->size[0] = 0;
        }
      } else {
        if (1 > idx) {
          b_N = 0;
        } else {
          b_N = idx;
        }

        i0 = r0->size[0];
        r0->size[0] = b_N;
        emxEnsureCapacity_int32_T(r0, i0);
        for (i0 = 0; i0 < b_N; i0++) {
          r0->data[i0] = i0;
        }

        b_N = r0->size[0];
        i0 = b_ii->size[0];
        b_ii->size[0] = b_N;
        emxEnsureCapacity_int32_T(b_ii, i0);
        for (i0 = 0; i0 < b_N; i0++) {
          b_ii->data[i0] = ii->data[r0->data[i0]];
        }

        i0 = ii->size[0];
        ii->size[0] = b_ii->size[0];
        emxEnsureCapacity_int32_T(ii, i0);
        b_N = b_ii->size[0];
        for (i0 = 0; i0 < b_N; i0++) {
          ii->data[i0] = b_ii->data[i0];
        }

        if (1 > idx) {
          b_N = 0;
        } else {
          b_N = idx;
        }

        i0 = r0->size[0];
        r0->size[0] = b_N;
        emxEnsureCapacity_int32_T(r0, i0);
        for (i0 = 0; i0 < b_N; i0++) {
          r0->data[i0] = i0;
        }

        b_N = r0->size[0];
        i0 = b_ii->size[0];
        b_ii->size[0] = b_N;
        emxEnsureCapacity_int32_T(b_ii, i0);
        for (i0 = 0; i0 < b_N; i0++) {
          b_ii->data[i0] = j->data[r0->data[i0]];
        }

        i0 = j->size[0];
        j->size[0] = b_ii->size[0];
        emxEnsureCapacity_int32_T(j, i0);
        b_N = b_ii->size[0];
        for (i0 = 0; i0 < b_N; i0++) {
          j->data[i0] = b_ii->data[i0];
        }
      }
    }

    emxFree_boolean_T(&x);
    i0 = goodInd->size[0];
    goodInd->size[0] = ii->size[0];
    emxEnsureCapacity_real_T(goodInd, i0);
    b_N = ii->size[0];
    for (i0 = 0; i0 < b_N; i0++) {
      goodInd->data[i0] = ii->data[i0];
    }

    i0 = wrongJ->size[0];
    wrongJ->size[0] = j->size[0];
    emxEnsureCapacity_real_T(wrongJ, i0);
    b_N = j->size[0];
    for (i0 = 0; i0 < b_N; i0++) {
      wrongJ->data[i0] = j->data[i0];
    }

    emxFree_int32_T(&j);
    i0 = goodInd->size[0];
    for (nx = 0; nx < i0; nx++) {
      fAssign->data[((int)wrongJ->data[nx] + fAssign->size[1] * ((int)
        goodInd->data[nx] - 1)) - 1] = 0.0;
    }

    b_sum(fAssign, varargin_2);

    //  lethality is the vector of object lethalities
    //  KVsAssigned is a vector that indicates how many KVs have been assigned
    //        to each object
    //  pKill is the probability of a KV eliminating the object's lethality once 
    //        it has been assigned to that object
    //
    //  leakageVector is the leakage from each object computed as
    //      leakageVector(i) =  lethality(i) * (1.0 - pKill(i)) ^ KVsAssigned(i) 
    //
    //  pLeakage is the leakage (or probability of leakage) computed as
    //      pLeakage = sum(  leakageVector  )
    //
    //  Author: G. Chiang
    //  Date: 3/29/2016
    //
    i0 = goodInd->size[0];
    goodInd->size[0] = pKill->size[1];
    emxEnsureCapacity_real_T(goodInd, i0);
    b_N = pKill->size[1];
    for (i0 = 0; i0 < b_N; i0++) {
      goodInd->data[i0] = 1.0 - pKill->data[i0];
    }

    if (goodInd->size[0] <= varargin_2->size[1]) {
      N = goodInd->size[0];
    } else {
      N = varargin_2->size[1];
    }

    i0 = wrongJ->size[0];
    wrongJ->size[0] = N;
    emxEnsureCapacity_real_T(wrongJ, i0);
    for (idx = 0; idx < N; idx++) {
      wrongJ->data[idx] = rt_powd_snf(goodInd->data[idx], varargin_2->data[idx]);
    }

    emxFree_real_T(&varargin_2);

    //  make leakageVector a row vector.
    i0 = goodInd->size[0];
    goodInd->size[0] = lethality->size[1];
    emxEnsureCapacity_real_T(goodInd, i0);
    b_N = lethality->size[1];
    for (i0 = 0; i0 < b_N; i0++) {
      goodInd->data[i0] = lethality->data[i0] * wrongJ->data[i0];
    }

    *fLeak = c_sum(goodInd);
    i0 = S->size[0] * S->size[1];
    S->size[1] = fAssign->size[1];
    S->size[0] = fAssign->size[0];
    emxEnsureCapacity_real_T(S, i0);
    b_N = fAssign->size[1] * fAssign->size[0];
    for (i0 = 0; i0 < b_N; i0++) {
      S->data[i0] = fAssign->data[i0] * reachMat->data[i0];
    }

    //  Matlab coder
    N = S->size[0] * S->size[1];
    i0 = 0;
    i1 = 0;
    subs_idx_0 = 0;
    b_N = wrongJ->size[0];
    wrongJ->size[0] = N;
    emxEnsureCapacity_real_T(wrongJ, b_N);
    for (b_N = 0; b_N < N; b_N++) {
      wrongJ->data[i0] = S->data[subs_idx_0 + S->size[1] * i1];
      i0++;
      i1++;
      if (i1 > S->size[0] - 1) {
        i1 = 0;
        subs_idx_0++;
      }
    }

    *totalReach = c_sum(wrongJ);

    //  Matlab coder
    emxFree_real_T(&wrongJ);
  }

  emxFree_int32_T(&b_ii);
  emxFree_real_T(&S);
  emxFree_int32_T(&r0);
  emxFree_int32_T(&ii);
  emxFree_real_T(&goodInd);
  emxFree_real_T(&Q);
}

//
// File trailer for optimalWTA.cpp
//
// [EOF]
//
