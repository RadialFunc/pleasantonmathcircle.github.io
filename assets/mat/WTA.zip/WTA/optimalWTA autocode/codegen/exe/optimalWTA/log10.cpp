//
// File: log10.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:56:32
//

// Include Files
#include <cmath>
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "log10.h"

// Function Definitions

//
// Arguments    : double *x
// Return Type  : void
//
void b_log10(double *x)
{
  *x = std::log10(*x);
}

//
// File trailer for log10.cpp
//
// [EOF]
//
