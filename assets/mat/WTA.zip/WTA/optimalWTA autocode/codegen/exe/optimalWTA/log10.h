//
// File: log10.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:56:32
//
#ifndef LOG10_H
#define LOG10_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "optimalWTA_types.h"

// Function Declarations
extern void b_log10(double *x);

#endif

//
// File trailer for log10.h
//
// [EOF]
//
