//
// File: nullAssignment.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:56:32
//

// Include Files
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "nullAssignment.h"
#include "optimalWTA_emxutil.h"

// Function Definitions

//
// Arguments    : emxArray_real_T *x
//                const emxArray_boolean_T *idx
// Return Type  : void
//
void b_nullAssignment(emxArray_real_T *x, const emxArray_boolean_T *idx)
{
  int nxin;
  int nxout;
  int k0;
  int k;
  emxArray_int32_T *r21;
  emxArray_real_T *b_x;
  nxin = x->size[1];
  nxout = 0;
  k0 = idx->size[0];
  for (k = 0; k < k0; k++) {
    nxout += idx->data[k];
  }

  nxout = x->size[1] - nxout;
  k0 = -1;
  for (k = 0; k < nxin; k++) {
    if ((k + 1 > idx->size[0]) || (!idx->data[k])) {
      k0++;
      x->data[k0] = x->data[k];
    }
  }

  if (1 > nxout) {
    nxout = 0;
  }

  emxInit_int32_T(&r21, 1);
  k0 = r21->size[0];
  r21->size[0] = nxout;
  emxEnsureCapacity_int32_T(r21, k0);
  for (k0 = 0; k0 < nxout; k0++) {
    r21->data[k0] = k0;
  }

  emxInit_real_T(&b_x, 2);
  nxout = r21->size[0];
  k0 = b_x->size[0] * b_x->size[1];
  b_x->size[1] = nxout;
  b_x->size[0] = 1;
  emxEnsureCapacity_real_T(b_x, k0);
  for (k0 = 0; k0 < nxout; k0++) {
    b_x->data[k0] = x->data[r21->data[k0]];
  }

  emxFree_int32_T(&r21);
  k0 = x->size[0] * x->size[1];
  x->size[1] = b_x->size[1];
  x->size[0] = 1;
  emxEnsureCapacity_real_T(x, k0);
  nxout = b_x->size[1];
  for (k0 = 0; k0 < nxout; k0++) {
    x->data[k0] = b_x->data[k0];
  }

  emxFree_real_T(&b_x);
}

//
// Arguments    : emxArray_real_T *x
//                const emxArray_boolean_T *idx
// Return Type  : void
//
void nullAssignment(emxArray_real_T *x, const emxArray_boolean_T *idx)
{
  int nxin;
  int k0;
  int i17;
  int k;
  int nxout;
  nxin = x->size[0];
  k0 = 0;
  i17 = idx->size[0];
  for (k = 0; k < i17; k++) {
    k0 += idx->data[k];
  }

  nxout = x->size[0] - k0;
  k0 = -1;
  for (k = 0; k < nxin; k++) {
    if ((k + 1 > idx->size[0]) || (!idx->data[k])) {
      k0++;
      x->data[k0] = x->data[k];
    }
  }

  if (1 > nxout) {
    x->size[0] = 0;
  } else {
    i17 = x->size[0];
    x->size[0] = nxout;
    emxEnsureCapacity_real_T(x, i17);
  }
}

//
// File trailer for nullAssignment.cpp
//
// [EOF]
//
