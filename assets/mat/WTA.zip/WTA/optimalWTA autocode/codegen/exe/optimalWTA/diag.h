//
// File: diag.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:56:32
//
#ifndef DIAG_H
#define DIAG_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "optimalWTA_types.h"

// Function Declarations
extern void diag(const emxArray_boolean_T *v, emxArray_boolean_T *d);

#endif

//
// File trailer for diag.h
//
// [EOF]
//
