//
// File: optimalWTA.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:50:40
//
#ifndef OPTIMALWTA_H
#define OPTIMALWTA_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "optimalWTA_types.h"

// Function Declarations
extern void optimalWTA(const emxArray_real_T *lethality, const emxArray_real_T
  *reachMat, const emxArray_real_T *pKill, double maxKV, emxArray_real_T
  *fAssign, double *fLeak, double *totalReach);

#endif

//
// File trailer for optimalWTA.h
//
// [EOF]
//
