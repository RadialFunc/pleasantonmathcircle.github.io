//
// File: munkres.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:50:40
//

// Include Files
#include "rt_nonfinite.h"
#include <cmath>
#include <string.h>
#include "optimalWTA.h"
#include "munkres.h"
#include "optimalWTA_emxutil.h"
#include "trace.h"
#include "diag.h"
#include "sum.h"
#include "nullAssignment.h"
#include "bsxfun.h"
#include "all.h"
#include "any1.h"
#include "mpower.h"
#include "log10.h"

// Function Declarations
static void outerplus(emxArray_real_T *M, const emxArray_real_T *x, const
                      emxArray_real_T *y, double *minval, emxArray_real_T *rIdx,
                      emxArray_real_T *cIdx);

// Function Definitions

//
// Arguments    : emxArray_real_T *M
//                const emxArray_real_T *x
//                const emxArray_real_T *y
//                double *minval
//                emxArray_real_T *rIdx
//                emxArray_real_T *cIdx
// Return Type  : void
//
static void outerplus(emxArray_real_T *M, const emxArray_real_T *x, const
                      emxArray_real_T *y, double *minval, emxArray_real_T *rIdx,
                      emxArray_real_T *cIdx)
{
  int i12;
  emxArray_real_T *r18;
  emxArray_real_T *r19;
  int nx;
  int ii;
  double b_y;
  emxArray_boolean_T *b_x;
  int i13;
  emxArray_int32_T *i;
  emxArray_int32_T *j;
  int idx;
  int jj;
  boolean_T exitg2;
  int exitg1;
  boolean_T guard1 = false;
  emxArray_int32_T *r20;
  emxArray_int32_T *b_i;
  *minval = rtInf;
  i12 = M->size[1];
  emxInit_real_T(&r18, 1);
  emxInit_real_T(&r19, 2);
  for (nx = 0; nx < i12; nx++) {
    ii = M->size[0];
    b_y = y->data[nx];
    i13 = r18->size[0];
    r18->size[0] = ii;
    emxEnsureCapacity_real_T(r18, i13);
    for (i13 = 0; i13 < ii; i13++) {
      r18->data[i13] = M->data[nx + M->size[1] * i13] - (x->data[i13] + b_y);
    }

    ii = r18->size[0];
    for (i13 = 0; i13 < ii; i13++) {
      M->data[nx + M->size[1] * i13] = r18->data[i13];
    }

    ii = M->size[0];
    i13 = r19->size[0] * r19->size[1];
    r19->size[1] = 1;
    r19->size[0] = ii;
    emxEnsureCapacity_real_T(r19, i13);
    for (i13 = 0; i13 < ii; i13++) {
      r19->data[i13] = M->data[nx + M->size[1] * i13];
    }

    i13 = M->size[0];
    ii = M->size[0];
    if (ii <= 2) {
      i13 = M->size[0];
      if (i13 == 1) {
        b_y = M->data[nx];
      } else if ((M->data[nx] > M->data[nx + M->size[1]]) || (rtIsNaN(M->data[nx])
                  && (!rtIsNaN(M->data[nx + M->size[1]])))) {
        b_y = M->data[nx + M->size[1]];
      } else {
        b_y = M->data[nx];
      }
    } else {
      if (!rtIsNaN(M->data[nx])) {
        idx = 1;
      } else {
        idx = 0;
        jj = 2;
        do {
          exitg1 = 0;
          ii = M->size[0];
          if (jj <= ii) {
            if (!rtIsNaN(r19->data[jj - 1])) {
              idx = jj;
              exitg1 = 1;
            } else {
              jj++;
            }
          } else {
            exitg1 = 1;
          }
        } while (exitg1 == 0);
      }

      if (idx == 0) {
        b_y = M->data[nx];
      } else {
        b_y = M->data[nx + M->size[1] * (idx - 1)];
        ii = idx + 1;
        for (jj = ii; jj <= i13; jj++) {
          if (b_y > r19->data[jj - 1]) {
            b_y = r19->data[jj - 1];
          }
        }
      }
    }

    if ((!(*minval < b_y)) && (!rtIsNaN(b_y))) {
      *minval = b_y;
    }
  }

  emxFree_real_T(&r19);
  emxFree_real_T(&r18);
  emxInit_boolean_T(&b_x, 2);
  i12 = b_x->size[0] * b_x->size[1];
  b_x->size[1] = M->size[1];
  b_x->size[0] = M->size[0];
  emxEnsureCapacity_boolean_T(b_x, i12);
  ii = M->size[1] * M->size[0];
  for (i12 = 0; i12 < ii; i12++) {
    b_x->data[i12] = (M->data[i12] == *minval);
  }

  nx = b_x->size[0] * b_x->size[1];
  emxInit_int32_T(&i, 1);
  emxInit_int32_T(&j, 1);
  if (nx == 0) {
    i->size[0] = 0;
    j->size[0] = 0;
  } else {
    idx = 0;
    i12 = i->size[0];
    i->size[0] = nx;
    emxEnsureCapacity_int32_T(i, i12);
    i12 = j->size[0];
    j->size[0] = nx;
    emxEnsureCapacity_int32_T(j, i12);
    ii = 1;
    jj = 1;
    exitg2 = false;
    while ((!exitg2) && (jj <= b_x->size[1])) {
      guard1 = false;
      if (b_x->data[(jj + b_x->size[1] * (ii - 1)) - 1]) {
        idx++;
        i->data[idx - 1] = ii;
        j->data[idx - 1] = jj;
        if (idx >= nx) {
          exitg2 = true;
        } else {
          guard1 = true;
        }
      } else {
        guard1 = true;
      }

      if (guard1) {
        ii++;
        if (ii > b_x->size[0]) {
          ii = 1;
          jj++;
        }
      }
    }

    if (nx == 1) {
      if (idx == 0) {
        i->size[0] = 0;
        j->size[0] = 0;
      }
    } else {
      if (1 > idx) {
        ii = 0;
      } else {
        ii = idx;
      }

      emxInit_int32_T(&r20, 1);
      i12 = r20->size[0];
      r20->size[0] = ii;
      emxEnsureCapacity_int32_T(r20, i12);
      for (i12 = 0; i12 < ii; i12++) {
        r20->data[i12] = i12;
      }

      emxInit_int32_T(&b_i, 1);
      ii = r20->size[0];
      i12 = b_i->size[0];
      b_i->size[0] = ii;
      emxEnsureCapacity_int32_T(b_i, i12);
      for (i12 = 0; i12 < ii; i12++) {
        b_i->data[i12] = i->data[r20->data[i12]];
      }

      i12 = i->size[0];
      i->size[0] = b_i->size[0];
      emxEnsureCapacity_int32_T(i, i12);
      ii = b_i->size[0];
      for (i12 = 0; i12 < ii; i12++) {
        i->data[i12] = b_i->data[i12];
      }

      if (1 > idx) {
        ii = 0;
      } else {
        ii = idx;
      }

      i12 = r20->size[0];
      r20->size[0] = ii;
      emxEnsureCapacity_int32_T(r20, i12);
      for (i12 = 0; i12 < ii; i12++) {
        r20->data[i12] = i12;
      }

      ii = r20->size[0];
      i12 = b_i->size[0];
      b_i->size[0] = ii;
      emxEnsureCapacity_int32_T(b_i, i12);
      for (i12 = 0; i12 < ii; i12++) {
        b_i->data[i12] = j->data[r20->data[i12]];
      }

      emxFree_int32_T(&r20);
      i12 = j->size[0];
      j->size[0] = b_i->size[0];
      emxEnsureCapacity_int32_T(j, i12);
      ii = b_i->size[0];
      for (i12 = 0; i12 < ii; i12++) {
        j->data[i12] = b_i->data[i12];
      }

      emxFree_int32_T(&b_i);
    }
  }

  emxFree_boolean_T(&b_x);
  i12 = rIdx->size[0];
  rIdx->size[0] = i->size[0];
  emxEnsureCapacity_real_T(rIdx, i12);
  ii = i->size[0];
  for (i12 = 0; i12 < ii; i12++) {
    rIdx->data[i12] = i->data[i12];
  }

  emxFree_int32_T(&i);
  i12 = cIdx->size[0];
  cIdx->size[0] = j->size[0];
  emxEnsureCapacity_real_T(cIdx, i12);
  ii = j->size[0];
  for (i12 = 0; i12 < ii; i12++) {
    cIdx->data[i12] = j->data[i12];
  }

  emxFree_int32_T(&j);
}

//
// MUNKRES   Munkres (Hungarian) Algorithm for Linear Assignment Problem.
//
//  [ASSIGN,COST] = munkres(COSTMAT) returns the optimal column indices,
//  ASSIGN assigned to each row and the minimum COST based on the assignment
//  problem represented by the COSTMAT, where the (i,j)th element represents the cost to assign the jth
//  job to the ith worker.
//
//  Partial assignment: This code can identify a partial assignment is a full
//  assignment is not feasible. For a partial assignment, there are some
//  zero elements in the returning assignment vector, which indicate
//  un-assigned tasks. The cost returned only contains the cost of partially
//  assigned tasks.
// Arguments    : emxArray_real_T *costMat
//                emxArray_real_T *assignment
//                double *cost
// Return Type  : void
//
void munkres(emxArray_real_T *costMat, emxArray_real_T *assignment, double *cost)
{
  int i3;
  int loop_ub;
  emxArray_boolean_T *r1;
  emxArray_boolean_T *r2;
  int n;
  boolean_T b0;
  boolean_T b1;
  int i4;
  boolean_T b2;
  boolean_T b3;
  int i5;
  int idx;
  int i;
  emxArray_int32_T *r3;
  int jj;
  int m;
  emxArray_real_T *minR;
  double bigM;
  emxArray_int32_T *ii;
  emxArray_boolean_T *r4;
  emxArray_boolean_T *validCol;
  emxArray_boolean_T *validRow;
  double nRows;
  double nCols;
  double b_n;
  emxArray_int32_T *j;
  emxArray_real_T *rIdx;
  int exitg1;
  emxArray_real_T *dMat;
  emxArray_int32_T *b_ii;
  emxArray_int32_T *c_ii;
  unsigned int dMat_idx_0;
  emxArray_real_T *minC;
  emxArray_real_T *varargin_1;
  boolean_T p;
  emxArray_boolean_T *zP;
  double uZr;
  emxArray_real_T *starZ;
  emxArray_boolean_T *z;
  emxArray_boolean_T *coverColumn;
  emxArray_boolean_T *coverRow;
  emxArray_real_T *primeZ;
  emxArray_real_T *cIdx;
  emxArray_uint32_T *cR;
  emxArray_uint32_T *cC;
  emxArray_real_T *b_cIdx;
  boolean_T exitg2;
  emxArray_int32_T *r5;
  emxArray_int32_T *r6;
  emxArray_int32_T *r7;
  emxArray_int32_T *r8;
  emxArray_int32_T *r9;
  emxArray_int32_T *r10;
  emxArray_int32_T *r11;
  emxArray_int32_T *r12;
  emxArray_int32_T *r13;
  int r_data[1];
  emxArray_int32_T *r14;
  emxArray_boolean_T *x;
  emxArray_boolean_T *b_starZ;
  emxArray_real_T *b_minR;
  int c_data[1];
  emxArray_real_T *b_minC;
  emxArray_int32_T *d_ii;
  emxArray_real_T *c_minC;
  emxArray_uint32_T *pass;
  emxArray_int32_T *r15;
  boolean_T guard1 = false;
  int exitg3;
  emxArray_int32_T *r16;
  emxArray_int32_T *r17;
  double uZc;
  int Step;
  boolean_T exitg4;

  //  This is vectorized implementation of the algorithm. It is the fastest
  //  among all Matlab implementations of the algorithm.
  //  Examples
  //  Example 1: a 5 x 5 example
  // {
  // [assignment,cost] = munkres(magic(5));
  // disp(assignment); % 3 2 1 5 4
  // disp(cost); %15
  // }
  //  Example 2: 400 x 400 random data
  // {
  // n=400;
  // A=rand(n);
  // tic
  // [a,b]=munkres(A);
  // toc                 % about 2 seconds
  // }
  //  Example 3: rectangular assignment with inf costs
  // {
  // A=rand(10,7);
  // A(A>0.7)=Inf;
  // [a,b]=munkres(A);
  // }
  //  Example 4: an example of partial assignment
  // {
  // A = [1 3 Inf; Inf Inf 5; Inf Inf 0.5];
  // [a,b]=munkres(A)
  // }
  //  a = [1 0 3]
  //  b = 1.5
  //  Reference:
  //  "Munkres' Assignment Algorithm, Modified for Rectangular Matrices",
  //  http://csclab.murraystate.edu/bob.pilgrim/445/munkres.html
  //  version 2.3 by Yi Cao at Cranfield University on 11th September 2011
  i3 = assignment->size[0] * assignment->size[1];
  assignment->size[1] = costMat->size[0];
  assignment->size[0] = 1;
  emxEnsureCapacity_real_T(assignment, i3);
  loop_ub = costMat->size[0];
  for (i3 = 0; i3 < loop_ub; i3++) {
    assignment->data[i3] = 0.0;
  }

  emxInit_boolean_T(&r1, 2);
  *cost = 0.0;
  i3 = r1->size[0] * r1->size[1];
  r1->size[1] = costMat->size[1];
  r1->size[0] = costMat->size[0];
  emxEnsureCapacity_boolean_T(r1, i3);
  loop_ub = costMat->size[1] * costMat->size[0];
  for (i3 = 0; i3 < loop_ub; i3++) {
    r1->data[i3] = (costMat->data[i3] == costMat->data[i3]);
  }

  emxInit_boolean_T(&r2, 2);
  i3 = r2->size[0] * r2->size[1];
  r2->size[1] = costMat->size[1];
  r2->size[0] = costMat->size[0];
  emxEnsureCapacity_boolean_T(r2, i3);
  loop_ub = costMat->size[1] * costMat->size[0];
  for (i3 = 0; i3 < loop_ub; i3++) {
    r2->data[i3] = (costMat->data[i3] < rtInf);
  }

  loop_ub = r1->size[0] * r1->size[1] - 1;
  n = 0;
  b0 = true;
  b1 = ((r1->size[1] <= 0) || (r1->size[0] <= 0));
  i3 = r1->size[1] * r1->size[0];
  i4 = 0;
  b2 = true;
  b3 = ((r2->size[1] <= 0) || (r2->size[0] <= 0));
  i5 = r2->size[1] * r2->size[0];
  idx = 0;
  for (i = 0; i <= loop_ub; i++) {
    if (b3 || (i >= i5)) {
      idx = 0;
      b2 = true;
    } else if (b2) {
      b2 = false;
      idx = r2->size[1];
      jj = r2->size[0];
      idx = i % jj * idx + i / jj;
    } else {
      jj = r2->size[1];
      m = jj * r2->size[0] - 1;
      if (idx > MAX_int32_T - jj) {
        idx = r2->size[1];
        jj = r2->size[0];
        idx = i % jj * idx + i / jj;
      } else {
        idx += jj;
        if (idx > m) {
          idx -= m;
        }
      }
    }

    if (b1 || (i >= i3)) {
      i4 = 0;
      b0 = true;
    } else if (b0) {
      b0 = false;
      i4 = r1->size[1];
      jj = r1->size[0];
      i4 = i % jj * i4 + i / jj;
    } else {
      jj = r1->size[1];
      m = jj * r1->size[0] - 1;
      if (i4 > MAX_int32_T - jj) {
        i4 = r1->size[1];
        jj = r1->size[0];
        i4 = i % jj * i4 + i / jj;
      } else {
        i4 += jj;
        if (i4 > m) {
          i4 -= m;
        }
      }
    }

    if (r1->data[i4] && r2->data[idx]) {
      n++;
    }
  }

  emxInit_int32_T(&r3, 1);
  i3 = r3->size[0];
  r3->size[0] = n;
  emxEnsureCapacity_int32_T(r3, i3);
  n = 0;
  b0 = true;
  b1 = ((r1->size[1] <= 0) || (r1->size[0] <= 0));
  i3 = r1->size[1] * r1->size[0];
  i4 = 0;
  b2 = true;
  b3 = ((r2->size[1] <= 0) || (r2->size[0] <= 0));
  i5 = r2->size[1] * r2->size[0];
  idx = 0;
  for (i = 0; i <= loop_ub; i++) {
    if (b3 || (i >= i5)) {
      idx = 0;
      b2 = true;
    } else if (b2) {
      b2 = false;
      idx = r2->size[1];
      jj = r2->size[0];
      idx = i % jj * idx + i / jj;
    } else {
      jj = r2->size[1];
      m = jj * r2->size[0] - 1;
      if (idx > MAX_int32_T - jj) {
        idx = r2->size[1];
        jj = r2->size[0];
        idx = i % jj * idx + i / jj;
      } else {
        idx += jj;
        if (idx > m) {
          idx -= m;
        }
      }
    }

    if (b1 || (i >= i3)) {
      i4 = 0;
      b0 = true;
    } else if (b0) {
      b0 = false;
      i4 = r1->size[1];
      jj = r1->size[0];
      i4 = i % jj * i4 + i / jj;
    } else {
      jj = r1->size[1];
      m = jj * r1->size[0] - 1;
      if (i4 > MAX_int32_T - jj) {
        i4 = r1->size[1];
        jj = r1->size[0];
        i4 = i % jj * i4 + i / jj;
      } else {
        i4 += jj;
        if (i4 > m) {
          i4 -= m;
        }
      }
    }

    if (r1->data[i4] && r2->data[idx]) {
      r3->data[n] = i + 1;
      n++;
    }
  }

  emxInit_real_T(&minR, 1);
  i3 = r3->size[0];
  emxEnsureCapacity_int32_T(r3, i3);
  loop_ub = r3->size[0];
  for (i3 = 0; i3 < loop_ub; i3++) {
    r3->data[i3]--;
  }

  i3 = costMat->size[1];
  i4 = costMat->size[0];
  i5 = minR->size[0];
  minR->size[0] = r3->size[0];
  emxEnsureCapacity_real_T(minR, i5);
  loop_ub = r3->size[0];
  for (i5 = 0; i5 < loop_ub; i5++) {
    minR->data[i5] = costMat->data[r3->data[i5] % i4 * i3 + r3->data[i5] / i4];
  }

  bigM = c_sum(minR);
  b_log10(&bigM);
  bigM = mpower(10.0, std::ceil(bigM) + 1.0);
  m = r1->size[1];
  jj = r1->size[0];
  loop_ub = jj * m - 1;
  n = 0;
  b0 = true;
  b1 = ((r1->size[1] <= 0) || (r1->size[0] <= 0));
  i3 = r1->size[1] * r1->size[0];
  i4 = 0;
  b2 = true;
  b3 = ((r2->size[1] <= 0) || (r2->size[0] <= 0));
  i5 = r2->size[1] * r2->size[0];
  idx = 0;
  for (i = 0; i <= loop_ub; i++) {
    if (b3 || (i >= i5)) {
      idx = 0;
      b2 = true;
    } else if (b2) {
      b2 = false;
      idx = r2->size[1];
      jj = r2->size[0];
      idx = i % jj * idx + i / jj;
    } else {
      jj = r2->size[1];
      m = jj * r2->size[0] - 1;
      if (idx > MAX_int32_T - jj) {
        idx = r2->size[1];
        jj = r2->size[0];
        idx = i % jj * idx + i / jj;
      } else {
        idx += jj;
        if (idx > m) {
          idx -= m;
        }
      }
    }

    if (b1 || (i >= i3)) {
      i4 = 0;
      b0 = true;
    } else if (b0) {
      b0 = false;
      i4 = r1->size[1];
      jj = r1->size[0];
      i4 = i % jj * i4 + i / jj;
    } else {
      jj = r1->size[1];
      m = jj * r1->size[0] - 1;
      if (i4 > MAX_int32_T - jj) {
        i4 = r1->size[1];
        jj = r1->size[0];
        i4 = i % jj * i4 + i / jj;
      } else {
        i4 += jj;
        if (i4 > m) {
          i4 -= m;
        }
      }
    }

    if ((!r1->data[i4]) || (!r2->data[idx])) {
      n++;
    }
  }

  emxInit_int32_T(&ii, 1);
  i3 = ii->size[0];
  ii->size[0] = n;
  emxEnsureCapacity_int32_T(ii, i3);
  n = 0;
  b0 = true;
  b1 = ((r1->size[1] <= 0) || (r1->size[0] <= 0));
  i3 = r1->size[1] * r1->size[0];
  i4 = 0;
  b2 = true;
  b3 = ((r2->size[1] <= 0) || (r2->size[0] <= 0));
  i5 = r2->size[1] * r2->size[0];
  idx = 0;
  for (i = 0; i <= loop_ub; i++) {
    if (b3 || (i >= i5)) {
      idx = 0;
      b2 = true;
    } else if (b2) {
      b2 = false;
      idx = r2->size[1];
      jj = r2->size[0];
      idx = i % jj * idx + i / jj;
    } else {
      jj = r2->size[1];
      m = jj * r2->size[0] - 1;
      if (idx > MAX_int32_T - jj) {
        idx = r2->size[1];
        jj = r2->size[0];
        idx = i % jj * idx + i / jj;
      } else {
        idx += jj;
        if (idx > m) {
          idx -= m;
        }
      }
    }

    if (b1 || (i >= i3)) {
      i4 = 0;
      b0 = true;
    } else if (b0) {
      b0 = false;
      i4 = r1->size[1];
      jj = r1->size[0];
      i4 = i % jj * i4 + i / jj;
    } else {
      jj = r1->size[1];
      m = jj * r1->size[0] - 1;
      if (i4 > MAX_int32_T - jj) {
        i4 = r1->size[1];
        jj = r1->size[0];
        i4 = i % jj * i4 + i / jj;
      } else {
        i4 += jj;
        if (i4 > m) {
          i4 -= m;
        }
      }
    }

    if ((!r1->data[i4]) || (!r2->data[idx])) {
      ii->data[n] = i + 1;
      n++;
    }
  }

  i3 = r3->size[0];
  r3->size[0] = ii->size[0];
  emxEnsureCapacity_int32_T(r3, i3);
  loop_ub = ii->size[0];
  for (i3 = 0; i3 < loop_ub; i3++) {
    r3->data[i3] = ii->data[i3] - 1;
  }

  i3 = costMat->size[1];
  i4 = costMat->size[0];
  loop_ub = ii->size[0] - 1;
  for (i5 = 0; i5 <= loop_ub; i5++) {
    costMat->data[r3->data[i5] % i4 * i3 + r3->data[i5] / i4] = bigM;
  }

  emxInit_boolean_T(&r4, 2);

  //  costMat(costMat~=costMat)=Inf;
  //  validMat = costMat<Inf;
  i3 = r4->size[0] * r4->size[1];
  r4->size[1] = r1->size[1];
  r4->size[0] = r1->size[0];
  emxEnsureCapacity_boolean_T(r4, i3);
  loop_ub = r1->size[1] * r1->size[0];
  for (i3 = 0; i3 < loop_ub; i3++) {
    r4->data[i3] = (r1->data[i3] && r2->data[i3]);
  }

  emxInit_boolean_T(&validCol, 2);
  any(r4, validCol);
  i3 = r4->size[0] * r4->size[1];
  r4->size[1] = r1->size[1];
  r4->size[0] = r1->size[0];
  emxEnsureCapacity_boolean_T(r4, i3);
  loop_ub = r1->size[1] * r1->size[0];
  for (i3 = 0; i3 < loop_ub; i3++) {
    r4->data[i3] = (r1->data[i3] && r2->data[i3]);
  }

  emxInit_boolean_T(&validRow, 1);
  b_any(r4, validRow);
  nRows = d_sum(validRow);
  nCols = e_sum(validCol);
  emxFree_boolean_T(&r4);
  if ((nRows > nCols) || rtIsNaN(nCols)) {
    b_n = nRows;
  } else {
    b_n = nCols;
  }

  if (b_n != 0.0) {
    loop_ub = r1->size[0] * r1->size[1] - 1;
    n = 0;
    b0 = true;
    b1 = ((r1->size[1] <= 0) || (r1->size[0] <= 0));
    i3 = r1->size[1] * r1->size[0];
    i4 = 0;
    b2 = true;
    b3 = ((r2->size[1] <= 0) || (r2->size[0] <= 0));
    i5 = r2->size[1] * r2->size[0];
    idx = 0;
    for (i = 0; i <= loop_ub; i++) {
      if (b3 || (i >= i5)) {
        idx = 0;
        b2 = true;
      } else if (b2) {
        b2 = false;
        idx = r2->size[1];
        jj = r2->size[0];
        idx = i % jj * idx + i / jj;
      } else {
        jj = r2->size[1];
        m = jj * r2->size[0] - 1;
        if (idx > MAX_int32_T - jj) {
          idx = r2->size[1];
          jj = r2->size[0];
          idx = i % jj * idx + i / jj;
        } else {
          idx += jj;
          if (idx > m) {
            idx -= m;
          }
        }
      }

      if (b1 || (i >= i3)) {
        i4 = 0;
        b0 = true;
      } else if (b0) {
        b0 = false;
        i4 = r1->size[1];
        jj = r1->size[0];
        i4 = i % jj * i4 + i / jj;
      } else {
        jj = r1->size[1];
        m = jj * r1->size[0] - 1;
        if (i4 > MAX_int32_T - jj) {
          i4 = r1->size[1];
          jj = r1->size[0];
          i4 = i % jj * i4 + i / jj;
        } else {
          i4 += jj;
          if (i4 > m) {
            i4 -= m;
          }
        }
      }

      if (r1->data[i4] && r2->data[idx]) {
        n++;
      }
    }

    emxInit_int32_T(&j, 1);
    i3 = j->size[0];
    j->size[0] = n;
    emxEnsureCapacity_int32_T(j, i3);
    n = 0;
    b0 = true;
    b1 = ((r1->size[1] <= 0) || (r1->size[0] <= 0));
    i3 = r1->size[1] * r1->size[0];
    i4 = 0;
    b2 = true;
    b3 = ((r2->size[1] <= 0) || (r2->size[0] <= 0));
    i5 = r2->size[1] * r2->size[0];
    idx = 0;
    for (i = 0; i <= loop_ub; i++) {
      if (b3 || (i >= i5)) {
        idx = 0;
        b2 = true;
      } else if (b2) {
        b2 = false;
        idx = r2->size[1];
        jj = r2->size[0];
        idx = i % jj * idx + i / jj;
      } else {
        jj = r2->size[1];
        m = jj * r2->size[0] - 1;
        if (idx > MAX_int32_T - jj) {
          idx = r2->size[1];
          jj = r2->size[0];
          idx = i % jj * idx + i / jj;
        } else {
          idx += jj;
          if (idx > m) {
            idx -= m;
          }
        }
      }

      if (b1 || (i >= i3)) {
        i4 = 0;
        b0 = true;
      } else if (b0) {
        b0 = false;
        i4 = r1->size[1];
        jj = r1->size[0];
        i4 = i % jj * i4 + i / jj;
      } else {
        jj = r1->size[1];
        m = jj * r1->size[0] - 1;
        if (i4 > MAX_int32_T - jj) {
          i4 = r1->size[1];
          jj = r1->size[0];
          i4 = i % jj * i4 + i / jj;
        } else {
          i4 += jj;
          if (i4 > m) {
            i4 -= m;
          }
        }
      }

      if (r1->data[i4] && r2->data[idx]) {
        j->data[n] = i + 1;
        n++;
      }
    }

    i3 = r3->size[0];
    r3->size[0] = j->size[0];
    emxEnsureCapacity_int32_T(r3, i3);
    loop_ub = j->size[0];
    for (i3 = 0; i3 < loop_ub; i3++) {
      r3->data[i3] = j->data[i3] - 1;
    }

    emxInit_real_T(&rIdx, 1);
    i3 = costMat->size[1];
    i4 = costMat->size[0];
    i5 = rIdx->size[0];
    rIdx->size[0] = r3->size[0];
    emxEnsureCapacity_real_T(rIdx, i5);
    loop_ub = r3->size[0];
    for (i5 = 0; i5 < loop_ub; i5++) {
      rIdx->data[i5] = costMat->data[r3->data[i5] % i4 * i3 + r3->data[i5] / i4];
    }

    i3 = r3->size[0];
    r3->size[0] = j->size[0];
    emxEnsureCapacity_int32_T(r3, i3);
    loop_ub = j->size[0];
    for (i3 = 0; i3 < loop_ub; i3++) {
      r3->data[i3] = j->data[i3] - 1;
    }

    i3 = costMat->size[1];
    i4 = costMat->size[0];
    i5 = r3->size[0];
    emxEnsureCapacity_int32_T(r3, i5);
    loop_ub = r3->size[0];
    for (i5 = 0; i5 < loop_ub; i5++) {
      r3->data[i5] = r3->data[i5] % i4 * i3 + r3->data[i5] / i4;
    }

    n = r3->size[0];
    i3 = r3->size[0];
    r3->size[0] = j->size[0];
    emxEnsureCapacity_int32_T(r3, i3);
    loop_ub = j->size[0];
    for (i3 = 0; i3 < loop_ub; i3++) {
      r3->data[i3] = j->data[i3] - 1;
    }

    i3 = costMat->size[1];
    i4 = costMat->size[0];
    i5 = r3->size[0];
    emxEnsureCapacity_int32_T(r3, i5);
    loop_ub = r3->size[0];
    for (i5 = 0; i5 < loop_ub; i5++) {
      r3->data[i5] = r3->data[i5] % i4 * i3 + r3->data[i5] / i4;
    }

    if (r3->size[0] <= 2) {
      i3 = j->size[0];
      emxEnsureCapacity_int32_T(j, i3);
      loop_ub = j->size[0];
      for (i3 = 0; i3 < loop_ub; i3++) {
        j->data[i3]--;
      }

      i3 = costMat->size[1];
      i4 = costMat->size[0];
      i5 = j->size[0];
      emxEnsureCapacity_int32_T(j, i5);
      loop_ub = j->size[0];
      for (i5 = 0; i5 < loop_ub; i5++) {
        j->data[i5] = j->data[i5] % i4 * i3 + j->data[i5] / i4;
      }

      if (j->size[0] == 1) {
        bigM = rIdx->data[0];
      } else if ((rIdx->data[0] < rIdx->data[1]) || (rtIsNaN(rIdx->data[0]) && (
                   !rtIsNaN(rIdx->data[1])))) {
        bigM = rIdx->data[1];
      } else {
        bigM = rIdx->data[0];
      }
    } else {
      if (!rtIsNaN(rIdx->data[0])) {
        idx = 1;
      } else {
        idx = 0;
        jj = 2;
        do {
          exitg1 = 0;
          i3 = r3->size[0];
          r3->size[0] = j->size[0];
          emxEnsureCapacity_int32_T(r3, i3);
          loop_ub = j->size[0];
          for (i3 = 0; i3 < loop_ub; i3++) {
            r3->data[i3] = j->data[i3] - 1;
          }

          i3 = costMat->size[1];
          i4 = costMat->size[0];
          i5 = r3->size[0];
          emxEnsureCapacity_int32_T(r3, i5);
          loop_ub = r3->size[0];
          for (i5 = 0; i5 < loop_ub; i5++) {
            r3->data[i5] = r3->data[i5] % i4 * i3 + r3->data[i5] / i4;
          }

          if (jj <= r3->size[0]) {
            if (!rtIsNaN(rIdx->data[jj - 1])) {
              idx = jj;
              exitg1 = 1;
            } else {
              jj++;
            }
          } else {
            exitg1 = 1;
          }
        } while (exitg1 == 0);
      }

      if (idx == 0) {
        bigM = rIdx->data[0];
      } else {
        bigM = rIdx->data[idx - 1];
        i3 = idx + 1;
        for (jj = i3; jj <= n; jj++) {
          if (bigM < rIdx->data[jj - 1]) {
            bigM = rIdx->data[jj - 1];
          }
        }
      }
    }

    emxInit_real_T(&dMat, 2);
    bigM *= 10.0;
    i3 = dMat->size[0] * dMat->size[1];
    dMat->size[1] = (int)b_n;
    dMat->size[0] = (int)b_n;
    emxEnsureCapacity_real_T(dMat, i3);
    loop_ub = (int)b_n * (int)b_n;
    for (i3 = 0; i3 < loop_ub; i3++) {
      dMat->data[i3] = bigM;
    }

    loop_ub = validRow->size[0] - 1;
    n = 0;
    for (i = 0; i <= loop_ub; i++) {
      if (validRow->data[i]) {
        n++;
      }
    }

    emxInit_int32_T(&b_ii, 1);
    i3 = b_ii->size[0];
    b_ii->size[0] = n;
    emxEnsureCapacity_int32_T(b_ii, i3);
    n = 0;
    for (i = 0; i <= loop_ub; i++) {
      if (validRow->data[i]) {
        b_ii->data[n] = i + 1;
        n++;
      }
    }

    loop_ub = validCol->size[1] - 1;
    n = 0;
    for (i = 0; i <= loop_ub; i++) {
      if (validCol->data[i]) {
        n++;
      }
    }

    emxInit_int32_T(&c_ii, 2);
    i3 = c_ii->size[0] * c_ii->size[1];
    c_ii->size[1] = n;
    c_ii->size[0] = 1;
    emxEnsureCapacity_int32_T(c_ii, i3);
    n = 0;
    for (i = 0; i <= loop_ub; i++) {
      if (validCol->data[i]) {
        c_ii->data[n] = i + 1;
        n++;
      }
    }

    i3 = c_ii->size[1] * c_ii->size[0];
    i4 = c_ii->size[0] * c_ii->size[1];
    c_ii->size[0] = 1;
    emxEnsureCapacity_int32_T(c_ii, i4);
    loop_ub = i3 - 1;
    for (i3 = 0; i3 <= loop_ub; i3++) {
      c_ii->data[i3]--;
    }

    jj = c_ii->size[1];
    loop_ub = b_ii->size[0];
    for (i3 = 0; i3 < loop_ub; i3++) {
      for (i4 = 0; i4 < jj; i4++) {
        dMat->data[i4 + dMat->size[1] * i3] = costMat->data[c_ii->data[i4] +
          costMat->size[1] * (b_ii->data[i3] - 1)];
      }
    }

    // *************************************************
    //  Munkres' Assignment Algorithm starts here
    // *************************************************
    // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    //    STEP 1: Subtract the row minimum from each row.
    // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    m = dMat->size[0];
    n = dMat->size[1];
    dMat_idx_0 = (unsigned int)dMat->size[0];
    i3 = minR->size[0];
    minR->size[0] = (int)dMat_idx_0;
    emxEnsureCapacity_real_T(minR, i3);
    for (i = 0; i < m; i++) {
      minR->data[i] = dMat->data[dMat->size[1] * i];
      for (jj = 2; jj <= n; jj++) {
        bigM = dMat->data[(jj + dMat->size[1] * i) - 1];
        p = ((!rtIsNaN(bigM)) && (rtIsNaN(minR->data[i]) || (minR->data[i] >
               bigM)));
        if (p) {
          minR->data[i] = dMat->data[(jj + dMat->size[1] * i) - 1];
        }
      }
    }

    emxInit_real_T(&minC, 2);
    emxInit_real_T(&varargin_1, 2);
    bsxfun(dMat, minR, varargin_1);
    m = varargin_1->size[0];
    n = varargin_1->size[1] - 1;
    dMat_idx_0 = (unsigned int)varargin_1->size[1];
    i3 = minC->size[0] * minC->size[1];
    minC->size[1] = (int)dMat_idx_0;
    minC->size[0] = 1;
    emxEnsureCapacity_real_T(minC, i3);
    for (jj = 0; jj <= n; jj++) {
      minC->data[jj] = varargin_1->data[jj];
    }

    for (i = 2; i <= m; i++) {
      for (jj = 0; jj <= n; jj++) {
        uZr = minC->data[jj];
        bigM = varargin_1->data[jj + varargin_1->size[1] * (i - 1)];
        if ((!rtIsNaN(bigM)) && (rtIsNaN(uZr) || (uZr > bigM))) {
          minC->data[jj] = varargin_1->data[jj + varargin_1->size[1] * (i - 1)];
        }
      }
    }

    emxInit_boolean_T(&zP, 2);

    // **************************************************************************   
    //    STEP 2: Find a zero of dMat. If there are no starred zeros in its
    //            column or row start the zero. Repeat for each zero
    // ************************************************************************** 
    b_bsxfun(minC, minR, varargin_1);
    i3 = zP->size[0] * zP->size[1];
    zP->size[1] = dMat->size[1];
    zP->size[0] = dMat->size[0];
    emxEnsureCapacity_boolean_T(zP, i3);
    loop_ub = dMat->size[1] * dMat->size[0];
    for (i3 = 0; i3 < loop_ub; i3++) {
      zP->data[i3] = (dMat->data[i3] == varargin_1->data[i3]);
    }

    emxInit_real_T(&starZ, 1);
    i3 = starZ->size[0];
    starZ->size[0] = (int)b_n;
    emxEnsureCapacity_real_T(starZ, i3);
    loop_ub = (int)b_n;
    for (i3 = 0; i3 < loop_ub; i3++) {
      starZ->data[i3] = 0.0;
    }

    emxInit_boolean_T(&z, 1);
    do {
      exitg1 = 0;
      jj = zP->size[0] * zP->size[1];
      i3 = 0;
      i4 = 0;
      i5 = 0;
      idx = z->size[0];
      z->size[0] = jj;
      emxEnsureCapacity_boolean_T(z, idx);
      for (idx = 0; idx < jj; idx++) {
        z->data[i3] = zP->data[i5 + zP->size[1] * i4];
        i3++;
        i4++;
        if (i4 > zP->size[0] - 1) {
          i4 = 0;
          i5++;
        }
      }

      if (c_any(z)) {
        idx = 0;
        i3 = ii->size[0];
        ii->size[0] = 1;
        emxEnsureCapacity_int32_T(ii, i3);
        i3 = j->size[0];
        j->size[0] = 1;
        emxEnsureCapacity_int32_T(j, i3);
        m = 1;
        jj = 1;
        exitg2 = false;
        while ((!exitg2) && (jj <= zP->size[1])) {
          if (zP->data[(jj + zP->size[1] * (m - 1)) - 1]) {
            idx = 1;
            ii->data[0] = m;
            j->data[0] = jj;
            exitg2 = true;
          } else {
            m++;
            if (m > zP->size[0]) {
              m = 1;
              jj++;
            }
          }
        }

        if (idx == 0) {
          ii->size[0] = 0;
          j->size[0] = 0;
        }

        jj = ii->size[0];
        loop_ub = ii->size[0];
        for (i3 = 0; i3 < loop_ub; i3++) {
          r_data[i3] = ii->data[i3];
        }

        m = j->size[0];
        loop_ub = j->size[0];
        for (i3 = 0; i3 < loop_ub; i3++) {
          c_data[i3] = j->data[i3];
        }

        for (i3 = 0; i3 < m; i3++) {
          starZ->data[r_data[i3] - 1] = c_data[i3];
        }

        loop_ub = zP->size[1];
        for (i3 = 0; i3 < jj; i3++) {
          for (i4 = 0; i4 < loop_ub; i4++) {
            zP->data[i4 + zP->size[1] * (r_data[i3] - 1)] = false;
          }
        }

        if (0 <= m - 1) {
          memcpy(&r_data[0], &c_data[0], (unsigned int)(m * (int)sizeof(int)));
        }

        loop_ub = zP->size[0];
        for (i3 = 0; i3 < loop_ub; i3++) {
          for (i4 = 0; i4 < m; i4++) {
            zP->data[(r_data[i4] + zP->size[1] * i3) - 1] = false;
          }
        }
      } else {
        exitg1 = 1;
      }
    } while (exitg1 == 0);

    emxInit_boolean_T(&coverColumn, 2);
    emxInit_boolean_T(&coverRow, 1);
    emxInit_real_T(&primeZ, 1);
    emxInit_real_T(&cIdx, 1);
    emxInit_uint32_T(&cR, 1);
    emxInit_uint32_T(&cC, 2);
    emxInit_real_T(&b_cIdx, 2);
    emxInit_int32_T(&r5, 1);
    emxInit_int32_T(&r6, 2);
    emxInit_int32_T(&r7, 1);
    emxInit_int32_T(&r8, 2);
    emxInit_int32_T(&r9, 1);
    emxInit_int32_T(&r10, 2);
    emxInit_int32_T(&r11, 1);
    emxInit_int32_T(&r12, 1);
    emxInit_int32_T(&r13, 2);
    emxInit_int32_T(&r14, 1);
    emxInit_boolean_T(&x, 2);
    emxInit_boolean_T(&b_starZ, 1);
    emxInit_real_T(&b_minR, 1);
    emxInit_real_T(&b_minC, 2);
    emxInit_int32_T(&d_ii, 2);
    emxInit_real_T(&c_minC, 1);
    do {
      exitg1 = 0;

      // ************************************************************************** 
      //    STEP 3: Cover each column with a starred zero. If all the columns are 
      //            covered then the matching is maximum
      // ************************************************************************** 
      i3 = b_starZ->size[0];
      b_starZ->size[0] = starZ->size[0];
      emxEnsureCapacity_boolean_T(b_starZ, i3);
      loop_ub = starZ->size[0];
      for (i3 = 0; i3 < loop_ub; i3++) {
        b_starZ->data[i3] = (starZ->data[i3] > 0.0);
      }

      if (all(b_starZ)) {
        exitg1 = 1;
      } else {
        i3 = coverColumn->size[0] * coverColumn->size[1];
        coverColumn->size[1] = (int)b_n;
        coverColumn->size[0] = 1;
        emxEnsureCapacity_boolean_T(coverColumn, i3);
        loop_ub = (int)b_n;
        for (i3 = 0; i3 < loop_ub; i3++) {
          coverColumn->data[i3] = false;
        }

        loop_ub = starZ->size[0];
        for (i = 0; i < loop_ub; i++) {
          if (starZ->data[i] > 0.0) {
            coverColumn->data[(int)starZ->data[i] - 1] = true;
          }
        }

        i3 = coverRow->size[0];
        coverRow->size[0] = (int)b_n;
        emxEnsureCapacity_boolean_T(coverRow, i3);
        loop_ub = (int)b_n;
        for (i3 = 0; i3 < loop_ub; i3++) {
          coverRow->data[i3] = false;
        }

        i3 = primeZ->size[0];
        primeZ->size[0] = (int)b_n;
        emxEnsureCapacity_real_T(primeZ, i3);
        loop_ub = (int)b_n;
        for (i3 = 0; i3 < loop_ub; i3++) {
          primeZ->data[i3] = 0.0;
        }

        m = coverColumn->size[1];
        loop_ub = (int)b_n - 1;
        n = 0;
        for (i = 0; i <= loop_ub; i++) {
          n++;
        }

        i3 = r5->size[0];
        r5->size[0] = n;
        emxEnsureCapacity_int32_T(r5, i3);
        n = 0;
        for (i = 0; i <= loop_ub; i++) {
          r5->data[n] = i + 1;
          n++;
        }

        loop_ub = m - 1;
        n = 0;
        for (i = 0; i <= loop_ub; i++) {
          if (!coverColumn->data[i]) {
            n++;
          }
        }

        i3 = r6->size[0] * r6->size[1];
        r6->size[1] = n;
        r6->size[0] = 1;
        emxEnsureCapacity_int32_T(r6, i3);
        n = 0;
        for (i = 0; i <= loop_ub; i++) {
          if (!coverColumn->data[i]) {
            r6->data[n] = i + 1;
            n++;
          }
        }

        loop_ub = (int)b_n - 1;
        n = 0;
        for (i = 0; i <= loop_ub; i++) {
          n++;
        }

        i3 = r7->size[0];
        r7->size[0] = n;
        emxEnsureCapacity_int32_T(r7, i3);
        n = 0;
        for (i = 0; i <= loop_ub; i++) {
          r7->data[n] = i + 1;
          n++;
        }

        loop_ub = m - 1;
        n = 0;
        for (i = 0; i <= loop_ub; i++) {
          if (!coverColumn->data[i]) {
            n++;
          }
        }

        i3 = r8->size[0] * r8->size[1];
        r8->size[1] = n;
        r8->size[0] = 1;
        emxEnsureCapacity_int32_T(r8, i3);
        n = 0;
        for (i = 0; i <= loop_ub; i++) {
          if (!coverColumn->data[i]) {
            r8->data[n] = i + 1;
            n++;
          }
        }

        i3 = c_ii->size[0] * c_ii->size[1];
        c_ii->size[1] = r8->size[1];
        c_ii->size[0] = 1;
        emxEnsureCapacity_int32_T(c_ii, i3);
        loop_ub = r8->size[1] * r8->size[0];
        for (i3 = 0; i3 < loop_ub; i3++) {
          c_ii->data[i3] = r8->data[i3] - 1;
        }

        i3 = b_minR->size[0];
        b_minR->size[0] = r5->size[0];
        emxEnsureCapacity_real_T(b_minR, i3);
        loop_ub = r5->size[0];
        for (i3 = 0; i3 < loop_ub; i3++) {
          b_minR->data[i3] = minR->data[r5->data[i3] - 1];
        }

        i3 = b_minC->size[0] * b_minC->size[1];
        b_minC->size[1] = r6->size[1];
        b_minC->size[0] = 1;
        emxEnsureCapacity_real_T(b_minC, i3);
        loop_ub = r6->size[1] * r6->size[0];
        for (i3 = 0; i3 < loop_ub; i3++) {
          b_minC->data[i3] = minC->data[r6->data[i3] - 1];
        }

        c_bsxfun(b_minR, b_minC, varargin_1);
        jj = c_ii->size[1];
        i3 = zP->size[0] * zP->size[1];
        zP->size[1] = jj;
        zP->size[0] = r7->size[0];
        emxEnsureCapacity_boolean_T(zP, i3);
        loop_ub = r7->size[0];
        for (i3 = 0; i3 < loop_ub; i3++) {
          for (i4 = 0; i4 < jj; i4++) {
            zP->data[i4 + zP->size[1] * i3] = (dMat->data[c_ii->data[i4] +
              dMat->size[1] * (r7->data[i3] - 1)] == varargin_1->data[i4 +
              varargin_1->size[1] * i3]);
          }
        }

        n = zP->size[0] * zP->size[1];
        if (n == 0) {
          ii->size[0] = 0;
          j->size[0] = 0;
        } else {
          idx = 0;
          i3 = ii->size[0];
          ii->size[0] = n;
          emxEnsureCapacity_int32_T(ii, i3);
          i3 = j->size[0];
          j->size[0] = n;
          emxEnsureCapacity_int32_T(j, i3);
          m = 1;
          jj = 1;
          exitg2 = false;
          while ((!exitg2) && (jj <= zP->size[1])) {
            guard1 = false;
            if (zP->data[(jj + zP->size[1] * (m - 1)) - 1]) {
              idx++;
              ii->data[idx - 1] = m;
              j->data[idx - 1] = jj;
              if (idx >= n) {
                exitg2 = true;
              } else {
                guard1 = true;
              }
            } else {
              guard1 = true;
            }

            if (guard1) {
              m++;
              if (m > zP->size[0]) {
                m = 1;
                jj++;
              }
            }
          }

          if (n == 1) {
            if (idx == 0) {
              ii->size[0] = 0;
              j->size[0] = 0;
            }
          } else {
            if (1 > idx) {
              loop_ub = 0;
            } else {
              loop_ub = idx;
            }

            i3 = r3->size[0];
            r3->size[0] = loop_ub;
            emxEnsureCapacity_int32_T(r3, i3);
            for (i3 = 0; i3 < loop_ub; i3++) {
              r3->data[i3] = i3;
            }

            loop_ub = r3->size[0];
            i3 = b_ii->size[0];
            b_ii->size[0] = loop_ub;
            emxEnsureCapacity_int32_T(b_ii, i3);
            for (i3 = 0; i3 < loop_ub; i3++) {
              b_ii->data[i3] = ii->data[r3->data[i3]];
            }

            i3 = ii->size[0];
            ii->size[0] = b_ii->size[0];
            emxEnsureCapacity_int32_T(ii, i3);
            loop_ub = b_ii->size[0];
            for (i3 = 0; i3 < loop_ub; i3++) {
              ii->data[i3] = b_ii->data[i3];
            }

            if (1 > idx) {
              loop_ub = 0;
            } else {
              loop_ub = idx;
            }

            i3 = r3->size[0];
            r3->size[0] = loop_ub;
            emxEnsureCapacity_int32_T(r3, i3);
            for (i3 = 0; i3 < loop_ub; i3++) {
              r3->data[i3] = i3;
            }

            loop_ub = r3->size[0];
            i3 = b_ii->size[0];
            b_ii->size[0] = loop_ub;
            emxEnsureCapacity_int32_T(b_ii, i3);
            for (i3 = 0; i3 < loop_ub; i3++) {
              b_ii->data[i3] = j->data[r3->data[i3]];
            }

            i3 = j->size[0];
            j->size[0] = b_ii->size[0];
            emxEnsureCapacity_int32_T(j, i3);
            loop_ub = b_ii->size[0];
            for (i3 = 0; i3 < loop_ub; i3++) {
              j->data[i3] = b_ii->data[i3];
            }
          }
        }

        i3 = rIdx->size[0];
        rIdx->size[0] = ii->size[0];
        emxEnsureCapacity_real_T(rIdx, i3);
        loop_ub = ii->size[0];
        for (i3 = 0; i3 < loop_ub; i3++) {
          rIdx->data[i3] = ii->data[i3];
        }

        i3 = cIdx->size[0];
        cIdx->size[0] = j->size[0];
        emxEnsureCapacity_real_T(cIdx, i3);
        loop_ub = j->size[0];
        for (i3 = 0; i3 < loop_ub; i3++) {
          cIdx->data[i3] = j->data[i3];
        }

        do {
          exitg3 = 0;

          // ************************************************************************** 
          //    STEP 4: Find a noncovered zero and prime it.  If there is no starred 
          //            zero in the row containing this primed zero, Go to Step 5.   
          //            Otherwise, cover this row and uncover the column containing  
          //            the starred zero. Continue in this manner until there are no  
          //            uncovered zeros left. Save the smallest uncovered value and  
          //            Go to Step 6.
          // ************************************************************************** 
          i3 = z->size[0];
          z->size[0] = coverRow->size[0];
          emxEnsureCapacity_boolean_T(z, i3);
          loop_ub = coverRow->size[0];
          for (i3 = 0; i3 < loop_ub; i3++) {
            z->data[i3] = !coverRow->data[i3];
          }

          n = z->size[0];
          idx = 0;
          i3 = ii->size[0];
          ii->size[0] = z->size[0];
          emxEnsureCapacity_int32_T(ii, i3);
          m = 0;
          exitg2 = false;
          while ((!exitg2) && (m <= n - 1)) {
            if (z->data[m]) {
              idx++;
              ii->data[idx - 1] = m + 1;
              if (idx >= n) {
                exitg2 = true;
              } else {
                m++;
              }
            } else {
              m++;
            }
          }

          if (z->size[0] == 1) {
            if (idx == 0) {
              ii->size[0] = 0;
            }
          } else {
            if (1 > idx) {
              loop_ub = 0;
            } else {
              loop_ub = idx;
            }

            i3 = r3->size[0];
            r3->size[0] = loop_ub;
            emxEnsureCapacity_int32_T(r3, i3);
            for (i3 = 0; i3 < loop_ub; i3++) {
              r3->data[i3] = i3;
            }

            loop_ub = r3->size[0];
            i3 = b_ii->size[0];
            b_ii->size[0] = loop_ub;
            emxEnsureCapacity_int32_T(b_ii, i3);
            for (i3 = 0; i3 < loop_ub; i3++) {
              b_ii->data[i3] = ii->data[r3->data[i3]];
            }

            i3 = ii->size[0];
            ii->size[0] = b_ii->size[0];
            emxEnsureCapacity_int32_T(ii, i3);
            loop_ub = b_ii->size[0];
            for (i3 = 0; i3 < loop_ub; i3++) {
              ii->data[i3] = b_ii->data[i3];
            }
          }

          i3 = cR->size[0];
          cR->size[0] = ii->size[0];
          emxEnsureCapacity_uint32_T(cR, i3);
          loop_ub = ii->size[0];
          for (i3 = 0; i3 < loop_ub; i3++) {
            cR->data[i3] = (unsigned int)ii->data[i3];
          }

          i3 = x->size[0] * x->size[1];
          x->size[1] = coverColumn->size[1];
          x->size[0] = 1;
          emxEnsureCapacity_boolean_T(x, i3);
          loop_ub = coverColumn->size[1] * coverColumn->size[0];
          for (i3 = 0; i3 < loop_ub; i3++) {
            x->data[i3] = !coverColumn->data[i3];
          }

          n = x->size[1];
          idx = 0;
          dMat_idx_0 = (unsigned int)x->size[1];
          i3 = c_ii->size[0] * c_ii->size[1];
          c_ii->size[1] = (int)dMat_idx_0;
          c_ii->size[0] = 1;
          emxEnsureCapacity_int32_T(c_ii, i3);
          m = 0;
          exitg2 = false;
          while ((!exitg2) && (m <= n - 1)) {
            if (x->data[m]) {
              idx++;
              c_ii->data[idx - 1] = m + 1;
              if (idx >= n) {
                exitg2 = true;
              } else {
                m++;
              }
            } else {
              m++;
            }
          }

          if (x->size[1] == 1) {
            if (idx == 0) {
              c_ii->size[1] = 0;
              c_ii->size[0] = 1;
            }
          } else {
            if (1 > idx) {
              loop_ub = 0;
            } else {
              loop_ub = idx;
            }

            i3 = r3->size[0];
            r3->size[0] = loop_ub;
            emxEnsureCapacity_int32_T(r3, i3);
            for (i3 = 0; i3 < loop_ub; i3++) {
              r3->data[i3] = i3;
            }

            jj = r3->size[0];
            i3 = d_ii->size[0] * d_ii->size[1];
            d_ii->size[1] = jj;
            d_ii->size[0] = 1;
            emxEnsureCapacity_int32_T(d_ii, i3);
            for (i3 = 0; i3 < jj; i3++) {
              d_ii->data[i3] = c_ii->data[r3->data[i3]];
            }

            i3 = c_ii->size[0] * c_ii->size[1];
            c_ii->size[1] = d_ii->size[1];
            c_ii->size[0] = 1;
            emxEnsureCapacity_int32_T(c_ii, i3);
            loop_ub = d_ii->size[1] * d_ii->size[0];
            for (i3 = 0; i3 < loop_ub; i3++) {
              c_ii->data[i3] = d_ii->data[i3];
            }
          }

          i3 = cC->size[0] * cC->size[1];
          cC->size[1] = c_ii->size[1];
          cC->size[0] = 1;
          emxEnsureCapacity_uint32_T(cC, i3);
          loop_ub = c_ii->size[1] * c_ii->size[0];
          for (i3 = 0; i3 < loop_ub; i3++) {
            cC->data[i3] = (unsigned int)c_ii->data[i3];
          }

          i3 = rIdx->size[0];
          emxEnsureCapacity_real_T(rIdx, i3);
          loop_ub = rIdx->size[0];
          for (i3 = 0; i3 < loop_ub; i3++) {
            rIdx->data[i3] = cR->data[(int)rIdx->data[i3] - 1];
          }

          jj = cIdx->size[0];
          i3 = b_cIdx->size[0] * b_cIdx->size[1];
          b_cIdx->size[1] = jj;
          b_cIdx->size[0] = 1;
          emxEnsureCapacity_real_T(b_cIdx, i3);
          for (i3 = 0; i3 < jj; i3++) {
            b_cIdx->data[i3] = cC->data[(int)cIdx->data[i3] - 1];
          }

          uZr = 1.0;

          //  Matlab coder
          uZc = 1.0;

          //  Matlab coder
          Step = 6;
          exitg2 = false;
          while ((!exitg2) && (b_cIdx->size[1] != 0)) {
            uZr = rIdx->data[0];
            uZc = b_cIdx->data[0];
            primeZ->data[(int)rIdx->data[0] - 1] = b_cIdx->data[0];
            if (!(starZ->data[(int)rIdx->data[0] - 1] != 0.0)) {
              Step = 5;
              exitg2 = true;
            } else {
              coverRow->data[(int)rIdx->data[0] - 1] = true;
              coverColumn->data[(int)starZ->data[(int)rIdx->data[0] - 1] - 1] =
                false;
              bigM = rIdx->data[0];
              i3 = z->size[0];
              z->size[0] = rIdx->size[0];
              emxEnsureCapacity_boolean_T(z, i3);
              loop_ub = rIdx->size[0];
              for (i3 = 0; i3 < loop_ub; i3++) {
                z->data[i3] = (rIdx->data[i3] == bigM);
              }

              nullAssignment(rIdx, z);

              //  Matlab coder
              b_nullAssignment(b_cIdx, z);

              //  Matlab coder
              i3 = z->size[0];
              z->size[0] = coverRow->size[0];
              emxEnsureCapacity_boolean_T(z, i3);
              loop_ub = coverRow->size[0];
              for (i3 = 0; i3 < loop_ub; i3++) {
                z->data[i3] = !coverRow->data[i3];
              }

              n = z->size[0];
              idx = 0;
              i3 = ii->size[0];
              ii->size[0] = z->size[0];
              emxEnsureCapacity_int32_T(ii, i3);
              m = 0;
              exitg4 = false;
              while ((!exitg4) && (m <= n - 1)) {
                if (z->data[m]) {
                  idx++;
                  ii->data[idx - 1] = m + 1;
                  if (idx >= n) {
                    exitg4 = true;
                  } else {
                    m++;
                  }
                } else {
                  m++;
                }
              }

              if (z->size[0] == 1) {
                if (idx == 0) {
                  ii->size[0] = 0;
                }
              } else {
                if (1 > idx) {
                  loop_ub = 0;
                } else {
                  loop_ub = idx;
                }

                i3 = r3->size[0];
                r3->size[0] = loop_ub;
                emxEnsureCapacity_int32_T(r3, i3);
                for (i3 = 0; i3 < loop_ub; i3++) {
                  r3->data[i3] = i3;
                }

                loop_ub = r3->size[0];
                i3 = b_ii->size[0];
                b_ii->size[0] = loop_ub;
                emxEnsureCapacity_int32_T(b_ii, i3);
                for (i3 = 0; i3 < loop_ub; i3++) {
                  b_ii->data[i3] = ii->data[r3->data[i3]];
                }

                i3 = ii->size[0];
                ii->size[0] = b_ii->size[0];
                emxEnsureCapacity_int32_T(ii, i3);
                loop_ub = b_ii->size[0];
                for (i3 = 0; i3 < loop_ub; i3++) {
                  ii->data[i3] = b_ii->data[i3];
                }
              }

              i3 = cR->size[0];
              cR->size[0] = ii->size[0];
              emxEnsureCapacity_uint32_T(cR, i3);
              loop_ub = ii->size[0];
              for (i3 = 0; i3 < loop_ub; i3++) {
                cR->data[i3] = (unsigned int)ii->data[i3];
              }

              jj = coverRow->size[0];
              loop_ub = jj - 1;
              n = 0;
              for (i = 0; i <= loop_ub; i++) {
                if (!coverRow->data[i]) {
                  n++;
                }
              }

              i3 = r11->size[0];
              r11->size[0] = n;
              emxEnsureCapacity_int32_T(r11, i3);
              n = 0;
              for (i = 0; i <= loop_ub; i++) {
                if (!coverRow->data[i]) {
                  r11->data[n] = i + 1;
                  n++;
                }
              }

              m = r11->size[0];
              bigM = minC->data[(int)starZ->data[(int)uZr - 1] - 1];
              jj = (int)starZ->data[(int)uZr - 1];
              i3 = z->size[0];
              z->size[0] = m;
              emxEnsureCapacity_boolean_T(z, i3);
              for (i3 = 0; i3 < m; i3++) {
                z->data[i3] = (dMat->data[(jj + dMat->size[1] * (r11->data[i3] -
                  1)) - 1] == minR->data[r11->data[i3] - 1] + bigM);
              }

              loop_ub = z->size[0] - 1;
              n = 0;
              for (i = 0; i <= loop_ub; i++) {
                if (z->data[i]) {
                  n++;
                }
              }

              i3 = r12->size[0];
              r12->size[0] = n;
              emxEnsureCapacity_int32_T(r12, i3);
              n = 0;
              for (i = 0; i <= loop_ub; i++) {
                if (z->data[i]) {
                  r12->data[n] = i + 1;
                  n++;
                }
              }

              i3 = c_minC->size[0];
              c_minC->size[0] = r12->size[0];
              emxEnsureCapacity_real_T(c_minC, i3);
              loop_ub = r12->size[0];
              for (i3 = 0; i3 < loop_ub; i3++) {
                c_minC->data[i3] = cR->data[r12->data[i3] - 1];
              }

              i3 = rIdx->size[0];
              i4 = c_minC->size[0];
              i5 = rIdx->size[0];
              rIdx->size[0] = i3 + i4;
              emxEnsureCapacity_real_T(rIdx, i5);
              loop_ub = r12->size[0];
              for (i4 = 0; i4 < loop_ub; i4++) {
                rIdx->data[i3 + i4] = cR->data[r12->data[i4] - 1];
              }

              //  Matlab coder
              bigM = d_sum(z);
              m = (int)bigM;
              i3 = b_cIdx->size[1];
              i4 = b_cIdx->size[0] * b_cIdx->size[1];
              b_cIdx->size[1] = i3 + m;
              emxEnsureCapacity_real_T(b_cIdx, i4);
              for (i4 = 0; i4 < m; i4++) {
                b_cIdx->data[i3 + i4] = starZ->data[(int)uZr - 1];
              }

              //  Matlab coder
            }
          }

          if (Step == 6) {
            //  ************************************************************************* 
            //  STEP 6: Add the minimum uncovered value to every element of each covered 
            //          row, and subtract it from every element of each uncovered column. 
            //          Return to Step 4 without altering any stars, primes, or covered lines. 
            // ************************************************************************** 
            loop_ub = coverRow->size[0] - 1;
            n = 0;
            for (i = 0; i <= loop_ub; i++) {
              if (!coverRow->data[i]) {
                n++;
              }
            }

            i3 = r9->size[0];
            r9->size[0] = n;
            emxEnsureCapacity_int32_T(r9, i3);
            n = 0;
            for (i = 0; i <= loop_ub; i++) {
              if (!coverRow->data[i]) {
                r9->data[n] = i + 1;
                n++;
              }
            }

            m = coverColumn->size[1];
            loop_ub = m - 1;
            n = 0;
            for (i = 0; i <= loop_ub; i++) {
              if (!coverColumn->data[i]) {
                n++;
              }
            }

            i3 = r10->size[0] * r10->size[1];
            r10->size[1] = n;
            r10->size[0] = 1;
            emxEnsureCapacity_int32_T(r10, i3);
            n = 0;
            for (i = 0; i <= loop_ub; i++) {
              if (!coverColumn->data[i]) {
                r10->data[n] = i + 1;
                n++;
              }
            }

            i3 = c_ii->size[0] * c_ii->size[1];
            c_ii->size[1] = r10->size[1];
            c_ii->size[0] = 1;
            emxEnsureCapacity_int32_T(c_ii, i3);
            loop_ub = r10->size[1] * r10->size[0];
            for (i3 = 0; i3 < loop_ub; i3++) {
              c_ii->data[i3] = r10->data[i3] - 1;
            }

            jj = c_ii->size[1];
            i3 = varargin_1->size[0] * varargin_1->size[1];
            varargin_1->size[1] = jj;
            varargin_1->size[0] = r9->size[0];
            emxEnsureCapacity_real_T(varargin_1, i3);
            loop_ub = r9->size[0];
            for (i3 = 0; i3 < loop_ub; i3++) {
              for (i4 = 0; i4 < jj; i4++) {
                varargin_1->data[i4 + varargin_1->size[1] * i3] = dMat->
                  data[c_ii->data[i4] + dMat->size[1] * (r9->data[i3] - 1)];
              }
            }

            i3 = b_minR->size[0];
            b_minR->size[0] = r9->size[0];
            emxEnsureCapacity_real_T(b_minR, i3);
            loop_ub = r9->size[0];
            for (i3 = 0; i3 < loop_ub; i3++) {
              b_minR->data[i3] = minR->data[r9->data[i3] - 1];
            }

            i3 = b_minC->size[0] * b_minC->size[1];
            b_minC->size[1] = r10->size[1];
            b_minC->size[0] = 1;
            emxEnsureCapacity_real_T(b_minC, i3);
            loop_ub = r10->size[1] * r10->size[0];
            for (i3 = 0; i3 < loop_ub; i3++) {
              b_minC->data[i3] = minC->data[r10->data[i3] - 1];
            }

            outerplus(varargin_1, b_minR, b_minC, &bigM, rIdx, cIdx);
            loop_ub = m - 1;
            n = 0;
            for (i = 0; i <= loop_ub; i++) {
              if (!coverColumn->data[i]) {
                n++;
              }
            }

            i3 = r13->size[0] * r13->size[1];
            r13->size[1] = n;
            r13->size[0] = 1;
            emxEnsureCapacity_int32_T(r13, i3);
            n = 0;
            for (i = 0; i <= loop_ub; i++) {
              if (!coverColumn->data[i]) {
                r13->data[n] = i + 1;
                n++;
              }
            }

            loop_ub = r13->size[1] * r13->size[0];
            i3 = c_minC->size[0];
            c_minC->size[0] = loop_ub;
            emxEnsureCapacity_real_T(c_minC, i3);
            for (i3 = 0; i3 < loop_ub; i3++) {
              c_minC->data[i3] = minC->data[r13->data[i3] - 1] + bigM;
            }

            loop_ub = c_minC->size[0];
            for (i3 = 0; i3 < loop_ub; i3++) {
              minC->data[r13->data[i3] - 1] = c_minC->data[i3];
            }

            loop_ub = coverRow->size[0] - 1;
            n = 0;
            for (i = 0; i <= loop_ub; i++) {
              if (coverRow->data[i]) {
                n++;
              }
            }

            i3 = r14->size[0];
            r14->size[0] = n;
            emxEnsureCapacity_int32_T(r14, i3);
            n = 0;
            for (i = 0; i <= loop_ub; i++) {
              if (coverRow->data[i]) {
                r14->data[n] = i + 1;
                n++;
              }
            }

            i3 = c_minC->size[0];
            c_minC->size[0] = r14->size[0];
            emxEnsureCapacity_real_T(c_minC, i3);
            loop_ub = r14->size[0];
            for (i3 = 0; i3 < loop_ub; i3++) {
              c_minC->data[i3] = minR->data[r14->data[i3] - 1] - bigM;
            }

            loop_ub = c_minC->size[0];
            for (i3 = 0; i3 < loop_ub; i3++) {
              minR->data[r14->data[i3] - 1] = c_minC->data[i3];
            }
          } else {
            exitg3 = 1;
          }
        } while (exitg3 == 0);

        // ************************************************************************** 
        //  STEP 5:
        //   Construct a series of alternating primed and starred zeros as
        //   follows:
        //   Let Z0 represent the uncovered primed zero found in Step 4.
        //   Let Z1 denote the starred zero in the column of Z0 (if any).
        //   Let Z2 denote the primed zero in the row of Z1 (there will always
        //   be one).  Continue until the series terminates at a primed zero
        //   that has no starred zero in its column.  Unstar each starred
        //   zero of the series, star each primed zero of the series, erase
        //   all primes and uncover every line in the matrix.  Return to Step 3. 
        // ************************************************************************** 
        i3 = z->size[0];
        z->size[0] = starZ->size[0];
        emxEnsureCapacity_boolean_T(z, i3);
        loop_ub = starZ->size[0];
        for (i3 = 0; i3 < loop_ub; i3++) {
          z->data[i3] = (starZ->data[i3] == uZc);
        }

        idx = 0;
        i3 = ii->size[0];
        ii->size[0] = 1;
        emxEnsureCapacity_int32_T(ii, i3);
        m = 0;
        exitg2 = false;
        while ((!exitg2) && (m <= z->size[0] - 1)) {
          if (z->data[m]) {
            idx = 1;
            ii->data[0] = m + 1;
            exitg2 = true;
          } else {
            m++;
          }
        }

        if (idx == 0) {
          ii->size[0] = 0;
        }

        i3 = rIdx->size[0];
        rIdx->size[0] = ii->size[0];
        emxEnsureCapacity_real_T(rIdx, i3);
        loop_ub = ii->size[0];
        for (i3 = 0; i3 < loop_ub; i3++) {
          rIdx->data[i3] = ii->data[i3];
        }

        //  Matlab coder
        starZ->data[(int)uZr - 1] = uZc;
        while (rIdx->size[0] != 0) {
          //  Matlab coder
          //  Matlab coder
          starZ->data[(int)rIdx->data[0] - 1] = 0.0;

          //  Matlab coder
          uZc = primeZ->data[(int)rIdx->data[0] - 1];

          //  Matlab coder
          uZr = rIdx->data[0];

          //  Matlab coder
          bigM = primeZ->data[(int)rIdx->data[0] - 1];
          i3 = z->size[0];
          z->size[0] = starZ->size[0];
          emxEnsureCapacity_boolean_T(z, i3);
          loop_ub = starZ->size[0];
          for (i3 = 0; i3 < loop_ub; i3++) {
            z->data[i3] = (starZ->data[i3] == bigM);
          }

          idx = 0;
          i3 = ii->size[0];
          ii->size[0] = 1;
          emxEnsureCapacity_int32_T(ii, i3);
          m = 0;
          exitg2 = false;
          while ((!exitg2) && (m <= z->size[0] - 1)) {
            if (z->data[m]) {
              idx = 1;
              ii->data[0] = m + 1;
              exitg2 = true;
            } else {
              m++;
            }
          }

          if (idx == 0) {
            ii->size[0] = 0;
          }

          i3 = rIdx->size[0];
          rIdx->size[0] = ii->size[0];
          emxEnsureCapacity_real_T(rIdx, i3);
          loop_ub = ii->size[0];
          for (i3 = 0; i3 < loop_ub; i3++) {
            rIdx->data[i3] = ii->data[i3];
          }

          //  Matlab coder
          starZ->data[(int)uZr - 1] = uZc;
        }
      }
    } while (exitg1 == 0);

    emxFree_real_T(&c_minC);
    emxFree_real_T(&b_minC);
    emxFree_real_T(&b_minR);
    emxFree_boolean_T(&b_starZ);
    emxFree_boolean_T(&x);
    emxFree_int32_T(&j);
    emxFree_int32_T(&r14);
    emxFree_int32_T(&r13);
    emxFree_int32_T(&r12);
    emxFree_int32_T(&r11);
    emxFree_int32_T(&r10);
    emxFree_int32_T(&r9);
    emxFree_int32_T(&r8);
    emxFree_int32_T(&r7);
    emxFree_int32_T(&r6);
    emxFree_int32_T(&r5);
    emxFree_real_T(&b_cIdx);
    emxFree_uint32_T(&cC);
    emxFree_uint32_T(&cR);
    emxFree_real_T(&cIdx);
    emxFree_real_T(&primeZ);
    emxFree_boolean_T(&coverRow);
    emxFree_boolean_T(&coverColumn);
    emxFree_real_T(&dMat);

    //  Cost of assignment
    n = validRow->size[0];
    idx = 0;
    i3 = ii->size[0];
    ii->size[0] = validRow->size[0];
    emxEnsureCapacity_int32_T(ii, i3);
    m = 0;
    exitg2 = false;
    while ((!exitg2) && (m <= n - 1)) {
      if (validRow->data[m]) {
        idx++;
        ii->data[idx - 1] = m + 1;
        if (idx >= n) {
          exitg2 = true;
        } else {
          m++;
        }
      } else {
        m++;
      }
    }

    if (validRow->size[0] == 1) {
      if (idx == 0) {
        ii->size[0] = 0;
      }
    } else {
      if (1 > idx) {
        loop_ub = 0;
      } else {
        loop_ub = idx;
      }

      i3 = r3->size[0];
      r3->size[0] = loop_ub;
      emxEnsureCapacity_int32_T(r3, i3);
      for (i3 = 0; i3 < loop_ub; i3++) {
        r3->data[i3] = i3;
      }

      loop_ub = r3->size[0];
      i3 = b_ii->size[0];
      b_ii->size[0] = loop_ub;
      emxEnsureCapacity_int32_T(b_ii, i3);
      for (i3 = 0; i3 < loop_ub; i3++) {
        b_ii->data[i3] = ii->data[r3->data[i3]];
      }

      i3 = ii->size[0];
      ii->size[0] = b_ii->size[0];
      emxEnsureCapacity_int32_T(ii, i3);
      loop_ub = b_ii->size[0];
      for (i3 = 0; i3 < loop_ub; i3++) {
        ii->data[i3] = b_ii->data[i3];
      }
    }

    emxFree_int32_T(&b_ii);
    i3 = rIdx->size[0];
    rIdx->size[0] = ii->size[0];
    emxEnsureCapacity_real_T(rIdx, i3);
    loop_ub = ii->size[0];
    for (i3 = 0; i3 < loop_ub; i3++) {
      rIdx->data[i3] = ii->data[i3];
    }

    n = validCol->size[1];
    idx = 0;
    dMat_idx_0 = (unsigned int)validCol->size[1];
    i3 = c_ii->size[0] * c_ii->size[1];
    c_ii->size[1] = (int)dMat_idx_0;
    c_ii->size[0] = 1;
    emxEnsureCapacity_int32_T(c_ii, i3);
    m = 0;
    exitg2 = false;
    while ((!exitg2) && (m <= n - 1)) {
      if (validCol->data[m]) {
        idx++;
        c_ii->data[idx - 1] = m + 1;
        if (idx >= n) {
          exitg2 = true;
        } else {
          m++;
        }
      } else {
        m++;
      }
    }

    if (validCol->size[1] == 1) {
      if (idx == 0) {
        c_ii->size[1] = 0;
        c_ii->size[0] = 1;
      }
    } else {
      if (1 > idx) {
        loop_ub = 0;
      } else {
        loop_ub = idx;
      }

      i3 = r3->size[0];
      r3->size[0] = loop_ub;
      emxEnsureCapacity_int32_T(r3, i3);
      for (i3 = 0; i3 < loop_ub; i3++) {
        r3->data[i3] = i3;
      }

      jj = r3->size[0];
      i3 = d_ii->size[0] * d_ii->size[1];
      d_ii->size[1] = jj;
      d_ii->size[0] = 1;
      emxEnsureCapacity_int32_T(d_ii, i3);
      for (i3 = 0; i3 < jj; i3++) {
        d_ii->data[i3] = c_ii->data[r3->data[i3]];
      }

      i3 = c_ii->size[0] * c_ii->size[1];
      c_ii->size[1] = d_ii->size[1];
      c_ii->size[0] = 1;
      emxEnsureCapacity_int32_T(c_ii, i3);
      loop_ub = d_ii->size[1] * d_ii->size[0];
      for (i3 = 0; i3 < loop_ub; i3++) {
        c_ii->data[i3] = d_ii->data[i3];
      }
    }

    emxFree_int32_T(&d_ii);
    i3 = minC->size[0] * minC->size[1];
    minC->size[1] = c_ii->size[1];
    minC->size[0] = 1;
    emxEnsureCapacity_real_T(minC, i3);
    loop_ub = c_ii->size[1] * c_ii->size[0];
    for (i3 = 0; i3 < loop_ub; i3++) {
      minC->data[i3] = c_ii->data[i3];
    }

    if (1.0 > nRows) {
      loop_ub = 0;
    } else {
      loop_ub = (int)nRows;
    }

    i3 = r3->size[0];
    r3->size[0] = loop_ub;
    emxEnsureCapacity_int32_T(r3, i3);
    for (i3 = 0; i3 < loop_ub; i3++) {
      r3->data[i3] = i3;
    }

    loop_ub = r3->size[0];
    for (i = 0; i < loop_ub; i++) {
      jj = r3->size[0];
      if (starZ->data[r3->data[i % jj]] <= nCols) {
        jj = r3->size[0];
        assignment->data[(int)rIdx->data[i] - 1] = (unsigned int)minC->data[(int)
          starZ->data[r3->data[i % jj]] - 1];
      }
    }

    emxFree_real_T(&rIdx);
    emxFree_real_T(&starZ);
    loop_ub = assignment->size[1] - 1;
    n = 0;
    for (i = 0; i <= loop_ub; i++) {
      if ((int)(unsigned int)assignment->data[i] > 0) {
        n++;
      }
    }

    emxInit_uint32_T(&pass, 2);
    i3 = pass->size[0] * pass->size[1];
    pass->size[1] = n;
    pass->size[0] = 1;
    emxEnsureCapacity_uint32_T(pass, i3);
    n = 0;
    for (i = 0; i <= loop_ub; i++) {
      if ((int)(unsigned int)assignment->data[i] > 0) {
        pass->data[n] = (unsigned int)assignment->data[i];
        n++;
      }
    }

    loop_ub = assignment->size[1] - 1;
    n = 0;
    for (i = 0; i <= loop_ub; i++) {
      if ((int)(unsigned int)assignment->data[i] > 0) {
        n++;
      }
    }

    emxInit_int32_T(&r15, 2);
    i3 = r15->size[0] * r15->size[1];
    r15->size[1] = n;
    r15->size[0] = 1;
    emxEnsureCapacity_int32_T(r15, i3);
    n = 0;
    for (i = 0; i <= loop_ub; i++) {
      if ((int)(unsigned int)assignment->data[i] > 0) {
        r15->data[n] = i + 1;
        n++;
      }
    }

    i3 = c_ii->size[0] * c_ii->size[1];
    c_ii->size[1] = r15->size[1];
    c_ii->size[0] = 1;
    emxEnsureCapacity_int32_T(c_ii, i3);
    loop_ub = r15->size[1] * r15->size[0];
    for (i3 = 0; i3 < loop_ub; i3++) {
      c_ii->data[i3] = r15->data[i3] - 1;
    }

    i3 = minC->size[0] * minC->size[1];
    minC->size[1] = r15->size[1];
    minC->size[0] = 1;
    emxEnsureCapacity_real_T(minC, i3);
    loop_ub = r15->size[1] * r15->size[0];
    for (i3 = 0; i3 < loop_ub; i3++) {
      minC->data[i3] = (unsigned int)assignment->data[r15->data[i3] - 1];
    }

    m = r15->size[1];
    jj = c_ii->size[1];
    i3 = zP->size[0] * zP->size[1];
    zP->size[1] = r1->size[1];
    zP->size[0] = r1->size[0];
    emxEnsureCapacity_boolean_T(zP, i3);
    loop_ub = r1->size[1] * r1->size[0];
    emxFree_int32_T(&r15);
    for (i3 = 0; i3 < loop_ub; i3++) {
      zP->data[i3] = (r1->data[i3] && r2->data[i3]);
    }

    i3 = r1->size[0] * r1->size[1];
    r1->size[1] = m;
    r1->size[0] = jj;
    emxEnsureCapacity_boolean_T(r1, i3);
    for (i3 = 0; i3 < jj; i3++) {
      for (i4 = 0; i4 < m; i4++) {
        r1->data[i4 + r1->size[1] * i3] = zP->data[((int)minC->data[i4] +
          zP->size[1] * c_ii->data[i3]) - 1];
      }
    }

    emxFree_boolean_T(&zP);
    diag(r1, z);
    i3 = z->size[0];
    emxEnsureCapacity_boolean_T(z, i3);
    loop_ub = z->size[0];
    for (i3 = 0; i3 < loop_ub; i3++) {
      z->data[i3] = !z->data[i3];
    }

    loop_ub = z->size[0] - 1;
    n = 0;
    for (i = 0; i <= loop_ub; i++) {
      if (z->data[i]) {
        n++;
      }
    }

    emxInit_int32_T(&r16, 1);
    i3 = r16->size[0];
    r16->size[0] = n;
    emxEnsureCapacity_int32_T(r16, i3);
    n = 0;
    for (i = 0; i <= loop_ub; i++) {
      if (z->data[i]) {
        r16->data[n] = i + 1;
        n++;
      }
    }

    emxFree_boolean_T(&z);
    loop_ub = r16->size[0];
    for (i3 = 0; i3 < loop_ub; i3++) {
      pass->data[r16->data[i3] - 1] = 0U;
    }

    emxFree_int32_T(&r16);
    loop_ub = assignment->size[1];
    n = 0;
    for (i = 0; i < loop_ub; i++) {
      if ((int)(unsigned int)assignment->data[i] > 0) {
        assignment->data[i] = pass->data[n];
        n++;
      }
    }

    emxFree_uint32_T(&pass);
    loop_ub = assignment->size[1] - 1;
    n = 0;
    for (i = 0; i <= loop_ub; i++) {
      if ((int)(unsigned int)assignment->data[i] > 0) {
        n++;
      }
    }

    emxInit_int32_T(&r17, 2);
    i3 = r17->size[0] * r17->size[1];
    r17->size[1] = n;
    r17->size[0] = 1;
    emxEnsureCapacity_int32_T(r17, i3);
    n = 0;
    for (i = 0; i <= loop_ub; i++) {
      if ((int)(unsigned int)assignment->data[i] > 0) {
        r17->data[n] = i + 1;
        n++;
      }
    }

    i3 = c_ii->size[0] * c_ii->size[1];
    c_ii->size[1] = r17->size[1];
    c_ii->size[0] = 1;
    emxEnsureCapacity_int32_T(c_ii, i3);
    loop_ub = r17->size[1] * r17->size[0];
    for (i3 = 0; i3 < loop_ub; i3++) {
      c_ii->data[i3] = r17->data[i3] - 1;
    }

    i3 = minC->size[0] * minC->size[1];
    minC->size[1] = r17->size[1];
    minC->size[0] = 1;
    emxEnsureCapacity_real_T(minC, i3);
    loop_ub = r17->size[1] * r17->size[0];
    for (i3 = 0; i3 < loop_ub; i3++) {
      minC->data[i3] = (unsigned int)assignment->data[r17->data[i3] - 1];
    }

    m = r17->size[1];
    jj = c_ii->size[1];
    i3 = varargin_1->size[0] * varargin_1->size[1];
    varargin_1->size[1] = m;
    varargin_1->size[0] = jj;
    emxEnsureCapacity_real_T(varargin_1, i3);
    emxFree_int32_T(&r17);
    for (i3 = 0; i3 < jj; i3++) {
      for (i4 = 0; i4 < m; i4++) {
        varargin_1->data[i4 + varargin_1->size[1] * i3] = costMat->data[((int)
          minC->data[i4] + costMat->size[1] * c_ii->data[i3]) - 1];
      }
    }

    emxFree_int32_T(&c_ii);
    emxFree_real_T(&minC);
    *cost = trace(varargin_1);
    emxFree_real_T(&varargin_1);
  }

  emxFree_int32_T(&ii);
  emxFree_int32_T(&r3);
  emxFree_boolean_T(&r2);
  emxFree_boolean_T(&r1);
  emxFree_real_T(&minR);
  emxFree_boolean_T(&validRow);
  emxFree_boolean_T(&validCol);
}

//
// File trailer for munkres.cpp
//
// [EOF]
//
