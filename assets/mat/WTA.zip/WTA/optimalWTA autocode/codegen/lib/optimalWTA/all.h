//
// File: all.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:50:40
//
#ifndef ALL_H
#define ALL_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "optimalWTA_types.h"

// Function Declarations
extern boolean_T all(const emxArray_boolean_T *x);

#endif

//
// File trailer for all.h
//
// [EOF]
//
