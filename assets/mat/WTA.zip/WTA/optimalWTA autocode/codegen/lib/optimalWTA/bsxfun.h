//
// File: bsxfun.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:50:40
//
#ifndef BSXFUN_H
#define BSXFUN_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "optimalWTA_types.h"

// Function Declarations
extern void b_bsxfun(const emxArray_real_T *a, const emxArray_real_T *b,
                     emxArray_real_T *c);
extern void bsxfun(const emxArray_real_T *a, const emxArray_real_T *b,
                   emxArray_real_T *c);
extern void c_bsxfun(const emxArray_real_T *a, const emxArray_real_T *b,
                     emxArray_real_T *c);

#endif

//
// File trailer for bsxfun.h
//
// [EOF]
//
