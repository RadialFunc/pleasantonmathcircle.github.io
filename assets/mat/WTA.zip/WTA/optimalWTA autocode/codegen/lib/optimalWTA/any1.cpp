//
// File: any1.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:50:40
//

// Include Files
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "any1.h"
#include "optimalWTA_emxutil.h"

// Function Definitions

//
// Arguments    : const emxArray_boolean_T *x
//                emxArray_boolean_T *y
// Return Type  : void
//
void any(const emxArray_boolean_T *x, emxArray_boolean_T *y)
{
  unsigned int szy_idx_1;
  int hi;
  int loop_ub;
  int k;
  boolean_T exitg1;
  boolean_T b4;
  szy_idx_1 = (unsigned int)x->size[1];
  hi = y->size[0] * y->size[1];
  y->size[1] = (int)szy_idx_1;
  y->size[0] = 1;
  emxEnsureCapacity_boolean_T(y, hi);
  loop_ub = (int)szy_idx_1;
  for (hi = 0; hi < loop_ub; hi++) {
    y->data[hi] = false;
  }

  hi = x->size[1];
  for (loop_ub = 0; loop_ub < hi; loop_ub++) {
    y->data[loop_ub] = false;
    k = 0;
    exitg1 = false;
    while ((!exitg1) && (k <= x->size[0] - 1)) {
      b4 = !x->data[loop_ub + x->size[1] * k];
      if (!b4) {
        y->data[loop_ub] = true;
        exitg1 = true;
      } else {
        k++;
      }
    }
  }
}

//
// Arguments    : const emxArray_boolean_T *x
//                emxArray_boolean_T *y
// Return Type  : void
//
void b_any(const emxArray_boolean_T *x, emxArray_boolean_T *y)
{
  unsigned int szy_idx_0;
  int hi;
  int loop_ub;
  int k;
  boolean_T exitg1;
  boolean_T b5;
  szy_idx_0 = (unsigned int)x->size[0];
  hi = y->size[0];
  y->size[0] = (int)szy_idx_0;
  emxEnsureCapacity_boolean_T(y, hi);
  loop_ub = (int)szy_idx_0;
  for (hi = 0; hi < loop_ub; hi++) {
    y->data[hi] = false;
  }

  hi = x->size[0];
  for (loop_ub = 0; loop_ub < hi; loop_ub++) {
    y->data[loop_ub] = false;
    k = 0;
    exitg1 = false;
    while ((!exitg1) && (k <= x->size[1] - 1)) {
      b5 = !x->data[k + x->size[1] * loop_ub];
      if (!b5) {
        y->data[loop_ub] = true;
        exitg1 = true;
      } else {
        k++;
      }
    }
  }
}

//
// Arguments    : const emxArray_boolean_T *x
// Return Type  : boolean_T
//
boolean_T c_any(const emxArray_boolean_T *x)
{
  boolean_T y;
  int k;
  boolean_T exitg1;
  boolean_T b6;
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k <= x->size[0] - 1)) {
    b6 = !x->data[k];
    if (!b6) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }

  return y;
}

//
// File trailer for any1.cpp
//
// [EOF]
//
