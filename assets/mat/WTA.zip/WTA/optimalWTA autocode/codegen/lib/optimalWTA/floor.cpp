//
// File: floor.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:50:40
//

// Include Files
#include <cmath>
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "floor.h"

// Function Definitions

//
// Arguments    : emxArray_real_T *x
// Return Type  : void
//
void b_floor(emxArray_real_T *x)
{
  int i15;
  int k;
  int i16;
  int subs_idx_0;
  int b_k;
  int subs_idx_1;
  i15 = x->size[0];
  for (k = 0; k < i15; k++) {
    i16 = x->size[1];
    if (0 <= i16 - 1) {
      subs_idx_0 = k + 1;
    }

    for (b_k = 0; b_k < i16; b_k++) {
      subs_idx_1 = 1 + b_k;
      x->data[(subs_idx_1 + x->size[1] * (subs_idx_0 - 1)) - 1] = std::floor
        (x->data[(subs_idx_1 + x->size[1] * (subs_idx_0 - 1)) - 1]);
    }
  }
}

//
// File trailer for floor.cpp
//
// [EOF]
//
