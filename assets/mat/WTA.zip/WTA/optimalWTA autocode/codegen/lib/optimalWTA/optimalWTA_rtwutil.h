//
// File: optimalWTA_rtwutil.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:50:40
//
#ifndef OPTIMALWTA_RTWUTIL_H
#define OPTIMALWTA_RTWUTIL_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "optimalWTA_types.h"

// Function Declarations
extern double rt_powd_snf(double u0, double u1);

#endif

//
// File trailer for optimalWTA_rtwutil.h
//
// [EOF]
//
