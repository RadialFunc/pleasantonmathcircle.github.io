//
// File: munkres.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:50:40
//
#ifndef MUNKRES_H
#define MUNKRES_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "optimalWTA_types.h"

// Function Declarations
extern void munkres(emxArray_real_T *costMat, emxArray_real_T *assignment,
                    double *cost);

#endif

//
// File trailer for munkres.h
//
// [EOF]
//
