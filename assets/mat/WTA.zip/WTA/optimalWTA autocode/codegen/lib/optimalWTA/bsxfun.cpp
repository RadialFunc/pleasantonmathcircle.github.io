//
// File: bsxfun.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:50:40
//

// Include Files
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "bsxfun.h"
#include "optimalWTA_emxutil.h"

// Function Definitions

//
// Arguments    : const emxArray_real_T *a
//                const emxArray_real_T *b
//                emxArray_real_T *c
// Return Type  : void
//
void b_bsxfun(const emxArray_real_T *a, const emxArray_real_T *b,
              emxArray_real_T *c)
{
  int csz_idx_0;
  int csz_idx_1;
  int i8;
  int varargin_3;
  int acoef;
  int i9;
  int k;
  csz_idx_0 = b->size[0];
  csz_idx_1 = a->size[1];
  i8 = c->size[0] * c->size[1];
  c->size[1] = csz_idx_1;
  c->size[0] = csz_idx_0;
  emxEnsureCapacity_real_T(c, i8);
  csz_idx_0 = (b->size[0] != 1);
  i8 = c->size[0] - 1;
  for (csz_idx_1 = 0; csz_idx_1 <= i8; csz_idx_1++) {
    varargin_3 = csz_idx_0 * csz_idx_1;
    acoef = (a->size[1] != 1);
    i9 = c->size[1] - 1;
    for (k = 0; k <= i9; k++) {
      c->data[k + c->size[1] * csz_idx_1] = a->data[acoef * k] + b->
        data[varargin_3];
    }
  }
}

//
// Arguments    : const emxArray_real_T *a
//                const emxArray_real_T *b
//                emxArray_real_T *c
// Return Type  : void
//
void bsxfun(const emxArray_real_T *a, const emxArray_real_T *b, emxArray_real_T *
            c)
{
  int csz_idx_0;
  int csz_idx_1;
  int i6;
  int k;
  int varargin_2;
  int varargin_3;
  int acoef;
  int i7;
  int b_k;
  csz_idx_0 = b->size[0];
  csz_idx_1 = a->size[0];
  if (csz_idx_0 < csz_idx_1) {
    csz_idx_1 = csz_idx_0;
  }

  if (b->size[0] == 1) {
    csz_idx_0 = a->size[0];
  } else if (a->size[0] == 1) {
    csz_idx_0 = b->size[0];
  } else if (a->size[0] == b->size[0]) {
    csz_idx_0 = a->size[0];
  } else {
    csz_idx_0 = csz_idx_1;
  }

  csz_idx_1 = a->size[1];
  i6 = c->size[0] * c->size[1];
  c->size[1] = csz_idx_1;
  c->size[0] = csz_idx_0;
  emxEnsureCapacity_real_T(c, i6);
  csz_idx_0 = (a->size[0] != 1);
  csz_idx_1 = (b->size[0] != 1);
  i6 = c->size[0] - 1;
  for (k = 0; k <= i6; k++) {
    varargin_2 = csz_idx_0 * k;
    varargin_3 = csz_idx_1 * k;
    acoef = (a->size[1] != 1);
    i7 = c->size[1] - 1;
    for (b_k = 0; b_k <= i7; b_k++) {
      c->data[b_k + c->size[1] * k] = a->data[acoef * b_k + a->size[1] *
        varargin_2] - b->data[varargin_3];
    }
  }
}

//
// Arguments    : const emxArray_real_T *a
//                const emxArray_real_T *b
//                emxArray_real_T *c
// Return Type  : void
//
void c_bsxfun(const emxArray_real_T *a, const emxArray_real_T *b,
              emxArray_real_T *c)
{
  int csz_idx_0;
  int csz_idx_1;
  int i10;
  int varargin_2;
  int bcoef;
  int i11;
  int k;
  csz_idx_0 = a->size[0];
  csz_idx_1 = b->size[1];
  i10 = c->size[0] * c->size[1];
  c->size[1] = csz_idx_1;
  c->size[0] = csz_idx_0;
  emxEnsureCapacity_real_T(c, i10);
  if ((c->size[0] != 0) && (c->size[1] != 0)) {
    csz_idx_0 = (a->size[0] != 1);
    i10 = c->size[0] - 1;
    for (csz_idx_1 = 0; csz_idx_1 <= i10; csz_idx_1++) {
      varargin_2 = csz_idx_0 * csz_idx_1;
      bcoef = (b->size[1] != 1);
      i11 = c->size[1] - 1;
      for (k = 0; k <= i11; k++) {
        c->data[k + c->size[1] * csz_idx_1] = a->data[varargin_2] + b->
          data[bcoef * k];
      }
    }
  }
}

//
// File trailer for bsxfun.cpp
//
// [EOF]
//
