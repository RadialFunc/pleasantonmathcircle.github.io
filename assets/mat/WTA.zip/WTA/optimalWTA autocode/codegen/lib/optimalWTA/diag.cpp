//
// File: diag.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:50:40
//

// Include Files
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "diag.h"
#include "optimalWTA_emxutil.h"

// Function Definitions

//
// Arguments    : const emxArray_boolean_T *v
//                emxArray_boolean_T *d
// Return Type  : void
//
void diag(const emxArray_boolean_T *v, emxArray_boolean_T *d)
{
  int u0;
  int u1;
  if ((v->size[0] == 1) && (v->size[1] == 1)) {
    u1 = d->size[0];
    d->size[0] = 1;
    emxEnsureCapacity_boolean_T(d, u1);
    d->data[0] = v->data[0];
  } else {
    u0 = v->size[0];
    u1 = v->size[1];
    if (u0 < u1) {
      u1 = u0;
    }

    if (0 < v->size[1]) {
      u0 = u1;
    } else {
      u0 = 0;
    }

    u1 = d->size[0];
    d->size[0] = u0;
    emxEnsureCapacity_boolean_T(d, u1);
    u1 = u0 - 1;
    for (u0 = 0; u0 <= u1; u0++) {
      d->data[u0] = v->data[u0 + v->size[1] * u0];
    }
  }
}

//
// File trailer for diag.cpp
//
// [EOF]
//
