//
// File: sum.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:50:40
//

// Include Files
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "sum.h"
#include "optimalWTA_emxutil.h"

// Function Definitions

//
// Arguments    : const emxArray_real_T *x
//                emxArray_real_T *y
// Return Type  : void
//
void b_sum(const emxArray_real_T *x, emxArray_real_T *y)
{
  int vlen;
  unsigned int sz_idx_1;
  int i2;
  int k;
  int b_k;
  vlen = x->size[0];
  if ((x->size[0] == 0) || (x->size[1] == 0)) {
    sz_idx_1 = (unsigned int)x->size[1];
    i2 = y->size[0] * y->size[1];
    y->size[1] = (int)sz_idx_1;
    y->size[0] = 1;
    emxEnsureCapacity_real_T(y, i2);
    vlen = (int)sz_idx_1;
    for (i2 = 0; i2 < vlen; i2++) {
      y->data[i2] = 0.0;
    }
  } else {
    sz_idx_1 = (unsigned int)x->size[1];
    i2 = y->size[0] * y->size[1];
    y->size[1] = (int)sz_idx_1;
    y->size[0] = 1;
    emxEnsureCapacity_real_T(y, i2);
    i2 = x->size[1];
    for (k = 0; k < i2; k++) {
      y->data[k] = x->data[k];
    }

    for (k = 2; k <= vlen; k++) {
      i2 = x->size[1];
      for (b_k = 0; b_k < i2; b_k++) {
        if (vlen >= 2) {
          y->data[b_k] += x->data[b_k + x->size[1] * (k - 1)];
        }
      }
    }
  }
}

//
// Arguments    : const emxArray_real_T *x
// Return Type  : double
//
double c_sum(const emxArray_real_T *x)
{
  double y;
  int vlen;
  int k;
  vlen = x->size[0];
  if (x->size[0] == 0) {
    y = 0.0;
  } else {
    y = x->data[0];
    for (k = 2; k <= vlen; k++) {
      if (vlen >= 2) {
        y += x->data[k - 1];
      }
    }
  }

  return y;
}

//
// Arguments    : const emxArray_boolean_T *x
// Return Type  : double
//
double d_sum(const emxArray_boolean_T *x)
{
  double y;
  int vlen;
  int k;
  vlen = x->size[0];
  if (x->size[0] == 0) {
    y = 0.0;
  } else {
    y = x->data[0];
    for (k = 2; k <= vlen; k++) {
      if (vlen >= 2) {
        y += (double)x->data[k - 1];
      }
    }
  }

  return y;
}

//
// Arguments    : const emxArray_boolean_T *x
// Return Type  : double
//
double e_sum(const emxArray_boolean_T *x)
{
  double y;
  int vlen;
  int k;
  vlen = x->size[1];
  if (x->size[1] == 0) {
    y = 0.0;
  } else {
    y = x->data[0];
    for (k = 2; k <= vlen; k++) {
      if (vlen >= 2) {
        y += (double)x->data[k - 1];
      }
    }
  }

  return y;
}

//
// Arguments    : const emxArray_real_T *x
// Return Type  : double
//
double sum(const emxArray_real_T *x)
{
  double y;
  int vlen;
  int k;
  vlen = x->size[1];
  if (x->size[1] == 0) {
    y = 0.0;
  } else {
    y = x->data[0];
    for (k = 2; k <= vlen; k++) {
      if (vlen >= 2) {
        y += x->data[k - 1];
      }
    }
  }

  return y;
}

//
// File trailer for sum.cpp
//
// [EOF]
//
