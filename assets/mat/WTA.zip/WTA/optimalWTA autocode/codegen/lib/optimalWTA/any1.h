//
// File: any1.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:50:40
//
#ifndef ANY1_H
#define ANY1_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "optimalWTA_types.h"

// Function Declarations
extern void any(const emxArray_boolean_T *x, emxArray_boolean_T *y);
extern void b_any(const emxArray_boolean_T *x, emxArray_boolean_T *y);
extern boolean_T c_any(const emxArray_boolean_T *x);

#endif

//
// File trailer for any1.h
//
// [EOF]
//
