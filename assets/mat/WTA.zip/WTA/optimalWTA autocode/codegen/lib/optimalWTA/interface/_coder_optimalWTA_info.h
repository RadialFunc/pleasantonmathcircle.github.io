/* 
 * File: _coder_optimalWTA_info.h 
 *  
 * MATLAB Coder version            : 4.1 
 * C/C++ source code generated on  : 15-Dec-2020 15:50:40 
 */

#ifndef _CODER_OPTIMALWTA_INFO_H
#define _CODER_OPTIMALWTA_INFO_H
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo();
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties();

#endif
/* 
 * File trailer for _coder_optimalWTA_info.h 
 *  
 * [EOF] 
 */
