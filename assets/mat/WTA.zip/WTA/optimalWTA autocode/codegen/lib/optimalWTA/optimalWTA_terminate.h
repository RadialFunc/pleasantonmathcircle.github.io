//
// File: optimalWTA_terminate.h
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:50:40
//
#ifndef OPTIMALWTA_TERMINATE_H
#define OPTIMALWTA_TERMINATE_H

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "optimalWTA_types.h"

// Function Declarations
extern void optimalWTA_terminate();

#endif

//
// File trailer for optimalWTA_terminate.h
//
// [EOF]
//
