//
// File: trace.cpp
//
// MATLAB Coder version            : 4.1
// C/C++ source code generated on  : 15-Dec-2020 15:50:40
//

// Include Files
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "trace.h"

// Function Definitions

//
// Arguments    : const emxArray_real_T *a
// Return Type  : double
//
double trace(const emxArray_real_T *a)
{
  double t;
  int i14;
  int k;
  t = 0.0;
  i14 = a->size[0];
  for (k = 0; k < i14; k++) {
    t += a->data[k + a->size[1] * k];
  }

  return t;
}

//
// File trailer for trace.cpp
//
// [EOF]
//
