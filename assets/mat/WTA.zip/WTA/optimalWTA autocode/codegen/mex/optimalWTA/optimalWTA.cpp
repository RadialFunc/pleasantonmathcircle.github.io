/*
 * optimalWTA.cpp
 *
 * Code generation for function 'optimalWTA'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "optimalWTA_emxutil.h"
#include "sum.h"
#include "error.h"
#include "eml_int_forloop_overflow_check.h"
#include "scalexpAlloc.h"
#include "indexShapeCheck.h"
#include "munkres.h"
#include "costPrep.h"
#include "floor.h"
#include "optimalWTA_data.h"

/* Variable Definitions */
static emlrtRSInfo emlrtRSI = { 19,    /* lineNo */
  "optimalWTA",                        /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pathName */
};

static emlrtRSInfo b_emlrtRSI = { 20,  /* lineNo */
  "optimalWTA",                        /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pathName */
};

static emlrtRSInfo c_emlrtRSI = { 23,  /* lineNo */
  "optimalWTA",                        /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pathName */
};

static emlrtRSInfo d_emlrtRSI = { 27,  /* lineNo */
  "optimalWTA",                        /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pathName */
};

static emlrtRSInfo e_emlrtRSI = { 28,  /* lineNo */
  "optimalWTA",                        /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pathName */
};

static emlrtRSInfo f_emlrtRSI = { 29,  /* lineNo */
  "optimalWTA",                        /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pathName */
};

static emlrtRSInfo g_emlrtRSI = { 31,  /* lineNo */
  "optimalWTA",                        /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pathName */
};

static emlrtRSInfo h_emlrtRSI = { 36,  /* lineNo */
  "optimalWTA",                        /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pathName */
};

static emlrtRSInfo i_emlrtRSI = { 40,  /* lineNo */
  "optimalWTA",                        /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pathName */
};

static emlrtRSInfo j_emlrtRSI = { 42,  /* lineNo */
  "optimalWTA",                        /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pathName */
};

static emlrtRSInfo p_emlrtRSI = { 37,  /* lineNo */
  "minOrMax",                          /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\minOrMax.m"/* pathName */
};

static emlrtRSInfo q_emlrtRSI = { 60,  /* lineNo */
  "binaryMinOrMax",                    /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\binaryMinOrMax.m"/* pathName */
};

static emlrtRSInfo r_emlrtRSI = { 65,  /* lineNo */
  "applyBinaryScalarFunction",         /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\applyBinaryScalarFunction.m"/* pathName */
};

static emlrtRSInfo s_emlrtRSI = { 175, /* lineNo */
  "applyBinaryScalarFunction",         /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\applyBinaryScalarFunction.m"/* pathName */
};

static emlrtRSInfo be_emlrtRSI = { 18, /* lineNo */
  "computeLeakage",                    /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\computeLeakage.m"/* pathName */
};

static emlrtRSInfo ce_emlrtRSI = { 21, /* lineNo */
  "computeLeakage",                    /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\computeLeakage.m"/* pathName */
};

static emlrtRSInfo de_emlrtRSI = { 58, /* lineNo */
  "power",                             /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\lib\\matlab\\ops\\power.m"/* pathName */
};

static emlrtRSInfo ee_emlrtRSI = { 60, /* lineNo */
  "power",                             /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\lib\\matlab\\ops\\power.m"/* pathName */
};

static emlrtRSInfo fe_emlrtRSI = { 45, /* lineNo */
  "applyBinaryScalarFunction",         /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\applyBinaryScalarFunction.m"/* pathName */
};

static emlrtRSInfo ge_emlrtRSI = { 203,/* lineNo */
  "applyBinaryScalarFunction",         /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\applyBinaryScalarFunction.m"/* pathName */
};

static emlrtRSInfo he_emlrtRSI = { 73, /* lineNo */
  "power",                             /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\lib\\matlab\\ops\\power.m"/* pathName */
};

static emlrtRSInfo ie_emlrtRSI = { 80, /* lineNo */
  "power",                             /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\lib\\matlab\\ops\\power.m"/* pathName */
};

static emlrtRSInfo je_emlrtRSI = { 36, /* lineNo */
  "vAllOrAny",                         /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\vAllOrAny.m"/* pathName */
};

static emlrtRSInfo ke_emlrtRSI = { 96, /* lineNo */
  "vAllOrAny",                         /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\vAllOrAny.m"/* pathName */
};

static emlrtRTEInfo emlrtRTEI = { 18,  /* lineNo */
  1,                                   /* colNo */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pName */
};

static emlrtRTEInfo b_emlrtRTEI = { 19,/* lineNo */
  11,                                  /* colNo */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pName */
};

static emlrtRTEInfo c_emlrtRTEI = { 60,/* lineNo */
  10,                                  /* colNo */
  "binaryMinOrMax",                    /* fName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\binaryMinOrMax.m"/* pName */
};

static emlrtRTEInfo f_emlrtRTEI = { 20,/* lineNo */
  1,                                   /* colNo */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pName */
};

static emlrtRTEInfo h_emlrtRTEI = { 26,/* lineNo */
  6,                                   /* colNo */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pName */
};

static emlrtRTEInfo i_emlrtRTEI = { 36,/* lineNo */
  25,                                  /* colNo */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pName */
};

static emlrtRTEInfo j_emlrtRTEI = { 36,/* lineNo */
  38,                                  /* colNo */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pName */
};

static emlrtRTEInfo p_emlrtRTEI = { 18,/* lineNo */
  35,                                  /* colNo */
  "computeLeakage",                    /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\computeLeakage.m"/* pName */
};

static emlrtRTEInfo q_emlrtRTEI = { 45,/* lineNo */
  6,                                   /* colNo */
  "applyBinaryScalarFunction",         /* fName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\applyBinaryScalarFunction.m"/* pName */
};

static emlrtRTEInfo r_emlrtRTEI = { 58,/* lineNo */
  5,                                   /* colNo */
  "power",                             /* fName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\lib\\matlab\\ops\\power.m"/* pName */
};

static emlrtRTEInfo s_emlrtRTEI = { 18,/* lineNo */
  17,                                  /* colNo */
  "computeLeakage",                    /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\computeLeakage.m"/* pName */
};

static emlrtRTEInfo t_emlrtRTEI = { 41,/* lineNo */
  1,                                   /* colNo */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pName */
};

static emlrtRTEInfo u_emlrtRTEI = { 19,/* lineNo */
  1,                                   /* colNo */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pName */
};

static emlrtRTEInfo v_emlrtRTEI = { 27,/* lineNo */
  1,                                   /* colNo */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pName */
};

static emlrtRTEInfo w_emlrtRTEI = { 1, /* lineNo */
  41,                                  /* colNo */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pName */
};

static emlrtRTEInfo x_emlrtRTEI = { 1, /* lineNo */
  27,                                  /* colNo */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pName */
};

static emlrtRTEInfo ab_emlrtRTEI = { 27,/* lineNo */
  17,                                  /* colNo */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pName */
};

static emlrtRTEInfo bb_emlrtRTEI = { 65,/* lineNo */
  27,                                  /* colNo */
  "applyBinaryScalarFunction",         /* fName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\applyBinaryScalarFunction.m"/* pName */
};

static emlrtBCInfo emlrtBCI = { -1,    /* iFirst */
  -1,                                  /* iLast */
  31,                                  /* lineNo */
  10,                                  /* colNo */
  "a",                                 /* aName */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo emlrtECI = { 2,     /* nDims */
  36,                                  /* lineNo */
  25,                                  /* colNo */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pName */
};

static emlrtECInfo b_emlrtECI = { 2,   /* nDims */
  41,                                  /* lineNo */
  14,                                  /* colNo */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m"/* pName */
};

static emlrtECInfo c_emlrtECI = { -1,  /* nDims */
  18,                                  /* lineNo */
  17,                                  /* colNo */
  "computeLeakage",                    /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\computeLeakage.m"/* pName */
};

static emlrtRTEInfo he_emlrtRTEI = { 18,/* lineNo */
  23,                                  /* colNo */
  "scalexpAlloc",                      /* fName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\scalexpAlloc.m"/* pName */
};

static emlrtBCInfo b_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  26,                                  /* lineNo */
  8,                                   /* colNo */
  "Q",                                 /* aName */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  32,                                  /* lineNo */
  9,                                   /* colNo */
  "fAssign",                           /* aName */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo d_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  32,                                  /* lineNo */
  9,                                   /* colNo */
  "goodInd",                           /* aName */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo e_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  32,                                  /* lineNo */
  9,                                   /* colNo */
  "objPTR",                            /* aName */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo f_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  32,                                  /* lineNo */
  9,                                   /* colNo */
  "a",                                 /* aName */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo g_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  38,                                  /* lineNo */
  5,                                   /* colNo */
  "fAssign",                           /* aName */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo h_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  38,                                  /* lineNo */
  5,                                   /* colNo */
  "wrongI",                            /* aName */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo i_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  38,                                  /* lineNo */
  5,                                   /* colNo */
  "wrongJ",                            /* aName */
  "optimalWTA",                        /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\optimalWTA.m",/* pName */
  0                                    /* checkKind */
};

/* Function Definitions */
void optimalWTA(const emlrtStack *sp, const emxArray_real_T *lethality, const
                emxArray_real_T *reachMat, const emxArray_real_T *pKill, real_T
                maxKV, emxArray_real_T *fAssign, real_T *fLeak, real_T
                *totalReach)
{
  int32_T nx_idx_0;
  int32_T m;
  int32_T i0;
  emxArray_real_T *b_totalReach;
  emxArray_real_T *Q;
  int32_T nx;
  emxArray_real_T *goodInd;
  uint32_T Q_idx_0;
  emxArray_int32_T *ii;
  boolean_T overflow;
  int32_T i;
  int32_T idx;
  boolean_T exitg1;
  int32_T b_fAssign[2];
  int32_T i1;
  emxArray_real_T *aKV;
  emxArray_real_T *varargin_2;
  emxArray_real_T *objPTR;
  real_T b;
  emxArray_boolean_T *x;
  emxArray_boolean_T *r0;
  int32_T b_x[2];
  emxArray_int32_T *j;
  emxArray_boolean_T *v;
  emxArray_real_T *wrongJ;
  boolean_T guard1 = false;
  emxArray_real_T b_varargin_2;
  int32_T c_varargin_2[1];
  emxArray_real_T *z1;
  boolean_T p;
  int32_T d_varargin_2[1];
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  emlrtStack g_st;
  emlrtStack h_st;
  emlrtStack i_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;
  g_st.prev = &f_st;
  g_st.tls = f_st.tls;
  h_st.prev = &g_st;
  h_st.tls = g_st.tls;
  i_st.prev = &h_st;
  i_st.tls = h_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);

  /*  lethality is the vector of object lethalities */
  /*  reachMat is the reachability matrix */
  /*  pKill is the probability of a KV eliminating the object's lethality once */
  /*        it has been assigned to that object */
  /*  maxKV is the maximum number of KVs allowed to assign to a single object */
  /*  */
  /*  fAssign is the (#KV x #Ojb) assignment matrix */
  /*  fLeak is the total lethality leakage for fAssign */
  /*  */
  /*  Author: G. Chiang */
  /*  Date: 3/29/2016 */
  /*  */
  nx_idx_0 = reachMat->size[0];
  m = reachMat->size[1];
  i0 = fAssign->size[0] * fAssign->size[1];
  fAssign->size[0] = nx_idx_0;
  fAssign->size[1] = m;
  emxEnsureCapacity_real_T(sp, fAssign, i0, &emlrtRTEI);
  m *= nx_idx_0;
  for (i0 = 0; i0 < m; i0++) {
    fAssign->data[i0] = 0.0;
  }

  emxInit_real_T(sp, &b_totalReach, 2, &x_emlrtRTEI, true);
  i0 = b_totalReach->size[0] * b_totalReach->size[1];
  b_totalReach->size[0] = reachMat->size[0];
  b_totalReach->size[1] = reachMat->size[1];
  emxEnsureCapacity_real_T(sp, b_totalReach, i0, &b_emlrtRTEI);
  m = reachMat->size[0] * reachMat->size[1];
  for (i0 = 0; i0 < m; i0++) {
    b_totalReach->data[i0] = reachMat->data[i0];
  }

  st.site = &emlrtRSI;
  b_floor(&st, b_totalReach);
  st.site = &emlrtRSI;
  b_st.site = &n_emlrtRSI;
  c_st.site = &o_emlrtRSI;
  d_st.site = &p_emlrtRSI;
  e_st.site = &q_emlrtRSI;
  nx_idx_0 = b_totalReach->size[0];
  m = b_totalReach->size[1];
  emxInit_real_T(&e_st, &Q, 2, &u_emlrtRTEI, true);
  i0 = Q->size[0] * Q->size[1];
  Q->size[0] = nx_idx_0;
  Q->size[1] = m;
  emxEnsureCapacity_real_T(&e_st, Q, i0, &c_emlrtRTEI);
  f_st.site = &r_emlrtRSI;
  nx = nx_idx_0 * m;
  g_st.site = &s_emlrtRSI;
  if ((1 <= nx) && (nx > 2147483646)) {
    h_st.site = &m_emlrtRSI;
    check_forloop_overflow_error(&h_st);
  }

  for (nx_idx_0 = 0; nx_idx_0 < nx; nx_idx_0++) {
    Q->data[nx_idx_0] = muDoubleScalarMin(1.0, b_totalReach->data[nx_idx_0]);
  }

  st.site = &b_emlrtRSI;
  b_st.site = &t_emlrtRSI;
  c_st.site = &o_emlrtRSI;
  d_st.site = &u_emlrtRSI;
  if (Q->size[1] < 1) {
    emlrtErrorWithMessageIdR2018a(&d_st, &de_emlrtRTEI,
      "Coder:toolbox:eml_min_or_max_varDimZero",
      "Coder:toolbox:eml_min_or_max_varDimZero", 0);
  }

  emxInit_real_T(&d_st, &goodInd, 1, &f_emlrtRTEI, true);
  e_st.site = &v_emlrtRSI;
  f_st.site = &w_emlrtRSI;
  g_st.site = &x_emlrtRSI;
  m = Q->size[0];
  nx = Q->size[1];
  Q_idx_0 = (uint32_T)Q->size[0];
  i0 = goodInd->size[0];
  goodInd->size[0] = (int32_T)Q_idx_0;
  emxEnsureCapacity_real_T(&g_st, goodInd, i0, &d_emlrtRTEI);
  if (Q->size[0] >= 1) {
    h_st.site = &bb_emlrtRSI;
    overflow = (Q->size[0] > 2147483646);
    if (overflow) {
      i_st.site = &m_emlrtRSI;
      check_forloop_overflow_error(&i_st);
    }

    for (i = 0; i < m; i++) {
      goodInd->data[i] = Q->data[i];
    }

    h_st.site = &ab_emlrtRSI;
    overflow = ((2 <= Q->size[1]) && (Q->size[1] > 2147483646));
    if (overflow) {
      i_st.site = &m_emlrtRSI;
      check_forloop_overflow_error(&i_st);
    }

    for (nx_idx_0 = 2; nx_idx_0 <= nx; nx_idx_0++) {
      h_st.site = &y_emlrtRSI;
      if ((1 <= m) && (m > 2147483646)) {
        i_st.site = &m_emlrtRSI;
        check_forloop_overflow_error(&i_st);
      }

      for (i = 0; i < m; i++) {
        if (goodInd->data[i] < Q->data[i + Q->size[0] * (nx_idx_0 - 1)]) {
          goodInd->data[i] = Q->data[i + Q->size[0] * (nx_idx_0 - 1)];
        }
      }
    }
  }

  emxInit_int32_T(&g_st, &ii, 1, &y_emlrtRTEI, true);
  st.site = &b_emlrtRSI;
  b_st.site = &cb_emlrtRSI;
  nx = goodInd->size[0];
  c_st.site = &db_emlrtRSI;
  idx = 0;
  i0 = ii->size[0];
  ii->size[0] = goodInd->size[0];
  emxEnsureCapacity_int32_T(&c_st, ii, i0, &e_emlrtRTEI);
  d_st.site = &eb_emlrtRSI;
  overflow = ((1 <= goodInd->size[0]) && (goodInd->size[0] > 2147483646));
  if (overflow) {
    e_st.site = &m_emlrtRSI;
    check_forloop_overflow_error(&e_st);
  }

  nx_idx_0 = 0;
  exitg1 = false;
  while ((!exitg1) && (nx_idx_0 <= nx - 1)) {
    if (goodInd->data[nx_idx_0] != 0.0) {
      idx++;
      ii->data[idx - 1] = nx_idx_0 + 1;
      if (idx >= nx) {
        exitg1 = true;
      } else {
        nx_idx_0++;
      }
    } else {
      nx_idx_0++;
    }
  }

  if (idx > goodInd->size[0]) {
    emlrtErrorWithMessageIdR2018a(&c_st, &ee_emlrtRTEI,
      "Coder:builtins:AssertionFailed", "Coder:builtins:AssertionFailed", 0);
  }

  if (goodInd->size[0] == 1) {
    if (idx == 0) {
      ii->size[0] = 0;
    }
  } else {
    if (1 > idx) {
      i0 = 0;
    } else {
      i0 = idx;
    }

    b_fAssign[0] = 1;
    b_fAssign[1] = i0;
    d_st.site = &fb_emlrtRSI;
    indexShapeCheck(&d_st, ii->size[0], b_fAssign);
    i1 = ii->size[0];
    ii->size[0] = i0;
    emxEnsureCapacity_int32_T(&c_st, ii, i1, &g_emlrtRTEI);
  }

  i0 = goodInd->size[0];
  goodInd->size[0] = ii->size[0];
  emxEnsureCapacity_real_T(&st, goodInd, i0, &f_emlrtRTEI);
  m = ii->size[0];
  for (i0 = 0; i0 < m; i0++) {
    goodInd->data[i0] = ii->data[i0];
  }

  /* exclude unassignable KVs from WTA */
  if (goodInd->size[0] == 0) {
    *totalReach = 0.0;

    /*  Matlab coder */
    st.site = &c_emlrtRSI;
    *fLeak = sum(&st, lethality);
  } else {
    nx_idx_0 = Q->size[0];
    m = goodInd->size[0];
    for (i0 = 0; i0 < m; i0++) {
      i1 = (int32_T)goodInd->data[i0];
      if ((i1 < 1) || (i1 > nx_idx_0)) {
        emlrtDynamicBoundsCheckR2012b(i1, 1, nx_idx_0, &b_emlrtBCI, sp);
      }
    }

    m = Q->size[1];
    i0 = b_totalReach->size[0] * b_totalReach->size[1];
    b_totalReach->size[0] = goodInd->size[0];
    b_totalReach->size[1] = m;
    emxEnsureCapacity_real_T(sp, b_totalReach, i0, &h_emlrtRTEI);
    for (i0 = 0; i0 < m; i0++) {
      nx_idx_0 = goodInd->size[0];
      for (i1 = 0; i1 < nx_idx_0; i1++) {
        b_totalReach->data[i1 + b_totalReach->size[0] * i0] = Q->data[((int32_T)
          goodInd->data[i1] + Q->size[0] * i0) - 1];
      }
    }

    emxInit_real_T(sp, &aKV, 2, &v_emlrtRTEI, true);
    emxInit_real_T(sp, &varargin_2, 2, &ab_emlrtRTEI, true);
    st.site = &d_emlrtRSI;
    b_sum(&st, b_totalReach, varargin_2);
    st.site = &d_emlrtRSI;
    b_st.site = &n_emlrtRSI;
    c_st.site = &o_emlrtRSI;
    d_st.site = &p_emlrtRSI;
    e_st.site = &q_emlrtRSI;
    i0 = aKV->size[0] * aKV->size[1];
    aKV->size[0] = 1;
    aKV->size[1] = varargin_2->size[1];
    emxEnsureCapacity_real_T(&e_st, aKV, i0, &c_emlrtRTEI);
    f_st.site = &r_emlrtRSI;
    nx = varargin_2->size[1];
    g_st.site = &s_emlrtRSI;
    overflow = ((1 <= aKV->size[1]) && (aKV->size[1] > 2147483646));
    if (overflow) {
      h_st.site = &m_emlrtRSI;
      check_forloop_overflow_error(&h_st);
    }

    for (nx_idx_0 = 0; nx_idx_0 < nx; nx_idx_0++) {
      aKV->data[nx_idx_0] = muDoubleScalarMin(maxKV, varargin_2->data[nx_idx_0]);
    }

    emxInit_real_T(&f_st, &objPTR, 2, &w_emlrtRTEI, true);
    st.site = &e_emlrtRSI;
    costPrep(&st, lethality, aKV, pKill, Q, b_totalReach, objPTR);
    st.site = &f_emlrtRSI;
    munkres(&st, b_totalReach, varargin_2, &b);
    i0 = goodInd->size[0];
    emxFree_real_T(&aKV);
    for (i = 0; i < i0; i++) {
      i1 = varargin_2->size[1];
      nx_idx_0 = 1 + i;
      if ((nx_idx_0 < 1) || (nx_idx_0 > i1)) {
        emlrtDynamicBoundsCheckR2012b(nx_idx_0, 1, i1, &emlrtBCI, sp);
      }

      st.site = &g_emlrtRSI;
      if (muDoubleScalarIsNaN(varargin_2->data[i])) {
        b_st.site = &dd_emlrtRSI;
        c_error(&b_st);
      }

      if (varargin_2->data[i] != 0.0) {
        i1 = fAssign->size[0];
        nx_idx_0 = goodInd->size[0];
        m = 1 + i;
        if ((m < 1) || (m > nx_idx_0)) {
          emlrtDynamicBoundsCheckR2012b(m, 1, nx_idx_0, &d_emlrtBCI, sp);
        }

        nx_idx_0 = (int32_T)goodInd->data[m - 1];
        if ((nx_idx_0 < 1) || (nx_idx_0 > i1)) {
          emlrtDynamicBoundsCheckR2012b(nx_idx_0, 1, i1, &c_emlrtBCI, sp);
        }

        i1 = fAssign->size[1];
        m = objPTR->size[1];
        nx = varargin_2->size[1];
        idx = 1 + i;
        if ((idx < 1) || (idx > nx)) {
          emlrtDynamicBoundsCheckR2012b(idx, 1, nx, &f_emlrtBCI, sp);
        }

        nx = (int32_T)varargin_2->data[idx - 1];
        if ((nx < 1) || (nx > m)) {
          emlrtDynamicBoundsCheckR2012b(nx, 1, m, &e_emlrtBCI, sp);
        }

        m = (int32_T)objPTR->data[nx - 1];
        if ((m < 1) || (m > i1)) {
          emlrtDynamicBoundsCheckR2012b(m, 1, i1, &c_emlrtBCI, sp);
        }

        fAssign->data[(nx_idx_0 + fAssign->size[0] * (m - 1)) - 1] = 1.0;
      }

      if (*emlrtBreakCheckR2012bFlagVar != 0) {
        emlrtBreakCheckR2012b(sp);
      }
    }

    emxFree_real_T(&objPTR);
    emxInit_boolean_T(sp, &x, 2, &i_emlrtRTEI, true);

    /*  Remove the KVs that have been WRONGLY assigned */
    i0 = x->size[0] * x->size[1];
    x->size[0] = fAssign->size[0];
    x->size[1] = fAssign->size[1];
    emxEnsureCapacity_boolean_T(sp, x, i0, &i_emlrtRTEI);
    m = fAssign->size[0] * fAssign->size[1];
    for (i0 = 0; i0 < m; i0++) {
      x->data[i0] = (fAssign->data[i0] == 1.0);
    }

    emxInit_boolean_T(sp, &r0, 2, &w_emlrtRTEI, true);
    i0 = r0->size[0] * r0->size[1];
    r0->size[0] = Q->size[0];
    r0->size[1] = Q->size[1];
    emxEnsureCapacity_boolean_T(sp, r0, i0, &j_emlrtRTEI);
    m = Q->size[0] * Q->size[1];
    for (i0 = 0; i0 < m; i0++) {
      r0->data[i0] = (Q->data[i0] == 0.0);
    }

    b_x[0] = x->size[0];
    b_x[1] = x->size[1];
    b_fAssign[0] = r0->size[0];
    b_fAssign[1] = r0->size[1];
    if ((b_x[0] != b_fAssign[0]) || (b_x[1] != b_fAssign[1])) {
      emlrtSizeEqCheckNDR2012b(&b_x[0], &b_fAssign[0], &emlrtECI, sp);
    }

    st.site = &h_emlrtRSI;
    i0 = x->size[0] * x->size[1];
    i1 = x->size[0] * x->size[1];
    emxEnsureCapacity_boolean_T(&st, x, i1, &i_emlrtRTEI);
    m = i0 - 1;
    for (i0 = 0; i0 <= m; i0++) {
      x->data[i0] = (x->data[i0] && r0->data[i0]);
    }

    emxFree_boolean_T(&r0);
    b_st.site = &nd_emlrtRSI;
    nx = x->size[0] * x->size[1];
    if ((x->size[0] != 1) || (x->size[1] <= 1)) {
    } else {
      emlrtErrorWithMessageIdR2018a(&b_st, &fe_emlrtRTEI,
        "Coder:toolbox:find_incompatibleShape",
        "Coder:toolbox:find_incompatibleShape", 0);
    }

    emxInit_int32_T(&b_st, &j, 1, &w_emlrtRTEI, true);
    if (nx == 0) {
      ii->size[0] = 0;
      j->size[0] = 0;
    } else {
      emxInit_boolean_T(&b_st, &v, 1, &w_emlrtRTEI, true);
      c_st.site = &od_emlrtRSI;
      idx = 0;
      i0 = ii->size[0];
      ii->size[0] = nx;
      emxEnsureCapacity_int32_T(&c_st, ii, i0, &k_emlrtRTEI);
      i0 = j->size[0];
      j->size[0] = nx;
      emxEnsureCapacity_int32_T(&c_st, j, i0, &k_emlrtRTEI);
      i0 = v->size[0];
      v->size[0] = nx;
      emxEnsureCapacity_boolean_T(&c_st, v, i0, &k_emlrtRTEI);
      nx_idx_0 = 1;
      m = 1;
      exitg1 = false;
      while ((!exitg1) && (m <= x->size[1])) {
        guard1 = false;
        if (x->data[(nx_idx_0 + x->size[0] * (m - 1)) - 1]) {
          idx++;
          ii->data[idx - 1] = nx_idx_0;
          j->data[idx - 1] = m;
          v->data[idx - 1] = x->data[(nx_idx_0 + x->size[0] * (m - 1)) - 1];
          if (idx >= nx) {
            exitg1 = true;
          } else {
            guard1 = true;
          }
        } else {
          guard1 = true;
        }

        if (guard1) {
          nx_idx_0++;
          if (nx_idx_0 > x->size[0]) {
            nx_idx_0 = 1;
            m++;
          }
        }
      }

      if (idx > nx) {
        emlrtErrorWithMessageIdR2018a(&c_st, &ge_emlrtRTEI,
          "Coder:builtins:AssertionFailed", "Coder:builtins:AssertionFailed", 0);
      }

      if (nx == 1) {
        if (idx == 0) {
          ii->size[0] = 0;
          j->size[0] = 0;
        }
      } else {
        if (1 > idx) {
          i0 = 0;
        } else {
          i0 = idx;
        }

        b_fAssign[0] = 1;
        b_fAssign[1] = i0;
        d_st.site = &pd_emlrtRSI;
        indexShapeCheck(&d_st, ii->size[0], b_fAssign);
        i1 = ii->size[0];
        ii->size[0] = i0;
        emxEnsureCapacity_int32_T(&c_st, ii, i1, &n_emlrtRTEI);
        if (1 > idx) {
          i0 = 0;
        } else {
          i0 = idx;
        }

        b_fAssign[0] = 1;
        b_fAssign[1] = i0;
        d_st.site = &qd_emlrtRSI;
        indexShapeCheck(&d_st, j->size[0], b_fAssign);
        i1 = j->size[0];
        j->size[0] = i0;
        emxEnsureCapacity_int32_T(&c_st, j, i1, &o_emlrtRTEI);
        b_fAssign[0] = 1;
        if (1 > idx) {
          b_fAssign[1] = 0;
        } else {
          b_fAssign[1] = idx;
        }

        d_st.site = &rd_emlrtRSI;
        indexShapeCheck(&d_st, v->size[0], b_fAssign);
      }

      emxFree_boolean_T(&v);
    }

    emxFree_boolean_T(&x);
    i0 = goodInd->size[0];
    goodInd->size[0] = ii->size[0];
    emxEnsureCapacity_real_T(&st, goodInd, i0, &l_emlrtRTEI);
    m = ii->size[0];
    for (i0 = 0; i0 < m; i0++) {
      goodInd->data[i0] = ii->data[i0];
    }

    emxInit_real_T(&st, &wrongJ, 1, &q_emlrtRTEI, true);
    i0 = wrongJ->size[0];
    wrongJ->size[0] = j->size[0];
    emxEnsureCapacity_real_T(&st, wrongJ, i0, &m_emlrtRTEI);
    m = j->size[0];
    for (i0 = 0; i0 < m; i0++) {
      wrongJ->data[i0] = j->data[i0];
    }

    emxFree_int32_T(&j);
    i0 = goodInd->size[0];
    for (i = 0; i < i0; i++) {
      i1 = fAssign->size[0];
      nx_idx_0 = goodInd->size[0];
      m = 1 + i;
      if ((m < 1) || (m > nx_idx_0)) {
        emlrtDynamicBoundsCheckR2012b(m, 1, nx_idx_0, &h_emlrtBCI, sp);
      }

      nx_idx_0 = (int32_T)goodInd->data[m - 1];
      if ((nx_idx_0 < 1) || (nx_idx_0 > i1)) {
        emlrtDynamicBoundsCheckR2012b(nx_idx_0, 1, i1, &g_emlrtBCI, sp);
      }

      i1 = fAssign->size[1];
      m = wrongJ->size[0];
      nx = 1 + i;
      if ((nx < 1) || (nx > m)) {
        emlrtDynamicBoundsCheckR2012b(nx, 1, m, &i_emlrtBCI, sp);
      }

      m = (int32_T)wrongJ->data[nx - 1];
      if ((m < 1) || (m > i1)) {
        emlrtDynamicBoundsCheckR2012b(m, 1, i1, &g_emlrtBCI, sp);
      }

      fAssign->data[(nx_idx_0 + fAssign->size[0] * (m - 1)) - 1] = 0.0;
      if (*emlrtBreakCheckR2012bFlagVar != 0) {
        emlrtBreakCheckR2012b(sp);
      }
    }

    st.site = &i_emlrtRSI;
    b_sum(&st, fAssign, varargin_2);
    st.site = &i_emlrtRSI;

    /*  lethality is the vector of object lethalities */
    /*  KVsAssigned is a vector that indicates how many KVs have been assigned */
    /*        to each object */
    /*  pKill is the probability of a KV eliminating the object's lethality once */
    /*        it has been assigned to that object */
    /*  */
    /*  leakageVector is the leakage from each object computed as */
    /*      leakageVector(i) =  lethality(i) * (1.0 - pKill(i)) ^ KVsAssigned(i) */
    /*  */
    /*  pLeakage is the leakage (or probability of leakage) computed as */
    /*      pLeakage = sum(  leakageVector  ) */
    /*  */
    /*  Author: G. Chiang */
    /*  Date: 3/29/2016 */
    /*  */
    b_st.site = &be_emlrtRSI;
    i0 = goodInd->size[0];
    goodInd->size[0] = pKill->size[1];
    emxEnsureCapacity_real_T(&b_st, goodInd, i0, &p_emlrtRTEI);
    m = pKill->size[1];
    for (i0 = 0; i0 < m; i0++) {
      goodInd->data[i0] = 1.0 - pKill->data[i0];
    }

    c_st.site = &pb_emlrtRSI;
    d_st.site = &de_emlrtRSI;
    e_st.site = &fe_emlrtRSI;
    if (goodInd->size[0] <= varargin_2->size[1]) {
      m = goodInd->size[0];
    } else {
      m = varargin_2->size[1];
    }

    i0 = wrongJ->size[0];
    wrongJ->size[0] = m;
    emxEnsureCapacity_real_T(&e_st, wrongJ, i0, &q_emlrtRTEI);
    nx_idx_0 = varargin_2->size[1];
    b_varargin_2 = *varargin_2;
    c_varargin_2[0] = nx_idx_0;
    b_varargin_2.size = &c_varargin_2[0];
    b_varargin_2.numDimensions = 1;
    if (!dimagree(wrongJ, goodInd, &b_varargin_2)) {
      emlrtErrorWithMessageIdR2018a(&e_st, &he_emlrtRTEI, "MATLAB:dimagree",
        "MATLAB:dimagree", 0);
    }

    emxInit_real_T(&e_st, &z1, 1, &bb_emlrtRTEI, true);
    i0 = z1->size[0];
    z1->size[0] = wrongJ->size[0];
    emxEnsureCapacity_real_T(&d_st, z1, i0, &r_emlrtRTEI);
    e_st.site = &r_emlrtRSI;
    f_st.site = &ge_emlrtRSI;
    overflow = ((1 <= wrongJ->size[0]) && (wrongJ->size[0] > 2147483646));
    emxFree_real_T(&wrongJ);
    if (overflow) {
      g_st.site = &m_emlrtRSI;
      check_forloop_overflow_error(&g_st);
    }

    for (nx_idx_0 = 0; nx_idx_0 < m; nx_idx_0++) {
      z1->data[nx_idx_0] = muDoubleScalarPower(goodInd->data[nx_idx_0],
        varargin_2->data[nx_idx_0]);
    }

    d_st.site = &ee_emlrtRSI;
    if (goodInd->size[0] == 1) {
      if (goodInd->data[0] < 0.0) {
        e_st.site = &he_emlrtRSI;
        f_st.site = &je_emlrtRSI;
        nx = varargin_2->size[1];
        p = false;
        g_st.site = &ke_emlrtRSI;
        overflow = ((1 <= varargin_2->size[1]) && (varargin_2->size[1] >
          2147483646));
        if (overflow) {
          h_st.site = &m_emlrtRSI;
          check_forloop_overflow_error(&h_st);
        }

        for (nx_idx_0 = 0; nx_idx_0 < nx; nx_idx_0++) {
          if (p) {
            p = true;
          } else {
            b = varargin_2->data[nx_idx_0];
            if ((!muDoubleScalarIsNaN(b)) && (muDoubleScalarFloor(b) !=
                 varargin_2->data[nx_idx_0])) {
              p = true;
            } else {
              p = false;
            }
          }
        }
      } else {
        p = false;
      }
    } else if (varargin_2->size[1] == 1) {
      if ((!muDoubleScalarIsNaN(varargin_2->data[0])) && (muDoubleScalarFloor
           (varargin_2->data[0]) != varargin_2->data[0])) {
        e_st.site = &ie_emlrtRSI;
        f_st.site = &je_emlrtRSI;
        nx = goodInd->size[0];
        p = false;
        g_st.site = &ke_emlrtRSI;
        overflow = ((1 <= goodInd->size[0]) && (goodInd->size[0] > 2147483646));
        if (overflow) {
          h_st.site = &m_emlrtRSI;
          check_forloop_overflow_error(&h_st);
        }

        for (nx_idx_0 = 0; nx_idx_0 < nx; nx_idx_0++) {
          if (p || (goodInd->data[nx_idx_0] < 0.0)) {
            p = true;
          } else {
            p = false;
          }
        }
      } else {
        p = false;
      }
    } else {
      p = false;
      i0 = goodInd->size[0];
      for (nx_idx_0 = 0; nx_idx_0 < i0; nx_idx_0++) {
        if (p || ((goodInd->data[nx_idx_0] < 0.0) && (!muDoubleScalarIsNaN
              (varargin_2->data[nx_idx_0])) && (muDoubleScalarFloor
              (varargin_2->data[nx_idx_0]) != varargin_2->data[nx_idx_0]))) {
          p = true;
        } else {
          p = false;
        }
      }
    }

    emxFree_real_T(&varargin_2);
    if (p) {
      d_st.site = &qb_emlrtRSI;
      error(&d_st);
    }

    i0 = lethality->size[1];
    i1 = z1->size[0];
    if (i0 != i1) {
      emlrtSizeEqCheck1DR2012b(i0, i1, &c_emlrtECI, &st);
    }

    /*  make leakageVector a row vector. */
    i0 = goodInd->size[0];
    goodInd->size[0] = lethality->size[1];
    emxEnsureCapacity_real_T(&st, goodInd, i0, &s_emlrtRTEI);
    m = lethality->size[1];
    for (i0 = 0; i0 < m; i0++) {
      goodInd->data[i0] = lethality->data[i0] * z1->data[i0];
    }

    emxFree_real_T(&z1);
    b_st.site = &ce_emlrtRSI;
    *fLeak = c_sum(&b_st, goodInd);
    b_fAssign[0] = fAssign->size[0];
    b_fAssign[1] = fAssign->size[1];
    b_x[0] = reachMat->size[0];
    b_x[1] = reachMat->size[1];
    if ((b_fAssign[0] != b_x[0]) || (b_fAssign[1] != b_x[1])) {
      emlrtSizeEqCheckNDR2012b(&b_fAssign[0], &b_x[0], &b_emlrtECI, sp);
    }

    i0 = b_totalReach->size[0] * b_totalReach->size[1];
    b_totalReach->size[0] = fAssign->size[0];
    b_totalReach->size[1] = fAssign->size[1];
    emxEnsureCapacity_real_T(sp, b_totalReach, i0, &t_emlrtRTEI);
    m = fAssign->size[0] * fAssign->size[1];
    for (i0 = 0; i0 < m; i0++) {
      b_totalReach->data[i0] = fAssign->data[i0] * reachMat->data[i0];
    }

    /*  Matlab coder */
    nx_idx_0 = b_totalReach->size[0] * b_totalReach->size[1];
    b_varargin_2 = *b_totalReach;
    d_varargin_2[0] = nx_idx_0;
    b_varargin_2.size = &d_varargin_2[0];
    b_varargin_2.numDimensions = 1;
    st.site = &j_emlrtRSI;
    *totalReach = c_sum(&st, &b_varargin_2);

    /*  Matlab coder */
  }

  emxFree_int32_T(&ii);
  emxFree_real_T(&b_totalReach);
  emxFree_real_T(&goodInd);
  emxFree_real_T(&Q);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

/* End of code generation (optimalWTA.cpp) */
