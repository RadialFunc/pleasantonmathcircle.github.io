/*
 * costPrep.cpp
 *
 * Code generation for function 'costPrep'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "costPrep.h"
#include "optimalWTA_emxutil.h"
#include "mpower.h"
#include "sum.h"
#include "optimalWTA_data.h"

/* Variable Definitions */
static emlrtRSInfo mb_emlrtRSI = { 15, /* lineNo */
  "costPrep",                          /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m"/* pathName */
};

static emlrtRSInfo nb_emlrtRSI = { 23, /* lineNo */
  "costPrep",                          /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m"/* pathName */
};

static emlrtRTEInfo eb_emlrtRTEI = { 16,/* lineNo */
  1,                                   /* colNo */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m"/* pName */
};

static emlrtRTEInfo fb_emlrtRTEI = { 17,/* lineNo */
  1,                                   /* colNo */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m"/* pName */
};

static emlrtRTEInfo gb_emlrtRTEI = { 27,/* lineNo */
  1,                                   /* colNo */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m"/* pName */
};

static emlrtRTEInfo hb_emlrtRTEI = { 23,/* lineNo */
  11,                                  /* colNo */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m"/* pName */
};

static emlrtRTEInfo ib_emlrtRTEI = { 23,/* lineNo */
  20,                                  /* colNo */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m"/* pName */
};

static emlrtRTEInfo jb_emlrtRTEI = { 1,/* lineNo */
  29,                                  /* colNo */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m"/* pName */
};

static emlrtBCInfo j_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  21,                                  /* lineNo */
  19,                                  /* colNo */
  "aKV",                               /* aName */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m",/* pName */
  0                                    /* checkKind */
};

static emlrtRTEInfo le_emlrtRTEI = { 21,/* lineNo */
  13,                                  /* colNo */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m"/* pName */
};

static emlrtBCInfo k_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  23,                                  /* lineNo */
  65,                                  /* colNo */
  "Q",                                 /* aName */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo l_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  23,                                  /* lineNo */
  14,                                  /* colNo */
  "S",                                 /* aName */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo d_emlrtECI = { -1,  /* nDims */
  23,                                  /* lineNo */
  9,                                   /* colNo */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m"/* pName */
};

static emlrtDCInfo emlrtDCI = { 16,    /* lineNo */
  19,                                  /* colNo */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m",/* pName */
  1                                    /* checkKind */
};

static emlrtDCInfo b_emlrtDCI = { 16,  /* lineNo */
  19,                                  /* colNo */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m",/* pName */
  4                                    /* checkKind */
};

static emlrtDCInfo c_emlrtDCI = { 17,  /* lineNo */
  16,                                  /* colNo */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m",/* pName */
  1                                    /* checkKind */
};

static emlrtDCInfo d_emlrtDCI = { 16,  /* lineNo */
  1,                                   /* colNo */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m",/* pName */
  1                                    /* checkKind */
};

static emlrtDCInfo e_emlrtDCI = { 17,  /* lineNo */
  1,                                   /* colNo */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo m_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  23,                                  /* lineNo */
  20,                                  /* colNo */
  "pKill",                             /* aName */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo n_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  23,                                  /* lineNo */
  29,                                  /* colNo */
  "lethality",                         /* aName */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo o_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  23,                                  /* lineNo */
  45,                                  /* colNo */
  "pKill",                             /* aName */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo p_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  24,                                  /* lineNo */
  9,                                   /* colNo */
  "objPTR",                            /* aName */
  "costPrep",                          /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\costPrep.m",/* pName */
  0                                    /* checkKind */
};

/* Function Definitions */
void costPrep(const emlrtStack *sp, const emxArray_real_T *lethality, const
              emxArray_real_T *aKV, const emxArray_real_T *pKill, const
              emxArray_real_T *Q, emxArray_real_T *costMat, emxArray_real_T
              *objPTR)
{
  real_T smak;
  int32_T i2;
  int32_T loop_ub;
  uint32_T kp;
  emxArray_int32_T *r1;
  emxArray_real_T *r2;
  int32_T i;
  int32_T i3;
  int32_T i4;
  int32_T j;
  int32_T i5;
  int32_T i6;
  int32_T iv0[1];
  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);

  /*  lethality is the vector of object lethalities */
  /*  aKV is the vector of total assignable KVs to each object */
  /*  pKill is the probability of a KV eliminating the object's lethality once */
  /*        it has been assigned to that object */
  /*  Q is the binary reachability matrix */
  /*  */
  /*  costMat is the cost matrix for Munkres algorithm */
  /*  objPTR is a vector mapping costMat columns to object IDs */
  /*  */
  /*  Author: G. Chiang */
  /*  Date: 3/29/2016 */
  /*  */
  /*  Matlab coder */
  st.site = &mb_emlrtRSI;
  smak = sum(&st, aKV);
  i2 = objPTR->size[0] * objPTR->size[1];
  objPTR->size[0] = 1;
  if (!(smak >= 0.0)) {
    emlrtNonNegativeCheckR2012b(smak, &b_emlrtDCI, sp);
  }

  if (smak != (int32_T)muDoubleScalarFloor(smak)) {
    emlrtIntegerCheckR2012b(smak, &emlrtDCI, sp);
  }

  objPTR->size[1] = (int32_T)smak;
  emxEnsureCapacity_real_T(sp, objPTR, i2, &eb_emlrtRTEI);
  if (smak != (int32_T)muDoubleScalarFloor(smak)) {
    emlrtIntegerCheckR2012b(smak, &d_emlrtDCI, sp);
  }

  loop_ub = (int32_T)smak;
  for (i2 = 0; i2 < loop_ub; i2++) {
    objPTR->data[i2] = 0.0;
  }

  i2 = costMat->size[0] * costMat->size[1];
  costMat->size[0] = Q->size[0];
  if (smak != (int32_T)muDoubleScalarFloor(smak)) {
    emlrtIntegerCheckR2012b(smak, &c_emlrtDCI, sp);
  }

  costMat->size[1] = (int32_T)smak;
  emxEnsureCapacity_real_T(sp, costMat, i2, &fb_emlrtRTEI);
  if (smak != (int32_T)muDoubleScalarFloor(smak)) {
    emlrtIntegerCheckR2012b(smak, &e_emlrtDCI, sp);
  }

  loop_ub = Q->size[0] * (int32_T)smak;
  for (i2 = 0; i2 < loop_ub; i2++) {
    costMat->data[i2] = 0.0;
  }

  kp = 0U;
  i2 = lethality->size[1];
  emxInit_int32_T(sp, &r1, 1, &jb_emlrtRTEI, true);
  emxInit_real_T(sp, &r2, 1, &jb_emlrtRTEI, true);
  for (i = 0; i < i2; i++) {
    i3 = aKV->size[1];
    i4 = 1 + i;
    if ((i4 < 1) || (i4 > i3)) {
      emlrtDynamicBoundsCheckR2012b(i4, 1, i3, &j_emlrtBCI, sp);
    }

    i3 = (int32_T)aKV->data[i];
    emlrtForLoopVectorCheckR2012b(1.0, 1.0, aKV->data[i], mxDOUBLE_CLASS,
      (int32_T)aKV->data[i], &le_emlrtRTEI, sp);
    for (j = 0; j < i3; j++) {
      kp++;

      /*  Matlab coder */
      loop_ub = costMat->size[0];
      i4 = r1->size[0];
      r1->size[0] = loop_ub;
      emxEnsureCapacity_int32_T(sp, r1, i4, &hb_emlrtRTEI);
      for (i4 = 0; i4 < loop_ub; i4++) {
        r1->data[i4] = i4;
      }

      i4 = costMat->size[1];
      loop_ub = (int32_T)kp;
      if ((loop_ub < 1) || (loop_ub > i4)) {
        emlrtDynamicBoundsCheckR2012b(loop_ub, 1, i4, &l_emlrtBCI, sp);
      }

      i4 = pKill->size[1];
      loop_ub = 1 + i;
      if ((loop_ub < 1) || (loop_ub > i4)) {
        emlrtDynamicBoundsCheckR2012b(loop_ub, 1, i4, &m_emlrtBCI, sp);
      }

      i4 = lethality->size[1];
      i5 = 1 + i;
      if ((i5 < 1) || (i5 > i4)) {
        emlrtDynamicBoundsCheckR2012b(i5, 1, i4, &n_emlrtBCI, sp);
      }

      i4 = pKill->size[1];
      i6 = 1 + i;
      if ((i6 < 1) || (i6 > i4)) {
        emlrtDynamicBoundsCheckR2012b(i6, 1, i4, &o_emlrtBCI, sp);
      }

      st.site = &nb_emlrtRSI;
      smak = pKill->data[loop_ub - 1] * lethality->data[i5 - 1] * mpower(&st,
        1.0 - pKill->data[i6 - 1], (1.0 + (real_T)j) - 1.0);
      i4 = Q->size[1];
      loop_ub = 1 + i;
      if ((loop_ub < 1) || (loop_ub > i4)) {
        emlrtDynamicBoundsCheckR2012b(loop_ub, 1, i4, &k_emlrtBCI, sp);
      }

      loop_ub = Q->size[0];
      i4 = r2->size[0];
      r2->size[0] = loop_ub;
      emxEnsureCapacity_real_T(sp, r2, i4, &ib_emlrtRTEI);
      for (i4 = 0; i4 < loop_ub; i4++) {
        r2->data[i4] = smak * Q->data[i4 + Q->size[0] * i];
      }

      iv0[0] = r1->size[0];
      emlrtSubAssignSizeCheckR2012b(&iv0[0], 1, &(*(int32_T (*)[1])r2->size)[0],
        1, &d_emlrtECI, sp);
      loop_ub = r2->size[0];
      for (i4 = 0; i4 < loop_ub; i4++) {
        costMat->data[r1->data[i4] + costMat->size[0] * ((int32_T)kp - 1)] =
          r2->data[i4];
      }

      /*  Matlab coder */
      i4 = objPTR->size[1];
      if (((int32_T)kp < 1) || ((int32_T)kp > i4)) {
        emlrtDynamicBoundsCheckR2012b((int32_T)kp, 1, i4, &p_emlrtBCI, sp);
      }

      objPTR->data[(int32_T)kp - 1] = 1.0 + (real_T)i;

      /*  Matlab coder */
      if (*emlrtBreakCheckR2012bFlagVar != 0) {
        emlrtBreakCheckR2012b(sp);
      }
    }

    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(sp);
    }
  }

  emxFree_real_T(&r2);
  emxFree_int32_T(&r1);
  i2 = costMat->size[0] * costMat->size[1];
  i3 = costMat->size[0] * costMat->size[1];
  emxEnsureCapacity_real_T(sp, costMat, i3, &gb_emlrtRTEI);
  loop_ub = i2 - 1;
  for (i2 = 0; i2 <= loop_ub; i2++) {
    costMat->data[i2] = 1.0 - costMat->data[i2];
  }

  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

/* End of code generation (costPrep.cpp) */
