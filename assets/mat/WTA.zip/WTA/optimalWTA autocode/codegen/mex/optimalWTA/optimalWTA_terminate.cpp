/*
 * optimalWTA_terminate.cpp
 *
 * Code generation for function 'optimalWTA_terminate'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "optimalWTA_terminate.h"
#include "_coder_optimalWTA_mex.h"
#include "optimalWTA_data.h"

/* Function Definitions */
void optimalWTA_atexit()
{
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  mexFunctionCreateRootTLS();
  st.tls = emlrtRootTLSGlobal;
  emlrtEnterRtStackR2012b(&st);
  emlrtLeaveRtStackR2012b(&st);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}

void optimalWTA_terminate()
{
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  st.tls = emlrtRootTLSGlobal;
  emlrtLeaveRtStackR2012b(&st);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}

/* End of code generation (optimalWTA_terminate.cpp) */
