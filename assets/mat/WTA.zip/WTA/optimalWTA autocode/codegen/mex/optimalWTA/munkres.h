/*
 * munkres.h
 *
 * Code generation for function 'munkres'
 *
 */

#ifndef MUNKRES_H
#define MUNKRES_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "optimalWTA_types.h"

/* Function Declarations */
extern void munkres(const emlrtStack *sp, emxArray_real_T *costMat,
                    emxArray_real_T *assignment, real_T *cost);

#endif

/* End of code generation (munkres.h) */
