/*
 * unaryMinOrMax.cpp
 *
 * Code generation for function 'unaryMinOrMax'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "unaryMinOrMax.h"
#include "eml_int_forloop_overflow_check.h"
#include "optimalWTA_data.h"

/* Variable Definitions */
static emlrtRSInfo hd_emlrtRSI = { 894,/* lineNo */
  "unaryMinOrMax",                     /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\unaryMinOrMax.m"/* pathName */
};

/* Function Definitions */
int32_T findFirst(const emlrtStack *sp, const emxArray_real_T *x)
{
  int32_T idx;
  boolean_T overflow;
  int32_T k;
  boolean_T exitg1;
  emlrtStack st;
  emlrtStack b_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  if (!muDoubleScalarIsNaN(x->data[0])) {
    idx = 1;
  } else {
    idx = 0;
    st.site = &hd_emlrtRSI;
    overflow = ((2 <= x->size[0]) && (x->size[0] > 2147483646));
    if (overflow) {
      b_st.site = &m_emlrtRSI;
      check_forloop_overflow_error(&b_st);
    }

    k = 2;
    exitg1 = false;
    while ((!exitg1) && (k <= x->size[0])) {
      if (!muDoubleScalarIsNaN(x->data[k - 1])) {
        idx = k;
        exitg1 = true;
      } else {
        k++;
      }
    }
  }

  return idx;
}

/* End of code generation (unaryMinOrMax.cpp) */
