/*
 * optimalWTA_initialize.cpp
 *
 * Code generation for function 'optimalWTA_initialize'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "optimalWTA_initialize.h"
#include "_coder_optimalWTA_mex.h"
#include "optimalWTA_data.h"

/* Function Definitions */
void optimalWTA_initialize()
{
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  mexFunctionCreateRootTLS();
  emlrtBreakCheckR2012bFlagVar = emlrtGetBreakCheckFlagAddressR2012b();
  st.tls = emlrtRootTLSGlobal;
  emlrtClearAllocCountR2012b(&st, false, 0U, 0);
  emlrtEnterRtStackR2012b(&st);
  emlrtFirstTimeR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (optimalWTA_initialize.cpp) */
