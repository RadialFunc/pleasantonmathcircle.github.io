/*
 * optimalWTA_terminate.h
 *
 * Code generation for function 'optimalWTA_terminate'
 *
 */

#ifndef OPTIMALWTA_TERMINATE_H
#define OPTIMALWTA_TERMINATE_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "optimalWTA_types.h"

/* Function Declarations */
extern void optimalWTA_atexit();
extern void optimalWTA_terminate();

#endif

/* End of code generation (optimalWTA_terminate.h) */
