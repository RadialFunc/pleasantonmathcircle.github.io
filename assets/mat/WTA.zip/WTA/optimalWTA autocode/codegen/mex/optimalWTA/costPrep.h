/*
 * costPrep.h
 *
 * Code generation for function 'costPrep'
 *
 */

#ifndef COSTPREP_H
#define COSTPREP_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "optimalWTA_types.h"

/* Function Declarations */
extern void costPrep(const emlrtStack *sp, const emxArray_real_T *lethality,
                     const emxArray_real_T *aKV, const emxArray_real_T *pKill,
                     const emxArray_real_T *Q, emxArray_real_T *costMat,
                     emxArray_real_T *objPTR);

#endif

/* End of code generation (costPrep.h) */
