/*
 * floor.h
 *
 * Code generation for function 'floor'
 *
 */

#ifndef FLOOR_H
#define FLOOR_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "optimalWTA_types.h"

/* Function Declarations */
extern void b_floor(const emlrtStack *sp, emxArray_real_T *x);

#endif

/* End of code generation (floor.h) */
