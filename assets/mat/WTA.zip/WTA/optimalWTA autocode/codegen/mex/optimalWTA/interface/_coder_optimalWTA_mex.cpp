/*
 * _coder_optimalWTA_mex.cpp
 *
 * Code generation for function '_coder_optimalWTA_mex'
 *
 */

/* Include files */
#include "optimalWTA.h"
#include "_coder_optimalWTA_mex.h"
#include "optimalWTA_terminate.h"
#include "_coder_optimalWTA_api.h"
#include "optimalWTA_initialize.h"
#include "optimalWTA_data.h"

/* Function Declarations */
static void optimalWTA_mexFunction(int32_T nlhs, mxArray *plhs[3], int32_T nrhs,
  const mxArray *prhs[4]);

/* Function Definitions */
static void optimalWTA_mexFunction(int32_T nlhs, mxArray *plhs[3], int32_T nrhs,
  const mxArray *prhs[4])
{
  const mxArray *outputs[3];
  int32_T b_nlhs;
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  st.tls = emlrtRootTLSGlobal;

  /* Check for proper number of arguments. */
  if (nrhs != 4) {
    emlrtErrMsgIdAndTxt(&st, "EMLRT:runTime:WrongNumberOfInputs", 5, 12, 4, 4,
                        10, "optimalWTA");
  }

  if (nlhs > 3) {
    emlrtErrMsgIdAndTxt(&st, "EMLRT:runTime:TooManyOutputArguments", 3, 4, 10,
                        "optimalWTA");
  }

  /* Call the function. */
  optimalWTA_api(prhs, nlhs, outputs);

  /* Copy over outputs to the caller. */
  if (nlhs < 1) {
    b_nlhs = 1;
  } else {
    b_nlhs = nlhs;
  }

  emlrtReturnArrays(b_nlhs, plhs, outputs);
}

void mexFunction(int32_T nlhs, mxArray *plhs[], int32_T nrhs, const mxArray
                 *prhs[])
{
  mexAtExit(optimalWTA_atexit);

  /* Module initialization. */
  optimalWTA_initialize();

  /* Dispatch the entry-point. */
  optimalWTA_mexFunction(nlhs, plhs, nrhs, prhs);

  /* Module termination. */
  optimalWTA_terminate();
}

emlrtCTX mexFunctionCreateRootTLS()
{
  emlrtCreateRootTLS(&emlrtRootTLSGlobal, &emlrtContextGlobal, NULL, 1);
  return emlrtRootTLSGlobal;
}

/* End of code generation (_coder_optimalWTA_mex.cpp) */
