/*
 * optimalWTA.h
 *
 * Code generation for function 'optimalWTA'
 *
 */

#ifndef OPTIMALWTA_H
#define OPTIMALWTA_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "optimalWTA_types.h"

/* Function Declarations */
extern void optimalWTA(const emlrtStack *sp, const emxArray_real_T *lethality,
  const emxArray_real_T *reachMat, const emxArray_real_T *pKill, real_T maxKV,
  emxArray_real_T *fAssign, real_T *fLeak, real_T *totalReach);

#endif

/* End of code generation (optimalWTA.h) */
