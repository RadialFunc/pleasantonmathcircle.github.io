/*
 * bsxfun.cpp
 *
 * Code generation for function 'bsxfun'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "bsxfun.h"
#include "optimalWTA_emxutil.h"

/* Variable Definitions */
static emlrtRTEInfo sd_emlrtRTEI = { 1,/* lineNo */
  14,                                  /* colNo */
  "bsxfun",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\lib\\matlab\\elmat\\bsxfun.m"/* pName */
};

static emlrtRTEInfo pe_emlrtRTEI = { 50,/* lineNo */
  15,                                  /* colNo */
  "bsxfun",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\lib\\matlab\\elmat\\bsxfun.m"/* pName */
};

/* Function Definitions */
void b_bsxfun(const emlrtStack *sp, const emxArray_real_T *a, const
              emxArray_real_T *b, emxArray_real_T *c)
{
  int32_T csz_idx_0;
  int32_T csz_idx_1;
  int32_T i12;
  int32_T varargin_2;
  int32_T bcoef;
  int32_T i13;
  int32_T k;
  csz_idx_0 = b->size[0];
  csz_idx_1 = a->size[1];
  i12 = c->size[0] * c->size[1];
  c->size[0] = csz_idx_0;
  c->size[1] = csz_idx_1;
  emxEnsureCapacity_real_T(sp, c, i12, &sd_emlrtRTEI);
  csz_idx_0 = (a->size[1] != 1);
  i12 = c->size[1] - 1;
  for (csz_idx_1 = 0; csz_idx_1 <= i12; csz_idx_1++) {
    varargin_2 = csz_idx_0 * csz_idx_1;
    bcoef = (b->size[0] != 1);
    i13 = c->size[0] - 1;
    for (k = 0; k <= i13; k++) {
      c->data[k + c->size[0] * csz_idx_1] = a->data[varargin_2] + b->data[bcoef *
        k];
    }
  }
}

void bsxfun(const emlrtStack *sp, const emxArray_real_T *a, const
            emxArray_real_T *b, emxArray_real_T *c)
{
  boolean_T iscompatible;
  int32_T csz_idx_0;
  int32_T csz_idx_1;
  int32_T i10;
  int32_T varargin_2;
  int32_T acoef;
  int32_T bcoef;
  int32_T i11;
  int32_T k;
  iscompatible = true;
  if (b->size[0] == 1) {
    csz_idx_0 = a->size[0];
  } else if (a->size[0] == 1) {
    csz_idx_0 = b->size[0];
  } else if (a->size[0] == b->size[0]) {
    csz_idx_0 = a->size[0];
  } else {
    iscompatible = false;
    csz_idx_0 = muIntScalarMin_sint32(b->size[0], a->size[0]);
  }

  csz_idx_1 = a->size[1];
  if (!iscompatible) {
    emlrtErrorWithMessageIdR2018a(sp, &pe_emlrtRTEI,
      "MATLAB:bsxfun:arrayDimensionsMustMatch",
      "MATLAB:bsxfun:arrayDimensionsMustMatch", 0);
  }

  i10 = c->size[0] * c->size[1];
  c->size[0] = csz_idx_0;
  c->size[1] = csz_idx_1;
  emxEnsureCapacity_real_T(sp, c, i10, &sd_emlrtRTEI);
  csz_idx_0 = (a->size[1] != 1);
  i10 = c->size[1] - 1;
  for (csz_idx_1 = 0; csz_idx_1 <= i10; csz_idx_1++) {
    varargin_2 = csz_idx_0 * csz_idx_1;
    acoef = (a->size[0] != 1);
    bcoef = (b->size[0] != 1);
    i11 = c->size[0] - 1;
    for (k = 0; k <= i11; k++) {
      c->data[k + c->size[0] * csz_idx_1] = a->data[acoef * k + a->size[0] *
        varargin_2] - b->data[bcoef * k];
    }
  }
}

void c_bsxfun(const emlrtStack *sp, const emxArray_real_T *a, const
              emxArray_real_T *b, emxArray_real_T *c)
{
  int32_T csz_idx_0;
  int32_T csz_idx_1;
  int32_T i14;
  int32_T varargin_3;
  int32_T acoef;
  int32_T i15;
  int32_T k;
  csz_idx_0 = a->size[0];
  csz_idx_1 = b->size[1];
  i14 = c->size[0] * c->size[1];
  c->size[0] = csz_idx_0;
  c->size[1] = csz_idx_1;
  emxEnsureCapacity_real_T(sp, c, i14, &sd_emlrtRTEI);
  if ((c->size[0] != 0) && (c->size[1] != 0)) {
    csz_idx_0 = (b->size[1] != 1);
    i14 = c->size[1] - 1;
    for (csz_idx_1 = 0; csz_idx_1 <= i14; csz_idx_1++) {
      varargin_3 = csz_idx_0 * csz_idx_1;
      acoef = (a->size[0] != 1);
      i15 = c->size[0] - 1;
      for (k = 0; k <= i15; k++) {
        c->data[k + c->size[0] * csz_idx_1] = a->data[acoef * k] + b->
          data[varargin_3];
      }
    }
  }
}

/* End of code generation (bsxfun.cpp) */
