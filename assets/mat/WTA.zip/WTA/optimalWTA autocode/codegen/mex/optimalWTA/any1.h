/*
 * any1.h
 *
 * Code generation for function 'any1'
 *
 */

#ifndef ANY1_H
#define ANY1_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "optimalWTA_types.h"

/* Function Declarations */
extern void any(const emlrtStack *sp, const emxArray_boolean_T *x,
                emxArray_boolean_T *y);
extern void b_any(const emlrtStack *sp, const emxArray_boolean_T *x,
                  emxArray_boolean_T *y);
extern boolean_T c_any(const emlrtStack *sp, const emxArray_boolean_T *x);

#endif

/* End of code generation (any1.h) */
