/*
 * any1.cpp
 *
 * Code generation for function 'any1'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "any1.h"
#include "optimalWTA_emxutil.h"
#include "eml_int_forloop_overflow_check.h"
#include "optimalWTA_data.h"

/* Variable Definitions */
static emlrtRSInfo yc_emlrtRSI = { 15, /* lineNo */
  "any",                               /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\lib\\matlab\\ops\\any.m"/* pathName */
};

static emlrtRSInfo ad_emlrtRSI = { 139,/* lineNo */
  "allOrAny",                          /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\allOrAny.m"/* pathName */
};

static emlrtRSInfo cd_emlrtRSI = { 142,/* lineNo */
  "allOrAny",                          /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\allOrAny.m"/* pathName */
};

static emlrtRSInfo md_emlrtRSI = { 12, /* lineNo */
  "any",                               /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\lib\\matlab\\ops\\any.m"/* pathName */
};

static emlrtRTEInfo rd_emlrtRTEI = { 15,/* lineNo */
  5,                                   /* colNo */
  "any",                               /* fName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\lib\\matlab\\ops\\any.m"/* pName */
};

static emlrtRTEInfo oe_emlrtRTEI = { 19,/* lineNo */
  19,                                  /* colNo */
  "eml_int_forloop_overflow_check",    /* fName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\lib\\matlab\\eml\\eml_int_forloop_overflow_check.m"/* pName */
};

/* Function Definitions */
void any(const emlrtStack *sp, const emxArray_boolean_T *x, emxArray_boolean_T
         *y)
{
  uint32_T outsize_idx_1;
  int32_T npages;
  int32_T i2;
  int32_T iy;
  boolean_T overflow;
  int32_T i;
  int32_T a;
  int32_T i1;
  boolean_T exitg1;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  st.prev = sp;
  st.tls = sp->tls;
  st.site = &yc_emlrtRSI;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  outsize_idx_1 = (uint32_T)x->size[1];
  npages = y->size[0] * y->size[1];
  y->size[0] = 1;
  y->size[1] = (int32_T)outsize_idx_1;
  emxEnsureCapacity_boolean_T(&st, y, npages, &rd_emlrtRTEI);
  i2 = (int32_T)outsize_idx_1;
  for (npages = 0; npages < i2; npages++) {
    y->data[npages] = false;
  }

  npages = x->size[1];
  i2 = 0;
  iy = -1;
  b_st.site = &ad_emlrtRSI;
  overflow = ((1 <= x->size[1]) && (x->size[1] > 2147483646));
  if (overflow) {
    c_st.site = &m_emlrtRSI;
    check_forloop_overflow_error(&c_st);
  }

  for (i = 0; i < npages; i++) {
    a = i2 + x->size[0];
    i1 = i2 + 1;
    i2 += x->size[0];
    iy++;
    b_st.site = &bd_emlrtRSI;
    if ((i1 <= a) && (a > 2147483646)) {
      c_st.site = &m_emlrtRSI;
      check_forloop_overflow_error(&c_st);
    }

    exitg1 = false;
    while ((!exitg1) && (i1 <= a)) {
      overflow = !x->data[i1 - 1];
      if (!overflow) {
        y->data[iy] = true;
        exitg1 = true;
      } else {
        i1++;
      }
    }
  }
}

void b_any(const emlrtStack *sp, const emxArray_boolean_T *x, emxArray_boolean_T
           *y)
{
  uint32_T outsize_idx_0;
  int32_T vstride;
  int32_T i2;
  int32_T iy;
  int32_T i1;
  boolean_T overflow;
  int32_T j;
  int32_T ix;
  boolean_T exitg1;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  st.prev = sp;
  st.tls = sp->tls;
  st.site = &yc_emlrtRSI;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  outsize_idx_0 = (uint32_T)x->size[0];
  vstride = y->size[0];
  y->size[0] = (int32_T)outsize_idx_0;
  emxEnsureCapacity_boolean_T(&st, y, vstride, &rd_emlrtRTEI);
  i2 = (int32_T)outsize_idx_0;
  for (vstride = 0; vstride < i2; vstride++) {
    y->data[vstride] = false;
  }

  vstride = x->size[0];
  i2 = (x->size[1] - 1) * x->size[0];
  iy = -1;
  i1 = 0;
  b_st.site = &cd_emlrtRSI;
  overflow = ((1 <= x->size[0]) && (x->size[0] > 2147483646));
  if (overflow) {
    c_st.site = &m_emlrtRSI;
    check_forloop_overflow_error(&c_st);
  }

  for (j = 0; j < vstride; j++) {
    i1++;
    i2++;
    iy++;
    b_st.site = &bd_emlrtRSI;
    if ((vstride == 0) || (i1 > i2)) {
      overflow = false;
    } else {
      overflow = (i2 > MAX_int32_T - vstride);
    }

    if (vstride == 0) {
      emlrtErrorWithMessageIdR2018a(&b_st, &oe_emlrtRTEI,
        "Coder:builtins:VectorStride", "Coder:builtins:VectorStride", 0);
    }

    if (overflow) {
      c_st.site = &m_emlrtRSI;
      check_forloop_overflow_error(&c_st);
    }

    ix = i1;
    exitg1 = false;
    while ((!exitg1) && (ix <= i2)) {
      overflow = !x->data[ix - 1];
      if (!overflow) {
        y->data[iy] = true;
        exitg1 = true;
      } else {
        ix += vstride;
      }
    }
  }
}

boolean_T c_any(const emlrtStack *sp, const emxArray_boolean_T *x)
{
  boolean_T y;
  boolean_T overflow;
  int32_T ix;
  boolean_T exitg1;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  st.prev = sp;
  st.tls = sp->tls;
  st.site = &md_emlrtRSI;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  y = false;
  b_st.site = &bd_emlrtRSI;
  overflow = ((1 <= x->size[0]) && (x->size[0] > 2147483646));
  if (overflow) {
    c_st.site = &m_emlrtRSI;
    check_forloop_overflow_error(&c_st);
  }

  ix = 1;
  exitg1 = false;
  while ((!exitg1) && (ix <= x->size[0])) {
    overflow = !x->data[ix - 1];
    if (!overflow) {
      y = true;
      exitg1 = true;
    } else {
      ix++;
    }
  }

  return y;
}

/* End of code generation (any1.cpp) */
