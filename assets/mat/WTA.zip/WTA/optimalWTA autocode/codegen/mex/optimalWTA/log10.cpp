/*
 * log10.cpp
 *
 * Code generation for function 'log10'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "log10.h"
#include "error.h"

/* Variable Definitions */
static emlrtRSInfo xc_emlrtRSI = { 13, /* lineNo */
  "log10",                             /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\lib\\matlab\\elfun\\log10.m"/* pathName */
};

/* Function Definitions */
void b_log10(const emlrtStack *sp, real_T *x)
{
  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  if (*x < 0.0) {
    st.site = &xc_emlrtRSI;
    b_error(&st);
  }

  *x = muDoubleScalarLog10(*x);
}

/* End of code generation (log10.cpp) */
