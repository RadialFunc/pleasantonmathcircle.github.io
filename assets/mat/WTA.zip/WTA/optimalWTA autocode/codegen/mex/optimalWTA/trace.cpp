/*
 * trace.cpp
 *
 * Code generation for function 'trace'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "trace.h"

/* Variable Definitions */
static emlrtRTEInfo re_emlrtRTEI = { 11,/* lineNo */
  15,                                  /* colNo */
  "trace",                             /* fName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\lib\\matlab\\matfun\\trace.m"/* pName */
};

/* Function Definitions */
real_T trace(const emlrtStack *sp, const emxArray_real_T *a)
{
  real_T t;
  boolean_T b0;
  int32_T i18;
  int32_T k;
  b0 = (a->size[0] == a->size[1]);
  if (!b0) {
    emlrtErrorWithMessageIdR2018a(sp, &re_emlrtRTEI, "Coder:MATLAB:square",
      "Coder:MATLAB:square", 0);
  }

  t = 0.0;
  i18 = a->size[0];
  for (k = 0; k < i18; k++) {
    t += a->data[k + a->size[0] * k];
  }

  return t;
}

/* End of code generation (trace.cpp) */
