/*
 * munkres.cpp
 *
 * Code generation for function 'munkres'
 *
 */

/* Include files */
#include "mwmathutil.h"
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "munkres.h"
#include "indexShapeCheck.h"
#include "sum.h"
#include "log10.h"
#include "mpower.h"
#include "any1.h"
#include "toLogicalCheck.h"
#include "optimalWTA_emxutil.h"
#include "unaryMinOrMax.h"
#include "eml_int_forloop_overflow_check.h"
#include "bsxfun.h"
#include "all.h"
#include "nullAssignment.h"
#include "diag.h"
#include "trace.h"
#include "optimalWTA_data.h"

/* Variable Definitions */
static emlrtRSInfo rb_emlrtRSI = { 56, /* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo sb_emlrtRSI = { 61, /* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo tb_emlrtRSI = { 62, /* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo ub_emlrtRSI = { 64, /* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo vb_emlrtRSI = { 65, /* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo wb_emlrtRSI = { 67, /* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo xb_emlrtRSI = { 71, /* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo yb_emlrtRSI = { 83, /* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo ac_emlrtRSI = { 84, /* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo bc_emlrtRSI = { 93, /* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo cc_emlrtRSI = { 94, /* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo dc_emlrtRSI = { 105,/* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo ec_emlrtRSI = { 112,/* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo fc_emlrtRSI = { 122,/* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo gc_emlrtRSI = { 123,/* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo hc_emlrtRSI = { 134,/* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo ic_emlrtRSI = { 141,/* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo jc_emlrtRSI = { 142,/* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo kc_emlrtRSI = { 143,/* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo lc_emlrtRSI = { 146,/* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo mc_emlrtRSI = { 154,/* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo nc_emlrtRSI = { 173,/* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo oc_emlrtRSI = { 182,/* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo pc_emlrtRSI = { 188,/* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo qc_emlrtRSI = { 189,/* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo rc_emlrtRSI = { 190,/* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo sc_emlrtRSI = { 194,/* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo tc_emlrtRSI = { 196,/* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo ed_emlrtRSI = { 114,/* lineNo */
  "unaryMinOrMax",                     /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\unaryMinOrMax.m"/* pathName */
};

static emlrtRSInfo fd_emlrtRSI = { 852,/* lineNo */
  "unaryMinOrMax",                     /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\unaryMinOrMax.m"/* pathName */
};

static emlrtRSInfo gd_emlrtRSI = { 844,/* lineNo */
  "unaryMinOrMax",                     /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\unaryMinOrMax.m"/* pathName */
};

static emlrtRSInfo id_emlrtRSI = { 910,/* lineNo */
  "unaryMinOrMax",                     /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\unaryMinOrMax.m"/* pathName */
};

static emlrtRSInfo jd_emlrtRSI = { 325,/* lineNo */
  "unaryMinOrMax",                     /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\unaryMinOrMax.m"/* pathName */
};

static emlrtRSInfo kd_emlrtRSI = { 404,/* lineNo */
  "unaryMinOrMax",                     /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\unaryMinOrMax.m"/* pathName */
};

static emlrtRSInfo ld_emlrtRSI = { 402,/* lineNo */
  "unaryMinOrMax",                     /* fcnName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\unaryMinOrMax.m"/* pathName */
};

static emlrtRSInfo yd_emlrtRSI = { 203,/* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRSInfo ae_emlrtRSI = { 205,/* lineNo */
  "munkres",                           /* fcnName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pathName */
};

static emlrtRTEInfo kb_emlrtRTEI = { 52,/* lineNo */
  1,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo lb_emlrtRTEI = { 55,/* lineNo */
  12,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo mb_emlrtRTEI = { 55,/* lineNo */
  33,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo nb_emlrtRTEI = { 1,/* lineNo */
  30,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo ob_emlrtRTEI = { 56,/* lineNo */
  27,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo pb_emlrtRTEI = { 71,/* lineNo */
  13,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo qb_emlrtRTEI = { 73,/* lineNo */
  1,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo rb_emlrtRTEI = { 74,/* lineNo */
  6,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo sb_emlrtRTEI = { 74,/* lineNo */
  14,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo tb_emlrtRTEI = { 74,/* lineNo */
  42,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo ub_emlrtRTEI = { 325,/* lineNo */
  14,                                  /* colNo */
  "unaryMinOrMax",                     /* fName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\unaryMinOrMax.m"/* pName */
};

static emlrtRTEInfo vb_emlrtRTEI = { 90,/* lineNo */
  1,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo wb_emlrtRTEI = { 92,/* lineNo */
  1,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo xb_emlrtRTEI = { 105,/* lineNo */
  12,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo yb_emlrtRTEI = { 108,/* lineNo */
  5,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo ac_emlrtRTEI = { 110,/* lineNo */
  5,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo bc_emlrtRTEI = { 111,/* lineNo */
  5,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo cc_emlrtRTEI = { 188,/* lineNo */
  1,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo dc_emlrtRTEI = { 112,/* lineNo */
  68,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo ec_emlrtRTEI = { 112,/* lineNo */
  84,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo fc_emlrtRTEI = { 189,/* lineNo */
  1,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo gc_emlrtRTEI = { 190,/* lineNo */
  1,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo hc_emlrtRTEI = { 112,/* lineNo */
  40,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo ic_emlrtRTEI = { 112,/* lineNo */
  25,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo jc_emlrtRTEI = { 194,/* lineNo */
  12,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo kc_emlrtRTEI = { 194,/* lineNo */
  6,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo lc_emlrtRTEI = { 122,/* lineNo */
  19,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo mc_emlrtRTEI = { 196,/* lineNo */
  14,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo nc_emlrtRTEI = { 122,/* lineNo */
  9,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo oc_emlrtRTEI = { 123,/* lineNo */
  19,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo pc_emlrtRTEI = { 123,/* lineNo */
  9,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo qc_emlrtRTEI = { 124,/* lineNo */
  9,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo rc_emlrtRTEI = { 125,/* lineNo */
  9,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo sc_emlrtRTEI = { 140,/* lineNo */
  13,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo tc_emlrtRTEI = { 173,/* lineNo */
  18,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo uc_emlrtRTEI = { 143,/* lineNo */
  23,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo vc_emlrtRTEI = { 154,/* lineNo */
  42,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo wc_emlrtRTEI = { 154,/* lineNo */
  71,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo xc_emlrtRTEI = { 173,/* lineNo */
  5,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo yc_emlrtRTEI = { 154,/* lineNo */
  87,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo ad_emlrtRTEI = { 143,/* lineNo */
  13,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo bd_emlrtRTEI = { 182,/* lineNo */
  22,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo cd_emlrtRTEI = { 155,/* lineNo */
  34,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo dd_emlrtRTEI = { 144,/* lineNo */
  13,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo ed_emlrtRTEI = { 182,/* lineNo */
  9,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo fd_emlrtRTEI = { 156,/* lineNo */
  30,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo gd_emlrtRTEI = { 145,/* lineNo */
  20,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo hd_emlrtRTEI = { 146,/* lineNo */
  20,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo id_emlrtRTEI = { 146,/* lineNo */
  13,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo jd_emlrtRTEI = { 61,/* lineNo */
  1,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo kd_emlrtRTEI = { 62,/* lineNo */
  1,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo ld_emlrtRTEI = { 83,/* lineNo */
  1,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo md_emlrtRTEI = { 84,/* lineNo */
  1,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo nd_emlrtRTEI = { 112,/* lineNo */
  6,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo od_emlrtRTEI = { 112,/* lineNo */
  12,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo pd_emlrtRTEI = { 193,/* lineNo */
  1,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo qd_emlrtRTEI = { 84,/* lineNo */
  12,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo td_emlrtRTEI = { 205,/* lineNo */
  18,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo ud_emlrtRTEI = { 202,/* lineNo */
  7,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo vd_emlrtRTEI = { 202,/* lineNo */
  12,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo wd_emlrtRTEI = { 203,/* lineNo */
  29,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo xd_emlrtRTEI = { 198,/* lineNo */
  29,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtRTEInfo ne_emlrtRTEI = { 22,/* lineNo */
  27,                                  /* colNo */
  "unaryMinOrMax",                     /* fName */
  "C:\\Program Files\\MATLAB\\R2018b\\toolbox\\eml\\eml\\+coder\\+internal\\unaryMinOrMax.m"/* pName */
};

static emlrtBCInfo q_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  144,                                 /* lineNo */
  45,                                  /* colNo */
  "minR",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo r_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  156,                                 /* lineNo */
  35,                                  /* colNo */
  "minR",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo s_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  144,                                 /* lineNo */
  22,                                  /* colNo */
  "dMat",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo t_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  155,                                 /* lineNo */
  39,                                  /* colNo */
  "minC",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo u_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  192,                                 /* lineNo */
  35,                                  /* colNo */
  "colIdx",                            /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo v_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  192,                                 /* lineNo */
  12,                                  /* colNo */
  "assignment",                        /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo w_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  112,                                 /* lineNo */
  40,                                  /* colNo */
  "dMat",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo x_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  112,                                 /* lineNo */
  30,                                  /* colNo */
  "dMat",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo y_emlrtBCI = { -1,  /* iFirst */
  -1,                                  /* iLast */
  109,                                 /* lineNo */
  17,                                  /* colNo */
  "coverColumn",                       /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ab_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  74,                                  /* lineNo */
  42,                                  /* colNo */
  "costMat",                           /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo bb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  74,                                  /* lineNo */
  33,                                  /* colNo */
  "costMat",                           /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo e_emlrtECI = { -1,  /* nDims */
  195,                                 /* lineNo */
  1,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtBCInfo cb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  190,                                 /* lineNo */
  17,                                  /* colNo */
  "starZ",                             /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo f_emlrtECI = { -1,  /* nDims */
  144,                                 /* lineNo */
  17,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtBCInfo db_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  144,                                 /* lineNo */
  32,                                  /* colNo */
  "dMat",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo eb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  133,                                 /* lineNo */
  25,                                  /* colNo */
  "starZ",                             /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo fb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  130,                                 /* lineNo */
  24,                                  /* colNo */
  "rIdx",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo g_emlrtECI = { 2,   /* nDims */
  112,                                 /* lineNo */
  25,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtECInfo h_emlrtECI = { -1,  /* nDims */
  95,                                  /* lineNo */
  5,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtECInfo i_emlrtECI = { 2,   /* nDims */
  90,                                  /* lineNo */
  6,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtECInfo j_emlrtECI = { -1,  /* nDims */
  74,                                  /* lineNo */
  1,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtBCInfo gb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  74,                                  /* lineNo */
  16,                                  /* colNo */
  "dMat",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo hb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  74,                                  /* lineNo */
  8,                                   /* colNo */
  "dMat",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo f_emlrtDCI = { 73,  /* lineNo */
  14,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  1                                    /* checkKind */
};

static emlrtECInfo k_emlrtECI = { 2,   /* nDims */
  55,                                  /* lineNo */
  12,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtDCInfo g_emlrtDCI = { 108, /* lineNo */
  27,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo ib_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  56,                                  /* lineNo */
  35,                                  /* colNo */
  "costMat",                           /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo jb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  57,                                  /* lineNo */
  1,                                   /* colNo */
  "costMat",                           /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo kb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  71,                                  /* lineNo */
  21,                                  /* colNo */
  "costMat",                           /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo h_emlrtDCI = { 92,  /* lineNo */
  1,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  1                                    /* checkKind */
};

static emlrtDCInfo i_emlrtDCI = { 108, /* lineNo */
  5,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo lb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  109,                                 /* lineNo */
  17,                                  /* colNo */
  "starZ",                             /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo j_emlrtDCI = { 110, /* lineNo */
  5,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  1                                    /* checkKind */
};

static emlrtDCInfo k_emlrtDCI = { 111, /* lineNo */
  5,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo mb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  95,                                  /* lineNo */
  11,                                  /* colNo */
  "starZ",                             /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo nb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  96,                                  /* lineNo */
  8,                                   /* colNo */
  "zP",                                /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ob_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  97,                                  /* lineNo */
  10,                                  /* colNo */
  "zP",                                /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo pb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  112,                                 /* lineNo */
  73,                                  /* colNo */
  "minR",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo qb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  112,                                 /* lineNo */
  89,                                  /* colNo */
  "minC",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo rb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  192,                                 /* lineNo */
  12,                                  /* colNo */
  "rowIdx",                            /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo sb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  192,                                 /* lineNo */
  35,                                  /* colNo */
  "starZ",                             /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo tb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  193,                                 /* lineNo */
  8,                                   /* colNo */
  "assignment",                        /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ub_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  194,                                 /* lineNo */
  21,                                  /* colNo */
  "validMat",                          /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo vb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  194,                                 /* lineNo */
  34,                                  /* colNo */
  "validMat",                          /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo wb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  194,                                 /* lineNo */
  1,                                   /* colNo */
  "pass",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo xb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  195,                                 /* lineNo */
  1,                                   /* colNo */
  "assignment",                        /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo yb_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  196,                                 /* lineNo */
  22,                                  /* colNo */
  "costMat",                           /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ac_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  196,                                 /* lineNo */
  35,                                  /* colNo */
  "costMat",                           /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo bc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  196,                                 /* lineNo */
  46,                                  /* colNo */
  "assignment",                        /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo cc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  124,                                 /* lineNo */
  19,                                  /* colNo */
  "cR",                                /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo dc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  125,                                 /* lineNo */
  22,                                  /* colNo */
  "cC",                                /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ec_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  132,                                 /* lineNo */
  13,                                  /* colNo */
  "primeZ",                            /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo fc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  138,                                 /* lineNo */
  13,                                  /* colNo */
  "coverRow",                          /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo gc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  139,                                 /* lineNo */
  13,                                  /* colNo */
  "coverColumn",                       /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo hc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  154,                                 /* lineNo */
  47,                                  /* colNo */
  "dMat",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo ic_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  154,                                 /* lineNo */
  57,                                  /* colNo */
  "dMat",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo jc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  154,                                 /* lineNo */
  76,                                  /* colNo */
  "minR",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo kc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  154,                                 /* lineNo */
  92,                                  /* colNo */
  "minC",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo lc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  174,                                 /* lineNo */
  5,                                   /* colNo */
  "starZ",                             /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo mc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  179,                                 /* lineNo */
  9,                                   /* colNo */
  "starZ",                             /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo nc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  180,                                 /* lineNo */
  15,                                  /* colNo */
  "primeZ",                            /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo oc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  155,                                 /* lineNo */
  13,                                  /* colNo */
  "minC",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo pc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  144,                                 /* lineNo */
  58,                                  /* colNo */
  "minC",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo qc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  183,                                 /* lineNo */
  9,                                   /* colNo */
  "starZ",                             /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo rc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  156,                                 /* lineNo */
  13,                                  /* colNo */
  "minR",                              /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo sc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  145,                                 /* lineNo */
  32,                                  /* colNo */
  "cR",                                /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo l_emlrtDCI = { 146, /* lineNo */
  41,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo tc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  203,                                 /* lineNo */
  33,                                  /* colNo */
  "M",                                 /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo l_emlrtECI = { -1,  /* nDims */
  202,                                 /* lineNo */
  5,                                   /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtBCInfo uc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  202,                                 /* lineNo */
  9,                                   /* colNo */
  "M",                                 /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo m_emlrtECI = { -1,  /* nDims */
  202,                                 /* lineNo */
  12,                                  /* colNo */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m"/* pName */
};

static emlrtBCInfo vc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  202,                                 /* lineNo */
  16,                                  /* colNo */
  "M",                                 /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo wc_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  202,                                 /* lineNo */
  22,                                  /* colNo */
  "y",                                 /* aName */
  "munkres",                           /* fName */
  "C:\\Users\\e371753\\Documents\\NGI\\IRAD\\Engagement Management\\WTA\\optimalWTA autocode\\munkres.m",/* pName */
  0                                    /* checkKind */
};

/* Function Declarations */
static void outerplus(const emlrtStack *sp, emxArray_real_T *M, const
                      emxArray_real_T *x, const emxArray_real_T *y, real_T
                      *minval, emxArray_real_T *rIdx, emxArray_real_T *cIdx);

/* Function Definitions */
static void outerplus(const emlrtStack *sp, emxArray_real_T *M, const
                      emxArray_real_T *x, const emxArray_real_T *y, real_T
                      *minval, emxArray_real_T *rIdx, emxArray_real_T *cIdx)
{
  int32_T i16;
  emxArray_int32_T *i;
  emxArray_real_T *b_M;
  int32_T c;
  int32_T i17;
  emxArray_boolean_T *b_x;
  int32_T jj;
  int32_T ii;
  int32_T nx;
  emxArray_int32_T *j;
  emxArray_boolean_T *v;
  int32_T idx;
  int32_T b_i[1];
  real_T b_y;
  boolean_T exitg1;
  boolean_T guard1 = false;
  int32_T iv2[2];
  boolean_T overflow;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  emlrtStack g_st;
  emlrtStack h_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;
  g_st.prev = &f_st;
  g_st.tls = f_st.tls;
  h_st.prev = &g_st;
  h_st.tls = g_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);
  *minval = rtInf;
  i16 = M->size[1];
  emxInit_int32_T(sp, &i, 1, &xd_emlrtRTEI, true);
  emxInit_real_T(sp, &b_M, 1, &vd_emlrtRTEI, true);
  for (c = 0; c < i16; c++) {
    i17 = M->size[1];
    jj = 1 + c;
    if ((jj < 1) || (jj > i17)) {
      emlrtDynamicBoundsCheckR2012b(jj, 1, i17, &vc_emlrtBCI, sp);
    }

    i17 = M->size[0];
    jj = x->size[0];
    if (i17 != jj) {
      emlrtSizeEqCheck1DR2012b(i17, jj, &m_emlrtECI, sp);
    }

    ii = M->size[0];
    i17 = i->size[0];
    i->size[0] = ii;
    emxEnsureCapacity_int32_T(sp, i, i17, &ud_emlrtRTEI);
    for (i17 = 0; i17 < ii; i17++) {
      i->data[i17] = i17;
    }

    i17 = M->size[1];
    jj = 1 + c;
    if ((jj < 1) || (jj > i17)) {
      emlrtDynamicBoundsCheckR2012b(jj, 1, i17, &uc_emlrtBCI, sp);
    }

    i17 = M->size[0];
    b_i[0] = i->size[0];
    emlrtSubAssignSizeCheckR2012b(&b_i[0], 1, &i17, 1, &l_emlrtECI, sp);
    ii = M->size[0];
    i17 = y->size[1];
    jj = 1 + c;
    if ((jj < 1) || (jj > i17)) {
      emlrtDynamicBoundsCheckR2012b(jj, 1, i17, &wc_emlrtBCI, sp);
    }

    b_y = y->data[jj - 1];
    i17 = b_M->size[0];
    b_M->size[0] = ii;
    emxEnsureCapacity_real_T(sp, b_M, i17, &vd_emlrtRTEI);
    for (i17 = 0; i17 < ii; i17++) {
      b_M->data[i17] = M->data[i17 + M->size[0] * c] - (x->data[i17] + b_y);
    }

    ii = b_M->size[0];
    for (i17 = 0; i17 < ii; i17++) {
      M->data[i->data[i17] + M->size[0] * c] = b_M->data[i17];
    }

    st.site = &yd_emlrtRSI;
    i17 = M->size[1];
    jj = 1 + c;
    if ((jj < 1) || (jj > i17)) {
      emlrtDynamicBoundsCheckR2012b(jj, 1, i17, &tc_emlrtBCI, &st);
    }

    b_st.site = &n_emlrtRSI;
    c_st.site = &o_emlrtRSI;
    d_st.site = &u_emlrtRSI;
    i17 = M->size[0];
    if (i17 == 1) {
    } else {
      i17 = M->size[0];
      if (i17 != 1) {
      } else {
        emlrtErrorWithMessageIdR2018a(&d_st, &ne_emlrtRTEI,
          "Coder:toolbox:autoDimIncompatibility",
          "Coder:toolbox:autoDimIncompatibility", 0);
      }
    }

    i17 = M->size[0];
    if (i17 < 1) {
      emlrtErrorWithMessageIdR2018a(&d_st, &de_emlrtRTEI,
        "Coder:toolbox:eml_min_or_max_varDimZero",
        "Coder:toolbox:eml_min_or_max_varDimZero", 0);
    }

    e_st.site = &ed_emlrtRSI;
    i17 = M->size[0];
    jj = M->size[0];
    if (jj <= 2) {
      i17 = M->size[0];
      if (i17 == 1) {
        b_y = M->data[M->size[0] * c];
      } else if ((M->data[M->size[0] * c] > M->data[1 + M->size[0] * c]) ||
                 (muDoubleScalarIsNaN(M->data[M->size[0] * c]) &&
                  (!muDoubleScalarIsNaN(M->data[1 + M->size[0] * c])))) {
        b_y = M->data[1 + M->size[0] * c];
      } else {
        b_y = M->data[M->size[0] * c];
      }
    } else {
      ii = M->size[0];
      jj = b_M->size[0];
      b_M->size[0] = ii;
      emxEnsureCapacity_real_T(&e_st, b_M, jj, &wd_emlrtRTEI);
      for (jj = 0; jj < ii; jj++) {
        b_M->data[jj] = M->data[jj + M->size[0] * c];
      }

      f_st.site = &gd_emlrtRSI;
      idx = findFirst(&f_st, b_M);
      if (idx == 0) {
        b_y = M->data[M->size[0] * c];
      } else {
        f_st.site = &fd_emlrtRSI;
        b_y = M->data[(idx + M->size[0] * c) - 1];
        nx = idx + 1;
        g_st.site = &id_emlrtRSI;
        jj = M->size[0];
        if (idx + 1 > jj) {
          overflow = false;
        } else {
          jj = M->size[0];
          overflow = (jj > 2147483646);
        }

        if (overflow) {
          h_st.site = &m_emlrtRSI;
          check_forloop_overflow_error(&h_st);
        }

        for (ii = nx; ii <= i17; ii++) {
          if (b_y > M->data[(ii + M->size[0] * c) - 1]) {
            b_y = M->data[(ii + M->size[0] * c) - 1];
          }
        }
      }
    }

    *minval = muDoubleScalarMin(*minval, b_y);
    if (*emlrtBreakCheckR2012bFlagVar != 0) {
      emlrtBreakCheckR2012b(sp);
    }
  }

  emxFree_real_T(&b_M);
  emxInit_boolean_T(sp, &b_x, 2, &td_emlrtRTEI, true);
  st.site = &ae_emlrtRSI;
  i16 = b_x->size[0] * b_x->size[1];
  b_x->size[0] = M->size[0];
  b_x->size[1] = M->size[1];
  emxEnsureCapacity_boolean_T(&st, b_x, i16, &td_emlrtRTEI);
  ii = M->size[0] * M->size[1];
  for (i16 = 0; i16 < ii; i16++) {
    b_x->data[i16] = (M->data[i16] == *minval);
  }

  b_st.site = &nd_emlrtRSI;
  nx = b_x->size[0] * b_x->size[1];
  if ((b_x->size[0] != 1) || (b_x->size[1] <= 1)) {
  } else {
    emlrtErrorWithMessageIdR2018a(&b_st, &fe_emlrtRTEI,
      "Coder:toolbox:find_incompatibleShape",
      "Coder:toolbox:find_incompatibleShape", 0);
  }

  emxInit_int32_T(&b_st, &j, 1, &xd_emlrtRTEI, true);
  if (nx == 0) {
    i->size[0] = 0;
    j->size[0] = 0;
  } else {
    emxInit_boolean_T(&b_st, &v, 1, &xd_emlrtRTEI, true);
    c_st.site = &od_emlrtRSI;
    idx = 0;
    i16 = i->size[0];
    i->size[0] = nx;
    emxEnsureCapacity_int32_T(&c_st, i, i16, &k_emlrtRTEI);
    i16 = j->size[0];
    j->size[0] = nx;
    emxEnsureCapacity_int32_T(&c_st, j, i16, &k_emlrtRTEI);
    i16 = v->size[0];
    v->size[0] = nx;
    emxEnsureCapacity_boolean_T(&c_st, v, i16, &k_emlrtRTEI);
    ii = 1;
    jj = 1;
    exitg1 = false;
    while ((!exitg1) && (jj <= b_x->size[1])) {
      guard1 = false;
      if (b_x->data[(ii + b_x->size[0] * (jj - 1)) - 1]) {
        idx++;
        i->data[idx - 1] = ii;
        j->data[idx - 1] = jj;
        v->data[idx - 1] = b_x->data[(ii + b_x->size[0] * (jj - 1)) - 1];
        if (idx >= nx) {
          exitg1 = true;
        } else {
          guard1 = true;
        }
      } else {
        guard1 = true;
      }

      if (guard1) {
        ii++;
        if (ii > b_x->size[0]) {
          ii = 1;
          jj++;
        }
      }
    }

    if (idx > nx) {
      emlrtErrorWithMessageIdR2018a(&c_st, &ge_emlrtRTEI,
        "Coder:builtins:AssertionFailed", "Coder:builtins:AssertionFailed", 0);
    }

    if (nx == 1) {
      if (idx == 0) {
        i->size[0] = 0;
        j->size[0] = 0;
      }
    } else {
      if (1 > idx) {
        i16 = 0;
      } else {
        i16 = idx;
      }

      iv2[0] = 1;
      iv2[1] = i16;
      d_st.site = &pd_emlrtRSI;
      indexShapeCheck(&d_st, i->size[0], iv2);
      i17 = i->size[0];
      i->size[0] = i16;
      emxEnsureCapacity_int32_T(&c_st, i, i17, &n_emlrtRTEI);
      if (1 > idx) {
        i16 = 0;
      } else {
        i16 = idx;
      }

      iv2[0] = 1;
      iv2[1] = i16;
      d_st.site = &qd_emlrtRSI;
      indexShapeCheck(&d_st, j->size[0], iv2);
      i17 = j->size[0];
      j->size[0] = i16;
      emxEnsureCapacity_int32_T(&c_st, j, i17, &o_emlrtRTEI);
      iv2[0] = 1;
      if (1 > idx) {
        iv2[1] = 0;
      } else {
        iv2[1] = idx;
      }

      d_st.site = &rd_emlrtRSI;
      indexShapeCheck(&d_st, v->size[0], iv2);
    }

    emxFree_boolean_T(&v);
  }

  emxFree_boolean_T(&b_x);
  i16 = rIdx->size[0];
  rIdx->size[0] = i->size[0];
  emxEnsureCapacity_real_T(&st, rIdx, i16, &l_emlrtRTEI);
  ii = i->size[0];
  for (i16 = 0; i16 < ii; i16++) {
    rIdx->data[i16] = i->data[i16];
  }

  emxFree_int32_T(&i);
  i16 = cIdx->size[0];
  cIdx->size[0] = j->size[0];
  emxEnsureCapacity_real_T(&st, cIdx, i16, &m_emlrtRTEI);
  ii = j->size[0];
  for (i16 = 0; i16 < ii; i16++) {
    cIdx->data[i16] = j->data[i16];
  }

  emxFree_int32_T(&j);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

void munkres(const emlrtStack *sp, emxArray_real_T *costMat, emxArray_real_T
             *assignment, real_T *cost)
{
  int32_T i7;
  int32_T loop_ub;
  emxArray_boolean_T *r3;
  emxArray_boolean_T *r4;
  int32_T iv1[2];
  int32_T ii[2];
  int32_T n;
  int32_T jj;
  int32_T idx;
  emxArray_int32_T *b_ii;
  emxArray_real_T *minR;
  real_T bigM;
  int32_T i8;
  int32_T m;
  int32_T Step;
  emxArray_int32_T *j;
  emxArray_boolean_T *r5;
  int32_T i9;
  emxArray_boolean_T *validCol;
  emxArray_boolean_T *validRow;
  real_T nRows;
  real_T nCols;
  real_T b_n;
  emxArray_int32_T *c_ii;
  emxArray_real_T *dMat;
  boolean_T overflow;
  int32_T b_loop_ub;
  emxArray_int32_T *r6;
  emxArray_int32_T *d_ii;
  emxArray_int32_T *r7;
  emxArray_int32_T *r8;
  uint32_T dMat_idx_0;
  emxArray_real_T *varargin_1;
  emxArray_real_T *minC;
  real_T uZr;
  int32_T b_varargin_1[2];
  emxArray_boolean_T *zP;
  emxArray_real_T *starZ;
  int32_T exitg1;
  emxArray_boolean_T b_zP;
  int32_T c_zP[1];
  emxArray_boolean_T *coverColumn;
  emxArray_boolean_T *coverRow;
  emxArray_real_T *primeZ;
  emxArray_real_T *rIdx;
  emxArray_real_T *cIdx;
  emxArray_uint32_T *cR;
  emxArray_uint32_T *cC;
  emxArray_boolean_T *z;
  emxArray_real_T *b_cIdx;
  emxArray_int32_T *r9;
  emxArray_int32_T *r10;
  emxArray_int32_T *r11;
  boolean_T exitg2;
  emxArray_int32_T *r12;
  emxArray_int32_T *r13;
  emxArray_int32_T *r14;
  emxArray_int32_T *r15;
  emxArray_int32_T *r16;
  emxArray_int32_T *r17;
  emxArray_int32_T *r18;
  emxArray_int32_T *r19;
  emxArray_int32_T *r20;
  emxArray_int32_T *r21;
  emxArray_boolean_T *x;
  int32_T r_data[1];
  emxArray_boolean_T *b_starZ;
  emxArray_real_T *b_minR;
  emxArray_real_T *b_minC;
  emxArray_real_T *c_minC;
  int32_T c_data[1];
  int32_T tmp_data[1];
  emxArray_uint32_T *pass;
  emxArray_int32_T *r22;
  boolean_T guard1 = false;
  int32_T exitg3;
  emxArray_int32_T *r23;
  emxArray_int32_T *r24;
  real_T uZc;
  boolean_T exitg4;
  emlrtStack *r25;
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  emlrtStack g_st;
  emlrtStack h_st;
  emlrtStack i_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;
  g_st.prev = &f_st;
  g_st.tls = f_st.tls;
  h_st.prev = &g_st;
  h_st.tls = g_st.tls;
  i_st.prev = &h_st;
  i_st.tls = h_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b(sp);

  /*  MUNKRES   Munkres (Hungarian) Algorithm for Linear Assignment Problem.  */
  /*  */
  /*  [ASSIGN,COST] = munkres(COSTMAT) returns the optimal column indices, */
  /*  ASSIGN assigned to each row and the minimum COST based on the assignment */
  /*  problem represented by the COSTMAT, where the (i,j)th element represents the cost to assign the jth */
  /*  job to the ith worker. */
  /*  */
  /*  Partial assignment: This code can identify a partial assignment is a full */
  /*  assignment is not feasible. For a partial assignment, there are some */
  /*  zero elements in the returning assignment vector, which indicate */
  /*  un-assigned tasks. The cost returned only contains the cost of partially */
  /*  assigned tasks. */
  /*  This is vectorized implementation of the algorithm. It is the fastest */
  /*  among all Matlab implementations of the algorithm. */
  /*  Examples */
  /*  Example 1: a 5 x 5 example */
  /* { */
  /* [assignment,cost] = munkres(magic(5)); */
  /* disp(assignment); % 3 2 1 5 4 */
  /* disp(cost); %15 */
  /* } */
  /*  Example 2: 400 x 400 random data */
  /* { */
  /* n=400; */
  /* A=rand(n); */
  /* tic */
  /* [a,b]=munkres(A); */
  /* toc                 % about 2 seconds  */
  /* } */
  /*  Example 3: rectangular assignment with inf costs */
  /* { */
  /* A=rand(10,7); */
  /* A(A>0.7)=Inf; */
  /* [a,b]=munkres(A); */
  /* } */
  /*  Example 4: an example of partial assignment */
  /* { */
  /* A = [1 3 Inf; Inf Inf 5; Inf Inf 0.5];  */
  /* [a,b]=munkres(A) */
  /* } */
  /*  a = [1 0 3] */
  /*  b = 1.5 */
  /*  Reference: */
  /*  "Munkres' Assignment Algorithm, Modified for Rectangular Matrices",  */
  /*  http://csclab.murraystate.edu/bob.pilgrim/445/munkres.html */
  /*  version 2.3 by Yi Cao at Cranfield University on 11th September 2011 */
  i7 = assignment->size[0] * assignment->size[1];
  assignment->size[0] = 1;
  assignment->size[1] = costMat->size[0];
  emxEnsureCapacity_real_T(sp, assignment, i7, &kb_emlrtRTEI);
  loop_ub = costMat->size[0];
  for (i7 = 0; i7 < loop_ub; i7++) {
    assignment->data[i7] = 0.0;
  }

  emxInit_boolean_T(sp, &r3, 2, &jc_emlrtRTEI, true);
  *cost = 0.0;
  i7 = r3->size[0] * r3->size[1];
  r3->size[0] = costMat->size[0];
  r3->size[1] = costMat->size[1];
  emxEnsureCapacity_boolean_T(sp, r3, i7, &lb_emlrtRTEI);
  loop_ub = costMat->size[0] * costMat->size[1];
  for (i7 = 0; i7 < loop_ub; i7++) {
    r3->data[i7] = (costMat->data[i7] == costMat->data[i7]);
  }

  emxInit_boolean_T(sp, &r4, 2, &nb_emlrtRTEI, true);
  i7 = r4->size[0] * r4->size[1];
  r4->size[0] = costMat->size[0];
  r4->size[1] = costMat->size[1];
  emxEnsureCapacity_boolean_T(sp, r4, i7, &mb_emlrtRTEI);
  loop_ub = costMat->size[0] * costMat->size[1];
  for (i7 = 0; i7 < loop_ub; i7++) {
    r4->data[i7] = (costMat->data[i7] < rtInf);
  }

  iv1[0] = r3->size[0];
  iv1[1] = r3->size[1];
  ii[0] = r4->size[0];
  ii[1] = r4->size[1];
  if ((iv1[0] != ii[0]) || (iv1[1] != ii[1])) {
    emlrtSizeEqCheckNDR2012b(&iv1[0], &ii[0], &k_emlrtECI, sp);
  }

  st.site = &rb_emlrtRSI;
  b_indexShapeCheck(&st, *(int32_T (*)[2])costMat->size, *(int32_T (*)[2])
                    r3->size);
  n = r3->size[0] * r3->size[1] - 1;
  jj = 0;
  for (idx = 0; idx <= n; idx++) {
    if (r3->data[idx] && r4->data[idx]) {
      jj++;
    }
  }

  emxInit_int32_T(sp, &b_ii, 1, &y_emlrtRTEI, true);
  i7 = b_ii->size[0];
  b_ii->size[0] = jj;
  emxEnsureCapacity_int32_T(sp, b_ii, i7, &nb_emlrtRTEI);
  jj = 0;
  for (idx = 0; idx <= n; idx++) {
    if (r3->data[idx] && r4->data[idx]) {
      b_ii->data[jj] = idx + 1;
      jj++;
    }
  }

  emxInit_real_T(sp, &minR, 1, &ld_emlrtRTEI, true);
  jj = costMat->size[0] * costMat->size[1];
  i7 = minR->size[0];
  minR->size[0] = b_ii->size[0];
  emxEnsureCapacity_real_T(sp, minR, i7, &ob_emlrtRTEI);
  loop_ub = b_ii->size[0];
  for (i7 = 0; i7 < loop_ub; i7++) {
    i8 = b_ii->data[i7];
    if ((i8 < 1) || (i8 > jj)) {
      emlrtDynamicBoundsCheckR2012b(i8, 1, jj, &ib_emlrtBCI, sp);
    }

    minR->data[i7] = costMat->data[i8 - 1];
  }

  st.site = &rb_emlrtRSI;
  bigM = c_sum(&st, minR);
  st.site = &rb_emlrtRSI;
  b_log10(&st, &bigM);
  bigM = muDoubleScalarCeil(bigM);
  st.site = &rb_emlrtRSI;
  bigM = mpower(&st, 10.0, bigM + 1.0);
  m = r3->size[0];
  Step = r3->size[1];
  n = m * Step - 1;
  jj = 0;
  for (idx = 0; idx <= n; idx++) {
    if ((!r3->data[idx]) || (!r4->data[idx])) {
      jj++;
    }
  }

  emxInit_int32_T(sp, &j, 1, &nb_emlrtRTEI, true);
  i7 = j->size[0];
  j->size[0] = jj;
  emxEnsureCapacity_int32_T(sp, j, i7, &nb_emlrtRTEI);
  jj = 0;
  for (idx = 0; idx <= n; idx++) {
    if ((!r3->data[idx]) || (!r4->data[idx])) {
      j->data[jj] = idx + 1;
      jj++;
    }
  }

  loop_ub = j->size[0] - 1;
  i7 = costMat->size[0];
  i8 = costMat->size[1];
  i7 *= i8;
  for (i8 = 0; i8 <= loop_ub; i8++) {
    i9 = j->data[i8];
    if ((i9 < 1) || (i9 > i7)) {
      emlrtDynamicBoundsCheckR2012b(i9, 1, i7, &jb_emlrtBCI, sp);
    }

    costMat->data[i9 - 1] = bigM;
  }

  emxInit_boolean_T(sp, &r5, 2, &lb_emlrtRTEI, true);

  /*  costMat(costMat~=costMat)=Inf; */
  /*  validMat = costMat<Inf; */
  i7 = r5->size[0] * r5->size[1];
  r5->size[0] = r3->size[0];
  r5->size[1] = r3->size[1];
  emxEnsureCapacity_boolean_T(sp, r5, i7, &lb_emlrtRTEI);
  loop_ub = r3->size[0] * r3->size[1];
  for (i7 = 0; i7 < loop_ub; i7++) {
    r5->data[i7] = (r3->data[i7] && r4->data[i7]);
  }

  emxInit_boolean_T(sp, &validCol, 2, &jd_emlrtRTEI, true);
  st.site = &sb_emlrtRSI;
  any(&st, r5, validCol);
  i7 = r5->size[0] * r5->size[1];
  r5->size[0] = r3->size[0];
  r5->size[1] = r3->size[1];
  emxEnsureCapacity_boolean_T(sp, r5, i7, &lb_emlrtRTEI);
  loop_ub = r3->size[0] * r3->size[1];
  for (i7 = 0; i7 < loop_ub; i7++) {
    r5->data[i7] = (r3->data[i7] && r4->data[i7]);
  }

  emxInit_boolean_T(sp, &validRow, 1, &kd_emlrtRTEI, true);
  st.site = &tb_emlrtRSI;
  b_any(&st, r5, validRow);
  st.site = &ub_emlrtRSI;
  nRows = d_sum(&st, validRow);
  st.site = &vb_emlrtRSI;
  nCols = e_sum(&st, validCol);
  b_n = muDoubleScalarMax(nRows, nCols);
  st.site = &wb_emlrtRSI;
  toLogicalCheck(&st, b_n);
  emxFree_boolean_T(&r5);
  if (b_n != 0.0) {
    st.site = &xb_emlrtRSI;
    b_indexShapeCheck(&st, *(int32_T (*)[2])costMat->size, *(int32_T (*)[2])
                      r3->size);
    n = r3->size[0] * r3->size[1] - 1;
    jj = 0;
    for (idx = 0; idx <= n; idx++) {
      if (r3->data[idx] && r4->data[idx]) {
        jj++;
      }
    }

    emxInit_int32_T(sp, &c_ii, 1, &tb_emlrtRTEI, true);
    i7 = c_ii->size[0];
    c_ii->size[0] = jj;
    emxEnsureCapacity_int32_T(sp, c_ii, i7, &nb_emlrtRTEI);
    jj = 0;
    for (idx = 0; idx <= n; idx++) {
      if (r3->data[idx] && r4->data[idx]) {
        c_ii->data[jj] = idx + 1;
        jj++;
      }
    }

    st.site = &xb_emlrtRSI;
    jj = costMat->size[0] * costMat->size[1];
    loop_ub = c_ii->size[0];
    for (i7 = 0; i7 < loop_ub; i7++) {
      i8 = c_ii->data[i7];
      if ((i8 < 1) || (i8 > jj)) {
        emlrtDynamicBoundsCheckR2012b(i8, 1, jj, &kb_emlrtBCI, &st);
      }
    }

    b_st.site = &t_emlrtRSI;
    c_st.site = &o_emlrtRSI;
    d_st.site = &u_emlrtRSI;
    if (c_ii->size[0] < 1) {
      emlrtErrorWithMessageIdR2018a(&d_st, &de_emlrtRTEI,
        "Coder:toolbox:eml_min_or_max_varDimZero",
        "Coder:toolbox:eml_min_or_max_varDimZero", 0);
    }

    e_st.site = &ed_emlrtRSI;
    n = c_ii->size[0];
    if (c_ii->size[0] <= 2) {
      if (c_ii->size[0] == 1) {
        bigM = costMat->data[c_ii->data[0] - 1];
      } else if ((costMat->data[c_ii->data[0] - 1] < costMat->data[c_ii->data[1]
                  - 1]) || (muDoubleScalarIsNaN(costMat->data[c_ii->data[0] - 1])
                            && (!muDoubleScalarIsNaN(costMat->data[c_ii->data[1]
        - 1])))) {
        bigM = costMat->data[c_ii->data[1] - 1];
      } else {
        bigM = costMat->data[c_ii->data[0] - 1];
      }
    } else {
      i7 = minR->size[0];
      minR->size[0] = c_ii->size[0];
      emxEnsureCapacity_real_T(&e_st, minR, i7, &pb_emlrtRTEI);
      loop_ub = c_ii->size[0];
      for (i7 = 0; i7 < loop_ub; i7++) {
        minR->data[i7] = costMat->data[c_ii->data[i7] - 1];
      }

      f_st.site = &gd_emlrtRSI;
      idx = findFirst(&f_st, minR);
      if (idx == 0) {
        bigM = costMat->data[c_ii->data[0] - 1];
      } else {
        f_st.site = &fd_emlrtRSI;
        bigM = costMat->data[c_ii->data[idx - 1] - 1];
        m = idx + 1;
        g_st.site = &id_emlrtRSI;
        overflow = ((idx + 1 <= c_ii->size[0]) && (c_ii->size[0] > 2147483646));
        if (overflow) {
          h_st.site = &m_emlrtRSI;
          check_forloop_overflow_error(&h_st);
        }

        for (jj = m; jj <= n; jj++) {
          if (bigM < costMat->data[c_ii->data[jj - 1] - 1]) {
            bigM = costMat->data[c_ii->data[jj - 1] - 1];
          }
        }
      }
    }

    emxInit_real_T(&e_st, &dMat, 2, &qb_emlrtRTEI, true);
    bigM *= 10.0;
    if (b_n != (int32_T)muDoubleScalarFloor(b_n)) {
      emlrtIntegerCheckR2012b(b_n, &f_emlrtDCI, sp);
    }

    i7 = dMat->size[0] * dMat->size[1];
    dMat->size[0] = (int32_T)b_n;
    dMat->size[1] = (int32_T)b_n;
    emxEnsureCapacity_real_T(sp, dMat, i7, &qb_emlrtRTEI);
    loop_ub = (int32_T)b_n * (int32_T)b_n;
    for (i7 = 0; i7 < loop_ub; i7++) {
      dMat->data[i7] = bigM;
    }

    if (1.0 > nRows) {
      loop_ub = 0;
    } else {
      i7 = dMat->size[0];
      loop_ub = (int32_T)nRows;
      if ((loop_ub < 1) || (loop_ub > i7)) {
        emlrtDynamicBoundsCheckR2012b(loop_ub, 1, i7, &hb_emlrtBCI, sp);
      }
    }

    if (1.0 > nCols) {
      b_loop_ub = 0;
    } else {
      i7 = dMat->size[1];
      b_loop_ub = (int32_T)nCols;
      if ((b_loop_ub < 1) || (b_loop_ub > i7)) {
        emlrtDynamicBoundsCheckR2012b(b_loop_ub, 1, i7, &gb_emlrtBCI, sp);
      }
    }

    i7 = b_ii->size[0];
    b_ii->size[0] = loop_ub;
    emxEnsureCapacity_int32_T(sp, b_ii, i7, &rb_emlrtRTEI);
    for (i7 = 0; i7 < loop_ub; i7++) {
      b_ii->data[i7] = i7;
    }

    i7 = j->size[0];
    j->size[0] = b_loop_ub;
    emxEnsureCapacity_int32_T(sp, j, i7, &sb_emlrtRTEI);
    for (i7 = 0; i7 < b_loop_ub; i7++) {
      j->data[i7] = i7;
    }

    n = validRow->size[0];
    for (idx = 0; idx < n; idx++) {
      if (validRow->data[idx]) {
        i7 = costMat->size[0];
        i8 = idx + 1;
        if ((i8 < 1) || (i8 > i7)) {
          emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &bb_emlrtBCI, sp);
        }
      }
    }

    n = validCol->size[1];
    for (idx = 0; idx < n; idx++) {
      if (validCol->data[idx]) {
        i7 = costMat->size[1];
        i8 = idx + 1;
        if ((i8 < 1) || (i8 > i7)) {
          emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &ab_emlrtBCI, sp);
        }
      }
    }

    n = validRow->size[0] - 1;
    jj = 0;
    for (idx = 0; idx <= n; idx++) {
      if (validRow->data[idx]) {
        jj++;
      }
    }

    emxInit_int32_T(sp, &r6, 1, &nb_emlrtRTEI, true);
    i7 = r6->size[0];
    r6->size[0] = jj;
    emxEnsureCapacity_int32_T(sp, r6, i7, &nb_emlrtRTEI);
    jj = 0;
    for (idx = 0; idx <= n; idx++) {
      if (validRow->data[idx]) {
        r6->data[jj] = idx + 1;
        jj++;
      }
    }

    n = validCol->size[1] - 1;
    jj = 0;
    for (idx = 0; idx <= n; idx++) {
      if (validCol->data[idx]) {
        jj++;
      }
    }

    emxInit_int32_T(sp, &d_ii, 2, &y_emlrtRTEI, true);
    i7 = d_ii->size[0] * d_ii->size[1];
    d_ii->size[0] = 1;
    d_ii->size[1] = jj;
    emxEnsureCapacity_int32_T(sp, d_ii, i7, &nb_emlrtRTEI);
    jj = 0;
    for (idx = 0; idx <= n; idx++) {
      if (validCol->data[idx]) {
        d_ii->data[jj] = idx + 1;
        jj++;
      }
    }

    ii[0] = b_ii->size[0];
    ii[1] = j->size[0];
    i7 = c_ii->size[0];
    c_ii->size[0] = d_ii->size[1];
    emxEnsureCapacity_int32_T(sp, c_ii, i7, &tb_emlrtRTEI);
    loop_ub = d_ii->size[1];
    for (i7 = 0; i7 < loop_ub; i7++) {
      c_ii->data[i7] = d_ii->data[i7];
    }

    iv1[0] = r6->size[0];
    iv1[1] = c_ii->size[0];
    emlrtSubAssignSizeCheckR2012b(&ii[0], 2, &iv1[0], 2, &j_emlrtECI, sp);
    n = validRow->size[0] - 1;
    jj = 0;
    emxFree_int32_T(&r6);
    for (idx = 0; idx <= n; idx++) {
      if (validRow->data[idx]) {
        jj++;
      }
    }

    emxInit_int32_T(sp, &r7, 1, &nb_emlrtRTEI, true);
    i7 = r7->size[0];
    r7->size[0] = jj;
    emxEnsureCapacity_int32_T(sp, r7, i7, &nb_emlrtRTEI);
    jj = 0;
    for (idx = 0; idx <= n; idx++) {
      if (validRow->data[idx]) {
        r7->data[jj] = idx + 1;
        jj++;
      }
    }

    n = validCol->size[1] - 1;
    jj = 0;
    for (idx = 0; idx <= n; idx++) {
      if (validCol->data[idx]) {
        jj++;
      }
    }

    emxInit_int32_T(sp, &r8, 2, &nb_emlrtRTEI, true);
    i7 = r8->size[0] * r8->size[1];
    r8->size[0] = 1;
    r8->size[1] = jj;
    emxEnsureCapacity_int32_T(sp, r8, i7, &nb_emlrtRTEI);
    jj = 0;
    for (idx = 0; idx <= n; idx++) {
      if (validCol->data[idx]) {
        r8->data[jj] = idx + 1;
        jj++;
      }
    }

    loop_ub = r8->size[1];
    for (i7 = 0; i7 < loop_ub; i7++) {
      b_loop_ub = r7->size[0];
      for (i8 = 0; i8 < b_loop_ub; i8++) {
        dMat->data[b_ii->data[i8] + dMat->size[0] * j->data[i7]] = costMat->
          data[(r7->data[i8] + costMat->size[0] * (r8->data[i7] - 1)) - 1];
      }
    }

    emxFree_int32_T(&r8);
    emxFree_int32_T(&r7);

    /* ************************************************* */
    /*  Munkres' Assignment Algorithm starts here */
    /* ************************************************* */
    /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
    /*    STEP 1: Subtract the row minimum from each row. */
    /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
    st.site = &yb_emlrtRSI;
    b_st.site = &n_emlrtRSI;
    c_st.site = &o_emlrtRSI;
    d_st.site = &u_emlrtRSI;
    e_st.site = &v_emlrtRSI;
    f_st.site = &w_emlrtRSI;
    g_st.site = &x_emlrtRSI;
    m = dMat->size[0];
    n = dMat->size[1];
    dMat_idx_0 = (uint32_T)dMat->size[0];
    i7 = minR->size[0];
    minR->size[0] = (int32_T)dMat_idx_0;
    emxEnsureCapacity_real_T(&g_st, minR, i7, &d_emlrtRTEI);
    h_st.site = &bb_emlrtRSI;
    overflow = ((1 <= dMat->size[0]) && (dMat->size[0] > 2147483646));
    if (overflow) {
      i_st.site = &m_emlrtRSI;
      check_forloop_overflow_error(&i_st);
    }

    for (idx = 0; idx < m; idx++) {
      minR->data[idx] = dMat->data[idx];
    }

    h_st.site = &ab_emlrtRSI;
    overflow = ((2 <= dMat->size[1]) && (dMat->size[1] > 2147483646));
    if (overflow) {
      i_st.site = &m_emlrtRSI;
      check_forloop_overflow_error(&i_st);
    }

    for (jj = 2; jj <= n; jj++) {
      h_st.site = &y_emlrtRSI;
      if ((1 <= m) && (m > 2147483646)) {
        i_st.site = &m_emlrtRSI;
        check_forloop_overflow_error(&i_st);
      }

      for (idx = 0; idx < m; idx++) {
        bigM = dMat->data[idx + dMat->size[0] * (jj - 1)];
        overflow = ((!muDoubleScalarIsNaN(bigM)) && (muDoubleScalarIsNaN
          (minR->data[idx]) || (minR->data[idx] > bigM)));
        if (overflow) {
          minR->data[idx] = dMat->data[idx + dMat->size[0] * (jj - 1)];
        }
      }
    }

    emxInit_real_T(&g_st, &varargin_1, 2, &qd_emlrtRTEI, true);
    st.site = &ac_emlrtRSI;
    bsxfun(&st, dMat, minR, varargin_1);
    st.site = &ac_emlrtRSI;
    b_st.site = &n_emlrtRSI;
    c_st.site = &o_emlrtRSI;
    d_st.site = &u_emlrtRSI;
    if ((varargin_1->size[0] != 1) || (varargin_1->size[1] == 1)) {
    } else {
      emlrtErrorWithMessageIdR2018a(&d_st, &ne_emlrtRTEI,
        "Coder:toolbox:autoDimIncompatibility",
        "Coder:toolbox:autoDimIncompatibility", 0);
    }

    emxInit_real_T(&d_st, &minC, 2, &md_emlrtRTEI, true);
    e_st.site = &v_emlrtRSI;
    f_st.site = &w_emlrtRSI;
    g_st.site = &jd_emlrtRSI;
    m = varargin_1->size[0];
    n = varargin_1->size[1];
    dMat_idx_0 = (uint32_T)varargin_1->size[1];
    i7 = minC->size[0] * minC->size[1];
    minC->size[0] = 1;
    minC->size[1] = (int32_T)dMat_idx_0;
    emxEnsureCapacity_real_T(&g_st, minC, i7, &ub_emlrtRTEI);
    h_st.site = &ld_emlrtRSI;
    overflow = ((1 <= varargin_1->size[1]) && (varargin_1->size[1] > 2147483646));
    if (overflow) {
      i_st.site = &m_emlrtRSI;
      check_forloop_overflow_error(&i_st);
    }

    for (jj = 0; jj < n; jj++) {
      minC->data[jj] = varargin_1->data[varargin_1->size[0] * jj];
      h_st.site = &kd_emlrtRSI;
      if ((2 <= m) && (m > 2147483646)) {
        i_st.site = &m_emlrtRSI;
        check_forloop_overflow_error(&i_st);
      }

      for (idx = 2; idx <= m; idx++) {
        uZr = minC->data[jj];
        bigM = varargin_1->data[(idx + varargin_1->size[0] * jj) - 1];
        if ((!muDoubleScalarIsNaN(bigM)) && (muDoubleScalarIsNaN(uZr) || (uZr >
              bigM))) {
          minC->data[jj] = varargin_1->data[(idx + varargin_1->size[0] * jj) - 1];
        }
      }
    }

    /* **************************************************************************   */
    /*    STEP 2: Find a zero of dMat. If there are no starred zeros in its */
    /*            column or row start the zero. Repeat for each zero */
    /* ************************************************************************** */
    b_bsxfun(sp, minC, minR, varargin_1);
    ii[0] = dMat->size[0];
    ii[1] = dMat->size[1];
    b_varargin_1[0] = varargin_1->size[0];
    b_varargin_1[1] = varargin_1->size[1];
    emxInit_boolean_T(sp, &zP, 2, &vb_emlrtRTEI, true);
    if ((ii[0] != b_varargin_1[0]) || (ii[1] != b_varargin_1[1])) {
      emlrtSizeEqCheckNDR2012b(&ii[0], &b_varargin_1[0], &i_emlrtECI, sp);
    }

    i7 = zP->size[0] * zP->size[1];
    zP->size[0] = dMat->size[0];
    zP->size[1] = dMat->size[1];
    emxEnsureCapacity_boolean_T(sp, zP, i7, &vb_emlrtRTEI);
    loop_ub = dMat->size[0] * dMat->size[1];
    for (i7 = 0; i7 < loop_ub; i7++) {
      zP->data[i7] = (dMat->data[i7] == varargin_1->data[i7]);
    }

    emxInit_real_T(sp, &starZ, 1, &wb_emlrtRTEI, true);
    i7 = starZ->size[0];
    if (b_n != (int32_T)muDoubleScalarFloor(b_n)) {
      emlrtIntegerCheckR2012b(b_n, &h_emlrtDCI, sp);
    }

    starZ->size[0] = (int32_T)b_n;
    emxEnsureCapacity_real_T(sp, starZ, i7, &wb_emlrtRTEI);
    if (b_n != (int32_T)muDoubleScalarFloor(b_n)) {
      emlrtIntegerCheckR2012b(b_n, &h_emlrtDCI, sp);
    }

    loop_ub = (int32_T)b_n;
    for (i7 = 0; i7 < loop_ub; i7++) {
      starZ->data[i7] = 0.0;
    }

    do {
      exitg1 = 0;
      jj = zP->size[0] * zP->size[1];
      b_zP = *zP;
      c_zP[0] = jj;
      b_zP.size = &c_zP[0];
      b_zP.numDimensions = 1;
      st.site = &bc_emlrtRSI;
      if (c_any(&st, &b_zP)) {
        st.site = &cc_emlrtRSI;
        b_st.site = &nd_emlrtRSI;
        if ((zP->size[0] != 1) || (zP->size[1] <= 1)) {
        } else {
          emlrtErrorWithMessageIdR2018a(&b_st, &fe_emlrtRTEI,
            "Coder:toolbox:find_incompatibleShape",
            "Coder:toolbox:find_incompatibleShape", 0);
        }

        c_st.site = &od_emlrtRSI;
        idx = 0;
        i7 = b_ii->size[0];
        b_ii->size[0] = 1;
        emxEnsureCapacity_int32_T(&c_st, b_ii, i7, &k_emlrtRTEI);
        i7 = j->size[0];
        j->size[0] = 1;
        emxEnsureCapacity_int32_T(&c_st, j, i7, &k_emlrtRTEI);
        m = 1;
        jj = 1;
        exitg2 = false;
        while ((!exitg2) && (jj <= zP->size[1])) {
          if (zP->data[(m + zP->size[0] * (jj - 1)) - 1]) {
            idx = 1;
            b_ii->data[0] = m;
            j->data[0] = jj;
            exitg2 = true;
          } else {
            m++;
            if (m > zP->size[0]) {
              m = 1;
              jj++;
            }
          }
        }

        if (idx == 0) {
          b_ii->size[0] = 0;
          j->size[0] = 0;
        }

        n = b_ii->size[0];
        loop_ub = b_ii->size[0];
        for (i7 = 0; i7 < loop_ub; i7++) {
          r_data[i7] = b_ii->data[i7];
        }

        idx = j->size[0];
        loop_ub = j->size[0];
        for (i7 = 0; i7 < loop_ub; i7++) {
          c_data[i7] = j->data[i7];
        }

        jj = starZ->size[0];
        for (i7 = 0; i7 < n; i7++) {
          if ((r_data[i7] < 1) || (r_data[i7] > jj)) {
            emlrtDynamicBoundsCheckR2012b(r_data[i7], 1, jj, &mb_emlrtBCI, sp);
          }

          tmp_data[i7] = r_data[i7];
        }

        if (n != idx) {
          emlrtSubAssignSizeCheck1dR2017a(n, idx, &h_emlrtECI, sp);
        }

        for (i7 = 0; i7 < idx; i7++) {
          starZ->data[tmp_data[i7] - 1] = c_data[i7];
        }

        m = zP->size[0];
        for (i7 = 0; i7 < n; i7++) {
          if ((r_data[i7] < 1) || (r_data[i7] > m)) {
            emlrtDynamicBoundsCheckR2012b(r_data[i7], 1, m, &nb_emlrtBCI, sp);
          }

          tmp_data[i7] = r_data[i7];
        }

        loop_ub = zP->size[1];
        for (i7 = 0; i7 < loop_ub; i7++) {
          for (i8 = 0; i8 < n; i8++) {
            zP->data[(tmp_data[i8] + zP->size[0] * i7) - 1] = false;
          }
        }

        m = zP->size[1];
        for (i7 = 0; i7 < idx; i7++) {
          if ((c_data[i7] < 1) || (c_data[i7] > m)) {
            emlrtDynamicBoundsCheckR2012b(c_data[i7], 1, m, &ob_emlrtBCI, sp);
          }

          tmp_data[i7] = c_data[i7];
        }

        loop_ub = zP->size[0];
        for (i7 = 0; i7 < idx; i7++) {
          for (i8 = 0; i8 < loop_ub; i8++) {
            zP->data[i8 + zP->size[0] * (tmp_data[i7] - 1)] = false;
          }
        }

        if (*emlrtBreakCheckR2012bFlagVar != 0) {
          emlrtBreakCheckR2012b(sp);
        }
      } else {
        exitg1 = 1;
      }
    } while (exitg1 == 0);

    emxInit_boolean_T(sp, &coverColumn, 2, &yb_emlrtRTEI, true);
    emxInit_boolean_T(sp, &coverRow, 1, &ac_emlrtRTEI, true);
    emxInit_real_T(sp, &primeZ, 1, &bc_emlrtRTEI, true);
    emxInit_real_T(sp, &rIdx, 1, &nd_emlrtRTEI, true);
    emxInit_real_T(sp, &cIdx, 1, &od_emlrtRTEI, true);
    emxInit_uint32_T(sp, &cR, 1, &nc_emlrtRTEI, true);
    emxInit_uint32_T(sp, &cC, 2, &pc_emlrtRTEI, true);
    emxInit_boolean_T(sp, &z, 1, &sc_emlrtRTEI, true);
    emxInit_real_T(sp, &b_cIdx, 2, &od_emlrtRTEI, true);
    emxInit_int32_T(sp, &r9, 1, &nb_emlrtRTEI, true);
    emxInit_int32_T(sp, &r10, 2, &nb_emlrtRTEI, true);
    emxInit_int32_T(sp, &r11, 1, &nb_emlrtRTEI, true);
    emxInit_int32_T(sp, &r12, 2, &nb_emlrtRTEI, true);
    emxInit_int32_T(sp, &r13, 1, &nb_emlrtRTEI, true);
    emxInit_int32_T(sp, &r14, 2, &nb_emlrtRTEI, true);
    emxInit_int32_T(sp, &r15, 1, &nb_emlrtRTEI, true);
    emxInit_int32_T(sp, &r16, 2, &nb_emlrtRTEI, true);
    emxInit_int32_T(sp, &r17, 1, &nb_emlrtRTEI, true);
    emxInit_int32_T(sp, &r18, 1, &nb_emlrtRTEI, true);
    emxInit_int32_T(sp, &r19, 1, &nb_emlrtRTEI, true);
    emxInit_int32_T(sp, &r20, 2, &nb_emlrtRTEI, true);
    emxInit_int32_T(sp, &r21, 1, &nb_emlrtRTEI, true);
    emxInit_boolean_T(sp, &x, 2, &oc_emlrtRTEI, true);
    emxInit_boolean_T(sp, &b_starZ, 1, &xb_emlrtRTEI, true);
    emxInit_real_T(sp, &b_minR, 1, &dc_emlrtRTEI, true);
    emxInit_real_T(sp, &b_minC, 2, &ec_emlrtRTEI, true);
    emxInit_real_T(sp, &c_minC, 1, &cd_emlrtRTEI, true);
    do {
      exitg1 = 0;

      /* ************************************************************************** */
      /*    STEP 3: Cover each column with a starred zero. If all the columns are */
      /*            covered then the matching is maximum */
      /* ************************************************************************** */
      i7 = b_starZ->size[0];
      b_starZ->size[0] = starZ->size[0];
      emxEnsureCapacity_boolean_T(sp, b_starZ, i7, &xb_emlrtRTEI);
      loop_ub = starZ->size[0];
      for (i7 = 0; i7 < loop_ub; i7++) {
        b_starZ->data[i7] = (starZ->data[i7] > 0.0);
      }

      st.site = &dc_emlrtRSI;
      if (all(&st, b_starZ)) {
        exitg1 = 1;
      } else {
        i7 = coverColumn->size[0] * coverColumn->size[1];
        coverColumn->size[0] = 1;
        if (b_n != (int32_T)muDoubleScalarFloor(b_n)) {
          emlrtIntegerCheckR2012b(b_n, &g_emlrtDCI, sp);
        }

        coverColumn->size[1] = (int32_T)b_n;
        emxEnsureCapacity_boolean_T(sp, coverColumn, i7, &yb_emlrtRTEI);
        if (b_n != (int32_T)muDoubleScalarFloor(b_n)) {
          emlrtIntegerCheckR2012b(b_n, &i_emlrtDCI, sp);
        }

        loop_ub = (int32_T)b_n;
        for (i7 = 0; i7 < loop_ub; i7++) {
          coverColumn->data[i7] = false;
        }

        n = starZ->size[0];
        for (idx = 0; idx < n; idx++) {
          if (starZ->data[idx] > 0.0) {
            i7 = (int32_T)b_n;
            i8 = starZ->size[0];
            i9 = idx + 1;
            if ((i9 < 1) || (i9 > i8)) {
              emlrtDynamicBoundsCheckR2012b(i9, 1, i8, &lb_emlrtBCI, sp);
            }

            i8 = (int32_T)starZ->data[i9 - 1];
            if ((i8 < 1) || (i8 > i7)) {
              emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &y_emlrtBCI, sp);
            }
          }
        }

        n = starZ->size[0];
        for (idx = 0; idx < n; idx++) {
          if (starZ->data[idx] > 0.0) {
            coverColumn->data[(int32_T)starZ->data[idx] - 1] = true;
          }
        }

        i7 = coverRow->size[0];
        if (b_n != (int32_T)muDoubleScalarFloor(b_n)) {
          emlrtIntegerCheckR2012b(b_n, &j_emlrtDCI, sp);
        }

        coverRow->size[0] = (int32_T)b_n;
        emxEnsureCapacity_boolean_T(sp, coverRow, i7, &ac_emlrtRTEI);
        if (b_n != (int32_T)muDoubleScalarFloor(b_n)) {
          emlrtIntegerCheckR2012b(b_n, &j_emlrtDCI, sp);
        }

        loop_ub = (int32_T)b_n;
        for (i7 = 0; i7 < loop_ub; i7++) {
          coverRow->data[i7] = false;
        }

        i7 = primeZ->size[0];
        if (b_n != (int32_T)muDoubleScalarFloor(b_n)) {
          emlrtIntegerCheckR2012b(b_n, &k_emlrtDCI, sp);
        }

        primeZ->size[0] = (int32_T)b_n;
        emxEnsureCapacity_real_T(sp, primeZ, i7, &bc_emlrtRTEI);
        if (b_n != (int32_T)muDoubleScalarFloor(b_n)) {
          emlrtIntegerCheckR2012b(b_n, &k_emlrtDCI, sp);
        }

        loop_ub = (int32_T)b_n;
        for (i7 = 0; i7 < loop_ub; i7++) {
          primeZ->data[i7] = 0.0;
        }

        n = (int32_T)b_n;
        for (idx = 0; idx < n; idx++) {
          i7 = dMat->size[0];
          i8 = idx + 1;
          if ((i8 < 1) || (i8 > i7)) {
            emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &x_emlrtBCI, sp);
          }
        }

        Step = coverColumn->size[1];
        for (idx = 0; idx < Step; idx++) {
          if (!coverColumn->data[idx]) {
            i7 = dMat->size[1];
            i8 = idx + 1;
            if ((i8 < 1) || (i8 > i7)) {
              emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &w_emlrtBCI, sp);
            }
          }
        }

        n = (int32_T)b_n - 1;
        jj = 0;
        for (idx = 0; idx <= n; idx++) {
          jj++;
        }

        i7 = r9->size[0];
        r9->size[0] = jj;
        emxEnsureCapacity_int32_T(sp, r9, i7, &nb_emlrtRTEI);
        jj = 0;
        for (idx = 0; idx <= n; idx++) {
          r9->data[jj] = idx + 1;
          jj++;
        }

        n = Step - 1;
        jj = 0;
        for (idx = 0; idx <= n; idx++) {
          if (!coverColumn->data[idx]) {
            jj++;
          }
        }

        i7 = r10->size[0] * r10->size[1];
        r10->size[0] = 1;
        r10->size[1] = jj;
        emxEnsureCapacity_int32_T(sp, r10, i7, &nb_emlrtRTEI);
        jj = 0;
        for (idx = 0; idx <= n; idx++) {
          if (!coverColumn->data[idx]) {
            r10->data[jj] = idx + 1;
            jj++;
          }
        }

        jj = minR->size[0];
        i7 = b_minR->size[0];
        b_minR->size[0] = r9->size[0];
        emxEnsureCapacity_real_T(sp, b_minR, i7, &dc_emlrtRTEI);
        loop_ub = r9->size[0];
        for (i7 = 0; i7 < loop_ub; i7++) {
          i8 = r9->data[i7];
          if ((i8 < 1) || (i8 > jj)) {
            emlrtDynamicBoundsCheckR2012b(i8, 1, jj, &pb_emlrtBCI, sp);
          }

          b_minR->data[i7] = minR->data[i8 - 1];
        }

        i7 = b_minC->size[0] * b_minC->size[1];
        b_minC->size[0] = 1;
        b_minC->size[1] = r10->size[1];
        emxEnsureCapacity_real_T(sp, b_minC, i7, &ec_emlrtRTEI);
        jj = minC->size[1];
        loop_ub = r10->size[0] * r10->size[1];
        for (i7 = 0; i7 < loop_ub; i7++) {
          i8 = r10->data[i7];
          if ((i8 < 1) || (i8 > jj)) {
            emlrtDynamicBoundsCheckR2012b(i8, 1, jj, &qb_emlrtBCI, sp);
          }

          b_minC->data[i7] = minC->data[i8 - 1];
        }

        c_bsxfun(sp, b_minR, b_minC, varargin_1);
        n = (int32_T)b_n - 1;
        jj = 0;
        for (idx = 0; idx <= n; idx++) {
          jj++;
        }

        i7 = r11->size[0];
        r11->size[0] = jj;
        emxEnsureCapacity_int32_T(sp, r11, i7, &nb_emlrtRTEI);
        jj = 0;
        for (idx = 0; idx <= n; idx++) {
          r11->data[jj] = idx + 1;
          jj++;
        }

        n = Step - 1;
        jj = 0;
        for (idx = 0; idx <= n; idx++) {
          if (!coverColumn->data[idx]) {
            jj++;
          }
        }

        i7 = r12->size[0] * r12->size[1];
        r12->size[0] = 1;
        r12->size[1] = jj;
        emxEnsureCapacity_int32_T(sp, r12, i7, &nb_emlrtRTEI);
        jj = 0;
        for (idx = 0; idx <= n; idx++) {
          if (!coverColumn->data[idx]) {
            r12->data[jj] = idx + 1;
            jj++;
          }
        }

        i7 = c_ii->size[0];
        c_ii->size[0] = r12->size[1];
        emxEnsureCapacity_int32_T(sp, c_ii, i7, &hc_emlrtRTEI);
        loop_ub = r12->size[1];
        for (i7 = 0; i7 < loop_ub; i7++) {
          c_ii->data[i7] = r12->data[i7];
        }

        iv1[0] = r11->size[0];
        iv1[1] = c_ii->size[0];
        b_varargin_1[0] = varargin_1->size[0];
        b_varargin_1[1] = varargin_1->size[1];
        if ((iv1[0] != b_varargin_1[0]) || (iv1[1] != b_varargin_1[1])) {
          emlrtSizeEqCheckNDR2012b(&iv1[0], &b_varargin_1[0], &g_emlrtECI, sp);
        }

        n = (int32_T)b_n - 1;
        jj = 0;
        for (idx = 0; idx <= n; idx++) {
          jj++;
        }

        i7 = r13->size[0];
        r13->size[0] = jj;
        emxEnsureCapacity_int32_T(sp, r13, i7, &nb_emlrtRTEI);
        jj = 0;
        for (idx = 0; idx <= n; idx++) {
          r13->data[jj] = idx + 1;
          jj++;
        }

        n = Step - 1;
        jj = 0;
        for (idx = 0; idx <= n; idx++) {
          if (!coverColumn->data[idx]) {
            jj++;
          }
        }

        i7 = r14->size[0] * r14->size[1];
        r14->size[0] = 1;
        r14->size[1] = jj;
        emxEnsureCapacity_int32_T(sp, r14, i7, &nb_emlrtRTEI);
        jj = 0;
        for (idx = 0; idx <= n; idx++) {
          if (!coverColumn->data[idx]) {
            r14->data[jj] = idx + 1;
            jj++;
          }
        }

        st.site = &ec_emlrtRSI;
        i7 = zP->size[0] * zP->size[1];
        zP->size[0] = r13->size[0];
        zP->size[1] = r14->size[1];
        emxEnsureCapacity_boolean_T(&st, zP, i7, &ic_emlrtRTEI);
        loop_ub = r14->size[1];
        for (i7 = 0; i7 < loop_ub; i7++) {
          b_loop_ub = r13->size[0];
          for (i8 = 0; i8 < b_loop_ub; i8++) {
            zP->data[i8 + zP->size[0] * i7] = (dMat->data[(r13->data[i8] +
              dMat->size[0] * (r14->data[i7] - 1)) - 1] == varargin_1->data[i8 +
              varargin_1->size[0] * i7]);
          }
        }

        b_st.site = &nd_emlrtRSI;
        n = zP->size[0] * zP->size[1];
        if ((zP->size[0] != 1) || (zP->size[1] <= 1)) {
        } else {
          emlrtErrorWithMessageIdR2018a(&b_st, &fe_emlrtRTEI,
            "Coder:toolbox:find_incompatibleShape",
            "Coder:toolbox:find_incompatibleShape", 0);
        }

        if (n == 0) {
          b_ii->size[0] = 0;
          j->size[0] = 0;
        } else {
          c_st.site = &od_emlrtRSI;
          idx = 0;
          i7 = b_ii->size[0];
          b_ii->size[0] = n;
          emxEnsureCapacity_int32_T(&c_st, b_ii, i7, &k_emlrtRTEI);
          i7 = j->size[0];
          j->size[0] = n;
          emxEnsureCapacity_int32_T(&c_st, j, i7, &k_emlrtRTEI);
          i7 = z->size[0];
          z->size[0] = n;
          emxEnsureCapacity_boolean_T(&c_st, z, i7, &k_emlrtRTEI);
          m = 1;
          jj = 1;
          exitg2 = false;
          while ((!exitg2) && (jj <= zP->size[1])) {
            guard1 = false;
            if (zP->data[(m + zP->size[0] * (jj - 1)) - 1]) {
              idx++;
              b_ii->data[idx - 1] = m;
              j->data[idx - 1] = jj;
              z->data[idx - 1] = zP->data[(m + zP->size[0] * (jj - 1)) - 1];
              if (idx >= n) {
                exitg2 = true;
              } else {
                guard1 = true;
              }
            } else {
              guard1 = true;
            }

            if (guard1) {
              m++;
              if (m > zP->size[0]) {
                m = 1;
                jj++;
              }
            }
          }

          if (idx > n) {
            emlrtErrorWithMessageIdR2018a(&c_st, &ge_emlrtRTEI,
              "Coder:builtins:AssertionFailed", "Coder:builtins:AssertionFailed",
              0);
          }

          if (n == 1) {
            if (idx == 0) {
              b_ii->size[0] = 0;
              j->size[0] = 0;
            }
          } else {
            if (1 > idx) {
              i7 = 0;
            } else {
              i7 = idx;
            }

            iv1[0] = 1;
            iv1[1] = i7;
            d_st.site = &pd_emlrtRSI;
            indexShapeCheck(&d_st, b_ii->size[0], iv1);
            i8 = b_ii->size[0];
            b_ii->size[0] = i7;
            emxEnsureCapacity_int32_T(&c_st, b_ii, i8, &n_emlrtRTEI);
            if (1 > idx) {
              i7 = 0;
            } else {
              i7 = idx;
            }

            iv1[0] = 1;
            iv1[1] = i7;
            d_st.site = &qd_emlrtRSI;
            indexShapeCheck(&d_st, j->size[0], iv1);
            i8 = j->size[0];
            j->size[0] = i7;
            emxEnsureCapacity_int32_T(&c_st, j, i8, &o_emlrtRTEI);
            iv1[0] = 1;
            if (1 > idx) {
              iv1[1] = 0;
            } else {
              iv1[1] = idx;
            }

            d_st.site = &rd_emlrtRSI;
            indexShapeCheck(&d_st, z->size[0], iv1);
          }
        }

        i7 = rIdx->size[0];
        rIdx->size[0] = b_ii->size[0];
        emxEnsureCapacity_real_T(&st, rIdx, i7, &l_emlrtRTEI);
        loop_ub = b_ii->size[0];
        for (i7 = 0; i7 < loop_ub; i7++) {
          rIdx->data[i7] = b_ii->data[i7];
        }

        i7 = cIdx->size[0];
        cIdx->size[0] = j->size[0];
        emxEnsureCapacity_real_T(&st, cIdx, i7, &m_emlrtRTEI);
        loop_ub = j->size[0];
        for (i7 = 0; i7 < loop_ub; i7++) {
          cIdx->data[i7] = j->data[i7];
        }

        do {
          exitg3 = 0;

          /* ************************************************************************** */
          /*    STEP 4: Find a noncovered zero and prime it.  If there is no starred */
          /*            zero in the row containing this primed zero, Go to Step 5.   */
          /*            Otherwise, cover this row and uncover the column containing  */
          /*            the starred zero. Continue in this manner until there are no  */
          /*            uncovered zeros left. Save the smallest uncovered value and  */
          /*            Go to Step 6. */
          /* ************************************************************************** */
          st.site = &fc_emlrtRSI;
          i7 = z->size[0];
          z->size[0] = coverRow->size[0];
          emxEnsureCapacity_boolean_T(&st, z, i7, &lc_emlrtRTEI);
          loop_ub = coverRow->size[0];
          for (i7 = 0; i7 < loop_ub; i7++) {
            z->data[i7] = !coverRow->data[i7];
          }

          b_st.site = &cb_emlrtRSI;
          n = z->size[0];
          c_st.site = &db_emlrtRSI;
          idx = 0;
          i7 = b_ii->size[0];
          b_ii->size[0] = z->size[0];
          emxEnsureCapacity_int32_T(&c_st, b_ii, i7, &e_emlrtRTEI);
          d_st.site = &eb_emlrtRSI;
          overflow = ((1 <= z->size[0]) && (z->size[0] > 2147483646));
          if (overflow) {
            e_st.site = &m_emlrtRSI;
            check_forloop_overflow_error(&e_st);
          }

          m = 0;
          exitg2 = false;
          while ((!exitg2) && (m <= n - 1)) {
            if (z->data[m]) {
              idx++;
              b_ii->data[idx - 1] = m + 1;
              if (idx >= n) {
                exitg2 = true;
              } else {
                m++;
              }
            } else {
              m++;
            }
          }

          if (idx > z->size[0]) {
            emlrtErrorWithMessageIdR2018a(&c_st, &ee_emlrtRTEI,
              "Coder:builtins:AssertionFailed", "Coder:builtins:AssertionFailed",
              0);
          }

          if (z->size[0] == 1) {
            if (idx == 0) {
              b_ii->size[0] = 0;
            }
          } else {
            if (1 > idx) {
              i7 = 0;
            } else {
              i7 = idx;
            }

            iv1[0] = 1;
            iv1[1] = i7;
            d_st.site = &fb_emlrtRSI;
            indexShapeCheck(&d_st, b_ii->size[0], iv1);
            i8 = b_ii->size[0];
            b_ii->size[0] = i7;
            emxEnsureCapacity_int32_T(&c_st, b_ii, i8, &g_emlrtRTEI);
          }

          i7 = cR->size[0];
          cR->size[0] = b_ii->size[0];
          emxEnsureCapacity_uint32_T(&st, cR, i7, &nc_emlrtRTEI);
          loop_ub = b_ii->size[0];
          for (i7 = 0; i7 < loop_ub; i7++) {
            cR->data[i7] = (uint32_T)b_ii->data[i7];
          }

          st.site = &gc_emlrtRSI;
          i7 = x->size[0] * x->size[1];
          x->size[0] = 1;
          x->size[1] = coverColumn->size[1];
          emxEnsureCapacity_boolean_T(&st, x, i7, &oc_emlrtRTEI);
          loop_ub = coverColumn->size[0] * coverColumn->size[1];
          for (i7 = 0; i7 < loop_ub; i7++) {
            x->data[i7] = !coverColumn->data[i7];
          }

          b_st.site = &cb_emlrtRSI;
          n = x->size[1];
          c_st.site = &db_emlrtRSI;
          idx = 0;
          i7 = d_ii->size[0] * d_ii->size[1];
          d_ii->size[0] = 1;
          d_ii->size[1] = x->size[1];
          emxEnsureCapacity_int32_T(&c_st, d_ii, i7, &e_emlrtRTEI);
          d_st.site = &eb_emlrtRSI;
          overflow = ((1 <= x->size[1]) && (x->size[1] > 2147483646));
          if (overflow) {
            e_st.site = &m_emlrtRSI;
            check_forloop_overflow_error(&e_st);
          }

          m = 0;
          exitg2 = false;
          while ((!exitg2) && (m <= n - 1)) {
            if (x->data[m]) {
              idx++;
              d_ii->data[idx - 1] = m + 1;
              if (idx >= n) {
                exitg2 = true;
              } else {
                m++;
              }
            } else {
              m++;
            }
          }

          if (idx > x->size[1]) {
            emlrtErrorWithMessageIdR2018a(&c_st, &ee_emlrtRTEI,
              "Coder:builtins:AssertionFailed", "Coder:builtins:AssertionFailed",
              0);
          }

          if (x->size[1] == 1) {
            if (idx == 0) {
              d_ii->size[0] = 1;
              d_ii->size[1] = 0;
            }
          } else if (1 > idx) {
            d_ii->size[1] = 0;
          } else {
            i7 = d_ii->size[0] * d_ii->size[1];
            d_ii->size[1] = idx;
            emxEnsureCapacity_int32_T(&c_st, d_ii, i7, &g_emlrtRTEI);
          }

          i7 = cC->size[0] * cC->size[1];
          cC->size[0] = 1;
          cC->size[1] = d_ii->size[1];
          emxEnsureCapacity_uint32_T(&st, cC, i7, &pc_emlrtRTEI);
          loop_ub = d_ii->size[0] * d_ii->size[1];
          for (i7 = 0; i7 < loop_ub; i7++) {
            cC->data[i7] = (uint32_T)d_ii->data[i7];
          }

          jj = cR->size[0];
          i7 = rIdx->size[0];
          emxEnsureCapacity_real_T(sp, rIdx, i7, &qc_emlrtRTEI);
          loop_ub = rIdx->size[0];
          for (i7 = 0; i7 < loop_ub; i7++) {
            i8 = (int32_T)rIdx->data[i7];
            if ((i8 < 1) || (i8 > jj)) {
              emlrtDynamicBoundsCheckR2012b(i8, 1, jj, &cc_emlrtBCI, sp);
            }

            rIdx->data[i7] = cR->data[i8 - 1];
          }

          m = cC->size[1];
          i7 = b_cIdx->size[0] * b_cIdx->size[1];
          b_cIdx->size[0] = 1;
          b_cIdx->size[1] = cIdx->size[0];
          emxEnsureCapacity_real_T(sp, b_cIdx, i7, &rc_emlrtRTEI);
          loop_ub = cIdx->size[0];
          for (i7 = 0; i7 < loop_ub; i7++) {
            i8 = (int32_T)cIdx->data[i7];
            if ((i8 < 1) || (i8 > m)) {
              emlrtDynamicBoundsCheckR2012b(i8, 1, m, &dc_emlrtBCI, sp);
            }

            b_cIdx->data[i7] = cC->data[i8 - 1];
          }

          uZr = 1.0;

          /*  Matlab coder */
          uZc = 1.0;

          /*  Matlab coder */
          Step = 6;
          exitg2 = false;
          while ((!exitg2) && (b_cIdx->size[1] != 0)) {
            i7 = rIdx->size[0];
            if (1 > i7) {
              emlrtDynamicBoundsCheckR2012b(1, 1, i7, &fb_emlrtBCI, sp);
            }

            uZr = rIdx->data[0];
            uZc = b_cIdx->data[0];
            i7 = primeZ->size[0];
            i8 = (int32_T)rIdx->data[0];
            if ((i8 < 1) || (i8 > i7)) {
              emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &ec_emlrtBCI, sp);
            }

            primeZ->data[i8 - 1] = b_cIdx->data[0];
            i7 = starZ->size[0];
            i8 = (int32_T)rIdx->data[0];
            if ((i8 < 1) || (i8 > i7)) {
              emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &eb_emlrtBCI, sp);
            }

            st.site = &hc_emlrtRSI;
            toLogicalCheck(&st, starZ->data[(int32_T)rIdx->data[0] - 1]);
            if (!(starZ->data[(int32_T)rIdx->data[0] - 1] != 0.0)) {
              Step = 5;
              exitg2 = true;
            } else {
              i7 = coverRow->size[0];
              i8 = (int32_T)rIdx->data[0];
              if ((i8 < 1) || (i8 > i7)) {
                emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &fc_emlrtBCI, sp);
              }

              coverRow->data[i8 - 1] = true;
              i7 = coverColumn->size[1];
              i8 = (int32_T)starZ->data[(int32_T)rIdx->data[0] - 1];
              if ((i8 < 1) || (i8 > i7)) {
                emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &gc_emlrtBCI, sp);
              }

              coverColumn->data[i8 - 1] = false;
              bigM = rIdx->data[0];
              i7 = z->size[0];
              z->size[0] = rIdx->size[0];
              emxEnsureCapacity_boolean_T(sp, z, i7, &sc_emlrtRTEI);
              loop_ub = rIdx->size[0];
              for (i7 = 0; i7 < loop_ub; i7++) {
                z->data[i7] = (rIdx->data[i7] == bigM);
              }

              st.site = &ic_emlrtRSI;
              nullAssignment(&st, rIdx, z);

              /*  Matlab coder */
              st.site = &jc_emlrtRSI;
              b_nullAssignment(&st, b_cIdx, z);

              /*  Matlab coder */
              st.site = &kc_emlrtRSI;
              i7 = z->size[0];
              z->size[0] = coverRow->size[0];
              emxEnsureCapacity_boolean_T(&st, z, i7, &uc_emlrtRTEI);
              loop_ub = coverRow->size[0];
              for (i7 = 0; i7 < loop_ub; i7++) {
                z->data[i7] = !coverRow->data[i7];
              }

              b_st.site = &cb_emlrtRSI;
              n = z->size[0];
              c_st.site = &db_emlrtRSI;
              idx = 0;
              i7 = b_ii->size[0];
              b_ii->size[0] = z->size[0];
              emxEnsureCapacity_int32_T(&c_st, b_ii, i7, &e_emlrtRTEI);
              d_st.site = &eb_emlrtRSI;
              overflow = ((1 <= z->size[0]) && (z->size[0] > 2147483646));
              if (overflow) {
                e_st.site = &m_emlrtRSI;
                check_forloop_overflow_error(&e_st);
              }

              m = 0;
              exitg4 = false;
              while ((!exitg4) && (m <= n - 1)) {
                if (z->data[m]) {
                  idx++;
                  b_ii->data[idx - 1] = m + 1;
                  if (idx >= n) {
                    exitg4 = true;
                  } else {
                    m++;
                  }
                } else {
                  m++;
                }
              }

              if (idx > z->size[0]) {
                emlrtErrorWithMessageIdR2018a(&c_st, &ee_emlrtRTEI,
                  "Coder:builtins:AssertionFailed",
                  "Coder:builtins:AssertionFailed", 0);
              }

              if (z->size[0] == 1) {
                if (idx == 0) {
                  b_ii->size[0] = 0;
                }
              } else {
                if (1 > idx) {
                  i7 = 0;
                } else {
                  i7 = idx;
                }

                iv1[0] = 1;
                iv1[1] = i7;
                d_st.site = &fb_emlrtRSI;
                indexShapeCheck(&d_st, b_ii->size[0], iv1);
                i8 = b_ii->size[0];
                b_ii->size[0] = i7;
                emxEnsureCapacity_int32_T(&c_st, b_ii, i8, &g_emlrtRTEI);
              }

              i7 = cR->size[0];
              cR->size[0] = b_ii->size[0];
              emxEnsureCapacity_uint32_T(&st, cR, i7, &ad_emlrtRTEI);
              loop_ub = b_ii->size[0];
              for (i7 = 0; i7 < loop_ub; i7++) {
                cR->data[i7] = (uint32_T)b_ii->data[i7];
              }

              m = coverRow->size[0];
              for (idx = 0; idx < m; idx++) {
                if (!coverRow->data[idx]) {
                  i7 = dMat->size[0];
                  i8 = idx + 1;
                  if ((i8 < 1) || (i8 > i7)) {
                    emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &s_emlrtBCI, sp);
                  }
                }
              }

              i7 = dMat->size[1];
              i8 = (int32_T)starZ->data[(int32_T)uZr - 1];
              if ((i8 < 1) || (i8 > i7)) {
                emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &db_emlrtBCI, sp);
              }

              for (idx = 0; idx < m; idx++) {
                if (!coverRow->data[idx]) {
                  i7 = minR->size[0];
                  i8 = idx + 1;
                  if ((i8 < 1) || (i8 > i7)) {
                    emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &q_emlrtBCI, sp);
                  }
                }
              }

              n = m - 1;
              jj = 0;
              for (idx = 0; idx <= n; idx++) {
                if (!coverRow->data[idx]) {
                  jj++;
                }
              }

              i7 = r17->size[0];
              r17->size[0] = jj;
              emxEnsureCapacity_int32_T(sp, r17, i7, &nb_emlrtRTEI);
              jj = 0;
              for (idx = 0; idx <= n; idx++) {
                if (!coverRow->data[idx]) {
                  r17->data[jj] = idx + 1;
                  jj++;
                }
              }

              i7 = r17->size[0];
              i8 = r17->size[0];
              if (i7 != i8) {
                emlrtSizeEqCheck1DR2012b(i7, i8, &f_emlrtECI, sp);
              }

              n = m - 1;
              jj = 0;
              for (idx = 0; idx <= n; idx++) {
                if (!coverRow->data[idx]) {
                  jj++;
                }
              }

              i7 = r18->size[0];
              r18->size[0] = jj;
              emxEnsureCapacity_int32_T(sp, r18, i7, &nb_emlrtRTEI);
              jj = 0;
              for (idx = 0; idx <= n; idx++) {
                if (!coverRow->data[idx]) {
                  r18->data[jj] = idx + 1;
                  jj++;
                }
              }

              i7 = minC->size[1];
              i8 = (int32_T)starZ->data[(int32_T)uZr - 1];
              if ((i8 < 1) || (i8 > i7)) {
                emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &pc_emlrtBCI, sp);
              }

              bigM = minC->data[i8 - 1];
              jj = (int32_T)starZ->data[(int32_T)uZr - 1];
              i7 = z->size[0];
              z->size[0] = r18->size[0];
              emxEnsureCapacity_boolean_T(sp, z, i7, &dd_emlrtRTEI);
              loop_ub = r18->size[0];
              for (i7 = 0; i7 < loop_ub; i7++) {
                z->data[i7] = (dMat->data[(r18->data[i7] + dMat->size[0] * (jj -
                  1)) - 1] == minR->data[r18->data[i7] - 1] + bigM);
              }

              n = z->size[0] - 1;
              jj = 0;
              for (idx = 0; idx <= n; idx++) {
                if (z->data[idx]) {
                  jj++;
                }
              }

              i7 = r19->size[0];
              r19->size[0] = jj;
              emxEnsureCapacity_int32_T(sp, r19, i7, &nb_emlrtRTEI);
              jj = 0;
              for (idx = 0; idx <= n; idx++) {
                if (z->data[idx]) {
                  r19->data[jj] = idx + 1;
                  jj++;
                }
              }

              jj = cR->size[0];
              i7 = c_minC->size[0];
              c_minC->size[0] = r19->size[0];
              emxEnsureCapacity_real_T(sp, c_minC, i7, &gd_emlrtRTEI);
              loop_ub = r19->size[0];
              for (i7 = 0; i7 < loop_ub; i7++) {
                i8 = r19->data[i7];
                if ((i8 < 1) || (i8 > jj)) {
                  emlrtDynamicBoundsCheckR2012b(i8, 1, jj, &sc_emlrtBCI, sp);
                }

                c_minC->data[i7] = cR->data[i8 - 1];
              }

              i7 = rIdx->size[0];
              i8 = c_minC->size[0];
              i9 = rIdx->size[0];
              rIdx->size[0] = i7 + i8;
              emxEnsureCapacity_real_T(sp, rIdx, i9, &nb_emlrtRTEI);
              jj = cR->size[0];
              loop_ub = r19->size[0];
              for (i8 = 0; i8 < loop_ub; i8++) {
                i9 = r19->data[i8];
                if ((i9 < 1) || (i9 > jj)) {
                  emlrtDynamicBoundsCheckR2012b(i9, 1, jj, &sc_emlrtBCI, sp);
                }

                rIdx->data[i7 + i8] = cR->data[i9 - 1];
              }

              /*  Matlab coder */
              st.site = &lc_emlrtRSI;
              r25 = &st;
              bigM = d_sum(r25, z);
              if (bigM != (int32_T)muDoubleScalarFloor(bigM)) {
                emlrtIntegerCheckR2012b(bigM, &l_emlrtDCI, &st);
              }

              loop_ub = b_cIdx->size[1];
              i7 = b_minC->size[0] * b_minC->size[1];
              b_minC->size[0] = 1;
              b_minC->size[1] = loop_ub + (int32_T)bigM;
              emxEnsureCapacity_real_T(&st, b_minC, i7, &hd_emlrtRTEI);
              for (i7 = 0; i7 < loop_ub; i7++) {
                b_minC->data[i7] = b_cIdx->data[i7];
              }

              b_loop_ub = (int32_T)bigM;
              for (i7 = 0; i7 < b_loop_ub; i7++) {
                b_minC->data[i7 + loop_ub] = starZ->data[(int32_T)uZr - 1];
              }

              i7 = b_cIdx->size[0] * b_cIdx->size[1];
              b_cIdx->size[0] = 1;
              b_cIdx->size[1] = b_minC->size[1];
              emxEnsureCapacity_real_T(&st, b_cIdx, i7, &id_emlrtRTEI);
              loop_ub = b_minC->size[0] * b_minC->size[1];
              for (i7 = 0; i7 < loop_ub; i7++) {
                b_cIdx->data[i7] = b_minC->data[i7];
              }

              /*  Matlab coder */
              if (*emlrtBreakCheckR2012bFlagVar != 0) {
                emlrtBreakCheckR2012b(&st);
              }
            }
          }

          if (Step == 6) {
            /*  ************************************************************************* */
            /*  STEP 6: Add the minimum uncovered value to every element of each covered */
            /*          row, and subtract it from every element of each uncovered column. */
            /*          Return to Step 4 without altering any stars, primes, or covered lines. */
            /* ************************************************************************** */
            n = coverRow->size[0] - 1;
            jj = 0;
            for (idx = 0; idx <= n; idx++) {
              if (!coverRow->data[idx]) {
                jj++;
              }
            }

            i7 = r15->size[0];
            r15->size[0] = jj;
            emxEnsureCapacity_int32_T(sp, r15, i7, &nb_emlrtRTEI);
            jj = 0;
            for (idx = 0; idx <= n; idx++) {
              if (!coverRow->data[idx]) {
                r15->data[jj] = idx + 1;
                jj++;
              }
            }

            Step = coverColumn->size[1];
            n = Step - 1;
            jj = 0;
            for (idx = 0; idx <= n; idx++) {
              if (!coverColumn->data[idx]) {
                jj++;
              }
            }

            i7 = r16->size[0] * r16->size[1];
            r16->size[0] = 1;
            r16->size[1] = jj;
            emxEnsureCapacity_int32_T(sp, r16, i7, &nb_emlrtRTEI);
            jj = 0;
            for (idx = 0; idx <= n; idx++) {
              if (!coverColumn->data[idx]) {
                r16->data[jj] = idx + 1;
                jj++;
              }
            }

            jj = dMat->size[0];
            m = dMat->size[1];
            i7 = varargin_1->size[0] * varargin_1->size[1];
            varargin_1->size[0] = r15->size[0];
            varargin_1->size[1] = r16->size[1];
            emxEnsureCapacity_real_T(sp, varargin_1, i7, &vc_emlrtRTEI);
            loop_ub = r16->size[1];
            for (i7 = 0; i7 < loop_ub; i7++) {
              b_loop_ub = r15->size[0];
              for (i8 = 0; i8 < b_loop_ub; i8++) {
                i9 = r15->data[i8];
                if ((i9 < 1) || (i9 > jj)) {
                  emlrtDynamicBoundsCheckR2012b(i9, 1, jj, &hc_emlrtBCI, sp);
                }

                idx = r16->data[i7];
                if ((idx < 1) || (idx > m)) {
                  emlrtDynamicBoundsCheckR2012b(idx, 1, m, &ic_emlrtBCI, sp);
                }

                varargin_1->data[i8 + varargin_1->size[0] * i7] = dMat->data[(i9
                  + dMat->size[0] * (idx - 1)) - 1];
              }
            }

            jj = minR->size[0];
            i7 = b_minR->size[0];
            b_minR->size[0] = r15->size[0];
            emxEnsureCapacity_real_T(sp, b_minR, i7, &wc_emlrtRTEI);
            loop_ub = r15->size[0];
            for (i7 = 0; i7 < loop_ub; i7++) {
              i8 = r15->data[i7];
              if ((i8 < 1) || (i8 > jj)) {
                emlrtDynamicBoundsCheckR2012b(i8, 1, jj, &jc_emlrtBCI, sp);
              }

              b_minR->data[i7] = minR->data[i8 - 1];
            }

            i7 = b_minC->size[0] * b_minC->size[1];
            b_minC->size[0] = 1;
            b_minC->size[1] = r16->size[1];
            emxEnsureCapacity_real_T(sp, b_minC, i7, &yc_emlrtRTEI);
            jj = minC->size[1];
            loop_ub = r16->size[0] * r16->size[1];
            for (i7 = 0; i7 < loop_ub; i7++) {
              i8 = r16->data[i7];
              if ((i8 < 1) || (i8 > jj)) {
                emlrtDynamicBoundsCheckR2012b(i8, 1, jj, &kc_emlrtBCI, sp);
              }

              b_minC->data[i7] = minC->data[i8 - 1];
            }

            st.site = &mc_emlrtRSI;
            outerplus(&st, varargin_1, b_minR, b_minC, &bigM, rIdx, cIdx);
            for (idx = 0; idx < Step; idx++) {
              if (!coverColumn->data[idx]) {
                i7 = minC->size[1];
                i8 = idx + 1;
                if ((i8 < 1) || (i8 > i7)) {
                  emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &t_emlrtBCI, sp);
                }
              }
            }

            n = Step - 1;
            jj = 0;
            for (idx = 0; idx <= n; idx++) {
              if (!coverColumn->data[idx]) {
                jj++;
              }
            }

            i7 = r20->size[0] * r20->size[1];
            r20->size[0] = 1;
            r20->size[1] = jj;
            emxEnsureCapacity_int32_T(sp, r20, i7, &nb_emlrtRTEI);
            jj = 0;
            for (idx = 0; idx <= n; idx++) {
              if (!coverColumn->data[idx]) {
                r20->data[jj] = idx + 1;
                jj++;
              }
            }

            loop_ub = r20->size[0] * r20->size[1];
            i7 = minC->size[1];
            i8 = c_minC->size[0];
            c_minC->size[0] = loop_ub;
            emxEnsureCapacity_real_T(sp, c_minC, i8, &cd_emlrtRTEI);
            for (i8 = 0; i8 < loop_ub; i8++) {
              c_minC->data[i8] = minC->data[r20->data[i8] - 1] + bigM;
            }

            loop_ub = c_minC->size[0];
            for (i8 = 0; i8 < loop_ub; i8++) {
              i9 = r20->data[i8];
              if ((i9 < 1) || (i9 > i7)) {
                emlrtDynamicBoundsCheckR2012b(i9, 1, i7, &oc_emlrtBCI, sp);
              }

              minC->data[i9 - 1] = c_minC->data[i8];
            }

            n = coverRow->size[0];
            for (idx = 0; idx < n; idx++) {
              if (coverRow->data[idx]) {
                i7 = minR->size[0];
                i8 = idx + 1;
                if ((i8 < 1) || (i8 > i7)) {
                  emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &r_emlrtBCI, sp);
                }
              }
            }

            n = coverRow->size[0] - 1;
            jj = 0;
            for (idx = 0; idx <= n; idx++) {
              if (coverRow->data[idx]) {
                jj++;
              }
            }

            i7 = r21->size[0];
            r21->size[0] = jj;
            emxEnsureCapacity_int32_T(sp, r21, i7, &nb_emlrtRTEI);
            jj = 0;
            for (idx = 0; idx <= n; idx++) {
              if (coverRow->data[idx]) {
                r21->data[jj] = idx + 1;
                jj++;
              }
            }

            i7 = minR->size[0];
            i8 = c_minC->size[0];
            c_minC->size[0] = r21->size[0];
            emxEnsureCapacity_real_T(sp, c_minC, i8, &fd_emlrtRTEI);
            loop_ub = r21->size[0];
            for (i8 = 0; i8 < loop_ub; i8++) {
              c_minC->data[i8] = minR->data[r21->data[i8] - 1] - bigM;
            }

            loop_ub = c_minC->size[0];
            for (i8 = 0; i8 < loop_ub; i8++) {
              i9 = r21->data[i8];
              if ((i9 < 1) || (i9 > i7)) {
                emlrtDynamicBoundsCheckR2012b(i9, 1, i7, &rc_emlrtBCI, sp);
              }

              minR->data[i9 - 1] = c_minC->data[i8];
            }

            if (*emlrtBreakCheckR2012bFlagVar != 0) {
              emlrtBreakCheckR2012b(sp);
            }
          } else {
            exitg3 = 1;
          }
        } while (exitg3 == 0);

        /* ************************************************************************** */
        /*  STEP 5: */
        /*   Construct a series of alternating primed and starred zeros as */
        /*   follows: */
        /*   Let Z0 represent the uncovered primed zero found in Step 4. */
        /*   Let Z1 denote the starred zero in the column of Z0 (if any). */
        /*   Let Z2 denote the primed zero in the row of Z1 (there will always */
        /*   be one).  Continue until the series terminates at a primed zero */
        /*   that has no starred zero in its column.  Unstar each starred */
        /*   zero of the series, star each primed zero of the series, erase */
        /*   all primes and uncover every line in the matrix.  Return to Step 3. */
        /* ************************************************************************** */
        st.site = &nc_emlrtRSI;
        i7 = z->size[0];
        z->size[0] = starZ->size[0];
        emxEnsureCapacity_boolean_T(&st, z, i7, &tc_emlrtRTEI);
        loop_ub = starZ->size[0];
        for (i7 = 0; i7 < loop_ub; i7++) {
          z->data[i7] = (starZ->data[i7] == uZc);
        }

        b_st.site = &cb_emlrtRSI;
        c_st.site = &db_emlrtRSI;
        idx = 0;
        i7 = b_ii->size[0];
        b_ii->size[0] = 1;
        emxEnsureCapacity_int32_T(&c_st, b_ii, i7, &e_emlrtRTEI);
        d_st.site = &eb_emlrtRSI;
        overflow = ((1 <= z->size[0]) && (z->size[0] > 2147483646));
        if (overflow) {
          e_st.site = &m_emlrtRSI;
          check_forloop_overflow_error(&e_st);
        }

        m = 0;
        exitg2 = false;
        while ((!exitg2) && (m <= z->size[0] - 1)) {
          if (z->data[m]) {
            idx = 1;
            b_ii->data[0] = m + 1;
            exitg2 = true;
          } else {
            m++;
          }
        }

        if (idx == 0) {
          b_ii->size[0] = 0;
        }

        i7 = rIdx->size[0];
        rIdx->size[0] = b_ii->size[0];
        emxEnsureCapacity_real_T(&st, rIdx, i7, &xc_emlrtRTEI);
        loop_ub = b_ii->size[0];
        for (i7 = 0; i7 < loop_ub; i7++) {
          rIdx->data[i7] = b_ii->data[i7];
        }

        /*  Matlab coder */
        i7 = starZ->size[0];
        i8 = (int32_T)uZr;
        if ((i8 < 1) || (i8 > i7)) {
          emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &lc_emlrtBCI, sp);
        }

        starZ->data[i8 - 1] = uZc;
        while (rIdx->size[0] != 0) {
          /*  Matlab coder */
          /*  Matlab coder */
          i7 = starZ->size[0];
          i8 = (int32_T)rIdx->data[0];
          if ((i8 < 1) || (i8 > i7)) {
            emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &mc_emlrtBCI, sp);
          }

          starZ->data[i8 - 1] = 0.0;

          /*  Matlab coder */
          i7 = primeZ->size[0];
          i8 = (int32_T)rIdx->data[0];
          if ((i8 < 1) || (i8 > i7)) {
            emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &nc_emlrtBCI, sp);
          }

          uZc = primeZ->data[i8 - 1];

          /*  Matlab coder */
          uZr = rIdx->data[0];

          /*  Matlab coder */
          st.site = &oc_emlrtRSI;
          bigM = primeZ->data[(int32_T)rIdx->data[0] - 1];
          i7 = z->size[0];
          z->size[0] = starZ->size[0];
          emxEnsureCapacity_boolean_T(&st, z, i7, &bd_emlrtRTEI);
          loop_ub = starZ->size[0];
          for (i7 = 0; i7 < loop_ub; i7++) {
            z->data[i7] = (starZ->data[i7] == bigM);
          }

          b_st.site = &cb_emlrtRSI;
          c_st.site = &db_emlrtRSI;
          idx = 0;
          i7 = b_ii->size[0];
          b_ii->size[0] = 1;
          emxEnsureCapacity_int32_T(&c_st, b_ii, i7, &e_emlrtRTEI);
          d_st.site = &eb_emlrtRSI;
          overflow = ((1 <= z->size[0]) && (z->size[0] > 2147483646));
          if (overflow) {
            e_st.site = &m_emlrtRSI;
            check_forloop_overflow_error(&e_st);
          }

          m = 0;
          exitg2 = false;
          while ((!exitg2) && (m <= z->size[0] - 1)) {
            if (z->data[m]) {
              idx = 1;
              b_ii->data[0] = m + 1;
              exitg2 = true;
            } else {
              m++;
            }
          }

          if (idx == 0) {
            b_ii->size[0] = 0;
          }

          i7 = rIdx->size[0];
          rIdx->size[0] = b_ii->size[0];
          emxEnsureCapacity_real_T(&st, rIdx, i7, &ed_emlrtRTEI);
          loop_ub = b_ii->size[0];
          for (i7 = 0; i7 < loop_ub; i7++) {
            rIdx->data[i7] = b_ii->data[i7];
          }

          /*  Matlab coder */
          i7 = starZ->size[0];
          i8 = (int32_T)uZr;
          if ((i8 < 1) || (i8 > i7)) {
            emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &qc_emlrtBCI, sp);
          }

          starZ->data[i8 - 1] = uZc;
          if (*emlrtBreakCheckR2012bFlagVar != 0) {
            emlrtBreakCheckR2012b(sp);
          }
        }

        if (*emlrtBreakCheckR2012bFlagVar != 0) {
          emlrtBreakCheckR2012b(sp);
        }
      }
    } while (exitg1 == 0);

    emxFree_real_T(&c_minC);
    emxFree_int32_T(&c_ii);
    emxFree_real_T(&b_minC);
    emxFree_real_T(&b_minR);
    emxFree_boolean_T(&b_starZ);
    emxFree_boolean_T(&x);
    emxFree_int32_T(&r21);
    emxFree_int32_T(&r20);
    emxFree_int32_T(&r19);
    emxFree_int32_T(&r18);
    emxFree_int32_T(&r17);
    emxFree_int32_T(&r16);
    emxFree_int32_T(&r15);
    emxFree_int32_T(&r14);
    emxFree_int32_T(&r13);
    emxFree_int32_T(&r12);
    emxFree_int32_T(&r11);
    emxFree_int32_T(&r10);
    emxFree_int32_T(&r9);
    emxFree_real_T(&b_cIdx);
    emxFree_uint32_T(&cC);
    emxFree_uint32_T(&cR);
    emxFree_real_T(&cIdx);
    emxFree_real_T(&primeZ);
    emxFree_boolean_T(&coverRow);
    emxFree_boolean_T(&coverColumn);
    emxFree_real_T(&dMat);

    /*  Cost of assignment */
    st.site = &pc_emlrtRSI;
    b_st.site = &cb_emlrtRSI;
    n = validRow->size[0];
    c_st.site = &db_emlrtRSI;
    idx = 0;
    i7 = b_ii->size[0];
    b_ii->size[0] = validRow->size[0];
    emxEnsureCapacity_int32_T(&c_st, b_ii, i7, &e_emlrtRTEI);
    d_st.site = &eb_emlrtRSI;
    overflow = ((1 <= validRow->size[0]) && (validRow->size[0] > 2147483646));
    if (overflow) {
      e_st.site = &m_emlrtRSI;
      check_forloop_overflow_error(&e_st);
    }

    m = 0;
    exitg2 = false;
    while ((!exitg2) && (m <= n - 1)) {
      if (validRow->data[m]) {
        idx++;
        b_ii->data[idx - 1] = m + 1;
        if (idx >= n) {
          exitg2 = true;
        } else {
          m++;
        }
      } else {
        m++;
      }
    }

    if (idx > validRow->size[0]) {
      emlrtErrorWithMessageIdR2018a(&c_st, &ee_emlrtRTEI,
        "Coder:builtins:AssertionFailed", "Coder:builtins:AssertionFailed", 0);
    }

    if (validRow->size[0] == 1) {
      if (idx == 0) {
        b_ii->size[0] = 0;
      }
    } else {
      if (1 > idx) {
        i7 = 0;
      } else {
        i7 = idx;
      }

      iv1[0] = 1;
      iv1[1] = i7;
      d_st.site = &fb_emlrtRSI;
      indexShapeCheck(&d_st, b_ii->size[0], iv1);
      i8 = b_ii->size[0];
      b_ii->size[0] = i7;
      emxEnsureCapacity_int32_T(&c_st, b_ii, i8, &g_emlrtRTEI);
    }

    i7 = rIdx->size[0];
    rIdx->size[0] = b_ii->size[0];
    emxEnsureCapacity_real_T(&st, rIdx, i7, &cc_emlrtRTEI);
    loop_ub = b_ii->size[0];
    for (i7 = 0; i7 < loop_ub; i7++) {
      rIdx->data[i7] = b_ii->data[i7];
    }

    st.site = &qc_emlrtRSI;
    b_st.site = &cb_emlrtRSI;
    n = validCol->size[1];
    c_st.site = &db_emlrtRSI;
    idx = 0;
    i7 = d_ii->size[0] * d_ii->size[1];
    d_ii->size[0] = 1;
    d_ii->size[1] = validCol->size[1];
    emxEnsureCapacity_int32_T(&c_st, d_ii, i7, &e_emlrtRTEI);
    d_st.site = &eb_emlrtRSI;
    overflow = ((1 <= validCol->size[1]) && (validCol->size[1] > 2147483646));
    if (overflow) {
      e_st.site = &m_emlrtRSI;
      check_forloop_overflow_error(&e_st);
    }

    m = 0;
    exitg2 = false;
    while ((!exitg2) && (m <= n - 1)) {
      if (validCol->data[m]) {
        idx++;
        d_ii->data[idx - 1] = m + 1;
        if (idx >= n) {
          exitg2 = true;
        } else {
          m++;
        }
      } else {
        m++;
      }
    }

    if (idx > validCol->size[1]) {
      emlrtErrorWithMessageIdR2018a(&c_st, &ee_emlrtRTEI,
        "Coder:builtins:AssertionFailed", "Coder:builtins:AssertionFailed", 0);
    }

    if (validCol->size[1] == 1) {
      if (idx == 0) {
        d_ii->size[0] = 1;
        d_ii->size[1] = 0;
      }
    } else if (1 > idx) {
      d_ii->size[1] = 0;
    } else {
      i7 = d_ii->size[0] * d_ii->size[1];
      d_ii->size[1] = idx;
      emxEnsureCapacity_int32_T(&c_st, d_ii, i7, &g_emlrtRTEI);
    }

    i7 = minC->size[0] * minC->size[1];
    minC->size[0] = 1;
    minC->size[1] = d_ii->size[1];
    emxEnsureCapacity_real_T(&st, minC, i7, &fc_emlrtRTEI);
    loop_ub = d_ii->size[0] * d_ii->size[1];
    for (i7 = 0; i7 < loop_ub; i7++) {
      minC->data[i7] = d_ii->data[i7];
    }

    emxFree_int32_T(&d_ii);
    if (1.0 > nRows) {
      n = 0;
    } else {
      i7 = starZ->size[0];
      n = (int32_T)nRows;
      if ((n < 1) || (n > i7)) {
        emlrtDynamicBoundsCheckR2012b(n, 1, i7, &cb_emlrtBCI, sp);
      }
    }

    iv1[0] = 1;
    iv1[1] = n;
    st.site = &rc_emlrtRSI;
    indexShapeCheck(&st, starZ->size[0], iv1);
    i7 = starZ->size[0];
    starZ->size[0] = n;
    emxEnsureCapacity_real_T(sp, starZ, i7, &gc_emlrtRTEI);
    for (idx = 0; idx < n; idx++) {
      if (starZ->data[idx] <= nCols) {
        i7 = assignment->size[1];
        i8 = rIdx->size[0];
        i9 = idx + 1;
        if (i9 > i8) {
          emlrtDynamicBoundsCheckR2012b(i9, 1, i8, &rb_emlrtBCI, sp);
        }

        i8 = (int32_T)rIdx->data[i9 - 1];
        if ((i8 < 1) || (i8 > i7)) {
          emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &v_emlrtBCI, sp);
        }
      }
    }

    for (idx = 0; idx < n; idx++) {
      if (starZ->data[idx] <= nCols) {
        i7 = minC->size[1];
        i8 = idx + 1;
        if (i8 > n) {
          emlrtDynamicBoundsCheckR2012b(i8, 1, n, &sb_emlrtBCI, sp);
        }

        i8 = (int32_T)starZ->data[i8 - 1];
        if ((i8 < 1) || (i8 > i7)) {
          emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &u_emlrtBCI, sp);
        }
      }
    }

    for (idx = 0; idx < n; idx++) {
      if (starZ->data[idx] <= nCols) {
        assignment->data[(int32_T)rIdx->data[idx] - 1] = (uint32_T)minC->data
          [(int32_T)starZ->data[idx] - 1];
      }
    }

    emxFree_real_T(&rIdx);
    emxFree_real_T(&starZ);
    emxFree_real_T(&minC);
    n = assignment->size[1] - 1;
    jj = 0;
    for (idx = 0; idx <= n; idx++) {
      if ((int32_T)(uint32_T)assignment->data[idx] > 0) {
        jj++;
      }
    }

    emxInit_uint32_T(sp, &pass, 2, &pd_emlrtRTEI, true);
    i7 = pass->size[0] * pass->size[1];
    pass->size[0] = 1;
    pass->size[1] = jj;
    emxEnsureCapacity_uint32_T(sp, pass, i7, &nb_emlrtRTEI);
    jj = 0;
    for (idx = 0; idx <= n; idx++) {
      if ((int32_T)(uint32_T)assignment->data[idx] > 0) {
        i7 = assignment->size[1];
        i8 = idx + 1;
        if ((i8 < 1) || (i8 > i7)) {
          emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &tb_emlrtBCI, sp);
        }

        pass->data[jj] = (uint32_T)assignment->data[i8 - 1];
        jj++;
      }
    }

    n = assignment->size[1] - 1;
    jj = 0;
    for (idx = 0; idx <= n; idx++) {
      if ((int32_T)(uint32_T)assignment->data[idx] > 0) {
        jj++;
      }
    }

    emxInit_int32_T(sp, &r22, 2, &nb_emlrtRTEI, true);
    i7 = r22->size[0] * r22->size[1];
    r22->size[0] = 1;
    r22->size[1] = jj;
    emxEnsureCapacity_int32_T(sp, r22, i7, &nb_emlrtRTEI);
    jj = 0;
    for (idx = 0; idx <= n; idx++) {
      if ((int32_T)(uint32_T)assignment->data[idx] > 0) {
        r22->data[jj] = idx + 1;
        jj++;
      }
    }

    i7 = r3->size[0];
    i8 = r3->size[1];
    i9 = zP->size[0] * zP->size[1];
    zP->size[0] = r3->size[0];
    zP->size[1] = r3->size[1];
    emxEnsureCapacity_boolean_T(sp, zP, i9, &lb_emlrtRTEI);
    loop_ub = r3->size[0] * r3->size[1];
    for (i9 = 0; i9 < loop_ub; i9++) {
      zP->data[i9] = (r3->data[i9] && r4->data[i9]);
    }

    i9 = r3->size[0] * r3->size[1];
    r3->size[0] = r22->size[1];
    r3->size[1] = r22->size[1];
    emxEnsureCapacity_boolean_T(sp, r3, i9, &jc_emlrtRTEI);
    loop_ub = r22->size[1];
    for (i9 = 0; i9 < loop_ub; i9++) {
      b_loop_ub = r22->size[1];
      for (idx = 0; idx < b_loop_ub; idx++) {
        jj = r22->data[idx];
        if ((jj < 1) || (jj > i7)) {
          emlrtDynamicBoundsCheckR2012b(jj, 1, i7, &ub_emlrtBCI, sp);
        }

        m = (int32_T)(uint32_T)assignment->data[r22->data[i9] - 1];
        if ((m < 1) || (m > i8)) {
          emlrtDynamicBoundsCheckR2012b(m, 1, i8, &vb_emlrtBCI, sp);
        }

        r3->data[idx + r3->size[0] * i9] = zP->data[(jj + zP->size[0] * (m - 1))
          - 1];
      }
    }

    emxFree_int32_T(&r22);
    emxFree_boolean_T(&zP);
    st.site = &sc_emlrtRSI;
    diag(&st, r3, z);
    i7 = z->size[0];
    emxEnsureCapacity_boolean_T(sp, z, i7, &kc_emlrtRTEI);
    loop_ub = z->size[0];
    for (i7 = 0; i7 < loop_ub; i7++) {
      z->data[i7] = !z->data[i7];
    }

    n = z->size[0] - 1;
    jj = 0;
    for (idx = 0; idx <= n; idx++) {
      if (z->data[idx]) {
        jj++;
      }
    }

    emxInit_int32_T(sp, &r23, 1, &nb_emlrtRTEI, true);
    i7 = r23->size[0];
    r23->size[0] = jj;
    emxEnsureCapacity_int32_T(sp, r23, i7, &nb_emlrtRTEI);
    jj = 0;
    for (idx = 0; idx <= n; idx++) {
      if (z->data[idx]) {
        r23->data[jj] = idx + 1;
        jj++;
      }
    }

    emxFree_boolean_T(&z);
    n = assignment->size[1];
    jj = 0;
    for (idx = 0; idx < n; idx++) {
      if ((int32_T)(uint32_T)assignment->data[idx] > 0) {
        jj++;
      }
    }

    loop_ub = r23->size[0];
    for (i7 = 0; i7 < loop_ub; i7++) {
      i8 = r23->data[i7];
      if ((i8 < 1) || (i8 > jj)) {
        emlrtDynamicBoundsCheckR2012b(i8, 1, jj, &wb_emlrtBCI, sp);
      }

      pass->data[i8 - 1] = 0U;
    }

    emxFree_int32_T(&r23);
    n = assignment->size[1];
    jj = 0;
    for (idx = 0; idx < n; idx++) {
      if ((int32_T)(uint32_T)assignment->data[idx] > 0) {
        jj++;
      }
    }

    i7 = pass->size[1];
    if (jj != i7) {
      emlrtSubAssignSizeCheck1dR2017a(jj, i7, &e_emlrtECI, sp);
    }

    n = assignment->size[1];
    jj = 0;
    for (idx = 0; idx < n; idx++) {
      if ((int32_T)(uint32_T)assignment->data[idx] > 0) {
        i7 = assignment->size[1];
        i8 = idx + 1;
        if ((i8 < 1) || (i8 > i7)) {
          emlrtDynamicBoundsCheckR2012b(i8, 1, i7, &xb_emlrtBCI, sp);
        }

        assignment->data[i8 - 1] = pass->data[jj];
        jj++;
      }
    }

    emxFree_uint32_T(&pass);
    n = assignment->size[1] - 1;
    jj = 0;
    for (idx = 0; idx <= n; idx++) {
      if ((int32_T)(uint32_T)assignment->data[idx] > 0) {
        jj++;
      }
    }

    emxInit_int32_T(sp, &r24, 2, &nb_emlrtRTEI, true);
    i7 = r24->size[0] * r24->size[1];
    r24->size[0] = 1;
    r24->size[1] = jj;
    emxEnsureCapacity_int32_T(sp, r24, i7, &nb_emlrtRTEI);
    jj = 0;
    for (idx = 0; idx <= n; idx++) {
      if ((int32_T)(uint32_T)assignment->data[idx] > 0) {
        r24->data[jj] = idx + 1;
        jj++;
      }
    }

    jj = costMat->size[0];
    m = assignment->size[1];
    n = costMat->size[1];
    i7 = varargin_1->size[0] * varargin_1->size[1];
    varargin_1->size[0] = r24->size[1];
    varargin_1->size[1] = r24->size[1];
    emxEnsureCapacity_real_T(sp, varargin_1, i7, &mc_emlrtRTEI);
    loop_ub = r24->size[1];
    for (i7 = 0; i7 < loop_ub; i7++) {
      b_loop_ub = r24->size[1];
      for (i8 = 0; i8 < b_loop_ub; i8++) {
        i9 = r24->data[i8];
        if ((i9 < 1) || (i9 > jj)) {
          emlrtDynamicBoundsCheckR2012b(i9, 1, jj, &yb_emlrtBCI, sp);
        }

        idx = r24->data[i7];
        if ((idx < 1) || (idx > m)) {
          emlrtDynamicBoundsCheckR2012b(idx, 1, m, &bc_emlrtBCI, sp);
        }

        idx = (int32_T)(uint32_T)assignment->data[idx - 1];
        if ((idx < 1) || (idx > n)) {
          emlrtDynamicBoundsCheckR2012b(idx, 1, n, &ac_emlrtBCI, sp);
        }

        varargin_1->data[i8 + varargin_1->size[0] * i7] = costMat->data[(i9 +
          costMat->size[0] * (idx - 1)) - 1];
      }
    }

    emxFree_int32_T(&r24);
    st.site = &tc_emlrtRSI;
    *cost = trace(&st, varargin_1);
    emxFree_real_T(&varargin_1);
  }

  emxFree_int32_T(&b_ii);
  emxFree_int32_T(&j);
  emxFree_boolean_T(&r4);
  emxFree_boolean_T(&r3);
  emxFree_real_T(&minR);
  emxFree_boolean_T(&validRow);
  emxFree_boolean_T(&validCol);
  emlrtHeapReferenceStackLeaveFcnR2012b(sp);
}

/* End of code generation (munkres.cpp) */
