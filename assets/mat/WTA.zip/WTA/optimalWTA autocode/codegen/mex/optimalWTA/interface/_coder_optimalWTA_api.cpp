/*
 * _coder_optimalWTA_api.cpp
 *
 * Code generation for function '_coder_optimalWTA_api'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "optimalWTA.h"
#include "_coder_optimalWTA_api.h"
#include "optimalWTA_emxutil.h"
#include "optimalWTA_data.h"

/* Variable Definitions */
static emlrtRTEInfo be_emlrtRTEI = { 1,/* lineNo */
  1,                                   /* colNo */
  "_coder_optimalWTA_api",             /* fName */
  ""                                   /* pName */
};

/* Function Declarations */
static void b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, emxArray_real_T *y);
static const mxArray *b_emlrt_marshallOut(const real_T u);
static void c_emlrt_marshallIn(const emlrtStack *sp, const mxArray *reachMat,
  const char_T *identifier, emxArray_real_T *y);
static void d_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, emxArray_real_T *y);
static real_T e_emlrt_marshallIn(const emlrtStack *sp, const mxArray *maxKV,
  const char_T *identifier);
static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *lethality,
  const char_T *identifier, emxArray_real_T *y);
static const mxArray *emlrt_marshallOut(const emxArray_real_T *u);
static real_T f_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId);
static void g_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, emxArray_real_T *ret);
static void h_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, emxArray_real_T *ret);
static real_T i_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId);

/* Function Definitions */
static void b_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, emxArray_real_T *y)
{
  g_emlrt_marshallIn(sp, emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static const mxArray *b_emlrt_marshallOut(const real_T u)
{
  const mxArray *y;
  const mxArray *m1;
  y = NULL;
  m1 = emlrtCreateDoubleScalar(u);
  emlrtAssign(&y, m1);
  return y;
}

static void c_emlrt_marshallIn(const emlrtStack *sp, const mxArray *reachMat,
  const char_T *identifier, emxArray_real_T *y)
{
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = const_cast<const char *>(identifier);
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  d_emlrt_marshallIn(sp, emlrtAlias(reachMat), &thisId, y);
  emlrtDestroyArray(&reachMat);
}

static void d_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId, emxArray_real_T *y)
{
  h_emlrt_marshallIn(sp, emlrtAlias(u), parentId, y);
  emlrtDestroyArray(&u);
}

static real_T e_emlrt_marshallIn(const emlrtStack *sp, const mxArray *maxKV,
  const char_T *identifier)
{
  real_T y;
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = const_cast<const char *>(identifier);
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  y = f_emlrt_marshallIn(sp, emlrtAlias(maxKV), &thisId);
  emlrtDestroyArray(&maxKV);
  return y;
}

static void emlrt_marshallIn(const emlrtStack *sp, const mxArray *lethality,
  const char_T *identifier, emxArray_real_T *y)
{
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = const_cast<const char *>(identifier);
  thisId.fParent = NULL;
  thisId.bParentIsCell = false;
  b_emlrt_marshallIn(sp, emlrtAlias(lethality), &thisId, y);
  emlrtDestroyArray(&lethality);
}

static const mxArray *emlrt_marshallOut(const emxArray_real_T *u)
{
  const mxArray *y;
  const mxArray *m0;
  static const int32_T iv3[2] = { 0, 0 };

  y = NULL;
  m0 = emlrtCreateNumericArray(2, iv3, mxDOUBLE_CLASS, mxREAL);
  emlrtMxSetData((mxArray *)m0, &u->data[0]);
  emlrtSetDimensions((mxArray *)m0, u->size, 2);
  emlrtAssign(&y, m0);
  return y;
}

static real_T f_emlrt_marshallIn(const emlrtStack *sp, const mxArray *u, const
  emlrtMsgIdentifier *parentId)
{
  real_T y;
  y = i_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static void g_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, emxArray_real_T *ret)
{
  static const int32_T dims[2] = { 1, -1 };

  const boolean_T bv0[2] = { false, true };

  int32_T iv4[2];
  int32_T i21;
  emlrtCheckVsBuiltInR2012b(sp, (const emlrtMsgIdentifier *)msgId, src, "double",
    false, 2U, *(int32_T (*)[2])&dims[0], (boolean_T *)&bv0[0], iv4);
  ret->allocatedSize = iv4[0] * iv4[1];
  i21 = ret->size[0] * ret->size[1];
  ret->size[0] = iv4[0];
  ret->size[1] = iv4[1];
  emxEnsureCapacity_real_T(sp, ret, i21, (emlrtRTEInfo *)NULL);
  ret->data = (real_T *)emlrtMxGetData(src);
  ret->canFreeData = false;
  ret->canFreeData = false;
  emlrtDestroyArray(&src);
}

static void h_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId, emxArray_real_T *ret)
{
  static const int32_T dims[2] = { -1, -1 };

  const boolean_T bv1[2] = { true, true };

  int32_T iv5[2];
  int32_T i22;
  emlrtCheckVsBuiltInR2012b(sp, (const emlrtMsgIdentifier *)msgId, src, "double",
    false, 2U, *(int32_T (*)[2])&dims[0], (boolean_T *)&bv1[0], iv5);
  ret->allocatedSize = iv5[0] * iv5[1];
  i22 = ret->size[0] * ret->size[1];
  ret->size[0] = iv5[0];
  ret->size[1] = iv5[1];
  emxEnsureCapacity_real_T(sp, ret, i22, (emlrtRTEInfo *)NULL);
  ret->data = (real_T *)emlrtMxGetData(src);
  ret->canFreeData = false;
  ret->canFreeData = false;
  emlrtDestroyArray(&src);
}

static real_T i_emlrt_marshallIn(const emlrtStack *sp, const mxArray *src, const
  emlrtMsgIdentifier *msgId)
{
  real_T ret;
  static const int32_T dims = 0;
  emlrtCheckBuiltInR2012b(sp, (const emlrtMsgIdentifier *)msgId, src, "double",
    false, 0U, (int32_T *)&dims);
  ret = *(real_T *)emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

void optimalWTA_api(const mxArray * const prhs[4], int32_T nlhs, const mxArray
                    *plhs[3])
{
  emxArray_real_T *lethality;
  emxArray_real_T *reachMat;
  emxArray_real_T *pKill;
  emxArray_real_T *fAssign;
  real_T maxKV;
  real_T fLeak;
  real_T totalReach;
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  st.tls = emlrtRootTLSGlobal;
  emlrtHeapReferenceStackEnterFcnR2012b(&st);
  emxInit_real_T(&st, &lethality, 2, &be_emlrtRTEI, true);
  emxInit_real_T(&st, &reachMat, 2, &be_emlrtRTEI, true);
  emxInit_real_T(&st, &pKill, 2, &be_emlrtRTEI, true);
  emxInit_real_T(&st, &fAssign, 2, &be_emlrtRTEI, true);

  /* Marshall function inputs */
  lethality->canFreeData = false;
  emlrt_marshallIn(&st, emlrtAlias(prhs[0]), "lethality", lethality);
  reachMat->canFreeData = false;
  c_emlrt_marshallIn(&st, emlrtAlias(prhs[1]), "reachMat", reachMat);
  pKill->canFreeData = false;
  emlrt_marshallIn(&st, emlrtAlias(prhs[2]), "pKill", pKill);
  maxKV = e_emlrt_marshallIn(&st, emlrtAliasP(prhs[3]), "maxKV");

  /* Invoke the target function */
  optimalWTA(&st, lethality, reachMat, pKill, maxKV, fAssign, &fLeak,
             &totalReach);

  /* Marshall function outputs */
  fAssign->canFreeData = false;
  plhs[0] = emlrt_marshallOut(fAssign);
  emxFree_real_T(&fAssign);
  emxFree_real_T(&pKill);
  emxFree_real_T(&reachMat);
  emxFree_real_T(&lethality);
  if (nlhs > 1) {
    plhs[1] = b_emlrt_marshallOut(fLeak);
  }

  if (nlhs > 2) {
    plhs[2] = b_emlrt_marshallOut(totalReach);
  }

  emlrtHeapReferenceStackLeaveFcnR2012b(&st);
}

/* End of code generation (_coder_optimalWTA_api.cpp) */
