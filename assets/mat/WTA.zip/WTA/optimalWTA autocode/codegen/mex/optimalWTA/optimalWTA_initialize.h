/*
 * optimalWTA_initialize.h
 *
 * Code generation for function 'optimalWTA_initialize'
 *
 */

#ifndef OPTIMALWTA_INITIALIZE_H
#define OPTIMALWTA_INITIALIZE_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "optimalWTA_types.h"

/* Function Declarations */
extern void optimalWTA_initialize();

#endif

/* End of code generation (optimalWTA_initialize.h) */
