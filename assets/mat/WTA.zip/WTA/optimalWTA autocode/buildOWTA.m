clear; clc;

%tgt = 'mex';
tgt = 'exe';
cfg = coder.config(tgt);
cfg.TargetLang = 'C++';
cfg.GenerateReport = true;
cfg.LaunchReport = true;
cfg.RowMajor = true;
if strcmp(tgt, 'lib')
    cfg.GenCodeOnly = true;
end

codegen -config cfg -g -args {coder.typeof(0, [1, Inf], [0, 1]), coder.typeof(0, [inf, inf], [1, 1]), coder.typeof(0, [1, inf], [0, 1]), coder.typeof(10, [], 0)} optimalWTA.m
%-args {coder.typeof(0, [1, Inf], [0, 1]), coder.typeof(0, [], [1, 1]), coder.typeof(0, [], [1, 1]), coder.typeof(10, [], 0)}