/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *jvcbench_types.h
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/
/*
 * File: jvcbench_types.h
 *
 * Real-Time Workshop code generated for Simulink model jvcbench.
 *
 * Model version                        : 1.281
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Jan 29 15:26:00 2009
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Jan 29 15:26:00 2009
 */
#ifndef RTW_HEADER_jvcbench_types_h_
#define RTW_HEADER_jvcbench_types_h_
#include "rtwtypes.h"
#endif                                 /* RTW_HEADER_jvcbench_types_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
