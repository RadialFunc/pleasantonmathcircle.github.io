/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *jvcbench.h
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/
/*
 * File: jvcbench.h
 *
 * Real-Time Workshop code generated for Simulink model jvcbench.
 *
 * Model version                        : 1.281
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Jan 29 15:26:00 2009
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Jan 29 15:26:00 2009
 */
#ifndef RTW_HEADER_jvcbench_h_
#define RTW_HEADER_jvcbench_h_
#ifndef jvcbench_COMMON_INCLUDES_
# define jvcbench_COMMON_INCLUDES_
#include <stdlib.h>
#include <stddef.h>
#include <math.h>
#include "rtwtypes.h"
#include "rtw_shared_utils.h"
#include "rt_nonfinite.h"
#endif                                 /* jvcbench_COMMON_INCLUDES_ */

#include "jvcbench_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((void*) 0)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((void) 0)
#endif

/* Block signals for system '<Root>/JVCBENCH' */
typedef struct {
  real_T x[1000];                      /* '<Root>/JVCBENCH' */
  real_T y[1000];                      /* '<Root>/JVCBENCH' */
} rtB_JVCBENCH_jvcbench;

/* Block states (auto storage) for system '<Root>/JVCBENCH' */
typedef struct {
  uint32_T twister_state[625];         /* '<Root>/JVCBENCH' */
  uint32_T v4_state;                   /* '<Root>/JVCBENCH' */
  uint8_T method;                      /* '<Root>/JVCBENCH' */
  boolean_T twister_state_not_empty;   /* '<Root>/JVCBENCH' */
} rtDW_JVCBENCH_jvcbench;

/* Block signals (auto storage) */
typedef struct {
  rtB_JVCBENCH_jvcbench sf_JVCBENCH;   /* '<Root>/JVCBENCH' */
} BlockIO_jvcbench;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  rtDW_JVCBENCH_jvcbench sf_JVCBENCH;  /* '<Root>/JVCBENCH' */
} D_Work_jvcbench;

/* External inputs (root inport signals with auto storage) */
typedef struct {
  real_T jvcbench_m;                   /* '<Root>/jvcbench_m' */
  real_T jvcbench_n;                   /* '<Root>/jvcbench_n' */
  real_T jvcbench_seed;                /* '<Root>/jvcbench_seed' */
  real_T jvcbench_level;               /* '<Root>/jvcbench_level' */
  real_T jvcbench_iterations;          /* '<Root>/jvcbench_iterations' */
} ExternalInputs_jvcbench;

/* External outputs (root outports fed by signals with auto storage) */
typedef struct {
  real_T jvcbench_x[1000];             /* '<Root>/jvcbench_x' */
  real_T jvcbench_y[1000];             /* '<Root>/jvcbench_y' */
} ExternalOutputs_jvcbench;

/* Model entry point functions */
extern void jvcbench_initialize(D_Work_jvcbench *jvcbench_DWork,
  ExternalInputs_jvcbench *jvcbench_U, ExternalOutputs_jvcbench *jvcbench_Y);
extern void jvcbench_step(BlockIO_jvcbench *jvcbench_B, D_Work_jvcbench
  *jvcbench_DWork, ExternalInputs_jvcbench *jvcbench_U, ExternalOutputs_jvcbench
  *jvcbench_Y);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : jvcbench
 * '<S1>'   : jvcbench/JVCBENCH
 * '<S2>'   : jvcbench/Model Info
 */
#endif                                 /* RTW_HEADER_jvcbench_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
