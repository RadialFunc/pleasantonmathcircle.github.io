/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *jvcbench.c
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/
/*
 * File: jvcbench.c
 *
 * Real-Time Workshop code generated for Simulink model jvcbench.
 *
 * Model version                        : 1.281
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Jan 29 15:26:00 2009
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Jan 29 15:26:00 2009
 */
#include "jvcbench.h"
#include "jvcbench_private.h"

static void jvcbench_c2_jvcbench(real_T rtu_0, real_T rtu_1, real_T rtu_2,
  real_T rtu_3, real_T rtu_4, rtB_JVCBENCH_jvcbench *localB,
  rtDW_JVCBENCH_jvcbench *localDW);
static void jvcbench_rand(real_T eml_varargin_2, real_T rtu_0, real_T rtu_1,
  real_T rtu_2, real_T rtu_3, real_T rtu_4, rtB_JVCBENCH_jvcbench *localB,
  rtDW_JVCBENCH_jvcbench *localDW);
static real_T jvcbench_rand_g(real_T rtu_0, real_T rtu_1, real_T rtu_2, real_T
  rtu_3, real_T rtu_4, rtB_JVCBENCH_jvcbench *localB, rtDW_JVCBENCH_jvcbench
  *localDW);
static void jvcbench_refp717_linprog_lap_jvc(real_T eml_m, real_T eml_n, real_T
  eml_ax[1001], real_T eml_ay[1001000], real_T eml_ac[1001000], real_T eml_x
  [1000], real_T eml_y[1000], real_T eml_v[1000]);

/* Functions for block: '<Root>/JVCBENCH' */
static void jvcbench_c2_jvcbench(real_T rtu_0, real_T rtu_1, real_T rtu_2,
  real_T rtu_3, real_T rtu_4, rtB_JVCBENCH_jvcbench *localB,
  rtDW_JVCBENCH_jvcbench *localDW)
{
  int32_T eml_i1;
  int32_T eml_i2;
  static real_T eml_I[1000000];
  real_T eml_ii;
  real_T eml_dv0[2];
  static real_T eml_R[1000000];
  real_T eml_jj;
  real_T eml_x;
  real_T eml_ci[1001];
  static real_T eml_cc[1001000];
  static real_T eml_cj[1001000];
  real_T eml_v[1000];

  /* Embedded MATLAB Function 'JVCBENCH': '<S1>:1' */
  /*  ---- constants ----  */
  /* '<S1>:1:7' */
  for (eml_i1 = 0; eml_i1 < 1000; eml_i1++) {
    localB->x[eml_i1] = 0.0;

    /* '<S1>:1:8' */
    localB->y[eml_i1] = 0.0;
  }

  /*  ---- problem generation ---- */
  /* '<S1>:1:11' */
  jvcbench_rand(rtu_2, rtu_0, rtu_1, rtu_2, rtu_3, rtu_4, localB, localDW);

  /* '<S1>:1:13' */
  for (eml_i1 = 0; eml_i1 < 1000; eml_i1++) {
    for (eml_i2 = 0; eml_i2 < 1000; eml_i2++) {
      eml_I[eml_i2 + 1000 * eml_i1] = rtInf;
    }
  }

  for (eml_ii = 1.0; eml_ii <= rtu_0; eml_ii++) {
    /* '<S1>:1:14' */
    /* '<S1>:1:15' */
    eml_dv0[0] = -log(rtu_3);
    eml_dv0[1] = 1.7976931348623157E+308;
    eml_I[((int32_T)eml_ii - 1) + 1000 * ((int32_T)eml_ii - 1)] =
      baaihlfccjmohlno_min(eml_dv0);
  }

  /* '<S1>:1:18' */
  for (eml_i1 = 0; eml_i1 < 1000; eml_i1++) {
    for (eml_i2 = 0; eml_i2 < 1000; eml_i2++) {
      eml_R[eml_i2 + 1000 * eml_i1] = rtInf;
    }
  }

  for (eml_ii = 1.0; eml_ii <= rtu_0; eml_ii++) {
    /* '<S1>:1:19' */
    for (eml_jj = 1.0; eml_jj <= rtu_1; eml_jj++) {
      /* '<S1>:1:20' */
      /* '<S1>:1:21' */
      eml_x = jvcbench_rand_g(rtu_0, rtu_1, rtu_2, rtu_3, rtu_4, localB, localDW);
      eml_R[((int32_T)eml_ii - 1) + 1000 * ((int32_T)eml_jj - 1)] = -log(eml_x);
      if (eml_R[((int32_T)eml_ii - 1) + 1000 * ((int32_T)eml_jj - 1)] >= -log
          (rtu_3)) {
        /* '<S1>:1:22' */
        /* '<S1>:1:23' */
        eml_R[((int32_T)eml_ii - 1) + 1000 * ((int32_T)eml_jj - 1)] = rtInf;
      }
    }
  }

  /*  ---- problem formulation ---- */
  /* '<S1>:1:29' */
  for (eml_i1 = 0; eml_i1 < 1001; eml_i1++) {
    eml_ci[eml_i1] = 0.0;
  }

  /* '<S1>:1:30' */
  for (eml_i1 = 0; eml_i1 < 1001000; eml_i1++) {
    eml_cc[eml_i1] = 0.0;

    /* '<S1>:1:31' */
    eml_cj[eml_i1] = 0.0;
  }

  /* '<S1>:1:33' */
  eml_jj = 1.0;
  for (eml_x = 1.0; eml_x <= rtu_0; eml_x++) {
    /* '<S1>:1:34' */
    /* '<S1>:1:35' */
    eml_ci[(int32_T)eml_x - 1] = eml_jj;
    for (eml_ii = 1.0; eml_ii <= rtu_1; eml_ii++) {
      /* '<S1>:1:37' */
      if (eml_R[((int32_T)eml_x - 1) + 1000 * ((int32_T)eml_ii - 1)] < rtInf) {
        /* '<S1>:1:38' */
        /* '<S1>:1:39' */
        eml_cj[(int32_T)eml_jj - 1] = eml_ii;

        /* '<S1>:1:40' */
        eml_cc[(int32_T)eml_jj - 1] = eml_R[((int32_T)eml_x - 1) + 1000 *
          ((int32_T)eml_ii - 1)];

        /* '<S1>:1:41' */
        eml_jj++;
      }
    }

    for (eml_ii = 1.0; eml_ii <= rtu_0; eml_ii++) {
      /* '<S1>:1:45' */
      if (eml_I[((int32_T)eml_x - 1) + 1000 * ((int32_T)eml_ii - 1)] < rtInf) {
        /* '<S1>:1:46' */
        /* '<S1>:1:47' */
        eml_cj[(int32_T)eml_jj - 1] = eml_ii;

        /* '<S1>:1:48' */
        eml_cc[(int32_T)eml_jj - 1] = eml_I[((int32_T)eml_x - 1) + 1000 *
          ((int32_T)eml_ii - 1)];

        /* '<S1>:1:49' */
        eml_jj++;
      }
    }
  }

  /* '<S1>:1:54' */
  eml_ci[(int32_T)(rtu_0 + 1.0) - 1] = eml_jj;
  for (eml_ii = 1.0; eml_ii <= rtu_4; eml_ii++) {
    /* '<S1>:1:56' */
    /*  ---- problem solution ---- */
    /* '<S1>:1:61' */
    for (eml_i1 = 0; eml_i1 < 1000; eml_i1++) {
      localB->x[eml_i1] = 0.0;
      localB->y[eml_i1] = 0.0;
      eml_v[eml_i1] = 0.0;
    }

    jvcbench_refp717_linprog_lap_jvc(rtu_0, rtu_1 + rtu_0, eml_ci, eml_cj,
      eml_cc, localB->x, localB->y, eml_v);

    /* '<S1>:1:61' */
  }

  /*  JVCBENCH */
}

static void jvcbench_rand(real_T eml_varargin_2, real_T rtu_0, real_T rtu_1,
  real_T rtu_2, real_T rtu_3, real_T rtu_4, rtB_JVCBENCH_jvcbench *localB,
  rtDW_JVCBENCH_jvcbench *localDW)
{
  real_T eml_d0;
  uint32_T eml_u0;
  uint32_T eml_r;
  int32_T eml_mti;
  localDW->twister_state_not_empty = true;
  eml_d0 = eml_varargin_2;
  if (eml_d0 < 4.294967296E+009) {
    if (eml_d0 >= 0.0) {
      eml_u0 = (uint32_T)eml_d0;
    } else {
      eml_u0 = 0U;
    }
  } else {
    eml_u0 = MAX_uint32_T;
  }

  eml_r = eml_u0;
  localDW->twister_state[0] = eml_r;
  for (eml_mti = 2; eml_mti < 625; eml_mti++) {
    eml_r = (eml_r ^ eml_r >> 30U) * 1812433253U + (uint32_T)(eml_mti - 1);
    localDW->twister_state[eml_mti - 1] = eml_r;
  }

  localDW->twister_state[624] = 624U;
  localDW->method = 2U;
}

static real_T jvcbench_rand_g(real_T rtu_0, real_T rtu_1, real_T rtu_2, real_T
  rtu_3, real_T rtu_4, rtB_JVCBENCH_jvcbench *localB, rtDW_JVCBENCH_jvcbench
  *localDW)
{
  real_T eml_r;
  int32_T eml_mti;
  uint32_T eml_r_0;
  uint32_T eml_u[2];
  int32_T eml_j;
  uint32_T eml_y;
  if (localDW->method == 2) {
    if (!localDW->twister_state_not_empty) {
      for (eml_mti = 0; eml_mti < 625; eml_mti++) {
        localDW->twister_state[eml_mti] = 0U;
      }

      eml_r_0 = 5489U;
      localDW->twister_state[0] = 5489U;
      for (eml_mti = 2; eml_mti < 625; eml_mti++) {
        eml_r_0 = (eml_r_0 ^ eml_r_0 >> 30U) * 1812433253U + (uint32_T)(eml_mti
          - 1);
        localDW->twister_state[eml_mti - 1] = eml_r_0;
      }

      localDW->twister_state[624] = 624U;
      localDW->twister_state_not_empty = true;
    }

    do {
      for (eml_mti = 0; eml_mti < 2; eml_mti++) {
        eml_u[eml_mti] = 0U;
      }

      for (eml_j = 0; eml_j < 2; eml_j++) {
        eml_r_0 = localDW->twister_state[624] + 1U;
        if (eml_r_0 >= 625U) {
          for (eml_mti = 0; eml_mti < 227; eml_mti++) {
            eml_y = (localDW->twister_state[eml_mti] & 2147483648U) |
              (localDW->twister_state[eml_mti + 1] & 2147483647U);
            if ((eml_y & 1U) == 0U) {
              eml_r_0 = eml_y >> 1U;
            } else {
              eml_r_0 = eml_y >> 1U ^ 2567483615U;
            }

            localDW->twister_state[eml_mti] = localDW->twister_state[eml_mti +
              397] ^ eml_r_0;
          }

          for (eml_mti = 228; eml_mti < 624; eml_mti++) {
            eml_y = (localDW->twister_state[eml_mti - 1] & 2147483648U) |
              (localDW->twister_state[eml_mti] & 2147483647U);
            if ((eml_y & 1U) == 0U) {
              eml_r_0 = eml_y >> 1U;
            } else {
              eml_r_0 = eml_y >> 1U ^ 2567483615U;
            }

            localDW->twister_state[eml_mti - 1] = localDW->twister_state[eml_mti
              - 228] ^ eml_r_0;
          }

          eml_y = (localDW->twister_state[623] & 2147483648U) |
            (localDW->twister_state[0] & 2147483647U);
          if ((eml_y & 1U) == 0U) {
            eml_r_0 = eml_y >> 1U;
          } else {
            eml_r_0 = eml_y >> 1U ^ 2567483615U;
          }

          localDW->twister_state[623] = localDW->twister_state[396] ^ eml_r_0;
          eml_r_0 = 1U;
        }

        eml_y = localDW->twister_state[(int32_T)eml_r_0 - 1];
        localDW->twister_state[624] = eml_r_0;
        eml_y ^= eml_y >> 11U;
        eml_y ^= eml_y << 7U & 2636928640U;
        eml_y ^= eml_y << 15U & 4022730752U;
        eml_y ^= eml_y >> 18U;
        eml_u[eml_j] = eml_y;
      }

      eml_u[0] >>= 5U;
      eml_u[1] >>= 6U;
      eml_r = 1.1102230246251565E-016 * ((real_T)eml_u[0] * 6.7108864E+007 +
        (real_T)eml_u[1]);
    } while (!(eml_r != 0.0));
  } else {
    eml_r_0 = (boolean_T)0 ? MAX_uint32_T : (uint32_T)(localDW->v4_state /
      127773U);
    eml_y = 16807U * (localDW->v4_state - eml_r_0 * 127773U);
    eml_r_0 *= 2836U;
    if (eml_y < eml_r_0) {
      localDW->v4_state = (2147483647U - eml_r_0) + eml_y;
    } else {
      localDW->v4_state = eml_y - eml_r_0;
    }

    return (real_T)localDW->v4_state * 4.6566128752457969E-010;
  }

  return eml_r;
}

static void jvcbench_refp717_linprog_lap_jvc(real_T eml_m, real_T eml_n, real_T
  eml_ax[1001], real_T eml_ay[1001000], real_T eml_ac[1001000], real_T eml_x
  [1000], real_T eml_y[1000], real_T eml_v[1000])
{
  real_T eml_qm;
  int32_T eml_reduction_pass;
  real_T eml_qx[1000];
  real_T eml_ii;
  real_T eml_queue_count;
  real_T eml_queue_index;
  real_T eml_src;
  real_T eml_src_n;
  real_T eml_min_snk1;
  real_T eml_min_snk2;
  real_T eml_min_cst1;
  real_T eml_min_cst2;
  real_T eml_cst;
  real_T eml_opens[1000];
  real_T eml_ii_0;
  real_T eml_dist[1000];
  real_T eml_pred[1000];
  real_T eml_end_snk;
  int32_T eml_exitg2;
  int32_T eml_exitg3;
  real_T eml_sinks[1000];
  int32_T eml_exitg1;

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Sensitivity: !SENSITIVITY! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  !COPYRIGHT! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* LINPROG_LAP_JVC : linear assignment problem algorithm */
  /*    [ x, y, u, v ] = asn_lap_jvc( m, n, ax, ay, ac, x, y, u, v ) */
  /*  */
  /*    LINPROG_LAP_JVC finds an optimal solution to the linear assignment problem  */
  /*    using the JVC (Jonker-Volgenant-Castanon) method. */
  /*  */
  /*    Note that the inputs are not checked for consistency or validity... */
  /*     */
  /*    /input/ */
  /*       m ( real ) : number of linear assignment problem sources; */
  /*       n ( real ) : number of linear assignment problem sinks; */
  /*       ax ( real[ m + 1 ] ) : array of pairing source indices; */
  /*       ay ( real[ k ] ) : array of pairing sinks; */
  /*       ac ( real[ k ] ) : array of pairing costs; */
  /*       x ( real[ m ] ) : source assignments; */
  /*       y ( real[ n ] ) : sink assignments; */
  /*       v ( real[ n ] ) : sink dual variables; */
  /*  */
  /*    /output/ */
  /*       x ( real[ m ] ) : source assignments; */
  /*       y ( real[ n ] ) : sink assignments; */
  /*       u ( real[ m ] ) : source dual variables; */
  /*       v ( real[ n ] ) : sink dual variables; */
  /*         */
  /*    /history/ */
  /*       2008.12.05 : jdc : initial release */
  /*  */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* % CONSTANTS */
  /* % INITIALIZATION */
  eml_qm = 0.0;

  /*  unassigned sources count */
  for (eml_reduction_pass = 0; eml_reduction_pass < 1000; eml_reduction_pass++)
  {
    eml_qx[eml_reduction_pass] = 0.0;
  }

  /*  unassigned sources queue */
  /*  initialize unassigned sources */
  for (eml_ii = 1.0; eml_ii <= eml_m; eml_ii++) {
    /*  .. if source unassigned */
    if (eml_x[(int32_T)eml_ii - 1] == 0.0) {
      eml_qm++;

      /*  increment unassigned sources count */
      eml_qx[(int32_T)eml_qm - 1] = eml_ii;

      /*  add unassigned source to queue */
    }
  }

  /* % REDUCTION */
  /*  ..while unassigned sources exist and reduction pass within bounds */
  for (eml_reduction_pass = 1; (eml_qm > 0.0) && (eml_reduction_pass <= 2);
       eml_reduction_pass++) {
    /*  ..while queue index within bounds */
    eml_queue_count = 0.0;
    eml_queue_index = 1.0;
    while (eml_queue_index <= eml_qm) {
      eml_src = eml_qx[(int32_T)eml_queue_index - 1];

      /*  current source */
      /*  current source beginning pairing index */
      eml_src_n = eml_ax[(int32_T)(eml_src + 1.0) - 1] - 1.0;

      /*  current source end pairing index */
      eml_queue_index++;

      /*  ..for each assignment */
      eml_min_snk1 = 0.0;

      /*  minimum pairing 1 sink */
      eml_min_snk2 = 0.0;

      /*  minimum pairing 2 sink */
      eml_min_cst1 = rtInf;

      /*  minimum pairing 1 cost */
      eml_min_cst2 = rtInf;

      /*  minimum pairing 2 cost */
      for (eml_ii = eml_ax[(int32_T)eml_src - 1]; eml_ii <= eml_src_n; eml_ii++)
      {
        eml_cst = eml_ac[(int32_T)eml_ii - 1] - eml_v[(int32_T)eml_ay[(int32_T)
          eml_ii - 1] - 1];

        /*  augmented assigment cost */
        /*  ..if cost is less than or equal to minimum pairing 1 cost */
        if (eml_cst <= eml_min_cst2) {
          /*  ..if cost is larger than minimum pairing 1 cost */
          if (eml_cst > eml_min_cst1) {
            eml_min_cst2 = eml_cst;
            eml_min_snk2 = eml_ay[(int32_T)eml_ii - 1];

            /*  ..otherwise */
          } else {
            eml_min_cst2 = eml_min_cst1;
            eml_min_snk2 = eml_min_snk1;
            eml_min_cst1 = eml_cst;
            eml_min_snk1 = eml_ay[(int32_T)eml_ii - 1];
          }
        }
      }

      /*  ..if minimum pairing not found */
      if (eml_min_snk1 == 0.0) {
        eml_x[(int32_T)eml_src - 1] = 0.0;

        /*  ..otherwise */
      } else {
        eml_ii = eml_y[(int32_T)eml_min_snk1 - 1];

        /*  minimum pairing 1 sink assignment */
        /*  ..if minimum pairing 1 cost is less than minimum pairing 2 cost */
        if (eml_min_cst1 < eml_min_cst2) {
          eml_v[(int32_T)eml_min_snk1 - 1] += eml_min_cst1 - eml_min_cst2;

          /*  ..otherwise if minimum pairing 1 sink unassigned */
        } else {
          if (eml_ii != 0.0) {
            /*  ..if minimum pairing 2 not found */
            if (eml_min_snk2 == 0.0) {
              eml_min_snk1 = 0.0;
              eml_ii = 0.0;

              /*  ..otherwise */
            } else {
              eml_min_snk1 = eml_min_snk2;
              eml_ii = eml_y[(int32_T)eml_min_snk2 - 1];
            }
          }
        }

        /*  assign source to minimum pairing sink */
        eml_x[(int32_T)eml_src - 1] = eml_min_snk1;
        if (eml_min_snk1 != 0.0) {
          eml_y[(int32_T)eml_min_snk1 - 1] = eml_src;
        }

        /*  ..if minimum pairing sink assigned */
        if (eml_ii != 0.0) {
          eml_x[(int32_T)eml_ii - 1] = 0.0;
          if (eml_min_cst1 + 2.2204460492503131E-016 < eml_min_cst2) {
            eml_queue_index--;
            eml_qx[(int32_T)eml_queue_index - 1] = eml_ii;
          } else {
            eml_queue_count++;
            eml_qx[(int32_T)eml_queue_count - 1] = eml_ii;
          }
        }
      }
    }

    eml_qm = eml_queue_count;
  }

  /* % AUGMENTATION */
  /*  ..if unassigned sources exist */
  if (eml_qm > 0.0) {
    for (eml_reduction_pass = 0; eml_reduction_pass < 1000; eml_reduction_pass++)
    {
      eml_opens[eml_reduction_pass] = 0.0;
    }

    /*  list of unvisited sinks */
    /*  ..for each unassigned source */
    for (eml_ii_0 = 1.0; eml_ii_0 <= eml_qm; eml_ii_0++) {
      eml_src = eml_qx[(int32_T)eml_ii_0 - 1];

      /*  current source */
      eml_ii = eml_ax[(int32_T)eml_src - 1];

      /*  current source beginning pairing index */
      eml_src_n = eml_ax[(int32_T)(eml_src + 1.0) - 1] - 1.0;

      /*  current source end pairing index */
      /*  ..if no feasible pairing */
      if (eml_ii == eml_src_n) {
        eml_x[(int32_T)eml_src - 1] = 0.0;
      } else {
        /*  initialize graph search data */
        for (eml_reduction_pass = 0; eml_reduction_pass < 1000;
             eml_reduction_pass++) {
          eml_dist[eml_reduction_pass] = rtInf;
          eml_pred[eml_reduction_pass] = rtInf;
        }

        /*  initialize reachable sinks */
        while (eml_ii <= eml_src_n) {
          eml_dist[(int32_T)eml_ay[(int32_T)eml_ii - 1] - 1] = eml_ac[(int32_T)
            eml_ii - 1] - eml_v[(int32_T)eml_ay[(int32_T)eml_ii - 1] - 1];
          eml_pred[(int32_T)eml_ay[(int32_T)eml_ii - 1] - 1] = eml_src;
          eml_ii++;
        }

        /*  initialize unvisited sinks */
        for (eml_ii = 1.0; eml_ii <= eml_n; eml_ii++) {
          eml_opens[(int32_T)eml_ii - 1] = eml_ii;
        }

        eml_min_cst1 = 1.0;

        /*  sinks 1..lo-1 ready */
        eml_min_cst2 = 1.0;

        /*  sinks lo..up-1 to scan */
        eml_src_n = rtInf;
        eml_end_snk = 0.0;

        /*  ..while end not reached and sinks to scan */
        do {
          eml_exitg2 = 0U;
          if ((eml_end_snk == 0.0) && (eml_min_cst1 <= eml_n)) {
            /*  ..if need sinks to scan */
            if (eml_min_cst2 == eml_min_cst1) {
              eml_src_n = rtInf;
              for (eml_ii = eml_min_cst2; eml_ii <= eml_n; eml_ii++) {
                eml_min_snk1 = eml_opens[(int32_T)eml_ii - 1];
                eml_cst = eml_dist[(int32_T)eml_min_snk1 - 1];
                if (eml_cst <= eml_src_n) {
                  if (eml_cst < eml_src_n) {
                    eml_min_cst2 = eml_min_cst1;
                    eml_src_n = eml_cst;
                  }

                  eml_opens[(int32_T)eml_ii - 1] = eml_opens[(int32_T)
                    eml_min_cst2 - 1];
                  eml_opens[(int32_T)eml_min_cst2 - 1] = eml_min_snk1;
                  eml_min_cst2++;
                }
              }

              eml_ii = eml_min_cst2 - 1.0;
              eml_queue_count = eml_min_cst1;
              eml_exitg3 = 0U;
              while ((eml_exitg3 == 0U) && (eml_queue_count <= eml_ii)) {
                if (eml_y[(int32_T)eml_opens[(int32_T)eml_queue_count - 1] - 1] ==
                    0.0) {
                  eml_end_snk = eml_opens[(int32_T)eml_queue_count - 1];
                  eml_exitg3 = 1U;
                } else {
                  eml_queue_count++;
                }
              }
            }

            /*  ..if end sink not found */
            if (eml_end_snk == 0.0) {
              eml_ii = eml_opens[(int32_T)eml_min_cst1 - 1];
              eml_min_snk2 = eml_y[(int32_T)eml_ii - 1];
              eml_queue_count = eml_ax[(int32_T)(eml_min_snk2 + 1.0) - 1] - 1.0;
              eml_min_cst1++;
              for (eml_reduction_pass = 0; eml_reduction_pass < 1000;
                   eml_reduction_pass++) {
                eml_sinks[eml_reduction_pass] = 0.0;
              }

              for (eml_queue_index = eml_ax[(int32_T)eml_min_snk2 - 1];
                   eml_queue_index <= eml_queue_count; eml_queue_index++) {
                eml_sinks[(int32_T)eml_ay[(int32_T)eml_queue_index - 1] - 1] =
                  eml_queue_index;
              }

              eml_ii = (eml_ac[(int32_T)eml_sinks[(int32_T)eml_ii - 1] - 1] -
                        eml_v[(int32_T)eml_ii - 1]) - eml_src_n;
              eml_queue_count = eml_min_cst2;
              eml_exitg1 = 0U;
             label_2:
              ;
              goto label_1;
             label_3:
              ;
              eml_queue_count++;
              goto label_2;
             label_1:
              ;
              if ((eml_exitg1 == 0U) && (eml_queue_count <= eml_n)) {
                eml_min_snk1 = eml_opens[(int32_T)eml_queue_count - 1];
                if (eml_sinks[(int32_T)eml_min_snk1 - 1] != 0.0) {
                  eml_queue_index = (eml_ac[(int32_T)eml_sinks[(int32_T)
                                     eml_min_snk1 - 1] - 1] - eml_v[(int32_T)
                                     eml_min_snk1 - 1]) - eml_ii;
                  if (eml_queue_index < eml_dist[(int32_T)eml_min_snk1 - 1]) {
                    eml_dist[(int32_T)eml_min_snk1 - 1] = eml_queue_index;
                    eml_pred[(int32_T)eml_min_snk1 - 1] = eml_min_snk2;
                    if (eml_queue_index == eml_src_n) {
                      if (eml_y[(int32_T)eml_min_snk1 - 1] == 0.0) {
                        eml_end_snk = eml_min_snk1;
                        eml_exitg1 = 1U;
                        goto label_2;
                      } else {
                        eml_opens[(int32_T)eml_queue_count - 1] = eml_opens
                          [(int32_T)eml_min_cst2 - 1];
                        eml_opens[(int32_T)eml_min_cst2 - 1] = eml_min_snk1;
                        eml_min_cst2++;
                        goto label_3;
                      }
                    } else {
                      goto label_3;
                    }
                  } else {
                    goto label_3;
                  }
                } else {
                  goto label_3;
                }
              }
            }
          } else {
            eml_exitg2 = 1U;
          }
        } while (eml_exitg2 == 0U);

        if (eml_end_snk == 0.0) {
          eml_x[(int32_T)eml_src - 1] = 0.0;
        } else {
          eml_ii = eml_min_cst1 - 1.0;
          for (eml_queue_count = 1.0; eml_queue_count <= eml_ii; eml_queue_count
               ++) {
            eml_v[(int32_T)eml_opens[(int32_T)eml_queue_count - 1] - 1] =
              (eml_v[(int32_T)eml_opens[(int32_T)eml_queue_count - 1] - 1] +
               eml_dist[(int32_T)eml_opens[(int32_T)eml_queue_count - 1] - 1]) -
              eml_src_n;
          }

          do {
            eml_ii = eml_pred[(int32_T)eml_end_snk - 1];
            eml_y[(int32_T)eml_end_snk - 1] = eml_ii;
            eml_queue_count = eml_end_snk;
            eml_end_snk = eml_x[(int32_T)eml_ii - 1];
            eml_x[(int32_T)eml_ii - 1] = eml_queue_count;
          } while (!(eml_ii == eml_src));
        }
      }
    }
  }

  /*  LINPROG_LAP_JVC */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
}

/* Initial conditions for atomic system: '<Root>/JVCBENCH' */
void jvcbench_JVCBENCH_Init(rtDW_JVCBENCH_jvcbench *localDW)
{
  /* Initialize code for chart: '<Root>/JVCBENCH' */
  {
    int32_T eml_i0;
    localDW->twister_state_not_empty = false;
    for (eml_i0 = 0; eml_i0 < 625; eml_i0++) {
      localDW->twister_state[eml_i0] = 0U;
    }

    localDW->method = 2U;
    localDW->v4_state = 1144108930U;
  }
}

/* Output and update for atomic system: '<Root>/JVCBENCH' */
void jvcbench_JVCBENCH(real_T rtu_0, real_T rtu_1, real_T rtu_2, real_T rtu_3,
  real_T rtu_4, rtB_JVCBENCH_jvcbench *localB, rtDW_JVCBENCH_jvcbench *localDW)
{
  /* Embedded MATLAB: '<Root>/JVCBENCH' */
  jvcbench_c2_jvcbench(rtu_0, rtu_1, rtu_2, rtu_3, rtu_4, localB, localDW);
}

/* Model step function */
void jvcbench_step(BlockIO_jvcbench *jvcbench_B, D_Work_jvcbench *jvcbench_DWork,
                   ExternalInputs_jvcbench *jvcbench_U, ExternalOutputs_jvcbench
                   *jvcbench_Y)
{
  {
    int32_T i;
    jvcbench_JVCBENCH(jvcbench_U->jvcbench_m, jvcbench_U->jvcbench_n,
                      jvcbench_U->jvcbench_seed, jvcbench_U->jvcbench_level,
                      jvcbench_U->jvcbench_iterations, &jvcbench_B->sf_JVCBENCH,
                      &jvcbench_DWork->sf_JVCBENCH);
    for (i = 0; i < 1000; i++) {
      /* Outport: '<Root>/jvcbench_x' */
      jvcbench_Y->jvcbench_x[i] = jvcbench_B->sf_JVCBENCH.x[i];

      /* Outport: '<Root>/jvcbench_y' */
      jvcbench_Y->jvcbench_y[i] = jvcbench_B->sf_JVCBENCH.y[i];
    }
  }
}

/* Model initialize function */
void jvcbench_initialize(D_Work_jvcbench *jvcbench_DWork,
  ExternalInputs_jvcbench *jvcbench_U, ExternalOutputs_jvcbench *jvcbench_Y)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));
  jvcbench_JVCBENCH_Init(&jvcbench_DWork->sf_JVCBENCH);
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
