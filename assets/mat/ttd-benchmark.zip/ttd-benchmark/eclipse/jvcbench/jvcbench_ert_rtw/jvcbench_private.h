/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *jvcbench_private.h
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/
/*
 * File: jvcbench_private.h
 *
 * Real-Time Workshop code generated for Simulink model jvcbench.
 *
 * Model version                        : 1.281
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Jan 29 15:26:00 2009
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Jan 29 15:26:00 2009
 */
#ifndef RTW_HEADER_jvcbench_private_h_
#define RTW_HEADER_jvcbench_private_h_
#include "rtwtypes.h"
#include "rtlibsrc.h"
#define CALL_EVENT                     (MAX_uint8_T)
#ifndef __RTWTYPES_H__
#error This file requires rtwtypes.h to be included
#else
#ifdef TMWTYPES_PREVIOUSLY_INCLUDED
#error This file requires rtwtypes.h to be included before tmwtypes.h
#else

/* Check for inclusion of an incorrect version of rtwtypes.h */
#ifndef RTWTYPES_ID_C08S16I32L32N32F1
#error This code was generated with a different "rtwtypes.h" than the file included
#endif                                 /* RTWTYPES_ID_C08S16I32L32N32F1 */
#endif                                 /* TMWTYPES_PREVIOUSLY_INCLUDED */
#endif                                 /* __RTWTYPES_H__ */

void jvcbench_JVCBENCH_Init(rtDW_JVCBENCH_jvcbench *localDW);
void jvcbench_JVCBENCH(real_T rtu_0, real_T rtu_1, real_T rtu_2, real_T rtu_3,
  real_T rtu_4, rtB_JVCBENCH_jvcbench *localB, rtDW_JVCBENCH_jvcbench *localDW);

#endif                                 /* RTW_HEADER_jvcbench_private_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
