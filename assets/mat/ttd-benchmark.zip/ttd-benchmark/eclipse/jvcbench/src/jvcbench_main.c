/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *jvcbench_main.cpp
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/

#include "../jvcbench_ert_rtw/jvcbench.h" /* Model's header file */

#include <rtwtypes.h> /* MathWorks types */

#include <time.h>
#include <stdio.h>


static BlockIO_jvcbench jvcbench_B;         /* Observable signals */
static D_Work_jvcbench jvcbench_DWork;      /* Observable states */
static ExternalInputs_jvcbench jvcbench_U;  /* External inputs */
static ExternalOutputs_jvcbench jvcbench_Y; /* External outputs */


int_T 
jvcbench_main ( int_T jvcbench_m,
                int_T jvcbench_n,
                int_T jvcbench_level,
				int_T jvcbench_iterations )
{
	int_T i   = 0;
	real_T dt = 0.0;

    clock_t c0 = 0;
    clock_t c1 = 0;

	printf("----------------- JCVBENCH ----------------\n");
    
	c0 = clock();
	{
		/* Initialize model */
		jvcbench_initialize(&jvcbench_DWork, &jvcbench_U, &jvcbench_Y);

		/* Execute model */
		for ( i = 0 ; i < jvcbench_n ; ++i )
		{
			/* Set model inputs here */
			jvcbench_U.jvcbench_m = jvcbench_m;
			jvcbench_U.jvcbench_n = jvcbench_n;
	        
			jvcbench_U.jvcbench_seed = 1337;

			jvcbench_U.jvcbench_level = jvcbench_level / 100.0;

			jvcbench_U.jvcbench_iterations = jvcbench_iterations;
	    
			/* Step the model */
			jvcbench_step(&jvcbench_B, &jvcbench_DWork, &jvcbench_U, &jvcbench_Y);
	        
			/* Get model outputs here */
		}
	}
	c1 = clock();
	dt = (double) (c1 - c0) / (double) CLOCKS_PER_SEC;
	
    printf("  iterations : %d\n", jvcbench_iterations);
    printf("  m          : %d\n", jvcbench_m);
	printf("  n          : %d\n", jvcbench_n);
	printf("  level      : %f\n", jvcbench_level / 100.0);
    printf("-------------------------------------------\n");
	printf("  total time   (s) : %f\n", dt);
    printf("  average time (s) : %f\n", dt / jvcbench_iterations);
    printf("-------------------------------------------\n");

    //getchar();

	return 0;
}

int_T 
main ( int_T argc, 
       const char_T * argv[ ] )
{
    jvcbench_main(10, 100, 30, 10 * 100 * 5);
	
	return 0;
}


/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
