#ifndef rtw_shared_utils_h_
# define rtw_shared_utils_h_

/* Shared utilities general include header file.*/
#include "rtwtypes.h"
#include "rt_nonfinite.h"
#include "baaihlfccjmohlno_min.h"
#endif                                 /* rtw_shared_utils_h_ */
