/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *d:\data\jdchan\My Documents\MATLAB\jvcbench\mdl\run\slprj\ert\_sharedutils\baaihlfccjmohlno_min.c
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/
/*
 * File: d:\data\jdchan\My Documents\MATLAB\jvcbench\mdl\run\slprj\ert\_sharedutils\baaihlfccjmohlno_min.c
 *
 * Real-Time Workshop code generated for Simulink model jvcbench.
 *
 * Model version                        : 1.281
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Jan 29 15:26:00 2009
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Jan 29 15:26:00 2009
 */
#include "rtwtypes.h"
#include "rt_nonfinite.h"
#include "rtw_shared_utils.h"
#include "rt_nonfinite.h"

real_T baaihlfccjmohlno_min(real_T eml_varargin_1[2])
{
  real_T eml_minval;
  eml_minval = eml_varargin_1[0];
  if ((!((boolean_T)rtIsNaN(eml_varargin_1[1]))) && (((boolean_T)rtIsNaN
        (eml_minval)) || (eml_varargin_1[1] < eml_minval))) {
    return eml_varargin_1[1];
  }

  return eml_minval;
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
