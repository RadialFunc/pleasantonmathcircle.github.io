/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *d:\data\jdchan\My Documents\MATLAB\jvcbench\mdl\run\slprj\ert\_sharedutils\baaihlfccjmohlno_min.h
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/
/*
 * File: d:\data\jdchan\My Documents\MATLAB\jvcbench\mdl\run\slprj\ert\_sharedutils\baaihlfccjmohlno_min.h
 *
 * Real-Time Workshop code generated for Simulink model jvcbench.
 *
 * Model version                        : 1.281
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Jan 29 15:26:00 2009
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Jan 29 15:26:00 2009
 */
#ifndef SHARE_baaihlfccjmohlno_min
#define SHARE_baaihlfccjmohlno_min

extern real_T baaihlfccjmohlno_min(real_T eml_varargin_1[2]);

#endif

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
