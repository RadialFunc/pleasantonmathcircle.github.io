/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *filterbench_ukf.c
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/
/*
 * File: filterbench_ukf.c
 *
 * Real-Time Workshop code generated for Simulink model filterbench_ukf.
 *
 * Model version                        : 1.227
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Jan 29 15:12:41 2009
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Jan 29 15:12:42 2009
 */
#include "filterbench_ukf.h"
#include "filterbench_ukf_private.h"

static void filterbench_ukf_randn(real_T eml_r[6], real_T rtu_0, real_T rtu_1,
  rtB_PROPBENCH_filterbench_ukf *localB, rtDW_PROPBENCH_filterbench_ukf *localDW);
static void filterbench_ukf_fil_ukf_propagate(real_T eml_Q[36], real_T eml_x[6],
  real_T eml_P[36], real_T eml_t, real_T eml_h, real_T eml_xk[6], real_T eml_Pk
  [36], real_T *eml_tk);
static void filterbench_ukf_fil_mdl_ballisticmid1(real_T eml_x[78], real_T eml_t,
  real_T eml_h, real_T eml_xk[78]);
static void filterbench_ukf_num_ode_rk4(real_T eml_y0[78], real_T eml_t0, real_T
  eml_h0, real_T eml_yn[78]);
static void filterbench_ukf_dyn_ode_pv2(real_T eml_y[78], real_T eml_k[78]);
static real_T filterbench_ukf_rand(real_T rtu_0, rtB_UPDTBENCH_filterbench_ukf
  *localB, rtDW_UPDTBENCH_filterbench_ukf *localDW);
static void filterbench_ukf_randn_d(real_T eml_r[2], real_T rtu_0,
  rtB_UPDTBENCH_filterbench_ukf *localB, rtDW_UPDTBENCH_filterbench_ukf *localDW);
static void filterbench_ukf_fil_ukf_update(real_T eml_B[4], real_T eml_x[6],
  real_T eml_P[36], real_T eml_z[2], real_T eml_R[4], real_T eml_s[6], real_T
  eml_T[9], real_T eml_xk[6], real_T eml_Pk[36]);
static void filterbench_ukf_fil_mdl_ir1(real_T eml_x[78], real_T eml_s[6],
  real_T eml_T[9], real_T eml_z[26]);

/* Functions for block: '<Root>/PROPBENCH' */
static void filterbench_ukf_randn(real_T eml_r[6], real_T rtu_0, real_T rtu_1,
  rtB_PROPBENCH_filterbench_ukf *localB, rtDW_PROPBENCH_filterbench_ukf *localDW)
{
  int32_T eml_k;
  uint32_T eml_i;
  int32_T eml_j;
  static real_T eml_dv3[65] = { 0.340945, 0.4573146, 0.5397793, 0.6062427,
    0.6631691, 0.7136975, 0.7596125, 0.8020356, 0.8417227, 0.8792102, 0.9148948,
    0.9490791, 0.9820005, 1.0138492, 1.044781, 1.0749254, 1.1043917, 1.1332738,
    1.161653, 1.189601, 1.2171815, 1.2444516, 1.2714635, 1.298265, 1.3249008,
    1.3514125, 1.3778399, 1.4042211, 1.4305929, 1.4569915, 1.4834527, 1.5100122,
    1.5367061, 1.5635712, 1.5906454, 1.617968, 1.6455802, 1.6735255, 1.7018503,
    1.7306045, 1.7598422, 1.7896223, 1.8200099, 1.851077, 1.8829044, 1.9155831,
    1.9492166, 1.9839239, 2.0198431, 2.0571356, 2.095993, 2.136645, 2.1793713,
    2.2245175, 2.2725186, 2.3239338, 2.3795008, 2.4402218, 2.5075117, 2.5834658,
    2.6713916, 2.7769942, 2.7769942, 2.7769942, 2.7769942 };

  real_T eml_vtj;
  real_T eml_vtjp1;
  real_T eml_x;
  real_T eml_absr;
  real_T eml_s;
  uint32_T eml_jsr;
  uint32_T eml_state;
  for (eml_k = 0; eml_k < 6; eml_k++) {
    eml_r[eml_k] = 0.0;
  }

  if (localDW->method == 0) {
    if (!localDW->icng_not_empty) {
      localDW->icng = 362436069U;
      localDW->icng_not_empty = true;
      localDW->jsr = 521288629U;
    }

    for (eml_k = 0; eml_k < 6; eml_k++) {
      localDW->icng = 69069U * localDW->icng + 1234567U;
      localDW->jsr = localDW->jsr ^ localDW->jsr << 13U;
      localDW->jsr = localDW->jsr ^ localDW->jsr >> 17U;
      localDW->jsr = localDW->jsr ^ localDW->jsr << 5U;
      eml_i = localDW->icng + localDW->jsr;
      eml_j = (int32_T)(eml_i & 63U);
      eml_vtj = eml_dv3[eml_j];
      eml_vtjp1 = eml_dv3[eml_j + 1];
      eml_x = (real_T)(int32_T)eml_i * 4.6566128730773926E-010 * eml_vtjp1;
      eml_absr = fabs(eml_x);
      if (!(eml_absr <= eml_vtj)) {
        eml_vtj = (eml_absr - eml_vtj) / (eml_vtjp1 - eml_vtj);
        localDW->icng = 69069U * localDW->icng + 1234567U;
        localDW->jsr = localDW->jsr ^ localDW->jsr << 13U;
        localDW->jsr = localDW->jsr ^ localDW->jsr >> 17U;
        localDW->jsr = localDW->jsr ^ localDW->jsr << 5U;
        eml_absr = 0.5 + (real_T)(int32_T)(localDW->icng + localDW->jsr) *
          2.3283064365386960E-010;
        eml_s = eml_vtj + eml_absr;
        if (eml_s > 1.301198) {
          if (eml_x < 0.0) {
            eml_x = 0.4878992 * eml_vtj - 0.4878992;
          } else {
            eml_x = 0.4878992 - 0.4878992 * eml_vtj;
          }
        } else {
          if (!(eml_s <= 0.9689279)) {
            eml_vtj = 0.4878992 - 0.4878992 * eml_vtj;
            if (eml_absr > 12.67706 - 12.37586 * exp(-0.5 * eml_vtj * eml_vtj))
            {
              if (eml_x < 0.0) {
                eml_x = -eml_vtj;
              } else {
                eml_x = eml_vtj;
              }
            } else {
              if (!(exp(-0.5 * eml_vtjp1 * eml_vtjp1) + eml_absr * 0.01958303 /
                    eml_vtjp1 <= exp(-0.5 * eml_x * eml_x))) {
                do {
                  eml_i = 69069U * localDW->icng + 1234567U;
                  eml_jsr = localDW->jsr ^ localDW->jsr << 13U;
                  eml_jsr ^= eml_jsr >> 17U;
                  eml_jsr ^= eml_jsr << 5U;
                  eml_vtj = log(0.5 + (real_T)(int32_T)(eml_i + eml_jsr) *
                                2.3283064365386960E-010) / 2.776994;
                  localDW->icng = 69069U * eml_i + 1234567U;
                  localDW->jsr = eml_jsr ^ eml_jsr << 13U;
                  localDW->jsr = localDW->jsr ^ localDW->jsr >> 17U;
                  localDW->jsr = localDW->jsr ^ localDW->jsr << 5U;
                } while (!(-2.0 * log(0.5 + (real_T)(int32_T)(localDW->icng +
                            localDW->jsr) * 2.3283064365386960E-010) > eml_vtj *
                           eml_vtj));

                if (eml_x < 0.0) {
                  eml_x = eml_vtj - 2.776994;
                } else {
                  eml_x = 2.776994 - eml_vtj;
                }
              }
            }
          }
        }
      }

      eml_r[eml_k] = eml_x;
    }
  } else {
    for (eml_k = 0; eml_k < 6; eml_k++) {
      do {
        eml_i = (boolean_T)0 ? MAX_uint32_T : (uint32_T)(localDW->v4_state /
          127773U);
        eml_jsr = 16807U * (localDW->v4_state - eml_i * 127773U);
        eml_i *= 2836U;
        if (eml_jsr < eml_i) {
          eml_state = (2147483647U - eml_i) + eml_jsr;
        } else {
          eml_state = eml_jsr - eml_i;
        }

        eml_i = (boolean_T)0 ? MAX_uint32_T : (uint32_T)(eml_state / 127773U);
        eml_jsr = 16807U * (eml_state - eml_i * 127773U);
        eml_i *= 2836U;
        if (eml_jsr < eml_i) {
          localDW->v4_state = (2147483647U - eml_i) + eml_jsr;
        } else {
          localDW->v4_state = eml_jsr - eml_i;
        }

        eml_vtj = 2.0 * ((real_T)eml_state * 4.6566128752457969E-010) - 1.0;
        eml_absr = 2.0 * ((real_T)localDW->v4_state * 4.6566128752457969E-010) -
          1.0;
        eml_absr = eml_absr * eml_absr + eml_vtj * eml_vtj;
      } while (!(eml_absr <= 1.0));

      eml_vtj *= sqrt(-2.0 * log(eml_absr) / eml_absr);
      eml_r[eml_k] = eml_vtj;
    }
  }
}

static void filterbench_ukf_fil_ukf_propagate(real_T eml_Q[36], real_T eml_x[6],
  real_T eml_P[36], real_T eml_t, real_T eml_h, real_T eml_xk[6], real_T eml_Pk
  [36], real_T *eml_tk)
{
  int32_T eml_ixstart;
  int32_T eml_j;
  real_T eml_L[36];
  real_T eml_Xi[78];
  int32_T eml_ii;
  real_T eml_x_0;
  real_T eml_Xi_0[13];
  real_T eml_Xi_1[78];
  static real_T eml_dv4[78] = { 3.3333333333333331E-001, 3.3333333333333331E-001,
    3.3333333333333331E-001, 3.3333333333333331E-001, 3.3333333333333331E-001,
    3.3333333333333331E-001, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002 };

  int32_T eml_ix;
  int32_T eml_k;
  static real_T eml_dv5[78] = { 3.3333333333333326E-001, 3.3333333333333326E-001,
    3.3333333333333326E-001, 3.3333333333333326E-001, 3.3333333333333326E-001,
    3.3333333333333326E-001, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002 };

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Sensitivity: !SENSITIVITY! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  !COPYRIGHT! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* FIL_UKF_PROPAGATE : Unscented Kalman Filter propagation */
  /*    [ xk, Pk, tk ] = fil_ukf_propagate( f, Q, x, P, t, h ) */
  /*  */
  /*    FIL_UKF_PROPAGATE performs the Unscented Kalman Filter propagation step. */
  /*     */
  /*    /input/ */
  /*       f ( function )       : function handle to process model; */
  /*       Q ( real[ m ][ m ] ) : additive independent process noise; */
  /*       x ( real[ m ] )      : system state mean vector; */
  /*       P ( real[ m ][ m ] ) : system state covariance matrix; */
  /*       t ( real )           : system state time; */
  /*       h ( real )           : propagation time step; */
  /*  */
  /*    /output/ */
  /*       xk ( real[ m ] )      : propagated system state mean vector; */
  /*       Pk ( real[ m ][ m ] ) : propagated system state covariance matrix; */
  /*       tk ( real )           : propagated system state time; */
  /*         */
  /*    /history/ */
  /*       2008.11.19 : jdc : initial release */
  /*  */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* % CONSTANTS */
  /*  Scaled Unscented Transform parameters */
  /* % PROPAGATION */
  /*  ---- initialize weights ---- */
  /*  ---- generate sigma points ---- */
  for (eml_ixstart = 0; eml_ixstart < 6; eml_ixstart++) {
    for (eml_j = 0; eml_j < 6; eml_j++) {
      eml_L[eml_j + 6 * eml_ixstart] = eml_P[eml_j + 6 * eml_ixstart] * 9.0;
    }
  }

  refp1_aaaiglfknglfecjm_chol(eml_L);
  for (eml_ixstart = 0; eml_ixstart < 6; eml_ixstart++) {
    eml_Xi[eml_ixstart] = 0.0;
  }

  for (eml_ixstart = 0; eml_ixstart < 6; eml_ixstart++) {
    for (eml_j = 0; eml_j < 6; eml_j++) {
      eml_Xi[eml_j + 6 * (eml_ixstart + 1)] = eml_L[eml_j + 6 * eml_ixstart];
    }
  }

  for (eml_ixstart = 0; eml_ixstart < 6; eml_ixstart++) {
    for (eml_j = 0; eml_j < 6; eml_j++) {
      eml_Xi[eml_j + 6 * (eml_ixstart + 7)] = -eml_L[eml_j + 6 * eml_ixstart];
    }
  }

  for (eml_ii = 0; eml_ii < 6; eml_ii++) {
    eml_x_0 = eml_x[eml_ii];
    for (eml_ixstart = 0; eml_ixstart < 13; eml_ixstart++) {
      eml_Xi_0[eml_ixstart] = eml_Xi[eml_ii + 6 * eml_ixstart] + eml_x_0;
    }

    for (eml_ixstart = 0; eml_ixstart < 13; eml_ixstart++) {
      eml_Xi[eml_ii + 6 * eml_ixstart] = eml_Xi_0[eml_ixstart];
    }
  }

  /*  ---- propagate sigma points---- */
  for (eml_ixstart = 0; eml_ixstart < 13; eml_ixstart++) {
    for (eml_j = 0; eml_j < 6; eml_j++) {
      eml_Xi_1[eml_j + 6 * eml_ixstart] = eml_Xi[eml_j + 6 * eml_ixstart];
    }
  }

  filterbench_ukf_fil_mdl_ballisticmid1(eml_Xi_1, eml_t, eml_h, eml_Xi);

  /*  ---- collect statistics ---- */
  for (eml_ixstart = 0; eml_ixstart < 13; eml_ixstart++) {
    for (eml_j = 0; eml_j < 6; eml_j++) {
      eml_Xi_1[eml_j + 6 * eml_ixstart] = eml_Xi[eml_j + 6 * eml_ixstart] *
        eml_dv4[eml_j + 6 * eml_ixstart];
    }
  }

  for (eml_ixstart = 0; eml_ixstart < 6; eml_ixstart++) {
    eml_xk[eml_ixstart] = 0.0;
  }

  eml_ii = 0;
  eml_ixstart = 0;
  for (eml_j = 0; eml_j < 6; eml_j++) {
    eml_ixstart++;
    eml_ix = eml_ixstart;
    eml_x_0 = eml_Xi_1[eml_ixstart - 1];
    for (eml_k = 2; eml_k < 14; eml_k++) {
      eml_ix += 6;
      eml_x_0 += eml_Xi_1[eml_ix - 1];
    }

    eml_ii++;
    eml_xk[eml_ii - 1] = eml_x_0;
  }

  for (eml_ii = 0; eml_ii < 6; eml_ii++) {
    eml_x_0 = eml_xk[eml_ii];
    for (eml_ixstart = 0; eml_ixstart < 13; eml_ixstart++) {
      eml_Xi_0[eml_ixstart] = eml_Xi[eml_ii + 6 * eml_ixstart] - eml_x_0;
    }

    for (eml_ixstart = 0; eml_ixstart < 13; eml_ixstart++) {
      eml_Xi[eml_ii + 6 * eml_ixstart] = eml_Xi_0[eml_ixstart];
    }
  }

  /*  ---- finalize state ---- */
  for (eml_ixstart = 0; eml_ixstart < 13; eml_ixstart++) {
    for (eml_j = 0; eml_j < 6; eml_j++) {
      eml_Xi_1[eml_j + 6 * eml_ixstart] = eml_Xi[eml_j + 6 * eml_ixstart] *
        eml_dv5[eml_j + 6 * eml_ixstart];
    }
  }

  for (eml_ixstart = 0; eml_ixstart < 6; eml_ixstart++) {
    for (eml_j = 0; eml_j < 6; eml_j++) {
      eml_x_0 = 0.0;
      for (eml_ix = 0; eml_ix < 13; eml_ix++) {
        eml_x_0 += eml_Xi_1[eml_ixstart + 6 * eml_ix] * eml_Xi[eml_j + 6 *
          eml_ix];
      }

      eml_Pk[eml_ixstart + 6 * eml_j] = eml_x_0 + eml_Q[eml_ixstart + 6 * eml_j];
    }
  }

  *eml_tk = eml_t + eml_h;

  /*  FIL_UKF_PROPAGATE */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
}

static void filterbench_ukf_fil_mdl_ballisticmid1(real_T eml_x[78], real_T eml_t,
  real_T eml_h, real_T eml_xk[78])
{
  real_T eml_tk;
  int32_T eml_i1;
  int32_T eml_i2;
  real_T eml_xn[78];
  real_T eml_tn;
  real_T eml_b;
  real_T eml_xn_0[78];
  real_T eml_b_0[78];
  real_T eml_hk1[78];
  real_T eml_hk2[78];
  real_T eml_b_1[78];

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Sensitivity: !SENSITIVITY! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  !COPYRIGHT! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* FIL_MDL_BALLISTICMID1 : generic midcourse ballistic process model */
  /*    [ xk ] = fil_mdl_ballisticmid( x, t, h ) */
  /*  */
  /*    FIL_MDL_BALLISTICMID1 provides a process model for a generic midcourse */
  /*    ballistic position-velocity state. */
  /*     */
  /*    /input/ */
  /*       x ( real[ m ][ n ] ) : system state vector; */
  /*       t ( real )           : system state time; */
  /*       h ( real )           : propagation time step; */
  /*  */
  /*    /output/ */
  /*       xk ( real[ m ][ n ] ) : propagated system state vector; */
  /*         */
  /*    /history/ */
  /*       2008.11.19 : jdc : initial release */
  /*  */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* % CONSTANTS */
  /*  propagation parameters */
  /* % PROPAGATION */
  /*  ---- initialize ---- */
  eml_tk = eml_t + eml_h;
  for (eml_i1 = 0; eml_i1 < 13; eml_i1++) {
    for (eml_i2 = 0; eml_i2 < 6; eml_i2++) {
      eml_xn[eml_i2 + 6 * eml_i1] = eml_x[eml_i2 + 6 * eml_i1];
    }
  }

  eml_tn = eml_t;
  eml_b = eml_h;
  if (fabs(eml_h) > 1.0) {
    if ((boolean_T)rtIsNaN(eml_h)) {
      eml_b = rtNaN;
    } else if (eml_h > 0.0) {
      eml_b = 1.0;
    } else {
      if (eml_h < 0.0) {
        eml_b = -1.0;
      }
    }
  }

  /*  ---- iterate ---- */
  while (fabs(eml_tn + eml_b) < fabs(eml_tk)) {
    for (eml_i1 = 0; eml_i1 < 13; eml_i1++) {
      for (eml_i2 = 0; eml_i2 < 6; eml_i2++) {
        eml_xn_0[eml_i2 + 6 * eml_i1] = eml_xn[eml_i2 + 6 * eml_i1];
      }
    }

    filterbench_ukf_num_ode_rk4(eml_xn_0, eml_tn, eml_b, eml_xn);
    eml_tn += eml_b;
  }

  /*  ---- finalize ---- */
  eml_tk -= eml_tn;

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Sensitivity: !SENSITIVITY! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  !COPYRIGHT! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* NUM_ODE_RK4 : Runge-Kutta fourth order */
  /*    [ yn ] = num_ode_rk4( f, y0, t0, h0 ) */
  /*  */
  /*    NUM_ODE_RK4 uses a fourth order Runge-Kutta method to numerically  */
  /*    approximate the solution to an ordinary differential equation. */
  /*     */
  /*    /input/ */
  /*       f ( function )        : function handle to derivative function; */
  /*       y0 ( real[ m ][ n ] ) : initial dependent variable value; */
  /*       t0 ( real )           : initial independent variable value; */
  /*       h0 ( real )           : initial independent variable step size; */
  /*  */
  /*    /output/ */
  /*       yn ( real[ m ][ n ] ) : final dependent variable value; */
  /*         */
  /*    /history/ */
  /*       2008.11.19 : jdc : initial release */
  /*  */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* % CONSTANTS */
  /*  Butcher Tableau */
  /* % APPROXIMATION */
  filterbench_ukf_dyn_ode_pv2(eml_xn, eml_b_0);
  for (eml_i1 = 0; eml_i1 < 13; eml_i1++) {
    for (eml_i2 = 0; eml_i2 < 6; eml_i2++) {
      eml_tn = eml_tk * eml_b_0[eml_i2 + 6 * eml_i1];
      eml_xn_0[eml_i2 + 6 * eml_i1] = eml_xn[eml_i2 + 6 * eml_i1] + 0.5 * eml_tn;
      eml_hk1[eml_i2 + 6 * eml_i1] = eml_tn;
    }
  }

  filterbench_ukf_dyn_ode_pv2(eml_xn_0, eml_b_0);
  for (eml_i1 = 0; eml_i1 < 13; eml_i1++) {
    for (eml_i2 = 0; eml_i2 < 6; eml_i2++) {
      eml_tn = eml_tk * eml_b_0[eml_i2 + 6 * eml_i1];
      eml_xn_0[eml_i2 + 6 * eml_i1] = eml_xn[eml_i2 + 6 * eml_i1] + 0.5 * eml_tn;
      eml_hk2[eml_i2 + 6 * eml_i1] = eml_tn;
    }
  }

  filterbench_ukf_dyn_ode_pv2(eml_xn_0, eml_b_0);
  for (eml_i1 = 0; eml_i1 < 13; eml_i1++) {
    for (eml_i2 = 0; eml_i2 < 6; eml_i2++) {
      eml_tn = eml_tk * eml_b_0[eml_i2 + 6 * eml_i1];
      eml_xn_0[eml_i2 + 6 * eml_i1] = eml_xn[eml_i2 + 6 * eml_i1] + eml_tn;
      eml_b_0[eml_i2 + 6 * eml_i1] = eml_tn;
    }
  }

  filterbench_ukf_dyn_ode_pv2(eml_xn_0, eml_b_1);
  for (eml_i1 = 0; eml_i1 < 13; eml_i1++) {
    for (eml_i2 = 0; eml_i2 < 6; eml_i2++) {
      eml_xk[eml_i2 + 6 * eml_i1] = (((eml_xn[eml_i2 + 6 * eml_i1] +
        1.6666666666666666E-001 * eml_hk1[eml_i2 + 6 * eml_i1]) +
        3.3333333333333331E-001 * eml_hk2[eml_i2 + 6 * eml_i1]) +
        3.3333333333333331E-001 * eml_b_0[eml_i2 + 6 * eml_i1]) +
        1.6666666666666666E-001 * (eml_tk * eml_b_1[eml_i2 + 6 * eml_i1]);
    }
  }

  /*  NUM_ODE_RK4 */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  FIL_MDL_BALLISTICMID1 */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
}

static void filterbench_ukf_num_ode_rk4(real_T eml_y0[78], real_T eml_t0, real_T
  eml_h0, real_T eml_yn[78])
{
  real_T eml_b[78];
  int32_T eml_i3;
  int32_T eml_i4;
  real_T eml_d0;
  real_T eml_y0_0[78];
  real_T eml_hk1[78];
  real_T eml_hk2[78];
  real_T eml_b_0[78];
  UNUSED_PARAMETER(eml_t0);

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Sensitivity: !SENSITIVITY! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  !COPYRIGHT! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* NUM_ODE_RK4 : Runge-Kutta fourth order */
  /*    [ yn ] = num_ode_rk4( f, y0, t0, h0 ) */
  /*  */
  /*    NUM_ODE_RK4 uses a fourth order Runge-Kutta method to numerically  */
  /*    approximate the solution to an ordinary differential equation. */
  /*     */
  /*    /input/ */
  /*       f ( function )        : function handle to derivative function; */
  /*       y0 ( real[ m ][ n ] ) : initial dependent variable value; */
  /*       t0 ( real )           : initial independent variable value; */
  /*       h0 ( real )           : initial independent variable step size; */
  /*  */
  /*    /output/ */
  /*       yn ( real[ m ][ n ] ) : final dependent variable value; */
  /*         */
  /*    /history/ */
  /*       2008.11.19 : jdc : initial release */
  /*  */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* % CONSTANTS */
  /*  Butcher Tableau */
  /* % APPROXIMATION */
  filterbench_ukf_dyn_ode_pv2(eml_y0, eml_b);
  for (eml_i3 = 0; eml_i3 < 13; eml_i3++) {
    for (eml_i4 = 0; eml_i4 < 6; eml_i4++) {
      eml_d0 = eml_h0 * eml_b[eml_i4 + 6 * eml_i3];
      eml_y0_0[eml_i4 + 6 * eml_i3] = eml_y0[eml_i4 + 6 * eml_i3] + 0.5 * eml_d0;
      eml_hk1[eml_i4 + 6 * eml_i3] = eml_d0;
    }
  }

  filterbench_ukf_dyn_ode_pv2(eml_y0_0, eml_b);
  for (eml_i3 = 0; eml_i3 < 13; eml_i3++) {
    for (eml_i4 = 0; eml_i4 < 6; eml_i4++) {
      eml_d0 = eml_h0 * eml_b[eml_i4 + 6 * eml_i3];
      eml_y0_0[eml_i4 + 6 * eml_i3] = eml_y0[eml_i4 + 6 * eml_i3] + 0.5 * eml_d0;
      eml_hk2[eml_i4 + 6 * eml_i3] = eml_d0;
    }
  }

  filterbench_ukf_dyn_ode_pv2(eml_y0_0, eml_b);
  for (eml_i3 = 0; eml_i3 < 13; eml_i3++) {
    for (eml_i4 = 0; eml_i4 < 6; eml_i4++) {
      eml_d0 = eml_h0 * eml_b[eml_i4 + 6 * eml_i3];
      eml_y0_0[eml_i4 + 6 * eml_i3] = eml_y0[eml_i4 + 6 * eml_i3] + eml_d0;
      eml_b[eml_i4 + 6 * eml_i3] = eml_d0;
    }
  }

  filterbench_ukf_dyn_ode_pv2(eml_y0_0, eml_b_0);
  for (eml_i3 = 0; eml_i3 < 13; eml_i3++) {
    for (eml_i4 = 0; eml_i4 < 6; eml_i4++) {
      eml_yn[eml_i4 + 6 * eml_i3] = (((eml_y0[eml_i4 + 6 * eml_i3] +
        1.6666666666666666E-001 * eml_hk1[eml_i4 + 6 * eml_i3]) +
        3.3333333333333331E-001 * eml_hk2[eml_i4 + 6 * eml_i3]) +
        3.3333333333333331E-001 * eml_b[eml_i4 + 6 * eml_i3]) +
        1.6666666666666666E-001 * (eml_h0 * eml_b_0[eml_i4 + 6 * eml_i3]);
    }
  }

  /*  NUM_ODE_RK4 */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
}

static void filterbench_ukf_dyn_ode_pv2(real_T eml_y[78], real_T eml_k[78])
{
  int32_T eml_i5;
  int32_T eml_i6;
  real_T eml_d1;
  real_T eml_d2;
  real_T eml_d3;
  real_T eml_a[13];
  real_T eml_y_0[13];
  real_T eml_y_1[13];
  real_T eml_c4[13];

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Sensitivity: !SENSITIVITY! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  !COPYRIGHT! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* DYN_ODE_PV2 : position-velocity derivative */
  /*    [ k ] = dyn_ode_pv2( t, y ) */
  /*  */
  /*    DYN_ODE_PV2 evaluates the position-velocity derivative. */
  /*  */
  /*    The position-velocity derivative is evaluated with ballistic-only  */
  /*    acceleration from a rudimentary WGS84/EGM96 J2 gravity model.  */
  /*  */
  /*    The gravity model is valid only for state positions outside the earth's */
  /*    atmosphere. */
  /*     */
  /*    /input/ */
  /*       t ( real )           : independent variable value; */
  /*       y ( real[ 6 ][ n ] ) : dependent variable value; */
  /*  */
  /*    /output/ */
  /*       k ( real[ 6 ][ n ] ) : final dependent variable value; */
  /*         */
  /*    /history/ */
  /*       2008.11.19 : jdc : initial release */
  /*  */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* % CONSTANTS */
  /*  WGS84 parameters */
  /*  semi-major axis (m) */
  /*  gravitational parameter w/ atmosphere (m**3/s**3) */
  /*  J2 zonal gravitational harmonic */
  /* % EVALUATION */
  /*  ---- initialization ---- */
  for (eml_i5 = 0; eml_i5 < 13; eml_i5++) {
    for (eml_i6 = 0; eml_i6 < 6; eml_i6++) {
      eml_k[eml_i6 + 6 * eml_i5] = 0.0;
    }
  }

  /*  ---- position derivative ---- */
  /*  (d/dt)(r) = v; */
  for (eml_i5 = 0; eml_i5 < 13; eml_i5++) {
    eml_k[6 * eml_i5] = eml_y[3 + 6 * eml_i5];
  }

  for (eml_i5 = 0; eml_i5 < 13; eml_i5++) {
    eml_k[1 + 6 * eml_i5] = eml_y[4 + 6 * eml_i5];
  }

  for (eml_i5 = 0; eml_i5 < 13; eml_i5++) {
    eml_k[2 + 6 * eml_i5] = eml_y[5 + 6 * eml_i5];
  }

  /*  ---- velocity deriviative ---- */
  for (eml_i5 = 0; eml_i5 < 13; eml_i5++) {
    eml_d1 = (pow(eml_y[6 * eml_i5], 2.0) + pow(eml_y[1 + 6 * eml_i5], 2.0)) +
      pow(eml_y[2 + 6 * eml_i5], 2.0);
    eml_d2 = -3.986004418E+014 / eml_d1 / sqrt(eml_d1);
    eml_d3 = 6.6063097365039955E+010 / eml_d1;
    eml_d1 = 5.0 * eml_y[2 + 6 * eml_i5] * eml_y[2 + 6 * eml_i5] / eml_d1;

    /*  g = [ c2 * (1 + c3 * (1 - c4)) * x ; */
    /*        c2 * (1 + c3 * (1 - c4)) * y ; */
    /*        c2 * (1 + c3 * (3 - c4)) * z ] */
    eml_a[eml_i5] = eml_d2 * ((1.0 + eml_d3) - eml_d3 * eml_d1);
    eml_y_0[eml_i5] = eml_d2;
    eml_y_1[eml_i5] = eml_d3;
    eml_c4[eml_i5] = eml_d1;
  }

  /*  (d/dt)(v) = a = g; */
  for (eml_i5 = 0; eml_i5 < 13; eml_i5++) {
    eml_k[3 + 6 * eml_i5] = eml_a[eml_i5] * eml_y[6 * eml_i5];
  }

  for (eml_i5 = 0; eml_i5 < 13; eml_i5++) {
    eml_k[4 + 6 * eml_i5] = eml_a[eml_i5] * eml_y[1 + 6 * eml_i5];
  }

  for (eml_i5 = 0; eml_i5 < 13; eml_i5++) {
    eml_k[5 + 6 * eml_i5] = eml_y_0[eml_i5] * ((1.0 + 3.0 * eml_y_1[eml_i5]) -
      eml_y_1[eml_i5] * eml_c4[eml_i5]) * eml_y[2 + 6 * eml_i5];
  }

  /*  DYN_ODE_PV2 */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
}

/* Initial conditions for atomic system: '<Root>/PROPBENCH' */
void filterbench_ukf_PROPBENCH_Init(rtDW_PROPBENCH_filterbench_ukf *localDW)
{
  /* Initialize code for chart: '<Root>/PROPBENCH' */
  localDW->icng_not_empty = false;
  localDW->method = 0U;
  localDW->v4_state = 1144108930U;
}

/* Output and update for atomic system: '<Root>/PROPBENCH' */
void filterbench_ukf_PROPBENCH(real_T rtu_0, real_T rtu_1,
  rtB_PROPBENCH_filterbench_ukf *localB, rtDW_PROPBENCH_filterbench_ukf *localDW)
{
  /* Embedded MATLAB: '<Root>/PROPBENCH' */
  {
    int32_T eml_j;
    static real_T eml_dv0[6] = { 0.0, 0.0, 0.0, 0.25, 0.25, 0.25 };

    real_T eml_v[6];
    int32_T eml_i0;
    real_T eml_a[36];
    real_T eml_Q[36];
    static uint16_T eml_uv0[36] = { 40000U, 0U, 0U, 0U, 0U, 0U, 0U, 40000U, 0U,
      0U, 0U, 0U, 0U, 0U, 40000U, 0U, 0U, 0U, 0U, 0U, 0U, 1U, 0U, 0U, 0U, 0U, 0U,
      0U, 1U, 0U, 0U, 0U, 0U, 0U, 0U, 1U };

    real_T eml_ii;
    real_T eml_tii;
    static int32_T eml_iv0[6] = { 7600000, 0, 0, 1000, 7000, 0 };

    real_T eml_dv1[6];
    real_T eml_Pii[36];
    static real_T eml_dv2[36] = { 40000.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 40000.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 40000.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0 };

    /* Embedded MATLAB Function 'PROPBENCH': '<S2>:1' */
    /*  ---- propagation parameters ---- */
    /* '<S2>:1:5' */
    for (eml_j = 0; eml_j < 6; eml_j++) {
      eml_v[eml_j] = eml_dv0[eml_j] * rtu_1;
      for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
        eml_a[eml_i0 + 6 * eml_j] = 0.0;
      }

      eml_a[eml_j + 6 * eml_j] = eml_v[eml_j];
    }

    for (eml_j = 0; eml_j < 36; eml_j++) {
      eml_Q[eml_j] = pow(eml_a[eml_j], 2.0);
    }

    /*  ---- generate base initial state ---- */
    /* '<S2>:1:8' */
    /* '<S2>:1:12' */
    for (eml_j = 0; eml_j < 6; eml_j++) {
      for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
        eml_a[eml_i0 + 6 * eml_j] = (real_T)eml_uv0[eml_i0 + 6 * eml_j];
      }
    }

    refp1_aaaiglfknglfecjm_chol(eml_a);

    /*  ---- propagate states ----  */
    /* '<S2>:1:15' */
    for (eml_j = 0; eml_j < 6; eml_j++) {
      localB->xk[eml_j] = 0.0;

      /* '<S2>:1:16' */
      for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
        localB->Pk[eml_i0 + 6 * eml_j] = 0.0;
      }
    }

    for (eml_ii = 1.0; eml_ii <= rtu_0; eml_ii++) {
      /* '<S2>:1:18' */
      /* '<S2>:1:19' */
      filterbench_ukf_randn(eml_v, rtu_0, rtu_1, localB, localDW);

      /* '<S2>:1:21' */
      /* '<S2>:1:25' */
      for (eml_j = 0; eml_j < 6; eml_j++) {
        eml_tii = 0.0;
        for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
          eml_tii += eml_a[eml_j + 6 * eml_i0] * eml_v[eml_i0];
        }

        eml_dv1[eml_j] = (real_T)eml_iv0[eml_j] + eml_tii;
      }

      filterbench_ukf_fil_ukf_propagate(eml_Q, eml_dv1, eml_dv2, 0.0, rtu_1,
        eml_v, eml_Pii, &eml_tii);

      /* '<S2>:1:27' */
      for (eml_j = 0; eml_j < 6; eml_j++) {
        localB->xk[eml_j] = localB->xk[eml_j] + eml_v[eml_j] / rtu_0;

        /* '<S2>:1:28' */
        for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
          localB->Pk[eml_i0 + 6 * eml_j] = localB->Pk[eml_i0 + 6 * eml_j] +
            eml_Pii[eml_i0 + 6 * eml_j] / rtu_0;
        }
      }
    }

    /*  PROPBENCH */
  }
}

/* Functions for block: '<Root>/UPDTBENCH' */
static real_T filterbench_ukf_rand(real_T rtu_0, rtB_UPDTBENCH_filterbench_ukf
  *localB, rtDW_UPDTBENCH_filterbench_ukf *localDW)
{
  real_T eml_r;
  int32_T eml_mti;
  uint32_T eml_r_0;
  uint32_T eml_u[2];
  int32_T eml_j;
  uint32_T eml_y;
  if (localDW->method == 2) {
    if (!localDW->twister_state_not_empty) {
      for (eml_mti = 0; eml_mti < 625; eml_mti++) {
        localDW->twister_state[eml_mti] = 0U;
      }

      eml_r_0 = 5489U;
      localDW->twister_state[0] = 5489U;
      for (eml_mti = 2; eml_mti < 625; eml_mti++) {
        eml_r_0 = (eml_r_0 ^ eml_r_0 >> 30U) * 1812433253U + (uint32_T)(eml_mti
          - 1);
        localDW->twister_state[eml_mti - 1] = eml_r_0;
      }

      localDW->twister_state[624] = 624U;
      localDW->twister_state_not_empty = true;
    }

    do {
      for (eml_mti = 0; eml_mti < 2; eml_mti++) {
        eml_u[eml_mti] = 0U;
      }

      for (eml_j = 0; eml_j < 2; eml_j++) {
        eml_r_0 = localDW->twister_state[624] + 1U;
        if (eml_r_0 >= 625U) {
          for (eml_mti = 0; eml_mti < 227; eml_mti++) {
            eml_y = (localDW->twister_state[eml_mti] & 2147483648U) |
              (localDW->twister_state[eml_mti + 1] & 2147483647U);
            if ((eml_y & 1U) == 0U) {
              eml_r_0 = eml_y >> 1U;
            } else {
              eml_r_0 = eml_y >> 1U ^ 2567483615U;
            }

            localDW->twister_state[eml_mti] = localDW->twister_state[eml_mti +
              397] ^ eml_r_0;
          }

          for (eml_mti = 228; eml_mti < 624; eml_mti++) {
            eml_y = (localDW->twister_state[eml_mti - 1] & 2147483648U) |
              (localDW->twister_state[eml_mti] & 2147483647U);
            if ((eml_y & 1U) == 0U) {
              eml_r_0 = eml_y >> 1U;
            } else {
              eml_r_0 = eml_y >> 1U ^ 2567483615U;
            }

            localDW->twister_state[eml_mti - 1] = localDW->twister_state[eml_mti
              - 228] ^ eml_r_0;
          }

          eml_y = (localDW->twister_state[623] & 2147483648U) |
            (localDW->twister_state[0] & 2147483647U);
          if ((eml_y & 1U) == 0U) {
            eml_r_0 = eml_y >> 1U;
          } else {
            eml_r_0 = eml_y >> 1U ^ 2567483615U;
          }

          localDW->twister_state[623] = localDW->twister_state[396] ^ eml_r_0;
          eml_r_0 = 1U;
        }

        eml_y = localDW->twister_state[(int32_T)eml_r_0 - 1];
        localDW->twister_state[624] = eml_r_0;
        eml_y ^= eml_y >> 11U;
        eml_y ^= eml_y << 7U & 2636928640U;
        eml_y ^= eml_y << 15U & 4022730752U;
        eml_y ^= eml_y >> 18U;
        eml_u[eml_j] = eml_y;
      }

      eml_u[0] >>= 5U;
      eml_u[1] >>= 6U;
      eml_r = 1.1102230246251565E-016 * ((real_T)eml_u[0] * 6.7108864E+007 +
        (real_T)eml_u[1]);
    } while (!(eml_r != 0.0));
  } else {
    eml_r_0 = (boolean_T)0 ? MAX_uint32_T : (uint32_T)(localDW->v4_state /
      127773U);
    eml_y = 16807U * (localDW->v4_state - eml_r_0 * 127773U);
    eml_r_0 *= 2836U;
    if (eml_y < eml_r_0) {
      localDW->v4_state = (2147483647U - eml_r_0) + eml_y;
    } else {
      localDW->v4_state = eml_y - eml_r_0;
    }

    return (real_T)localDW->v4_state * 4.6566128752457969E-010;
  }

  return eml_r;
}

static void filterbench_ukf_randn_d(real_T eml_r[2], real_T rtu_0,
  rtB_UPDTBENCH_filterbench_ukf *localB, rtDW_UPDTBENCH_filterbench_ukf *localDW)
{
  int32_T eml_k;
  uint32_T eml_i;
  int32_T eml_j;
  static real_T eml_dv5[65] = { 0.340945, 0.4573146, 0.5397793, 0.6062427,
    0.6631691, 0.7136975, 0.7596125, 0.8020356, 0.8417227, 0.8792102, 0.9148948,
    0.9490791, 0.9820005, 1.0138492, 1.044781, 1.0749254, 1.1043917, 1.1332738,
    1.161653, 1.189601, 1.2171815, 1.2444516, 1.2714635, 1.298265, 1.3249008,
    1.3514125, 1.3778399, 1.4042211, 1.4305929, 1.4569915, 1.4834527, 1.5100122,
    1.5367061, 1.5635712, 1.5906454, 1.617968, 1.6455802, 1.6735255, 1.7018503,
    1.7306045, 1.7598422, 1.7896223, 1.8200099, 1.851077, 1.8829044, 1.9155831,
    1.9492166, 1.9839239, 2.0198431, 2.0571356, 2.095993, 2.136645, 2.1793713,
    2.2245175, 2.2725186, 2.3239338, 2.3795008, 2.4402218, 2.5075117, 2.5834658,
    2.6713916, 2.7769942, 2.7769942, 2.7769942, 2.7769942 };

  real_T eml_vtj;
  real_T eml_vtjp1;
  real_T eml_x;
  real_T eml_absr;
  real_T eml_s;
  uint32_T eml_jsr;
  uint32_T eml_state;
  for (eml_k = 0; eml_k < 2; eml_k++) {
    eml_r[eml_k] = 0.0;
  }

  if (localDW->method_i == 0) {
    if (!localDW->icng_not_empty) {
      localDW->icng = 362436069U;
      localDW->icng_not_empty = true;
      localDW->jsr = 521288629U;
    }

    for (eml_k = 0; eml_k < 2; eml_k++) {
      localDW->icng = 69069U * localDW->icng + 1234567U;
      localDW->jsr = localDW->jsr ^ localDW->jsr << 13U;
      localDW->jsr = localDW->jsr ^ localDW->jsr >> 17U;
      localDW->jsr = localDW->jsr ^ localDW->jsr << 5U;
      eml_i = localDW->icng + localDW->jsr;
      eml_j = (int32_T)(eml_i & 63U);
      eml_vtj = eml_dv5[eml_j];
      eml_vtjp1 = eml_dv5[eml_j + 1];
      eml_x = (real_T)(int32_T)eml_i * 4.6566128730773926E-010 * eml_vtjp1;
      eml_absr = fabs(eml_x);
      if (!(eml_absr <= eml_vtj)) {
        eml_vtj = (eml_absr - eml_vtj) / (eml_vtjp1 - eml_vtj);
        localDW->icng = 69069U * localDW->icng + 1234567U;
        localDW->jsr = localDW->jsr ^ localDW->jsr << 13U;
        localDW->jsr = localDW->jsr ^ localDW->jsr >> 17U;
        localDW->jsr = localDW->jsr ^ localDW->jsr << 5U;
        eml_absr = 0.5 + (real_T)(int32_T)(localDW->icng + localDW->jsr) *
          2.3283064365386960E-010;
        eml_s = eml_vtj + eml_absr;
        if (eml_s > 1.301198) {
          if (eml_x < 0.0) {
            eml_x = 0.4878992 * eml_vtj - 0.4878992;
          } else {
            eml_x = 0.4878992 - 0.4878992 * eml_vtj;
          }
        } else {
          if (!(eml_s <= 0.9689279)) {
            eml_vtj = 0.4878992 - 0.4878992 * eml_vtj;
            if (eml_absr > 12.67706 - 12.37586 * exp(-0.5 * eml_vtj * eml_vtj))
            {
              if (eml_x < 0.0) {
                eml_x = -eml_vtj;
              } else {
                eml_x = eml_vtj;
              }
            } else {
              if (!(exp(-0.5 * eml_vtjp1 * eml_vtjp1) + eml_absr * 0.01958303 /
                    eml_vtjp1 <= exp(-0.5 * eml_x * eml_x))) {
                do {
                  eml_i = 69069U * localDW->icng + 1234567U;
                  eml_jsr = localDW->jsr ^ localDW->jsr << 13U;
                  eml_jsr ^= eml_jsr >> 17U;
                  eml_jsr ^= eml_jsr << 5U;
                  eml_vtj = log(0.5 + (real_T)(int32_T)(eml_i + eml_jsr) *
                                2.3283064365386960E-010) / 2.776994;
                  localDW->icng = 69069U * eml_i + 1234567U;
                  localDW->jsr = eml_jsr ^ eml_jsr << 13U;
                  localDW->jsr = localDW->jsr ^ localDW->jsr >> 17U;
                  localDW->jsr = localDW->jsr ^ localDW->jsr << 5U;
                } while (!(-2.0 * log(0.5 + (real_T)(int32_T)(localDW->icng +
                            localDW->jsr) * 2.3283064365386960E-010) > eml_vtj *
                           eml_vtj));

                if (eml_x < 0.0) {
                  eml_x = eml_vtj - 2.776994;
                } else {
                  eml_x = 2.776994 - eml_vtj;
                }
              }
            }
          }
        }
      }

      eml_r[eml_k] = eml_x;
    }
  } else {
    for (eml_k = 0; eml_k < 2; eml_k++) {
      do {
        eml_i = (boolean_T)0 ? MAX_uint32_T : (uint32_T)(localDW->v4_state_o /
          127773U);
        eml_jsr = 16807U * (localDW->v4_state_o - eml_i * 127773U);
        eml_i *= 2836U;
        if (eml_jsr < eml_i) {
          eml_state = (2147483647U - eml_i) + eml_jsr;
        } else {
          eml_state = eml_jsr - eml_i;
        }

        eml_i = (boolean_T)0 ? MAX_uint32_T : (uint32_T)(eml_state / 127773U);
        eml_jsr = 16807U * (eml_state - eml_i * 127773U);
        eml_i *= 2836U;
        if (eml_jsr < eml_i) {
          localDW->v4_state_o = (2147483647U - eml_i) + eml_jsr;
        } else {
          localDW->v4_state_o = eml_jsr - eml_i;
        }

        eml_vtj = 2.0 * ((real_T)eml_state * 4.6566128752457969E-010) - 1.0;
        eml_absr = 2.0 * ((real_T)localDW->v4_state_o * 4.6566128752457969E-010)
          - 1.0;
        eml_absr = eml_absr * eml_absr + eml_vtj * eml_vtj;
      } while (!(eml_absr <= 1.0));

      eml_vtj *= sqrt(-2.0 * log(eml_absr) / eml_absr);
      eml_r[eml_k] = eml_vtj;
    }
  }
}

static void filterbench_ukf_fil_ukf_update(real_T eml_B[4], real_T eml_x[6],
  real_T eml_P[36], real_T eml_z[2], real_T eml_R[4], real_T eml_s[6], real_T
  eml_T[9], real_T eml_xk[6], real_T eml_Pk[36])
{
  int32_T eml_i0;
  int32_T eml_ii;
  real_T eml_L[36];
  real_T eml_Xi[78];
  real_T eml_x_0;
  real_T eml_Xi_0[13];
  real_T eml_Yi[26];
  static real_T eml_dv6[78] = { 3.3333333333333331E-001, 3.3333333333333331E-001,
    3.3333333333333331E-001, 3.3333333333333331E-001, 3.3333333333333331E-001,
    3.3333333333333331E-001, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002 };

  real_T eml_Xi_1[78];
  real_T eml_ux[6];
  static real_T eml_dv7[26] = { 3.3333333333333331E-001, 3.3333333333333331E-001,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002 };

  real_T eml_Yi_0[26];
  real_T eml_uy[2];
  static real_T eml_dv8[26] = { 3.3333333333333326E-001, 3.3333333333333326E-001,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002 };

  int32_T eml_i1;
  real_T eml_S[4];
  real_T eml_hoistedExpr[4];
  static real_T eml_dv9[4] = { 1.0, 0.0, 0.0, 1.0 };

  static real_T eml_dv10[78] = { 3.3333333333333326E-001,
    3.3333333333333326E-001, 3.3333333333333326E-001, 3.3333333333333326E-001,
    3.3333333333333326E-001, 3.3333333333333326E-001, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002, 5.5555555555555552E-002,
    5.5555555555555552E-002, 5.5555555555555552E-002 };

  real_T eml_Xi_2[12];
  real_T eml_K[12];
  real_T eml_z_0[2];

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Sensitivity: !SENSITIVITY! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  !COPYRIGHT! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* FIL_UKF_UPDATE : Unscented Kalman Filter update */
  /*    [ xk, Pk ] = fil_ukf_update( f, B, x, P, z, R, s, T ) */
  /*  */
  /*    FIL_UKF_UPDATE performs the Unscented Kalman Filter update step. */
  /*     */
  /*    /input/ */
  /*       f ( function )         : function handle to observer model; */
  /*       B ( real[ m1 ][ m1 ] ) : additive independent observer noise; */
  /*       x ( real[ m1 ] )       : system state mean vector; */
  /*       P ( real[ m1 ][ m1 ] ) : system state covariance matrix; */
  /*       z ( real[ m2 ] )       : measurement state mean vector; */
  /*       R ( real[ m2 ][ m2 ] ) : measurement state covariance matrix; */
  /*       s ( real[ m1 ] )       : observer state vector; */
  /*       T ( real[ 3 ][ 3 ] )   : observer state direction cosine matrix; */
  /*  */
  /*    /output/ */
  /*       xk ( real[ m1 ] )       : updated system state mean vector; */
  /*       Pk ( real[ m1 ][ m1 ] ) : updated system state covariance matrix; */
  /*         */
  /*    /history/ */
  /*       2008.11.19 : jdc : initial release */
  /*  */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* % CONSTANTS */
  /*  Scaled Unscented Transform parameters */
  /* % UPDATE */
  /*  ---- initialize weights ---- */
  /*  ---- generate sigma points ---- */
  for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
    for (eml_ii = 0; eml_ii < 6; eml_ii++) {
      eml_L[eml_ii + 6 * eml_i0] = eml_P[eml_ii + 6 * eml_i0] * 9.0;
    }
  }

  refp1_aaaiglfknglfecjm_chol(eml_L);
  for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
    eml_Xi[eml_i0] = 0.0;
  }

  for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
    for (eml_ii = 0; eml_ii < 6; eml_ii++) {
      eml_Xi[eml_ii + 6 * (eml_i0 + 1)] = eml_L[eml_ii + 6 * eml_i0];
    }
  }

  for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
    for (eml_ii = 0; eml_ii < 6; eml_ii++) {
      eml_Xi[eml_ii + 6 * (eml_i0 + 7)] = -eml_L[eml_ii + 6 * eml_i0];
    }
  }

  for (eml_ii = 0; eml_ii < 6; eml_ii++) {
    eml_x_0 = eml_x[eml_ii];
    for (eml_i0 = 0; eml_i0 < 13; eml_i0++) {
      eml_Xi_0[eml_i0] = eml_Xi[eml_ii + 6 * eml_i0] + eml_x_0;
    }

    for (eml_i0 = 0; eml_i0 < 13; eml_i0++) {
      eml_Xi[eml_ii + 6 * eml_i0] = eml_Xi_0[eml_i0];
    }
  }

  /*  ---- project sigma points---- */
  filterbench_ukf_fil_mdl_ir1(eml_Xi, eml_s, eml_T, eml_Yi);

  /*  ---- collect statistics ---- */
  for (eml_i0 = 0; eml_i0 < 13; eml_i0++) {
    for (eml_ii = 0; eml_ii < 6; eml_ii++) {
      eml_Xi_1[eml_ii + 6 * eml_i0] = eml_Xi[eml_ii + 6 * eml_i0] *
        eml_dv6[eml_ii + 6 * eml_i0];
    }
  }

  aiekimopecjeoppp_sum(eml_Xi_1, eml_ux);
  for (eml_ii = 0; eml_ii < 6; eml_ii++) {
    eml_x_0 = eml_ux[eml_ii];
    for (eml_i0 = 0; eml_i0 < 13; eml_i0++) {
      eml_Xi_0[eml_i0] = eml_Xi[eml_ii + 6 * eml_i0] - eml_x_0;
    }

    for (eml_i0 = 0; eml_i0 < 13; eml_i0++) {
      eml_Xi[eml_ii + 6 * eml_i0] = eml_Xi_0[eml_i0];
    }
  }

  for (eml_i0 = 0; eml_i0 < 13; eml_i0++) {
    for (eml_ii = 0; eml_ii < 2; eml_ii++) {
      eml_Yi_0[eml_ii + (eml_i0 << 1)] = eml_Yi[eml_ii + (eml_i0 << 1)] *
        eml_dv7[eml_ii + (eml_i0 << 1)];
    }
  }

  jecjglnoohlfnoph_sum(eml_Yi_0, eml_uy);
  for (eml_ii = 0; eml_ii < 2; eml_ii++) {
    eml_x_0 = eml_uy[eml_ii];
    for (eml_i0 = 0; eml_i0 < 13; eml_i0++) {
      eml_Xi_0[eml_i0] = eml_Yi[eml_ii + (eml_i0 << 1)] - eml_x_0;
    }

    for (eml_i0 = 0; eml_i0 < 13; eml_i0++) {
      eml_Yi[eml_ii + (eml_i0 << 1)] = eml_Xi_0[eml_i0];
    }
  }

  /*  ---- calculate gain ---- */
  for (eml_i0 = 0; eml_i0 < 13; eml_i0++) {
    for (eml_ii = 0; eml_ii < 2; eml_ii++) {
      eml_Yi_0[eml_ii + (eml_i0 << 1)] = eml_Yi[eml_ii + (eml_i0 << 1)] *
        eml_dv8[eml_ii + (eml_i0 << 1)];
    }
  }

  for (eml_i0 = 0; eml_i0 < 2; eml_i0++) {
    for (eml_ii = 0; eml_ii < 2; eml_ii++) {
      eml_x_0 = 0.0;
      for (eml_i1 = 0; eml_i1 < 13; eml_i1++) {
        eml_x_0 += eml_Yi_0[eml_i0 + (eml_i1 << 1)] * eml_Yi[eml_ii + (eml_i1 <<
          1)];
      }

      eml_S[eml_i0 + (eml_ii << 1)] = (eml_x_0 + eml_R[eml_i0 + (eml_ii << 1)])
        + eml_B[eml_i0 + (eml_ii << 1)];
    }
  }

  ekngjmglgdbiohln_mrdivide(eml_dv9, eml_S, eml_hoistedExpr);
  for (eml_i0 = 0; eml_i0 < 13; eml_i0++) {
    for (eml_ii = 0; eml_ii < 6; eml_ii++) {
      eml_Xi_1[eml_ii + 6 * eml_i0] = eml_Xi[eml_ii + 6 * eml_i0] *
        eml_dv10[eml_ii + 6 * eml_i0];
    }
  }

  for (eml_i1 = 0; eml_i1 < 6; eml_i1++) {
    for (eml_i0 = 0; eml_i0 < 2; eml_i0++) {
      eml_Xi_2[eml_i1 + 6 * eml_i0] = 0.0;
      for (eml_ii = 0; eml_ii < 13; eml_ii++) {
        eml_Xi_2[eml_i1 + 6 * eml_i0] += eml_Xi_1[eml_i1 + 6 * eml_ii] *
          eml_Yi[eml_i0 + (eml_ii << 1)];
      }
    }

    for (eml_i0 = 0; eml_i0 < 2; eml_i0++) {
      eml_K[eml_i1 + 6 * eml_i0] = 0.0;
      for (eml_ii = 0; eml_ii < 2; eml_ii++) {
        eml_K[eml_i1 + 6 * eml_i0] += eml_Xi_2[eml_i1 + 6 * eml_ii] *
          eml_hoistedExpr[eml_ii + (eml_i0 << 1)];
      }
    }
  }

  /*  ---- finalize state ---- */
  for (eml_i0 = 0; eml_i0 < 2; eml_i0++) {
    eml_z_0[eml_i0] = eml_z[eml_i0] - eml_uy[eml_i0];
  }

  for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
    eml_x_0 = 0.0;
    for (eml_ii = 0; eml_ii < 2; eml_ii++) {
      eml_x_0 += eml_K[eml_i0 + 6 * eml_ii] * eml_z_0[eml_ii];
    }

    eml_xk[eml_i0] = eml_x[eml_i0] + eml_x_0;
  }

  for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
    for (eml_ii = 0; eml_ii < 2; eml_ii++) {
      eml_Xi_2[eml_i0 + 6 * eml_ii] = 0.0;
      for (eml_i1 = 0; eml_i1 < 2; eml_i1++) {
        eml_Xi_2[eml_i0 + 6 * eml_ii] += eml_K[eml_i0 + 6 * eml_i1] *
          eml_S[eml_i1 + (eml_ii << 1)];
      }
    }
  }

  for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
    for (eml_ii = 0; eml_ii < 6; eml_ii++) {
      eml_x_0 = 0.0;
      for (eml_i1 = 0; eml_i1 < 2; eml_i1++) {
        eml_x_0 += eml_Xi_2[eml_i0 + 6 * eml_i1] * eml_K[eml_ii + 6 * eml_i1];
      }

      eml_Pk[eml_i0 + 6 * eml_ii] = eml_P[eml_i0 + 6 * eml_ii] - eml_x_0;
    }
  }

  /*  FIL_UKF_UPDATE */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
}

static void filterbench_ukf_fil_mdl_ir1(real_T eml_x[78], real_T eml_s[6],
  real_T eml_T[9], real_T eml_z[26])
{
  int32_T eml_k;
  int32_T eml_ixstart;
  real_T eml_obj_r[39];
  real_T eml_sen_r[3];
  real_T eml_sen_r_0;
  real_T eml_obj_r_0[13];
  real_T eml_r[39];
  int32_T eml_i;
  int32_T eml_k_0;

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Sensitivity: !SENSITIVITY! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  !COPYRIGHT! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* FIL_MDL_IR1 : generic IR sensor observer model */
  /*    [ z ] = fil_ukf_update( x, s, T ) */
  /*  */
  /*    FIL_MDL_IR1 provides an observer model for a generic IR sensor. */
  /*     */
  /*    /input/ */
  /*       x ( real[ m ][ n ] ) : system state vector; */
  /*       s ( real[ m ] )      : observer state vector; */
  /*       T ( real[ 3 ][ 3 ] ) : observer state direction cosine matrix; */
  /*  */
  /*    /output/ */
  /*       z ( real[ 2 ][ n ] ) : observed system state vector; */
  /*         */
  /*    /history/ */
  /*       2008.11.19 : jdc : initial release */
  /*  */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* % PROJECTION */
  /*  ---- extract positions ---- */
  for (eml_k = 0; eml_k < 13; eml_k++) {
    for (eml_ixstart = 0; eml_ixstart < 3; eml_ixstart++) {
      eml_obj_r[eml_ixstart + 3 * eml_k] = eml_x[eml_ixstart + 6 * eml_k];
    }
  }

  for (eml_k = 0; eml_k < 3; eml_k++) {
    eml_sen_r[eml_k] = eml_s[eml_k];
  }

  /*  ---- transform to sensor frame ---- */
  eml_sen_r_0 = eml_sen_r[0];
  for (eml_k = 0; eml_k < 13; eml_k++) {
    eml_obj_r_0[eml_k] = eml_obj_r[3 * eml_k] - eml_sen_r_0;
  }

  for (eml_k = 0; eml_k < 13; eml_k++) {
    eml_obj_r[3 * eml_k] = eml_obj_r_0[eml_k];
  }

  eml_sen_r_0 = eml_sen_r[1];
  for (eml_k = 0; eml_k < 13; eml_k++) {
    eml_obj_r_0[eml_k] = eml_obj_r[1 + 3 * eml_k] - eml_sen_r_0;
  }

  for (eml_k = 0; eml_k < 13; eml_k++) {
    eml_obj_r[1 + 3 * eml_k] = eml_obj_r_0[eml_k];
  }

  eml_sen_r_0 = eml_sen_r[2];
  for (eml_k = 0; eml_k < 13; eml_k++) {
    eml_obj_r_0[eml_k] = eml_obj_r[2 + 3 * eml_k] - eml_sen_r_0;
  }

  for (eml_k = 0; eml_k < 13; eml_k++) {
    eml_obj_r[2 + 3 * eml_k] = eml_obj_r_0[eml_k];
  }

  for (eml_k = 0; eml_k < 3; eml_k++) {
    for (eml_ixstart = 0; eml_ixstart < 13; eml_ixstart++) {
      eml_r[eml_k + 3 * eml_ixstart] = 0.0;
      for (eml_i = 0; eml_i < 3; eml_i++) {
        eml_r[eml_k + 3 * eml_ixstart] += eml_T[eml_k + 3 * eml_i] *
          eml_obj_r[eml_i + 3 * eml_ixstart];
      }
    }
  }

  /*  ---- transform to sensor coordinate system (spherical) ---- */
  for (eml_k = 0; eml_k < 39; eml_k++) {
    eml_obj_r[eml_k] = pow(eml_r[eml_k], 2.0);
  }

  for (eml_k = 0; eml_k < 13; eml_k++) {
    eml_obj_r_0[eml_k] = 0.0;
  }

  eml_ixstart = 0;
  eml_k = 0;
  for (eml_i = 0; eml_i < 13; eml_i++) {
    eml_ixstart++;
    eml_sen_r_0 = eml_obj_r[eml_ixstart - 1];
    for (eml_k_0 = 2; eml_k_0 < 4; eml_k_0++) {
      eml_ixstart++;
      eml_sen_r_0 += eml_obj_r[eml_ixstart - 1];
    }

    eml_k++;
    eml_obj_r_0[eml_k - 1] = eml_sen_r_0;
  }

  for (eml_k = 0; eml_k < 13; eml_k++) {
    /*  ---- project to sensor state space ---- */
    eml_z[eml_k << 1] = rt_atan2(eml_r[1 + 3 * eml_k], eml_r[3 * eml_k]);
    eml_z[1 + (eml_k << 1)] = asin(eml_r[2 + 3 * eml_k] / sqrt(eml_obj_r_0[eml_k]));
  }

  /*  FIL_MDL_IR1 */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
}

/* Initial conditions for atomic system: '<Root>/UPDTBENCH' */
void filterbench_ukf_UPDTBENCH_Init(rtDW_UPDTBENCH_filterbench_ukf *localDW)
{
  /* Initialize code for chart: '<Root>/UPDTBENCH' */
  localDW->twister_state_not_empty = false;
  localDW->icng_not_empty = false;
  localDW->method = 2U;
  localDW->v4_state = 1144108930U;
  localDW->method_i = 0U;
  localDW->v4_state_o = 1144108930U;
}

/* Output and update for atomic system: '<Root>/UPDTBENCH' */
void filterbench_ukf_UPDTBENCH(real_T rtu_0, rtB_UPDTBENCH_filterbench_ukf
  *localB, rtDW_UPDTBENCH_filterbench_ukf *localDW)
{
  /* Embedded MATLAB: '<Root>/UPDTBENCH' */
  {
    real_T eml_a;
    int32_T eml_j;
    real_T eml_v[2];
    int32_T eml_Coffset;
    real_T eml_a_0[4];
    real_T eml_B[4];
    real_T eml_R0[4];
    real_T eml_L0[4];
    int32_T eml_colj;
    int32_T eml_j_0;
    int32_T eml_exitg1;
    int32_T eml_jm1;
    int32_T eml_jj;
    int32_T eml_br;
    int32_T eml_cr;
    int32_T eml_jjp1;
    int32_T eml_coljp1;
    int32_T eml_loop_ub;
    int32_T eml_ic;
    real_T eml_temp;
    int32_T eml_w;
    real_T eml_dv0[2];
    real_T eml_Pii[36];
    real_T eml_xii[6];
    static real_T eml_dv1[9] = { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0 };

    static real_T eml_dv2[6] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };

    static real_T eml_dv3[36] = { 40000.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 40000.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 40000.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0 };

    static real_T eml_dv4[6] = { 1000.0, 0.0, 0.0, 0.0, 0.0, 0.0 };

    /* Embedded MATLAB Function 'UPDTBENCH': '<S3>:1' */
    /*  ---- update parameters ---- */
    /* '<S3>:1:4' */
    eml_a = filterbench_ukf_rand(rtu_0, localB, localDW);
    eml_a *= 0.001;

    /* '<S3>:1:9' */
    for (eml_j = 0; eml_j < 2; eml_j++) {
      eml_v[eml_j] = eml_a;
      for (eml_Coffset = 0; eml_Coffset < 2; eml_Coffset++) {
        eml_a_0[eml_Coffset + (eml_j << 1)] = 0.0;
      }

      eml_a_0[eml_j + (eml_j << 1)] = eml_v[eml_j];
    }

    for (eml_j = 0; eml_j < 4; eml_j++) {
      eml_B[eml_j] = pow(eml_a_0[eml_j], 2.0);
    }

    /* '<S3>:1:11' */
    /* '<S3>:1:12' */
    for (eml_j = 0; eml_j < 2; eml_j++) {
      eml_v[eml_j] = 1.5 * eml_a;
      for (eml_Coffset = 0; eml_Coffset < 2; eml_Coffset++) {
        eml_a_0[eml_Coffset + (eml_j << 1)] = 0.0;
      }

      eml_a_0[eml_j + (eml_j << 1)] = eml_v[eml_j];
    }

    for (eml_j = 0; eml_j < 4; eml_j++) {
      eml_R0[eml_j] = pow(eml_a_0[eml_j], 2.0);
    }

    /* '<S3>:1:14' */
    for (eml_j = 0; eml_j < 2; eml_j++) {
      for (eml_Coffset = 0; eml_Coffset < 2; eml_Coffset++) {
        eml_L0[eml_Coffset + (eml_j << 1)] = eml_R0[eml_Coffset + (eml_j << 1)];
      }
    }

    eml_colj = 1;
    eml_j_0 = 1;
    eml_exitg1 = 0U;
    while ((eml_exitg1 == 0U) && (eml_j_0 < 3)) {
      eml_jm1 = eml_j_0 - 1;
      eml_jj = eml_colj + eml_jm1;
      eml_a = 0.0;
      if (!(eml_jm1 < 1)) {
        eml_j = eml_colj;
        eml_br = eml_colj;
        for (eml_cr = 1; eml_cr <= 1; eml_cr = 2) {
          eml_a += eml_L0[eml_j - 1] * eml_L0[eml_br - 1];
          eml_br++;
          eml_j++;
        }
      }

      eml_a = eml_L0[eml_jj - 1] - eml_a;
      if (eml_a <= 0.0) {
        eml_L0[eml_jj - 1] = eml_a;
        eml_exitg1 = 1U;
      } else {
        eml_a = sqrt(eml_a);
        eml_L0[eml_jj - 1] = eml_a;
        if (eml_j_0 < 2) {
          eml_jjp1 = eml_jj + 2;
          eml_coljp1 = eml_colj + 2;
          for (eml_j = 0; eml_j < 2; eml_j++) {
            for (eml_Coffset = 0; eml_Coffset < 2; eml_Coffset++) {
              eml_a_0[eml_Coffset + (eml_j << 1)] = eml_L0[eml_Coffset + (eml_j <<
                1)];
            }
          }

          if (!(eml_jm1 == 0)) {
            eml_Coffset = eml_jjp1 - 1;
            eml_j = eml_colj - 1;
            eml_br = eml_coljp1 - 1;
            for (eml_cr = eml_Coffset; eml_cr <= eml_Coffset; eml_cr += 2) {
              eml_colj = eml_j;
              eml_loop_ub = eml_cr + 1;
              for (eml_ic = eml_cr + 1; eml_ic <= eml_loop_ub; eml_ic++) {
                eml_temp = 0.0;
                for (eml_w = 1; eml_w <= eml_jm1; eml_w = 2) {
                  eml_temp += eml_a_0[eml_colj] * eml_a_0[eml_br];
                }

                eml_L0[eml_ic - 1] += -1.0 * eml_temp;
                eml_colj += 2;
              }

              eml_br += 2;
            }
          }

          eml_a = 1.0 / eml_a;
          for (eml_j = eml_jjp1; eml_j <= eml_jjp1; eml_j += 2) {
            eml_L0[eml_j - 1] *= eml_a;
          }

          eml_colj = eml_coljp1;
          eml_L0[eml_jj] = 0.0;
        }

        eml_j_0++;
      }
    }

    /*  ---- generate base initial state ---- */
    /*  ---- update states ----  */
    /* '<S3>:1:21' */
    for (eml_j = 0; eml_j < 6; eml_j++) {
      localB->xk[eml_j] = 0.0;

      /* '<S3>:1:22' */
      for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
        localB->Pk[eml_Coffset + 6 * eml_j] = 0.0;
      }
    }

    for (eml_a = 1.0; eml_a <= rtu_0; eml_a++) {
      /* '<S3>:1:24' */
      /* '<S3>:1:25' */
      filterbench_ukf_randn_d(eml_v, rtu_0, localB, localDW);

      /* '<S3>:1:27' */
      /* '<S3>:1:30' */
      for (eml_j = 0; eml_j < 2; eml_j++) {
        eml_temp = 0.0;
        for (eml_Coffset = 0; eml_Coffset < 2; eml_Coffset++) {
          eml_temp += eml_L0[eml_j + (eml_Coffset << 1)] * eml_v[eml_Coffset];
        }

        eml_dv0[eml_j] = eml_temp;
      }

      filterbench_ukf_fil_ukf_update(eml_B, eml_dv4, eml_dv3, eml_dv0, eml_R0,
        eml_dv2, eml_dv1, eml_xii, eml_Pii);

      /* '<S3>:1:32' */
      for (eml_j = 0; eml_j < 6; eml_j++) {
        localB->xk[eml_j] = localB->xk[eml_j] + eml_xii[eml_j] / rtu_0;

        /* '<S3>:1:33' */
        for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
          localB->Pk[eml_Coffset + 6 * eml_j] = localB->Pk[eml_Coffset + 6 *
            eml_j] + eml_Pii[eml_Coffset + 6 * eml_j] / rtu_0;
        }
      }
    }

    /*  UPDTBENCH */
  }
}

/* Model step function */
void filterbench_ukf_step(BlockIO_filterbench_ukf *filterbench_ukf_B,
  D_Work_filterbench_ukf *filterbench_ukf_DWork, ExternalInputs_filterbench_ukf *
  filterbench_ukf_U, ExternalOutputs_filterbench_ukf *filterbench_ukf_Y)
{
  {
    int32_T i;
    filterbench_ukf_PROPBENCH(filterbench_ukf_U->propbench_n,
      filterbench_ukf_U->propbench_dt, &filterbench_ukf_B->sf_PROPBENCH,
      &filterbench_ukf_DWork->sf_PROPBENCH);
    for (i = 0; i < 6; i++) {
      /* Outport: '<Root>/propbench_xk' */
      filterbench_ukf_Y->propbench_xk[i] = filterbench_ukf_B->sf_PROPBENCH.xk[i];
    }

    for (i = 0; i < 36; i++) {
      /* Outport: '<Root>/propbench_Pk' */
      filterbench_ukf_Y->propbench_Pk[i] = filterbench_ukf_B->sf_PROPBENCH.Pk[i];
    }

    filterbench_ukf_UPDTBENCH(filterbench_ukf_U->updtbench_n,
      &filterbench_ukf_B->sf_UPDTBENCH, &filterbench_ukf_DWork->sf_UPDTBENCH);
    for (i = 0; i < 6; i++) {
      /* Outport: '<Root>/updtbench_xk' */
      filterbench_ukf_Y->updtbench_xk[i] = filterbench_ukf_B->sf_UPDTBENCH.xk[i];
    }

    for (i = 0; i < 36; i++) {
      /* Outport: '<Root>/updtbench_Pk' */
      filterbench_ukf_Y->updtbench_Pk[i] = filterbench_ukf_B->sf_UPDTBENCH.Pk[i];
    }
  }
}

/* Model initialize function */
void filterbench_ukf_initialize(D_Work_filterbench_ukf *filterbench_ukf_DWork,
  ExternalInputs_filterbench_ukf *filterbench_ukf_U,
  ExternalOutputs_filterbench_ukf *filterbench_ukf_Y)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));
  filterbench_ukf_PROPBENCH_Init(&filterbench_ukf_DWork->sf_PROPBENCH);
  filterbench_ukf_UPDTBENCH_Init(&filterbench_ukf_DWork->sf_UPDTBENCH);
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
