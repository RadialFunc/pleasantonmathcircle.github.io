/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *filterbench_ukf_private.h
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/
/*
 * File: filterbench_ukf_private.h
 *
 * Real-Time Workshop code generated for Simulink model filterbench_ukf.
 *
 * Model version                        : 1.227
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Jan 29 15:12:41 2009
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Jan 29 15:12:42 2009
 */
#ifndef RTW_HEADER_filterbench_ukf_private_h_
#define RTW_HEADER_filterbench_ukf_private_h_
#include "rtwtypes.h"
#include "rtlibsrc.h"
#define CALL_EVENT                     (MAX_uint8_T)
#ifndef __RTWTYPES_H__
#error This file requires rtwtypes.h to be included
#else
#ifdef TMWTYPES_PREVIOUSLY_INCLUDED
#error This file requires rtwtypes.h to be included before tmwtypes.h
#else

/* Check for inclusion of an incorrect version of rtwtypes.h */
#ifndef RTWTYPES_ID_C08S16I32L32N32F1
#error This code was generated with a different "rtwtypes.h" than the file included
#endif                                 /* RTWTYPES_ID_C08S16I32L32N32F1 */
#endif                                 /* TMWTYPES_PREVIOUSLY_INCLUDED */
#endif                                 /* __RTWTYPES_H__ */

/*
 * UNUSED_PARAMETER(x)
 *   Used to specify that a function parameter (argument) is required but not
 *   accessed by the function body.
 */
#ifndef UNUSED_PARAMETER
# if defined(__LCC__)
#   define UNUSED_PARAMETER(x)                                   /* do nothing */
# else

/*
 * This is the semi-ANSI standard way of indicating that an
 * unused function parameter is required.
 */
#   define UNUSED_PARAMETER(x)         (void) (x)
# endif
#endif

void filterbench_ukf_PROPBENCH_Init(rtDW_PROPBENCH_filterbench_ukf *localDW);
void filterbench_ukf_PROPBENCH(real_T rtu_0, real_T rtu_1,
  rtB_PROPBENCH_filterbench_ukf *localB, rtDW_PROPBENCH_filterbench_ukf *localDW);
void filterbench_ukf_UPDTBENCH_Init(rtDW_UPDTBENCH_filterbench_ukf *localDW);
void filterbench_ukf_UPDTBENCH(real_T rtu_0, rtB_UPDTBENCH_filterbench_ukf
  *localB, rtDW_UPDTBENCH_filterbench_ukf *localDW);

#endif                                 /* RTW_HEADER_filterbench_ukf_private_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
