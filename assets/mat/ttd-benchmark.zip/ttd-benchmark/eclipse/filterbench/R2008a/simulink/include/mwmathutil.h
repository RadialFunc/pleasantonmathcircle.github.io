#if defined(_MSC_VER) || __GNUC__ > 3 || (__GNUC__ == 3 && __GNUC_MINOR__ > 3)
#pragma once
#endif

#ifndef mwmathutil_h
#define mwmathutil_h

/* Copyright 2003-2007 The MathWorks, Inc. */

/* Only define EXTERN_C if it hasn't been defined already. This allows
 * individual modules to have more control over managing their exports.
 */
#ifndef EXTERN_C

#ifdef __cplusplus
  #define EXTERN_C extern "C"
#else
  #define EXTERN_C extern
#endif

#endif


#ifdef __WATCOMC__
#pragma aux muDoubleScalarAbs value [8087];
#pragma aux muDoubleScalarCeil value [8087];
#pragma aux muDoubleScalarFloor value [8087];
#pragma aux muDoubleScalarRound value [8087];
#pragma aux muDoubleScalarAcos value [8087];
#pragma aux muDoubleScalarAcosh value [8087];
#pragma aux muDoubleScalarAsin value [8087];
#pragma aux muDoubleScalarAsinh value [8087];
#pragma aux muDoubleScalarAtan value [8087];
#pragma aux muDoubleScalarAtanh value [8087];
#pragma aux muDoubleScalarCos value [8087];
#pragma aux muDoubleScalarCosh value [8087];
#pragma aux muDoubleScalarExp value [8087];
#pragma aux muDoubleScalarLog value [8087];
#pragma aux muDoubleScalarLog10 value [8087];
#pragma aux muDoubleScalarAtan2 value [8087]
#pragma aux muDoubleScalarMax value [8087]
#pragma aux muDoubleScalarMin value [8087]
#pragma aux muDoubleScalarPower value [8087]
#pragma aux muDoubleScalarSin value [8087];
#pragma aux muDoubleScalarSign value [8087];
#pragma aux muDoubleScalarSinh value [8087];
#pragma aux muDoubleScalarSqrt value [8087];
#pragma aux muDoubleScalarTan value [8087];
#pragma aux muDoubleScalarTanh value [8087];
#pragma aux muDoubleScalarMod value [8087]
#pragma aux muDoubleScalarRem value [8087]
#pragma aux muDoubleScalarHypot value [8087];
#endif


/* abs(a) */
EXTERN_C double muDoubleScalarAbs(double a);


/* ceil(a) */
EXTERN_C double muDoubleScalarCeil(double a);


/* floor(a) */
EXTERN_C double muDoubleScalarFloor(double a);


/* round(a) */
EXTERN_C double muDoubleScalarRound(double a);


/* acos(a) */
EXTERN_C double muDoubleScalarAcos(double a);


/* acosh(a) */
EXTERN_C double muDoubleScalarAcosh(double a);


/* asin(a) */
EXTERN_C double muDoubleScalarAsin(double a);


/* asinh(a) */
EXTERN_C double muDoubleScalarAsinh(double a);


/* atan(a) */
EXTERN_C double muDoubleScalarAtan(double a);


/* atanh(a) */
EXTERN_C double muDoubleScalarAtanh(double a);


/* cos(a) */
EXTERN_C double muDoubleScalarCos(double a);


/* cosh(a) */
EXTERN_C double muDoubleScalarCosh(double a);


/* exp(a) */	
EXTERN_C double muDoubleScalarExp(double a);


/* log */
/*A warning 'Log of zero' should be issued by users for a = 0 */
EXTERN_C double muDoubleScalarLog(double a);


/* log10 */
/*A warning 'Log of zero' should be issued by users for a = 0 */
EXTERN_C double muDoubleScalarLog10(double a);


/* atan2(a,b) */
EXTERN_C double muDoubleScalarAtan2(double a, double b);


/* max(a,b) */
EXTERN_C double muDoubleScalarMax(double a, double b);


/* min(a,b) */
EXTERN_C double muDoubleScalarMin(double a, double b);


/* power(a,b) */
EXTERN_C double muDoubleScalarPower(double a, double b);


/* sin(a) */
EXTERN_C double muDoubleScalarSin(double a);


/* sign(a) */
EXTERN_C double muDoubleScalarSign(double a);


/* sinh(a) */
EXTERN_C double muDoubleScalarSinh(double a);


/* sqrt(a) */
EXTERN_C double muDoubleScalarSqrt(double a);


/* tan(a) */
EXTERN_C double muDoubleScalarTan(double a);


/* tanh(a) */
EXTERN_C double muDoubleScalarTanh(double a);


/* mod(a,b) */
EXTERN_C double muDoubleScalarMod(double a, double b);


/* rem(a,b) */
EXTERN_C double muDoubleScalarRem(double a, double b);


/* hypot(a,b) */
EXTERN_C double muDoubleScalarHypot(double a,double b);

#endif /* mwmathutil_h */
