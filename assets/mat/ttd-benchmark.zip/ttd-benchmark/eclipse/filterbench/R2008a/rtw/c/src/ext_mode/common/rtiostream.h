/*
 * Copyright 2007 The MathWorks, Inc.
 *
 * File: rtiostream.h     $Revision: 1.1.10.1 $
 *
 * Abstract:
 *  Function prototypes and defines for rtIOStream API.
 */

#define RTIOSTREAM_ERROR -1

int rtIOStreamOpen(
    const int   argc,
    void      * argv[]
);

int rtIOStreamSend(
    const int      streamID,
    const void   * src, 
    const size_t   size,
    size_t       * sizeSent
    );

int rtIOStreamRecv(
    const int      streamID,
    void         * dst, 
    const size_t   size,
    size_t       * sizeRecvd
    );

int rtIOStreamClose(
    const int streamID
);

