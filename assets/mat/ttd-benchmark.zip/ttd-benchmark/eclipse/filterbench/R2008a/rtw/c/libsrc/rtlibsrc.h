#ifndef rtlibsrc_h
#define rtlibsrc_h

/* Copyright 1994-2007 The MathWorks, Inc.
 *
 * File    : rtlibsrc.h
 * Abstract:
 *      Function prototypes for .c sources in rtw/c/libsrc.
 *
 */

/* $Revision: 1.54.4.22 $ */

/*==========*
 * Includes *
 *==========*/

#include "rtwtypes.h"
#include <limits.h>

#ifdef __cplusplus
extern "C" {
#endif


/*=========*
 * Asserts *
 *=========*/
#ifndef utAssert 
# if defined(DOASSERTS)
#  if !defined(PRINT_ASSERTS)
#    include <assert.h>
#    define utAssert(exp)  assert(exp)
#  else
     static void _assert(char *statement, char *file, int line)
     {
        printf("%s in %s on line %d\n", statement, file, line);
     }
#   define utAssert(_EX) ((_EX) ? (void)0 : _assert(#_EX, __FILE__, __LINE__))
#  endif
# else
#  define utAssert(exp) /* do nothing */
# endif
#endif

#define rt_MAX(u1,u2) ( ((u1)   >= (u2)) ? (u1)                        : (u2)   )
#define rt_MIN(u1,u2) ( ((u1)   <= (u2)) ? (u1)                        : (u2)   )

#define rt_FSGN(u1)   ( ((u1)   >= 0.0F) ? ((u1) > 0.0F ? 1.0F : 0.0F) : -1.0F  )

#ifdef __cplusplus
}
#endif

#endif /* rtlibsrc_h */
