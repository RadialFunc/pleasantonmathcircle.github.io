/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *d:\data\jdchan\My Documents\MATLAB\filterbench\mdl\run\slprj\ert\_sharedutils\refp1_aaaiglfknglfecjm_chol.h
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/
/*
 * File: d:\data\jdchan\My Documents\MATLAB\filterbench\mdl\run\slprj\ert\_sharedutils\refp1_aaaiglfknglfecjm_chol.h
 *
 * Real-Time Workshop code generated for Simulink model filterbench.
 *
 * Model version                        : 1.225
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Jan 29 15:12:22 2009
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Jan 29 15:12:22 2009
 */
#ifndef SHARE_refp1_aaaiglfknglfecjm_chol
#define SHARE_refp1_aaaiglfknglfecjm_chol

extern void refp1_aaaiglfknglfecjm_chol(real_T eml_A[36]);

#endif

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
