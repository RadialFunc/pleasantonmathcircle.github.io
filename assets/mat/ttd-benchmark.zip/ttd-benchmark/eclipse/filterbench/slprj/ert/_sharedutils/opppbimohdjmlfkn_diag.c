/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *d:\data\jdchan\My Documents\MATLAB\filterbench\mdl\run\slprj\ert\_sharedutils\opppbimohdjmlfkn_diag.c
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/
/*
 * File: d:\data\jdchan\My Documents\MATLAB\filterbench\mdl\run\slprj\ert\_sharedutils\opppbimohdjmlfkn_diag.c
 *
 * Real-Time Workshop code generated for Simulink model filterbench_ekf.
 *
 * Model version                        : 1.225
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Jan 29 15:12:58 2009
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Jan 29 15:12:59 2009
 */
#include "rtwtypes.h"
#include "rt_nonfinite.h"
#include "rtw_shared_utils.h"

void opppbimohdjmlfkn_diag(real_T eml_v[2], real_T eml_d[4])
{
  int32_T eml_i0;
  int32_T eml_i1;
  for (eml_i0 = 0; eml_i0 < 2; eml_i0++) {
    for (eml_i1 = 0; eml_i1 < 2; eml_i1++) {
      eml_d[eml_i1 + (eml_i0 << 1)] = 0.0;
    }

    eml_d[eml_i0 + (eml_i0 << 1)] = eml_v[eml_i0];
  }
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
