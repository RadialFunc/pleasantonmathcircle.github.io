/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *rt_atan2.h
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/
/*
 * File: rt_atan2.h
 *
 * Real-Time Workshop code generated for Simulink model filterbench.
 *
 * Model version                        : 1.225
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Jan 29 15:12:22 2009
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Jan 29 15:12:22 2009
 */
#ifndef RTW_HEADER_rt_atan2_h_
#define RTW_HEADER_rt_atan2_h_
#include <math.h>
#include "rtwtypes.h"
#include "rt_nonfinite.h"

extern real_T rt_atan2(real_T a, real_T b);
extern real32_T rt_atan232(real32_T a, real32_T b);

#endif                                 /* RTW_HEADER_rt_atan2_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
