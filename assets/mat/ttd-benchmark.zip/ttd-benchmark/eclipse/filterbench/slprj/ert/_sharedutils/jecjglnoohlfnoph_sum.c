/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *d:\data\jdchan\My Documents\MATLAB\filterbench\mdl\run\slprj\ert\_sharedutils\jecjglnoohlfnoph_sum.c
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/
/*
 * File: d:\data\jdchan\My Documents\MATLAB\filterbench\mdl\run\slprj\ert\_sharedutils\jecjglnoohlfnoph_sum.c
 *
 * Real-Time Workshop code generated for Simulink model filterbench.
 *
 * Model version                        : 1.225
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Jan 29 15:12:22 2009
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Jan 29 15:12:22 2009
 */
#include "rtwtypes.h"
#include <math.h>
#include "rt_nonfinite.h"
#include "rtw_shared_utils.h"

void jecjglnoohlfnoph_sum(real_T eml_x[26], real_T eml_y[2])
{
  int32_T eml_iy;
  int32_T eml_ixstart;
  int32_T eml_j;
  int32_T eml_ix;
  real_T eml_s;
  int32_T eml_k;
  for (eml_iy = 0; eml_iy < 2; eml_iy++) {
    eml_y[eml_iy] = 0.0;
  }

  eml_iy = 0;
  eml_ixstart = 0;
  for (eml_j = 0; eml_j < 2; eml_j++) {
    eml_ixstart++;
    eml_ix = eml_ixstart;
    eml_s = eml_x[eml_ixstart - 1];
    for (eml_k = 2; eml_k < 14; eml_k++) {
      eml_ix += 2;
      eml_s += eml_x[eml_ix - 1];
    }

    eml_iy++;
    eml_y[eml_iy - 1] = eml_s;
  }
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
