/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *d:\data\jdchan\My Documents\MATLAB\filterbench\mdl\run\slprj\ert\_sharedutils\ekngjmglgdbiohln_mrdivide.c
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/
/*
 * File: d:\data\jdchan\My Documents\MATLAB\filterbench\mdl\run\slprj\ert\_sharedutils\ekngjmglgdbiohln_mrdivide.c
 *
 * Real-Time Workshop code generated for Simulink model filterbench.
 *
 * Model version                        : 1.225
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Jan 29 15:12:22 2009
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Jan 29 15:12:22 2009
 */
#include "rtwtypes.h"
#include <math.h>
#include "rt_nonfinite.h"
#include "rtw_shared_utils.h"
#include <math.h>

void ekngjmglgdbiohln_mrdivide(real_T eml_A[4], real_T eml_B[4], real_T eml_y[4])
{
  int32_T eml_a;
  int32_T eml_ix;
  real_T eml_A_0[4];
  static int8_T eml_iv0[2] = { 1, 2 };

  int8_T eml_ipiv[2];
  int32_T eml_ix_0;
  real_T eml_x;
  real_T eml_Y[4];
  int32_T eml_kAcol;
  int32_T eml_i;
  int32_T eml_i_0;
  for (eml_a = 0; eml_a < 2; eml_a++) {
    for (eml_ix = 0; eml_ix < 2; eml_ix++) {
      eml_A_0[eml_ix + (eml_a << 1)] = eml_B[eml_a + (eml_ix << 1)];
    }

    eml_ipiv[eml_a] = eml_iv0[eml_a];
  }

  eml_a = 1;
  if (fabs(eml_A_0[1]) > fabs(eml_A_0[0])) {
    eml_a = 2;
  }

  eml_a--;
  if (eml_A_0[eml_a] != 0.0) {
    if (eml_a != 0) {
      eml_ipiv[0] = (int8_T)(1 + eml_a);
      eml_ix = 1;
      eml_a++;
      for (eml_ix_0 = 0; eml_ix_0 < 2; eml_ix_0++) {
        eml_x = eml_A_0[eml_ix - 1];
        eml_A_0[eml_ix - 1] = eml_A_0[eml_a - 1];
        eml_A_0[eml_a - 1] = eml_x;
        eml_a += 2;
        eml_ix += 2;
      }
    }

    eml_A_0[1] /= eml_A_0[0];
  }

  eml_x = eml_A_0[2];
  if (eml_x != 0.0) {
    eml_x *= -1.0;
    eml_A_0[3] += eml_A_0[1] * eml_x;
  }

  for (eml_a = 0; eml_a < 2; eml_a++) {
    for (eml_ix = 0; eml_ix < 2; eml_ix++) {
      eml_Y[eml_ix + (eml_a << 1)] = eml_A[eml_a + (eml_ix << 1)];
    }
  }

  for (eml_a = 0; eml_a < 2; eml_a++) {
    if (eml_ipiv[eml_a] != eml_a + 1) {
      eml_ix_0 = (int32_T)eml_ipiv[eml_a];
      for (eml_ix = 0; eml_ix < 2; eml_ix++) {
        eml_x = eml_Y[eml_a + (eml_ix << 1)];
        eml_Y[eml_a + (eml_ix << 1)] = eml_Y[(eml_ix_0 - 1) + (eml_ix << 1)];
        eml_Y[(eml_ix_0 - 1) + (eml_ix << 1)] = eml_x;
      }
    }
  }

  for (eml_a = 0; eml_a < 2; eml_a++) {
    eml_ix_0 = eml_a << 1;
    for (eml_ix = 0; eml_ix < 2; eml_ix++) {
      eml_kAcol = eml_ix << 1;
      if (eml_Y[((eml_ix + 1) + eml_ix_0) - 1] != 0.0) {
        for (eml_i = eml_ix + 2; eml_i <= 2; eml_i = 3) {
          eml_Y[eml_ix_0 + 1] -= eml_Y[((eml_ix + 1) + eml_ix_0) - 1] *
            eml_A_0[eml_kAcol + 1];
        }
      }
    }
  }

  for (eml_a = 0; eml_a < 2; eml_a++) {
    eml_ix_0 = eml_a << 1;
    for (eml_ix = 2; eml_ix > 0; eml_ix += -1) {
      eml_kAcol = (eml_ix - 1) << 1;
      if (eml_Y[(eml_ix + eml_ix_0) - 1] != 0.0) {
        eml_Y[(eml_ix + eml_ix_0) - 1] /= eml_A_0[(eml_ix + eml_kAcol) - 1];
        eml_i = eml_ix - 1;
        for (eml_i_0 = 1; eml_i_0 <= eml_i; eml_i_0 = 2) {
          eml_Y[eml_ix_0] -= eml_Y[(eml_ix + eml_ix_0) - 1] * eml_A_0[eml_kAcol];
        }
      }
    }
  }

  for (eml_a = 0; eml_a < 2; eml_a++) {
    for (eml_ix = 0; eml_ix < 2; eml_ix++) {
      eml_y[eml_ix + (eml_a << 1)] = eml_Y[eml_a + (eml_ix << 1)];
    }
  }
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
