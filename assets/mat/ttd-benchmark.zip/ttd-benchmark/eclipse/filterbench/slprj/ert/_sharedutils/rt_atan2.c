/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *rt_atan2.c
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/
/*
 * File: rt_atan2.c
 *
 * Real-Time Workshop code generated for Simulink model filterbench.
 *
 * Model version                        : 1.225
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Jan 29 15:12:22 2009
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Jan 29 15:12:22 2009
 */
#include "rt_atan2.h"

/* Function: rt_atan2 =======================================================
 * Abstract:
 *   Calls ATAN2, with guards against domain error and non-finites
 */
real_T rt_atan2(real_T a, real_T b)
{
  real_T retValue;
  if (((boolean_T) rtIsNaN(a)) || ((boolean_T) rtIsNaN(b))) {
    retValue = rtNaN;
  } else {
    if (((boolean_T)rtIsInf(a)) && ((boolean_T)rtIsInf(b))) {
      if (b > 0.0) {
        b = 1.0;
      } else {
        b = -1.0;
      }

      if (a > 0.0) {
        a = 1.0;
      } else {
        a = -1.0;
      }

      retValue = atan2(a,b);
    } else if (b == 0.0) {
      if (a > 0.0) {
        retValue = 1.5707963267948966E+00;
      } else if (a < 0.0) {
        retValue = -1.5707963267948966E+00;
      } else {
        retValue = 0.0;
      }
    } else {
      retValue = atan2(a,b);
    }
  }

  return retValue;
}                                      /* end rt_atan2 */

/* Function: rt_atan232 =====================================================
 * Abstract:
 *   Calls single-precision version of ATAN2, with guard against domain error
 *   and guards against non-finites
 */
real32_T rt_atan232(real32_T a, real32_T b)
{
  real32_T retValue;
  if (((boolean_T) rtIsNaNF(a)) || ((boolean_T) rtIsNaNF(b))) {
    retValue = ((real32_T) rtNaN);
  } else {
    if (((boolean_T)rtIsInfF(a)) && ((boolean_T)rtIsInfF(b))) {
      if (b > 0.0F) {
        b = 1.0F;
      } else {
        b = -1.0F;
      }

      if (a > 0.0F) {
        a = 1.0F;
      } else {
        a = -1.0F;
      }

      retValue = (real32_T) atan2(a,b);
    } else if (b == 0.0F) {
      if (a > 0.0F) {
        retValue = 1.5707963267948966E+00F;
      } else if (a < 0.0F) {
        retValue = -1.5707963267948966E+00F;
      } else {
        retValue = 0.0F;
      }
    } else {
      retValue = (real32_T) atan2(a,b);
    }
  }

  return retValue;
}                                      /* end rt_atan232 */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
