/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *d:\data\jdchan\My Documents\MATLAB\filterbench\mdl\run\slprj\ert\_sharedutils\opppbimohdjmlfkn_diag.h
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/
/*
 * File: d:\data\jdchan\My Documents\MATLAB\filterbench\mdl\run\slprj\ert\_sharedutils\opppbimohdjmlfkn_diag.h
 *
 * Real-Time Workshop code generated for Simulink model filterbench_ekf.
 *
 * Model version                        : 1.225
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Jan 29 15:12:58 2009
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Jan 29 15:12:59 2009
 */
#ifndef SHARE_opppbimohdjmlfkn_diag
#define SHARE_opppbimohdjmlfkn_diag

extern void opppbimohdjmlfkn_diag(real_T eml_v[2], real_T eml_d[4]);

#endif

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
