/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *d:\data\jdchan\My Documents\MATLAB\filterbench\mdl\run\slprj\ert\_sharedutils\refp1_aaaiglfknglfecjm_chol.c
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/
/*
 * File: d:\data\jdchan\My Documents\MATLAB\filterbench\mdl\run\slprj\ert\_sharedutils\refp1_aaaiglfknglfecjm_chol.c
 *
 * Real-Time Workshop code generated for Simulink model filterbench.
 *
 * Model version                        : 1.225
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Jan 29 15:12:22 2009
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Jan 29 15:12:22 2009
 */
#include "rtwtypes.h"
#include <math.h>
#include "rtw_shared_utils.h"
#include <math.h>

void refp1_aaaiglfknglfecjm_chol(real_T eml_A[36])
{
  int32_T eml_colj;
  int32_T eml_j;
  int32_T eml_exitg1;
  int32_T eml_jm1;
  int32_T eml_jj;
  real_T eml_d;
  int32_T eml_j_0;
  int32_T eml_lastColC;
  int32_T eml_br;
  int32_T eml_nmj;
  int32_T eml_jjp1;
  int32_T eml_coljp1;
  int32_T eml_Coffset;
  real_T eml_A_0[36];
  int32_T eml_loop_ub;
  int32_T eml_ic;
  real_T eml_temp;
  int32_T eml_w;
  eml_colj = 1;
  eml_j = 1;
  eml_exitg1 = 0U;
  while ((eml_exitg1 == 0U) && (eml_j < 7)) {
    eml_jm1 = eml_j - 1;
    eml_jj = eml_colj + eml_jm1;
    eml_d = 0.0;
    if (!(eml_jm1 < 1)) {
      eml_j_0 = eml_colj;
      eml_lastColC = eml_colj;
      for (eml_br = 1; eml_br <= eml_jm1; eml_br++) {
        eml_d += eml_A[eml_j_0 - 1] * eml_A[eml_lastColC - 1];
        eml_lastColC++;
        eml_j_0++;
      }
    }

    eml_d = eml_A[eml_jj - 1] - eml_d;
    if (eml_d <= 0.0) {
      eml_A[eml_jj - 1] = eml_d;
      eml_exitg1 = 1U;
    } else {
      eml_d = sqrt(eml_d);
      eml_A[eml_jj - 1] = eml_d;
      if (eml_j < 6) {
        eml_nmj = 6 - eml_j;
        eml_jjp1 = eml_jj + 6;
        eml_coljp1 = eml_colj + 6;
        for (eml_j_0 = 0; eml_j_0 < 6; eml_j_0++) {
          for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
            eml_A_0[eml_Coffset + 6 * eml_j_0] = eml_A[eml_Coffset + 6 * eml_j_0];
          }
        }

        if (!(eml_jm1 == 0)) {
          eml_Coffset = eml_jjp1 - 1;
          eml_j_0 = eml_colj - 1;
          eml_lastColC = eml_Coffset + 6 * (eml_nmj - 1);
          eml_br = eml_coljp1 - 1;
          while (eml_Coffset <= eml_lastColC) {
            eml_colj = eml_j_0;
            eml_loop_ub = eml_Coffset + 1;
            for (eml_ic = eml_Coffset + 1; eml_ic <= eml_loop_ub; eml_ic++) {
              eml_temp = 0.0;
              for (eml_w = 1; eml_w <= eml_jm1; eml_w++) {
                eml_temp += eml_A_0[(eml_w + eml_colj) - 1] * eml_A_0[(eml_w +
                  eml_br) - 1];
              }

              eml_A[eml_ic - 1] += -1.0 * eml_temp;
              eml_colj += 6;
            }

            eml_br += 6;
            eml_Coffset += 6;
          }
        }

        eml_d = 1.0 / eml_d;
        eml_j_0 = eml_jjp1 + 6 * (eml_nmj - 1);
        while (eml_jjp1 <= eml_j_0) {
          eml_A[eml_jjp1 - 1] *= eml_d;
          eml_jjp1 += 6;
        }

        eml_colj = eml_coljp1;
        for (eml_j_0 = 1; eml_j_0 <= eml_nmj; eml_j_0++) {
          eml_A[(eml_jj + eml_j_0) - 1] = 0.0;
        }
      }

      eml_j++;
    }
  }
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
