/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *filterbench.h
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/
/*
 * File: filterbench.h
 *
 * Real-Time Workshop code generated for Simulink model filterbench.
 *
 * Model version                        : 1.225
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Jan 29 15:12:22 2009
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Jan 29 15:12:22 2009
 */
#ifndef RTW_HEADER_filterbench_h_
#define RTW_HEADER_filterbench_h_
#ifndef filterbench_COMMON_INCLUDES_
# define filterbench_COMMON_INCLUDES_
#include <stdlib.h>
#include <stddef.h>
#include <math.h>
#include "rtwtypes.h"
#include "rtw_shared_utils.h"
#include "rt_atan2.h"
#include "rt_nonfinite.h"
#endif                                 /* filterbench_COMMON_INCLUDES_ */

#include "filterbench_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((void*) 0)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((void) 0)
#endif

/* Block signals for system '<Root>/PROPBENCH' */
typedef struct {
  real_T xk[6];                        /* '<Root>/PROPBENCH' */
  real_T Pk[36];                       /* '<Root>/PROPBENCH' */
} rtB_PROPBENCH_filterbench;

/* Block states (auto storage) for system '<Root>/PROPBENCH' */
typedef struct {
  uint32_T icng;                       /* '<Root>/PROPBENCH' */
  uint32_T jsr;                        /* '<Root>/PROPBENCH' */
  uint32_T v4_state;                   /* '<Root>/PROPBENCH' */
  uint8_T method;                      /* '<Root>/PROPBENCH' */
  boolean_T icng_not_empty;            /* '<Root>/PROPBENCH' */
} rtDW_PROPBENCH_filterbench;

/* Block signals for system '<Root>/UPDTBENCH' */
typedef struct {
  real_T xk[6];                        /* '<Root>/UPDTBENCH' */
  real_T Pk[36];                       /* '<Root>/UPDTBENCH' */
} rtB_UPDTBENCH_filterbench;

/* Block states (auto storage) for system '<Root>/UPDTBENCH' */
typedef struct {
  uint32_T twister_state[625];         /* '<Root>/UPDTBENCH' */
  uint32_T v4_state;                   /* '<Root>/UPDTBENCH' */
  uint32_T icng;                       /* '<Root>/UPDTBENCH' */
  uint32_T jsr;                        /* '<Root>/UPDTBENCH' */
  uint32_T v4_state_j;                 /* '<Root>/UPDTBENCH' */
  uint8_T method;                      /* '<Root>/UPDTBENCH' */
  uint8_T method_a;                    /* '<Root>/UPDTBENCH' */
  boolean_T twister_state_not_empty;   /* '<Root>/UPDTBENCH' */
  boolean_T icng_not_empty;            /* '<Root>/UPDTBENCH' */
} rtDW_UPDTBENCH_filterbench;

/* Block signals (auto storage) */
typedef struct {
  rtB_UPDTBENCH_filterbench sf_UPDTBENCH;/* '<Root>/UPDTBENCH' */
  rtB_PROPBENCH_filterbench sf_PROPBENCH;/* '<Root>/PROPBENCH' */
} BlockIO_filterbench;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  rtDW_UPDTBENCH_filterbench sf_UPDTBENCH;/* '<Root>/UPDTBENCH' */
  rtDW_PROPBENCH_filterbench sf_PROPBENCH;/* '<Root>/PROPBENCH' */
} D_Work_filterbench;

/* External inputs (root inport signals with auto storage) */
typedef struct {
  real_T propbench_n;                  /* '<Root>/propbench_n' */
  real_T propbench_dt;                 /* '<Root>/propbench_dt' */
  real_T updtbench_n;                  /* '<Root>/updtbench_n' */
} ExternalInputs_filterbench;

/* External outputs (root outports fed by signals with auto storage) */
typedef struct {
  real_T propbench_xk[6];              /* '<Root>/propbench_xk' */
  real_T propbench_Pk[36];             /* '<Root>/propbench_Pk' */
  real_T updtbench_xk[6];              /* '<Root>/updtbench_xk' */
  real_T updtbench_Pk[36];             /* '<Root>/updtbench_Pk' */
} ExternalOutputs_filterbench;

/* Model entry point functions */
extern void filterbench_initialize(D_Work_filterbench *filterbench_DWork,
  ExternalInputs_filterbench *filterbench_U, ExternalOutputs_filterbench
  *filterbench_Y);
extern void filterbench_step(BlockIO_filterbench *filterbench_B,
  D_Work_filterbench *filterbench_DWork, ExternalInputs_filterbench
  *filterbench_U, ExternalOutputs_filterbench *filterbench_Y);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : filterbench
 * '<S1>'   : filterbench/Model Info
 * '<S2>'   : filterbench/PROPBENCH
 * '<S3>'   : filterbench/UPDTBENCH
 */
#endif                                 /* RTW_HEADER_filterbench_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
