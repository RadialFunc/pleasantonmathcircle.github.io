/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *filterbench_ekf.c
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/
/*
 * File: filterbench_ekf.c
 *
 * Real-Time Workshop code generated for Simulink model filterbench_ekf.
 *
 * Model version                        : 1.225
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Jan 29 15:12:58 2009
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Jan 29 15:12:59 2009
 */
#include "filterbench_ekf.h"
#include "filterbench_ekf_private.h"

static void filterbench_ekf_randn(real_T eml_r[6], real_T rtu_0, real_T rtu_1,
  rtB_PROPBENCH_filterbench_ekf *localB, rtDW_PROPBENCH_filterbench_ekf *localDW);
static void filterbench_ekf_fil_mdl_ballisticmid1(real_T eml_x[6], real_T eml_t,
  real_T eml_h, real_T eml_xk[6]);
static void filterbench_ekf_dyn_ode_pv2(real_T eml_y[6], real_T eml_k[6]);
static real_T filterbench_ekf_rand(real_T rtu_0, rtB_UPDTBENCH_filterbench_ekf
  *localB, rtDW_UPDTBENCH_filterbench_ekf *localDW);
static void filterbench_ekf_randn_e(real_T eml_r[2], real_T rtu_0,
  rtB_UPDTBENCH_filterbench_ekf *localB, rtDW_UPDTBENCH_filterbench_ekf *localDW);

/* Functions for block: '<Root>/PROPBENCH' */
static void filterbench_ekf_randn(real_T eml_r[6], real_T rtu_0, real_T rtu_1,
  rtB_PROPBENCH_filterbench_ekf *localB, rtDW_PROPBENCH_filterbench_ekf *localDW)
{
  int32_T eml_k;
  uint32_T eml_i;
  int32_T eml_j;
  static real_T eml_dv1[65] = { 0.340945, 0.4573146, 0.5397793, 0.6062427,
    0.6631691, 0.7136975, 0.7596125, 0.8020356, 0.8417227, 0.8792102, 0.9148948,
    0.9490791, 0.9820005, 1.0138492, 1.044781, 1.0749254, 1.1043917, 1.1332738,
    1.161653, 1.189601, 1.2171815, 1.2444516, 1.2714635, 1.298265, 1.3249008,
    1.3514125, 1.3778399, 1.4042211, 1.4305929, 1.4569915, 1.4834527, 1.5100122,
    1.5367061, 1.5635712, 1.5906454, 1.617968, 1.6455802, 1.6735255, 1.7018503,
    1.7306045, 1.7598422, 1.7896223, 1.8200099, 1.851077, 1.8829044, 1.9155831,
    1.9492166, 1.9839239, 2.0198431, 2.0571356, 2.095993, 2.136645, 2.1793713,
    2.2245175, 2.2725186, 2.3239338, 2.3795008, 2.4402218, 2.5075117, 2.5834658,
    2.6713916, 2.7769942, 2.7769942, 2.7769942, 2.7769942 };

  real_T eml_vtj;
  real_T eml_vtjp1;
  real_T eml_x;
  real_T eml_absr;
  real_T eml_s;
  uint32_T eml_jsr;
  uint32_T eml_state;
  for (eml_k = 0; eml_k < 6; eml_k++) {
    eml_r[eml_k] = 0.0;
  }

  if (localDW->method == 0) {
    if (!localDW->icng_not_empty) {
      localDW->icng = 362436069U;
      localDW->icng_not_empty = true;
      localDW->jsr = 521288629U;
    }

    for (eml_k = 0; eml_k < 6; eml_k++) {
      localDW->icng = 69069U * localDW->icng + 1234567U;
      localDW->jsr = localDW->jsr ^ localDW->jsr << 13U;
      localDW->jsr = localDW->jsr ^ localDW->jsr >> 17U;
      localDW->jsr = localDW->jsr ^ localDW->jsr << 5U;
      eml_i = localDW->icng + localDW->jsr;
      eml_j = (int32_T)(eml_i & 63U);
      eml_vtj = eml_dv1[eml_j];
      eml_vtjp1 = eml_dv1[eml_j + 1];
      eml_x = (real_T)(int32_T)eml_i * 4.6566128730773926E-010 * eml_vtjp1;
      eml_absr = fabs(eml_x);
      if (!(eml_absr <= eml_vtj)) {
        eml_vtj = (eml_absr - eml_vtj) / (eml_vtjp1 - eml_vtj);
        localDW->icng = 69069U * localDW->icng + 1234567U;
        localDW->jsr = localDW->jsr ^ localDW->jsr << 13U;
        localDW->jsr = localDW->jsr ^ localDW->jsr >> 17U;
        localDW->jsr = localDW->jsr ^ localDW->jsr << 5U;
        eml_absr = 0.5 + (real_T)(int32_T)(localDW->icng + localDW->jsr) *
          2.3283064365386960E-010;
        eml_s = eml_vtj + eml_absr;
        if (eml_s > 1.301198) {
          if (eml_x < 0.0) {
            eml_x = 0.4878992 * eml_vtj - 0.4878992;
          } else {
            eml_x = 0.4878992 - 0.4878992 * eml_vtj;
          }
        } else {
          if (!(eml_s <= 0.9689279)) {
            eml_vtj = 0.4878992 - 0.4878992 * eml_vtj;
            if (eml_absr > 12.67706 - 12.37586 * exp(-0.5 * eml_vtj * eml_vtj))
            {
              if (eml_x < 0.0) {
                eml_x = -eml_vtj;
              } else {
                eml_x = eml_vtj;
              }
            } else {
              if (!(exp(-0.5 * eml_vtjp1 * eml_vtjp1) + eml_absr * 0.01958303 /
                    eml_vtjp1 <= exp(-0.5 * eml_x * eml_x))) {
                do {
                  eml_i = 69069U * localDW->icng + 1234567U;
                  eml_jsr = localDW->jsr ^ localDW->jsr << 13U;
                  eml_jsr ^= eml_jsr >> 17U;
                  eml_jsr ^= eml_jsr << 5U;
                  eml_vtj = log(0.5 + (real_T)(int32_T)(eml_i + eml_jsr) *
                                2.3283064365386960E-010) / 2.776994;
                  localDW->icng = 69069U * eml_i + 1234567U;
                  localDW->jsr = eml_jsr ^ eml_jsr << 13U;
                  localDW->jsr = localDW->jsr ^ localDW->jsr >> 17U;
                  localDW->jsr = localDW->jsr ^ localDW->jsr << 5U;
                } while (!(-2.0 * log(0.5 + (real_T)(int32_T)(localDW->icng +
                            localDW->jsr) * 2.3283064365386960E-010) > eml_vtj *
                           eml_vtj));

                if (eml_x < 0.0) {
                  eml_x = eml_vtj - 2.776994;
                } else {
                  eml_x = 2.776994 - eml_vtj;
                }
              }
            }
          }
        }
      }

      eml_r[eml_k] = eml_x;
    }
  } else {
    for (eml_k = 0; eml_k < 6; eml_k++) {
      do {
        eml_i = (boolean_T)0 ? MAX_uint32_T : (uint32_T)(localDW->v4_state /
          127773U);
        eml_jsr = 16807U * (localDW->v4_state - eml_i * 127773U);
        eml_i *= 2836U;
        if (eml_jsr < eml_i) {
          eml_state = (2147483647U - eml_i) + eml_jsr;
        } else {
          eml_state = eml_jsr - eml_i;
        }

        eml_i = (boolean_T)0 ? MAX_uint32_T : (uint32_T)(eml_state / 127773U);
        eml_jsr = 16807U * (eml_state - eml_i * 127773U);
        eml_i *= 2836U;
        if (eml_jsr < eml_i) {
          localDW->v4_state = (2147483647U - eml_i) + eml_jsr;
        } else {
          localDW->v4_state = eml_jsr - eml_i;
        }

        eml_vtj = 2.0 * ((real_T)eml_state * 4.6566128752457969E-010) - 1.0;
        eml_absr = 2.0 * ((real_T)localDW->v4_state * 4.6566128752457969E-010) -
          1.0;
        eml_absr = eml_absr * eml_absr + eml_vtj * eml_vtj;
      } while (!(eml_absr <= 1.0));

      eml_vtj *= sqrt(-2.0 * log(eml_absr) / eml_absr);
      eml_r[eml_k] = eml_vtj;
    }
  }
}

static void filterbench_ekf_fil_mdl_ballisticmid1(real_T eml_x[6], real_T eml_t,
  real_T eml_h, real_T eml_xk[6])
{
  real_T eml_tk;
  int32_T eml_i0;
  real_T eml_xn[6];
  real_T eml_tn;
  real_T eml_b;
  real_T eml_hoistedExpr[6];
  real_T eml_d0;
  real_T eml_xn_0[6];
  real_T eml_hk1[6];
  real_T eml_hk2[6];
  real_T eml_hoistedExpr_0[6];

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Sensitivity: !SENSITIVITY! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  !COPYRIGHT! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* FIL_MDL_BALLISTICMID1 : generic midcourse ballistic process model */
  /*    [ xk ] = fil_mdl_ballisticmid( x, t, h ) */
  /*  */
  /*    FIL_MDL_BALLISTICMID1 provides a process model for a generic midcourse */
  /*    ballistic position-velocity state. */
  /*     */
  /*    /input/ */
  /*       x ( real[ m ][ n ] ) : system state vector; */
  /*       t ( real )           : system state time; */
  /*       h ( real )           : propagation time step; */
  /*  */
  /*    /output/ */
  /*       xk ( real[ m ][ n ] ) : propagated system state vector; */
  /*         */
  /*    /history/ */
  /*       2008.11.19 : jdc : initial release */
  /*  */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* % CONSTANTS */
  /*  propagation parameters */
  /* % PROPAGATION */
  /*  ---- initialize ---- */
  eml_tk = eml_t + eml_h;
  for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
    eml_xn[eml_i0] = eml_x[eml_i0];
  }

  eml_tn = eml_t;
  eml_b = eml_h;
  if (fabs(eml_h) > 1.0) {
    if ((boolean_T)rtIsNaN(eml_h)) {
      eml_b = rtNaN;
    } else if (eml_h > 0.0) {
      eml_b = 1.0;
    } else {
      if (eml_h < 0.0) {
        eml_b = -1.0;
      }
    }
  }

  /*  ---- iterate ---- */
  while (fabs(eml_tn + eml_b) < fabs(eml_tk)) {
    /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
    /*  Classification: UNCLASSIFIED */
    /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
    /*  Sensitivity: !SENSITIVITY! */
    /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
    /*  !COPYRIGHT! */
    /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
    /* NUM_ODE_RK4 : Runge-Kutta fourth order */
    /*    [ yn ] = num_ode_rk4( f, y0, t0, h0 ) */
    /*  */
    /*    NUM_ODE_RK4 uses a fourth order Runge-Kutta method to numerically  */
    /*    approximate the solution to an ordinary differential equation. */
    /*     */
    /*    /input/ */
    /*       f ( function )        : function handle to derivative function; */
    /*       y0 ( real[ m ][ n ] ) : initial dependent variable value; */
    /*       t0 ( real )           : initial independent variable value; */
    /*       h0 ( real )           : initial independent variable step size; */
    /*  */
    /*    /output/ */
    /*       yn ( real[ m ][ n ] ) : final dependent variable value; */
    /*         */
    /*    /history/ */
    /*       2008.11.19 : jdc : initial release */
    /*  */
    /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
    /* % CONSTANTS */
    /*  Butcher Tableau */
    /* % APPROXIMATION */
    filterbench_ekf_dyn_ode_pv2(eml_xn, eml_hoistedExpr);
    for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
      eml_d0 = eml_b * eml_hoistedExpr[eml_i0];
      eml_xn_0[eml_i0] = eml_xn[eml_i0] + 0.5 * eml_d0;
      eml_hk1[eml_i0] = eml_d0;
    }

    filterbench_ekf_dyn_ode_pv2(eml_xn_0, eml_hoistedExpr);
    for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
      eml_d0 = eml_b * eml_hoistedExpr[eml_i0];
      eml_xn_0[eml_i0] = eml_xn[eml_i0] + 0.5 * eml_d0;
      eml_hk2[eml_i0] = eml_d0;
    }

    filterbench_ekf_dyn_ode_pv2(eml_xn_0, eml_hoistedExpr);
    for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
      eml_d0 = eml_b * eml_hoistedExpr[eml_i0];
      eml_xn_0[eml_i0] = eml_xn[eml_i0] + eml_d0;
      eml_hoistedExpr[eml_i0] = eml_d0;
    }

    filterbench_ekf_dyn_ode_pv2(eml_xn_0, eml_hoistedExpr_0);
    for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
      eml_xn[eml_i0] = (((eml_xn[eml_i0] + 1.6666666666666666E-001 *
                          eml_hk1[eml_i0]) + 3.3333333333333331E-001 *
                         eml_hk2[eml_i0]) + 3.3333333333333331E-001 *
                        eml_hoistedExpr[eml_i0]) + 1.6666666666666666E-001 *
        (eml_b * eml_hoistedExpr_0[eml_i0]);
    }

    /*  NUM_ODE_RK4 */
    /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
    /*  Classification: UNCLASSIFIED */
    /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
    eml_tn += eml_b;
  }

  /*  ---- finalize ---- */
  eml_tk -= eml_tn;

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Sensitivity: !SENSITIVITY! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  !COPYRIGHT! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* NUM_ODE_RK4 : Runge-Kutta fourth order */
  /*    [ yn ] = num_ode_rk4( f, y0, t0, h0 ) */
  /*  */
  /*    NUM_ODE_RK4 uses a fourth order Runge-Kutta method to numerically  */
  /*    approximate the solution to an ordinary differential equation. */
  /*     */
  /*    /input/ */
  /*       f ( function )        : function handle to derivative function; */
  /*       y0 ( real[ m ][ n ] ) : initial dependent variable value; */
  /*       t0 ( real )           : initial independent variable value; */
  /*       h0 ( real )           : initial independent variable step size; */
  /*  */
  /*    /output/ */
  /*       yn ( real[ m ][ n ] ) : final dependent variable value; */
  /*         */
  /*    /history/ */
  /*       2008.11.19 : jdc : initial release */
  /*  */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* % CONSTANTS */
  /*  Butcher Tableau */
  /* % APPROXIMATION */
  filterbench_ekf_dyn_ode_pv2(eml_xn, eml_hoistedExpr);
  for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
    eml_d0 = eml_tk * eml_hoistedExpr[eml_i0];
    eml_xn_0[eml_i0] = eml_xn[eml_i0] + 0.5 * eml_d0;
    eml_hk1[eml_i0] = eml_d0;
  }

  filterbench_ekf_dyn_ode_pv2(eml_xn_0, eml_hoistedExpr);
  for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
    eml_d0 = eml_tk * eml_hoistedExpr[eml_i0];
    eml_xn_0[eml_i0] = eml_xn[eml_i0] + 0.5 * eml_d0;
    eml_hk2[eml_i0] = eml_d0;
  }

  filterbench_ekf_dyn_ode_pv2(eml_xn_0, eml_hoistedExpr);
  for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
    eml_d0 = eml_tk * eml_hoistedExpr[eml_i0];
    eml_xn_0[eml_i0] = eml_xn[eml_i0] + eml_d0;
    eml_hoistedExpr[eml_i0] = eml_d0;
  }

  filterbench_ekf_dyn_ode_pv2(eml_xn_0, eml_hoistedExpr_0);
  for (eml_i0 = 0; eml_i0 < 6; eml_i0++) {
    eml_xk[eml_i0] = (((eml_xn[eml_i0] + 1.6666666666666666E-001 *
                        eml_hk1[eml_i0]) + 3.3333333333333331E-001 *
                       eml_hk2[eml_i0]) + 3.3333333333333331E-001 *
                      eml_hoistedExpr[eml_i0]) + 1.6666666666666666E-001 *
      (eml_tk * eml_hoistedExpr_0[eml_i0]);
  }

  /*  NUM_ODE_RK4 */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  FIL_MDL_BALLISTICMID1 */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
}

static void filterbench_ekf_dyn_ode_pv2(real_T eml_y[6], real_T eml_k[6])
{
  real_T eml_c0;
  real_T eml_c2;
  real_T eml_c3;
  real_T eml_c5;

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Sensitivity: !SENSITIVITY! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  !COPYRIGHT! */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* DYN_ODE_PV2 : position-velocity derivative */
  /*    [ k ] = dyn_ode_pv2( t, y ) */
  /*  */
  /*    DYN_ODE_PV2 evaluates the position-velocity derivative. */
  /*  */
  /*    The position-velocity derivative is evaluated with ballistic-only  */
  /*    acceleration from a rudimentary WGS84/EGM96 J2 gravity model.  */
  /*  */
  /*    The gravity model is valid only for state positions outside the earth's */
  /*    atmosphere. */
  /*     */
  /*    /input/ */
  /*       t ( real )           : independent variable value; */
  /*       y ( real[ 6 ][ n ] ) : dependent variable value; */
  /*  */
  /*    /output/ */
  /*       k ( real[ 6 ][ n ] ) : final dependent variable value; */
  /*         */
  /*    /history/ */
  /*       2008.11.19 : jdc : initial release */
  /*  */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* % CONSTANTS */
  /*  WGS84 parameters */
  /*  semi-major axis (m) */
  /*  gravitational parameter w/ atmosphere (m**3/s**3) */
  /*  J2 zonal gravitational harmonic */
  /* % EVALUATION */
  /*  ---- initialization ---- */
  /*  ---- position derivative ---- */
  /*  (d/dt)(r) = v; */
  eml_k[0] = eml_y[3];
  eml_k[1] = eml_y[4];
  eml_k[2] = eml_y[5];

  /*  ---- velocity deriviative ---- */
  eml_c0 = (pow(eml_y[0], 2.0) + pow(eml_y[1], 2.0)) + pow(eml_y[2], 2.0);
  eml_c2 = -3.986004418E+014 / eml_c0 / sqrt(eml_c0);
  eml_c3 = 6.6063097365039955E+010 / eml_c0;
  eml_c0 = 5.0 * eml_y[2] * eml_y[2] / eml_c0;

  /*  g = [ c2 * (1 + c3 * (1 - c4)) * x ; */
  /*        c2 * (1 + c3 * (1 - c4)) * y ; */
  /*        c2 * (1 + c3 * (3 - c4)) * z ] */
  eml_c5 = eml_c2 * ((1.0 + eml_c3) - eml_c3 * eml_c0);

  /*  (d/dt)(v) = a = g; */
  eml_k[3] = eml_c5 * eml_y[0];
  eml_k[4] = eml_c5 * eml_y[1];
  eml_k[5] = eml_c2 * ((1.0 + 3.0 * eml_c3) - eml_c3 * eml_c0) * eml_y[2];

  /*  DYN_ODE_PV2 */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*  Classification: UNCLASSIFIED */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
}

/* Initial conditions for atomic system: '<Root>/PROPBENCH' */
void filterbench_ekf_PROPBENCH_Init(rtDW_PROPBENCH_filterbench_ekf *localDW)
{
  /* Initialize code for chart: '<Root>/PROPBENCH' */
  localDW->icng_not_empty = false;
  localDW->method = 0U;
  localDW->v4_state = 1144108930U;
}

/* Output and update for atomic system: '<Root>/PROPBENCH' */
void filterbench_ekf_PROPBENCH(real_T rtu_0, real_T rtu_1,
  rtB_PROPBENCH_filterbench_ekf *localB, rtDW_PROPBENCH_filterbench_ekf *localDW)
{
  /* Embedded MATLAB: '<Root>/PROPBENCH' */
  {
    int32_T eml_lastColC;
    static real_T eml_dv0[6] = { 0.0, 0.0, 0.0, 0.25, 0.25, 0.25 };

    real_T eml_v[6];
    int32_T eml_Coffset;
    real_T eml_a[36];
    int32_T eml_j;
    real_T eml_Q[36];
    static uint16_T eml_uv0[36] = { 40000U, 0U, 0U, 0U, 0U, 0U, 0U, 40000U, 0U,
      0U, 0U, 0U, 0U, 0U, 40000U, 0U, 0U, 0U, 0U, 0U, 0U, 1U, 0U, 0U, 0U, 0U, 0U,
      0U, 1U, 0U, 0U, 0U, 0U, 0U, 0U, 1U };

    real_T eml_L0[36];
    int32_T eml_colj;
    int32_T eml_j_0;
    int32_T eml_exitg1;
    int32_T eml_jm1;
    int32_T eml_jj;
    real_T eml_d;
    int32_T eml_br;
    int32_T eml_nmj;
    int32_T eml_jjp1;
    int32_T eml_coljp1;
    int32_T eml_loop_ub;
    int32_T eml_ic;
    real_T eml_temp;
    int32_T eml_w;
    real_T eml_ii;
    static int32_T eml_iv0[6] = { 7600000, 0, 0, 1000, 7000, 0 };

    real_T eml_x[6];
    real_T eml_x_0[3];
    real_T eml_c2;
    real_T eml_a_0[3];
    real_T eml_T[36];
    boolean_T eml_I[36];
    real_T eml_F[36];
    real_T eml_T_0[36];

    /* Embedded MATLAB Function 'PROPBENCH': '<S2>:1' */
    /*  ---- propagation parameters ---- */
    /* '<S2>:1:5' */
    for (eml_lastColC = 0; eml_lastColC < 6; eml_lastColC++) {
      eml_v[eml_lastColC] = eml_dv0[eml_lastColC] * rtu_1;
      for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
        eml_a[eml_Coffset + 6 * eml_lastColC] = 0.0;
      }

      eml_a[eml_lastColC + 6 * eml_lastColC] = eml_v[eml_lastColC];
    }

    for (eml_j = 0; eml_j < 36; eml_j++) {
      eml_Q[eml_j] = pow(eml_a[eml_j], 2.0);
    }

    /*  ---- generate base initial state ---- */
    /* '<S2>:1:8' */
    /* '<S2>:1:12' */
    for (eml_lastColC = 0; eml_lastColC < 6; eml_lastColC++) {
      for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
        eml_L0[eml_Coffset + 6 * eml_lastColC] = (real_T)eml_uv0[eml_Coffset + 6
          * eml_lastColC];
      }
    }

    eml_colj = 1;
    eml_j_0 = 1;
    eml_exitg1 = 0U;
    while ((eml_exitg1 == 0U) && (eml_j_0 < 7)) {
      eml_jm1 = eml_j_0 - 1;
      eml_jj = eml_colj + eml_jm1;
      eml_d = 0.0;
      if (!(eml_jm1 < 1)) {
        eml_j = eml_colj;
        eml_lastColC = eml_colj;
        for (eml_br = 1; eml_br <= eml_jm1; eml_br++) {
          eml_d += eml_L0[eml_j - 1] * eml_L0[eml_lastColC - 1];
          eml_lastColC++;
          eml_j++;
        }
      }

      eml_d = eml_L0[eml_jj - 1] - eml_d;
      if (eml_d <= 0.0) {
        eml_L0[eml_jj - 1] = eml_d;
        eml_exitg1 = 1U;
      } else {
        eml_d = sqrt(eml_d);
        eml_L0[eml_jj - 1] = eml_d;
        if (eml_j_0 < 6) {
          eml_nmj = 6 - eml_j_0;
          eml_jjp1 = eml_jj + 6;
          eml_coljp1 = eml_colj + 6;
          for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
            for (eml_br = 0; eml_br < 6; eml_br++) {
              eml_a[eml_br + 6 * eml_Coffset] = eml_L0[eml_br + 6 * eml_Coffset];
            }
          }

          if (!(eml_jm1 == 0)) {
            eml_Coffset = eml_jjp1 - 1;
            eml_j = eml_colj - 1;
            eml_lastColC = eml_Coffset + 6 * (eml_nmj - 1);
            eml_br = eml_coljp1 - 1;
            while (eml_Coffset <= eml_lastColC) {
              eml_colj = eml_j;
              eml_loop_ub = eml_Coffset + 1;
              for (eml_ic = eml_Coffset + 1; eml_ic <= eml_loop_ub; eml_ic++) {
                eml_temp = 0.0;
                for (eml_w = 1; eml_w <= eml_jm1; eml_w++) {
                  eml_temp += eml_a[(eml_w + eml_colj) - 1] * eml_a[(eml_w +
                    eml_br) - 1];
                }

                eml_L0[eml_ic - 1] += -1.0 * eml_temp;
                eml_colj += 6;
              }

              eml_br += 6;
              eml_Coffset += 6;
            }
          }

          eml_d = 1.0 / eml_d;
          eml_j = eml_jjp1 + 6 * (eml_nmj - 1);
          while (eml_jjp1 <= eml_j) {
            eml_L0[eml_jjp1 - 1] *= eml_d;
            eml_jjp1 += 6;
          }

          eml_colj = eml_coljp1;
          for (eml_j = 1; eml_j <= eml_nmj; eml_j++) {
            eml_L0[(eml_jj + eml_j) - 1] = 0.0;
          }
        }

        eml_j_0++;
      }
    }

    /*  ---- propagate states ----  */
    /* '<S2>:1:15' */
    for (eml_lastColC = 0; eml_lastColC < 6; eml_lastColC++) {
      localB->xk[eml_lastColC] = 0.0;

      /* '<S2>:1:16' */
      for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
        localB->Pk[eml_Coffset + 6 * eml_lastColC] = 0.0;
      }
    }

    for (eml_ii = 1.0; eml_ii <= rtu_0; eml_ii++) {
      /* '<S2>:1:18' */
      /* '<S2>:1:19' */
      filterbench_ekf_randn(eml_v, rtu_0, rtu_1, localB, localDW);

      /* '<S2>:1:21' */
      for (eml_lastColC = 0; eml_lastColC < 6; eml_lastColC++) {
        eml_d = 0.0;
        for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
          eml_d += eml_L0[eml_lastColC + 6 * eml_Coffset] * eml_v[eml_Coffset];
        }

        eml_x[eml_lastColC] = (real_T)eml_iv0[eml_lastColC] + eml_d;
      }

      /* '<S2>:1:25' */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  Classification: UNCLASSIFIED */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  Sensitivity: !SENSITIVITY! */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  !COPYRIGHT! */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /* FIL_EKF_PROPAGATE : Extended Kalman Filter propagation */
      /*    [ xk, Pk, tk ] = fil_ekf_propagate( f, Q, x, P, t, h ) */
      /*  */
      /*    FIL_EKF_PROPAGATE performs the Extended Kalman Filter propagation step. */
      /*     */
      /*    /input/ */
      /*       f1 ( function )      : function handle to process model; */
      /*       f2 ( function )      : function handle to process transition matrix; */
      /*       Q ( real[ m ][ m ] ) : additive independent process noise; */
      /*       x ( real[ m ] )      : system state mean vector; */
      /*       P ( real[ m ][ m ] ) : system state covariance matrix; */
      /*       t ( real )           : system state time; */
      /*       h ( real )           : propagation time step; */
      /*  */
      /*    /output/ */
      /*       xk ( real[ m ] )      : propagated system state mean vector; */
      /*       Pk ( real[ m ][ m ] ) : propagated system state covariance matrix; */
      /*       tk ( real )           : propagated system state time; */
      /*         */
      /*    /history/ */
      /*       2008.11.19 : jdc : initial release */
      /*  */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /* % CONSTANTS */
      /* % PROPAGATION */
      /*  ---- propagate mean ---- */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  Classification: UNCLASSIFIED */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  Sensitivity: !SENSITIVITY! */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  !COPYRIGHT! */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /* FIL_MDL_BALLISTICMID1_EXT : generic midcourse ballistic process model */
      /*    [ Fk ] = fil_mdl_ballisticmid_ext( x, t, h ) */
      /*  */
      /*    FIL_MDL_BALLISTICMID1_EXT provides the state transition matrix required by */
      /*    the Extended Kalman Filter for FIL_MDL_BALLLISTICMID1. */
      /*     */
      /*    /input/ */
      /*       x ( real[ m ][ n ] ) : system state vector; */
      /*       t ( real )           : system state time; */
      /*       h ( real )           : propagation time step; */
      /*  */
      /*    /output/ */
      /*       Fk ( real[ m ][ m ][ n ] ) : state transition matrix; */
      /*         */
      /*    /history/ */
      /*       2008.11.19 : jdc : initial release */
      /*  */
      /*    see also FIL_MDL_BALLLISTICMID1 */
      /*  */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /* % CONSTANTS */
      /*  WGS84 parameters */
      /*  semi-major axis (m) */
      /*  gravitational parameter w/ atmosphere (m**3/s**3) */
      /*  J2 zonal gravitational harmonic */
      /*  expansion parameters */
      /* % PROPAGATION */
      /*  ---- initialize ---- */
      filterbench_ekf_fil_mdl_ballisticmid1(eml_x, 0.0, rtu_1 / 2.0, eml_v);

      /*  ---- gravity gradient ---- */
      for (eml_lastColC = 0; eml_lastColC < 3; eml_lastColC++) {
        eml_d = eml_v[eml_lastColC];
        eml_x_0[eml_lastColC] = pow(eml_d, 2.0);
      }

      eml_d = eml_x_0[0];
      for (eml_j = 2; eml_j < 4; eml_j++) {
        eml_d += eml_x_0[eml_j - 1];
      }

      eml_d = sqrt(eml_d);
      eml_temp = -3.986004418E+014 / eml_d / eml_d / eml_d;
      eml_c2 = 1.6239447319699575E-003 * pow(6.378137E+006 / eml_d / eml_d *
        6.378137E+006, 2.0);
      eml_d = 5.0 * pow(eml_v[2] / eml_d, 2.0);
      eml_a_0[0] = eml_temp * ((1.0 + eml_c2) - eml_c2 * eml_d);
      eml_a_0[1] = eml_temp * ((1.0 + eml_c2) - eml_c2 * eml_d);
      eml_a_0[2] = eml_temp * ((1.0 + 3.0 * eml_c2) - eml_c2 * eml_d);

      /*  ---- construct jacobian matrix ---- */
      for (eml_lastColC = 0; eml_lastColC < 6; eml_lastColC++) {
        for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
          eml_a[eml_Coffset + 6 * eml_lastColC] = 0.0;

          /*  ---- construct state transition matrix ---- */
          eml_T[eml_Coffset + 6 * eml_lastColC] = 0.0;
          eml_I[eml_Coffset + 6 * eml_lastColC] = false;
        }

        eml_T[eml_lastColC + 6 * eml_lastColC] = 1.0;
        eml_I[eml_lastColC + 6 * eml_lastColC] = true;
      }

      eml_a[18] = 1.0;
      eml_a[25] = 1.0;
      eml_a[32] = 1.0;
      eml_a[21] = eml_a_0[0];
      eml_a[28] = eml_a_0[1];
      eml_a[35] = eml_a_0[2];
      for (eml_lastColC = 0; eml_lastColC < 6; eml_lastColC++) {
        for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
          eml_F[eml_Coffset + 6 * eml_lastColC] = (real_T)eml_I[eml_Coffset + 6 *
            eml_lastColC];
        }
      }

      for (eml_j = 0; eml_j < 9; eml_j++) {
        eml_d = fabs(rtu_1);
        for (eml_lastColC = 0; eml_lastColC < 6; eml_lastColC++) {
          for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
            eml_T_0[eml_lastColC + 6 * eml_Coffset] = 0.0;
            for (eml_br = 0; eml_br < 6; eml_br++) {
              eml_T_0[eml_lastColC + 6 * eml_Coffset] += eml_T[eml_lastColC + 6 *
                eml_br] * eml_a[eml_br + 6 * eml_Coffset];
            }
          }
        }

        eml_lastColC = eml_j + 1;
        for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
          for (eml_br = 0; eml_br < 6; eml_br++) {
            eml_T[eml_br + 6 * eml_Coffset] = eml_T_0[eml_br + 6 * eml_Coffset] *
              eml_d / (real_T)eml_lastColC;
          }
        }

        for (eml_lastColC = 0; eml_lastColC < 6; eml_lastColC++) {
          for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
            eml_T_0[eml_Coffset + 6 * eml_lastColC] = eml_F[eml_Coffset + 6 *
              eml_lastColC] + eml_T[eml_Coffset + 6 * eml_lastColC];
          }
        }

        for (eml_lastColC = 0; eml_lastColC < 6; eml_lastColC++) {
          for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
            eml_F[eml_Coffset + 6 * eml_lastColC] = eml_T_0[eml_Coffset + 6 *
              eml_lastColC];
          }
        }
      }

      /*  FIL_MDL_BALLISTICMID1_EXT */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  Classification: UNCLASSIFIED */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  ---- finalize state ---- */
      /*  FIL_EKF_PROPAGATE */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  Classification: UNCLASSIFIED */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /* '<S2>:1:27' */
      filterbench_ekf_fil_mdl_ballisticmid1(eml_x, 0.0, rtu_1, eml_v);

      /* '<S2>:1:28' */
      for (eml_lastColC = 0; eml_lastColC < 6; eml_lastColC++) {
        localB->xk[eml_lastColC] = localB->xk[eml_lastColC] + eml_v[eml_lastColC]
          / rtu_0;
        for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
          eml_T_0[eml_lastColC + 6 * eml_Coffset] = 0.0;
          for (eml_br = 0; eml_br < 6; eml_br++) {
            eml_T_0[eml_lastColC + 6 * eml_Coffset] += eml_F[eml_lastColC + 6 *
              eml_br] * (real_T)eml_uv0[eml_br + 6 * eml_Coffset];
          }
        }
      }

      for (eml_lastColC = 0; eml_lastColC < 6; eml_lastColC++) {
        for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
          eml_d = 0.0;
          for (eml_br = 0; eml_br < 6; eml_br++) {
            eml_d += eml_T_0[eml_lastColC + 6 * eml_br] * eml_F[eml_Coffset + 6 *
              eml_br];
          }

          localB->Pk[eml_lastColC + 6 * eml_Coffset] = localB->Pk[eml_lastColC +
            6 * eml_Coffset] + (eml_d + eml_Q[eml_lastColC + 6 * eml_Coffset]) /
            rtu_0;
        }
      }
    }

    /*  PROPBENCH */
  }
}

/* Functions for block: '<Root>/UPDTBENCH' */
static real_T filterbench_ekf_rand(real_T rtu_0, rtB_UPDTBENCH_filterbench_ekf
  *localB, rtDW_UPDTBENCH_filterbench_ekf *localDW)
{
  real_T eml_r;
  int32_T eml_mti;
  uint32_T eml_r_0;
  uint32_T eml_u[2];
  int32_T eml_j;
  uint32_T eml_y;
  if (localDW->method == 2) {
    if (!localDW->twister_state_not_empty) {
      for (eml_mti = 0; eml_mti < 625; eml_mti++) {
        localDW->twister_state[eml_mti] = 0U;
      }

      eml_r_0 = 5489U;
      localDW->twister_state[0] = 5489U;
      for (eml_mti = 2; eml_mti < 625; eml_mti++) {
        eml_r_0 = (eml_r_0 ^ eml_r_0 >> 30U) * 1812433253U + (uint32_T)(eml_mti
          - 1);
        localDW->twister_state[eml_mti - 1] = eml_r_0;
      }

      localDW->twister_state[624] = 624U;
      localDW->twister_state_not_empty = true;
    }

    do {
      for (eml_mti = 0; eml_mti < 2; eml_mti++) {
        eml_u[eml_mti] = 0U;
      }

      for (eml_j = 0; eml_j < 2; eml_j++) {
        eml_r_0 = localDW->twister_state[624] + 1U;
        if (eml_r_0 >= 625U) {
          for (eml_mti = 0; eml_mti < 227; eml_mti++) {
            eml_y = (localDW->twister_state[eml_mti] & 2147483648U) |
              (localDW->twister_state[eml_mti + 1] & 2147483647U);
            if ((eml_y & 1U) == 0U) {
              eml_r_0 = eml_y >> 1U;
            } else {
              eml_r_0 = eml_y >> 1U ^ 2567483615U;
            }

            localDW->twister_state[eml_mti] = localDW->twister_state[eml_mti +
              397] ^ eml_r_0;
          }

          for (eml_mti = 228; eml_mti < 624; eml_mti++) {
            eml_y = (localDW->twister_state[eml_mti - 1] & 2147483648U) |
              (localDW->twister_state[eml_mti] & 2147483647U);
            if ((eml_y & 1U) == 0U) {
              eml_r_0 = eml_y >> 1U;
            } else {
              eml_r_0 = eml_y >> 1U ^ 2567483615U;
            }

            localDW->twister_state[eml_mti - 1] = localDW->twister_state[eml_mti
              - 228] ^ eml_r_0;
          }

          eml_y = (localDW->twister_state[623] & 2147483648U) |
            (localDW->twister_state[0] & 2147483647U);
          if ((eml_y & 1U) == 0U) {
            eml_r_0 = eml_y >> 1U;
          } else {
            eml_r_0 = eml_y >> 1U ^ 2567483615U;
          }

          localDW->twister_state[623] = localDW->twister_state[396] ^ eml_r_0;
          eml_r_0 = 1U;
        }

        eml_y = localDW->twister_state[(int32_T)eml_r_0 - 1];
        localDW->twister_state[624] = eml_r_0;
        eml_y ^= eml_y >> 11U;
        eml_y ^= eml_y << 7U & 2636928640U;
        eml_y ^= eml_y << 15U & 4022730752U;
        eml_y ^= eml_y >> 18U;
        eml_u[eml_j] = eml_y;
      }

      eml_u[0] >>= 5U;
      eml_u[1] >>= 6U;
      eml_r = 1.1102230246251565E-016 * ((real_T)eml_u[0] * 6.7108864E+007 +
        (real_T)eml_u[1]);
    } while (!(eml_r != 0.0));
  } else {
    eml_r_0 = (boolean_T)0 ? MAX_uint32_T : (uint32_T)(localDW->v4_state /
      127773U);
    eml_y = 16807U * (localDW->v4_state - eml_r_0 * 127773U);
    eml_r_0 *= 2836U;
    if (eml_y < eml_r_0) {
      localDW->v4_state = (2147483647U - eml_r_0) + eml_y;
    } else {
      localDW->v4_state = eml_y - eml_r_0;
    }

    return (real_T)localDW->v4_state * 4.6566128752457969E-010;
  }

  return eml_r;
}

static void filterbench_ekf_randn_e(real_T eml_r[2], real_T rtu_0,
  rtB_UPDTBENCH_filterbench_ekf *localB, rtDW_UPDTBENCH_filterbench_ekf *localDW)
{
  int32_T eml_k;
  uint32_T eml_i;
  int32_T eml_j;
  static real_T eml_dv5[65] = { 0.340945, 0.4573146, 0.5397793, 0.6062427,
    0.6631691, 0.7136975, 0.7596125, 0.8020356, 0.8417227, 0.8792102, 0.9148948,
    0.9490791, 0.9820005, 1.0138492, 1.044781, 1.0749254, 1.1043917, 1.1332738,
    1.161653, 1.189601, 1.2171815, 1.2444516, 1.2714635, 1.298265, 1.3249008,
    1.3514125, 1.3778399, 1.4042211, 1.4305929, 1.4569915, 1.4834527, 1.5100122,
    1.5367061, 1.5635712, 1.5906454, 1.617968, 1.6455802, 1.6735255, 1.7018503,
    1.7306045, 1.7598422, 1.7896223, 1.8200099, 1.851077, 1.8829044, 1.9155831,
    1.9492166, 1.9839239, 2.0198431, 2.0571356, 2.095993, 2.136645, 2.1793713,
    2.2245175, 2.2725186, 2.3239338, 2.3795008, 2.4402218, 2.5075117, 2.5834658,
    2.6713916, 2.7769942, 2.7769942, 2.7769942, 2.7769942 };

  real_T eml_vtj;
  real_T eml_vtjp1;
  real_T eml_x;
  real_T eml_absr;
  real_T eml_s;
  uint32_T eml_jsr;
  uint32_T eml_state;
  for (eml_k = 0; eml_k < 2; eml_k++) {
    eml_r[eml_k] = 0.0;
  }

  if (localDW->method_o == 0) {
    if (!localDW->icng_not_empty) {
      localDW->icng = 362436069U;
      localDW->icng_not_empty = true;
      localDW->jsr = 521288629U;
    }

    for (eml_k = 0; eml_k < 2; eml_k++) {
      localDW->icng = 69069U * localDW->icng + 1234567U;
      localDW->jsr = localDW->jsr ^ localDW->jsr << 13U;
      localDW->jsr = localDW->jsr ^ localDW->jsr >> 17U;
      localDW->jsr = localDW->jsr ^ localDW->jsr << 5U;
      eml_i = localDW->icng + localDW->jsr;
      eml_j = (int32_T)(eml_i & 63U);
      eml_vtj = eml_dv5[eml_j];
      eml_vtjp1 = eml_dv5[eml_j + 1];
      eml_x = (real_T)(int32_T)eml_i * 4.6566128730773926E-010 * eml_vtjp1;
      eml_absr = fabs(eml_x);
      if (!(eml_absr <= eml_vtj)) {
        eml_vtj = (eml_absr - eml_vtj) / (eml_vtjp1 - eml_vtj);
        localDW->icng = 69069U * localDW->icng + 1234567U;
        localDW->jsr = localDW->jsr ^ localDW->jsr << 13U;
        localDW->jsr = localDW->jsr ^ localDW->jsr >> 17U;
        localDW->jsr = localDW->jsr ^ localDW->jsr << 5U;
        eml_absr = 0.5 + (real_T)(int32_T)(localDW->icng + localDW->jsr) *
          2.3283064365386960E-010;
        eml_s = eml_vtj + eml_absr;
        if (eml_s > 1.301198) {
          if (eml_x < 0.0) {
            eml_x = 0.4878992 * eml_vtj - 0.4878992;
          } else {
            eml_x = 0.4878992 - 0.4878992 * eml_vtj;
          }
        } else {
          if (!(eml_s <= 0.9689279)) {
            eml_vtj = 0.4878992 - 0.4878992 * eml_vtj;
            if (eml_absr > 12.67706 - 12.37586 * exp(-0.5 * eml_vtj * eml_vtj))
            {
              if (eml_x < 0.0) {
                eml_x = -eml_vtj;
              } else {
                eml_x = eml_vtj;
              }
            } else {
              if (!(exp(-0.5 * eml_vtjp1 * eml_vtjp1) + eml_absr * 0.01958303 /
                    eml_vtjp1 <= exp(-0.5 * eml_x * eml_x))) {
                do {
                  eml_i = 69069U * localDW->icng + 1234567U;
                  eml_jsr = localDW->jsr ^ localDW->jsr << 13U;
                  eml_jsr ^= eml_jsr >> 17U;
                  eml_jsr ^= eml_jsr << 5U;
                  eml_vtj = log(0.5 + (real_T)(int32_T)(eml_i + eml_jsr) *
                                2.3283064365386960E-010) / 2.776994;
                  localDW->icng = 69069U * eml_i + 1234567U;
                  localDW->jsr = eml_jsr ^ eml_jsr << 13U;
                  localDW->jsr = localDW->jsr ^ localDW->jsr >> 17U;
                  localDW->jsr = localDW->jsr ^ localDW->jsr << 5U;
                } while (!(-2.0 * log(0.5 + (real_T)(int32_T)(localDW->icng +
                            localDW->jsr) * 2.3283064365386960E-010) > eml_vtj *
                           eml_vtj));

                if (eml_x < 0.0) {
                  eml_x = eml_vtj - 2.776994;
                } else {
                  eml_x = 2.776994 - eml_vtj;
                }
              }
            }
          }
        }
      }

      eml_r[eml_k] = eml_x;
    }
  } else {
    for (eml_k = 0; eml_k < 2; eml_k++) {
      do {
        eml_i = (boolean_T)0 ? MAX_uint32_T : (uint32_T)(localDW->v4_state_n /
          127773U);
        eml_jsr = 16807U * (localDW->v4_state_n - eml_i * 127773U);
        eml_i *= 2836U;
        if (eml_jsr < eml_i) {
          eml_state = (2147483647U - eml_i) + eml_jsr;
        } else {
          eml_state = eml_jsr - eml_i;
        }

        eml_i = (boolean_T)0 ? MAX_uint32_T : (uint32_T)(eml_state / 127773U);
        eml_jsr = 16807U * (eml_state - eml_i * 127773U);
        eml_i *= 2836U;
        if (eml_jsr < eml_i) {
          localDW->v4_state_n = (2147483647U - eml_i) + eml_jsr;
        } else {
          localDW->v4_state_n = eml_jsr - eml_i;
        }

        eml_vtj = 2.0 * ((real_T)eml_state * 4.6566128752457969E-010) - 1.0;
        eml_absr = 2.0 * ((real_T)localDW->v4_state_n * 4.6566128752457969E-010)
          - 1.0;
        eml_absr = eml_absr * eml_absr + eml_vtj * eml_vtj;
      } while (!(eml_absr <= 1.0));

      eml_vtj *= sqrt(-2.0 * log(eml_absr) / eml_absr);
      eml_r[eml_k] = eml_vtj;
    }
  }
}

/* Initial conditions for atomic system: '<Root>/UPDTBENCH' */
void filterbench_ekf_UPDTBENCH_Init(rtDW_UPDTBENCH_filterbench_ekf *localDW)
{
  /* Initialize code for chart: '<Root>/UPDTBENCH' */
  localDW->twister_state_not_empty = false;
  localDW->icng_not_empty = false;
  localDW->method = 2U;
  localDW->v4_state = 1144108930U;
  localDW->method_o = 0U;
  localDW->v4_state_n = 1144108930U;
}

/* Output and update for atomic system: '<Root>/UPDTBENCH' */
void filterbench_ekf_UPDTBENCH(real_T rtu_0, rtB_UPDTBENCH_filterbench_ekf
  *localB, rtDW_UPDTBENCH_filterbench_ekf *localDW)
{
  /* Embedded MATLAB: '<Root>/UPDTBENCH' */
  {
    real_T eml_a;
    int32_T eml_j;
    real_T eml_dv0[2];
    real_T eml_hoistedExpr[4];
    real_T eml_B[4];
    real_T eml_v[2];
    int32_T eml_Coffset;
    real_T eml_R0[4];
    real_T eml_L0[4];
    int32_T eml_colj;
    int32_T eml_j_0;
    int32_T eml_exitg1;
    int32_T eml_jm1;
    int32_T eml_jj;
    int32_T eml_br;
    int32_T eml_cr;
    int32_T eml_jjp1;
    int32_T eml_coljp1;
    int32_T eml_loop_ub;
    int32_T eml_ic;
    real_T eml_temp;
    int32_T eml_w;
    real_T eml_ii;
    static int16_T eml_iv0[3] = { 1000, 0, 0 };

    int16_T eml_obj_r[3];
    real_T eml_r[3];
    static boolean_T eml_bv0[9] = { true, false, false, false, true, false,
      false, false, true };

    real_T eml_x[3];
    real_T eml_x_0;
    real_T eml_x_1[3];
    real_T eml_c3;
    real_T eml_J[6];
    real_T eml_H[12];
    real_T eml_J_0[6];
    static boolean_T eml_bv1[2] = { false, true };

    static boolean_T eml_bv2[18] = { true, false, false, false, true, false,
      false, false, true, false, false, false, false, false, false, false, false,
      false };

    real_T eml_H_0[12];
    static uint16_T eml_uv0[36] = { 40000U, 0U, 0U, 0U, 0U, 0U, 0U, 40000U, 0U,
      0U, 0U, 0U, 0U, 0U, 40000U, 0U, 0U, 0U, 0U, 0U, 0U, 1U, 0U, 0U, 0U, 0U, 0U,
      0U, 1U, 0U, 0U, 0U, 0U, 0U, 0U, 1U };

    real_T eml_H_1[4];
    static real_T eml_dv1[4] = { 1.0, 0.0, 0.0, 1.0 };

    real_T eml_dv2[12];
    real_T eml_K[12];
    boolean_T eml_I[36];
    real_T eml_dv3[2];
    real_T eml_dv4[2];
    static int16_T eml_iv1[6] = { 1000, 0, 0, 0, 0, 0 };

    real_T eml_I_0[36];

    /* Embedded MATLAB Function 'UPDTBENCH': '<S3>:1' */
    /*  ---- update parameters ---- */
    /* '<S3>:1:4' */
    eml_a = filterbench_ekf_rand(rtu_0, localB, localDW);
    eml_a *= 0.001;

    /* '<S3>:1:9' */
    for (eml_j = 0; eml_j < 2; eml_j++) {
      eml_dv0[eml_j] = eml_a;
    }

    opppbimohdjmlfkn_diag(eml_dv0, eml_hoistedExpr);
    kfkfmoppcbimiekn_power(eml_hoistedExpr, 2.0, eml_B);

    /* '<S3>:1:11' */
    /* '<S3>:1:12' */
    for (eml_j = 0; eml_j < 2; eml_j++) {
      eml_v[eml_j] = 1.5 * eml_a;
      for (eml_Coffset = 0; eml_Coffset < 2; eml_Coffset++) {
        eml_hoistedExpr[eml_Coffset + (eml_j << 1)] = 0.0;
      }

      eml_hoistedExpr[eml_j + (eml_j << 1)] = eml_v[eml_j];
    }

    for (eml_j = 0; eml_j < 4; eml_j++) {
      eml_R0[eml_j] = pow(eml_hoistedExpr[eml_j], 2.0);
    }

    /* '<S3>:1:14' */
    for (eml_j = 0; eml_j < 2; eml_j++) {
      for (eml_Coffset = 0; eml_Coffset < 2; eml_Coffset++) {
        eml_L0[eml_Coffset + (eml_j << 1)] = eml_R0[eml_Coffset + (eml_j << 1)];
      }
    }

    eml_colj = 1;
    eml_j_0 = 1;
    eml_exitg1 = 0U;
    while ((eml_exitg1 == 0U) && (eml_j_0 < 3)) {
      eml_jm1 = eml_j_0 - 1;
      eml_jj = eml_colj + eml_jm1;
      eml_a = 0.0;
      if (!(eml_jm1 < 1)) {
        eml_j = eml_colj;
        eml_br = eml_colj;
        for (eml_cr = 1; eml_cr <= 1; eml_cr = 2) {
          eml_a += eml_L0[eml_j - 1] * eml_L0[eml_br - 1];
          eml_br++;
          eml_j++;
        }
      }

      eml_a = eml_L0[eml_jj - 1] - eml_a;
      if (eml_a <= 0.0) {
        eml_L0[eml_jj - 1] = eml_a;
        eml_exitg1 = 1U;
      } else {
        eml_a = sqrt(eml_a);
        eml_L0[eml_jj - 1] = eml_a;
        if (eml_j_0 < 2) {
          eml_jjp1 = eml_jj + 2;
          eml_coljp1 = eml_colj + 2;
          for (eml_j = 0; eml_j < 2; eml_j++) {
            for (eml_Coffset = 0; eml_Coffset < 2; eml_Coffset++) {
              eml_hoistedExpr[eml_Coffset + (eml_j << 1)] = eml_L0[eml_Coffset +
                (eml_j << 1)];
            }
          }

          if (!(eml_jm1 == 0)) {
            eml_Coffset = eml_jjp1 - 1;
            eml_j = eml_colj - 1;
            eml_br = eml_coljp1 - 1;
            for (eml_cr = eml_Coffset; eml_cr <= eml_Coffset; eml_cr += 2) {
              eml_colj = eml_j;
              eml_loop_ub = eml_cr + 1;
              for (eml_ic = eml_cr + 1; eml_ic <= eml_loop_ub; eml_ic++) {
                eml_temp = 0.0;
                for (eml_w = 1; eml_w <= eml_jm1; eml_w = 2) {
                  eml_temp += eml_hoistedExpr[eml_colj] * eml_hoistedExpr[eml_br];
                }

                eml_L0[eml_ic - 1] += -1.0 * eml_temp;
                eml_colj += 2;
              }

              eml_br += 2;
            }
          }

          eml_a = 1.0 / eml_a;
          for (eml_j = eml_jjp1; eml_j <= eml_jjp1; eml_j += 2) {
            eml_L0[eml_j - 1] *= eml_a;
          }

          eml_colj = eml_coljp1;
          eml_L0[eml_jj] = 0.0;
        }

        eml_j_0++;
      }
    }

    /*  ---- generate base initial state ---- */
    /*  ---- update states ----  */
    /* '<S3>:1:21' */
    for (eml_j = 0; eml_j < 6; eml_j++) {
      localB->xk[eml_j] = 0.0;

      /* '<S3>:1:22' */
      for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
        localB->Pk[eml_Coffset + 6 * eml_j] = 0.0;
      }
    }

    for (eml_ii = 1.0; eml_ii <= rtu_0; eml_ii++) {
      /* '<S3>:1:24' */
      /* '<S3>:1:25' */
      filterbench_ekf_randn_e(eml_v, rtu_0, localB, localDW);

      /* '<S3>:1:27' */
      /* '<S3>:1:30' */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  Classification: UNCLASSIFIED */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  Sensitivity: !SENSITIVITY! */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  !COPYRIGHT! */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /* FIL_EKF_UPDATE : Extended Kalman Filter update */
      /*    [ xk, Pk ] = fil_ekf_update( f, B, x, P, z, R, s, T ) */
      /*  */
      /*    FIL_EKF_UPDATE performs the Extended Kalman Filter update step. */
      /*     */
      /*    /input/ */
      /*       f1 ( function )        : function handle to observer model; */
      /*       f2 ( function )        : function handle to observer transition matrix; */
      /*       B ( real[ m1 ][ m1 ] ) : additive independent observer noise; */
      /*       x ( real[ m1 ] )       : system state mean vector; */
      /*       P ( real[ m1 ][ m1 ] ) : system state covariance matrix; */
      /*       z ( real[ m2 ] )       : measurement state mean vector; */
      /*       R ( real[ m2 ][ m2 ] ) : measurement state covariance matrix; */
      /*       s ( real[ m1 ] )       : observer state vector; */
      /*       T ( real[ 3 ][ 3 ] )   : observer state direction cosine matrix; */
      /*  */
      /*    /output/ */
      /*       xk ( real[ m1 ] )       : updated system state mean vector; */
      /*       Pk ( real[ m1 ][ m1 ] ) : updated system state covariance matrix; */
      /*         */
      /*    /history/ */
      /*       2008.11.19 : jdc : initial release */
      /*  */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /* % CONSTANTS */
      /* % UPDATE */
      /*  ---- project mean ---- */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  Classification: UNCLASSIFIED */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  Sensitivity: !SENSITIVITY! */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  !COPYRIGHT! */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /* FIL_MDL_IR1 : generic IR sensor observer model */
      /*    [ z ] = fil_ukf_update( x, s, T ) */
      /*  */
      /*    FIL_MDL_IR1 provides an observer model for a generic IR sensor. */
      /*     */
      /*    /input/ */
      /*       x ( real[ m ][ n ] ) : system state vector; */
      /*       s ( real[ m ] )      : observer state vector; */
      /*       T ( real[ 3 ][ 3 ] ) : observer state direction cosine matrix; */
      /*  */
      /*    /output/ */
      /*       z ( real[ 2 ][ n ] ) : observed system state vector; */
      /*         */
      /*    /history/ */
      /*       2008.11.19 : jdc : initial release */
      /*  */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /* % PROJECTION */
      /*  ---- extract positions ---- */
      for (eml_j = 0; eml_j < 3; eml_j++) {
        eml_obj_r[eml_j] = eml_iv0[eml_j];
      }

      /*  ---- transform to sensor frame ---- */
      eml_obj_r[0] = 1000;

      /*  ---- transform to sensor coordinate system (spherical) ---- */
      for (eml_j = 0; eml_j < 3; eml_j++) {
        eml_r[eml_j] = 0.0;
        for (eml_Coffset = 0; eml_Coffset < 3; eml_Coffset++) {
          eml_r[eml_j] += (real_T)eml_bv0[eml_j + 3 * eml_Coffset] * (real_T)
            eml_obj_r[eml_Coffset];
        }

        eml_x[eml_j] = pow(eml_r[eml_j], 2.0);
      }

      eml_x_0 = eml_x[0];
      for (eml_j = 2; eml_j < 4; eml_j++) {
        eml_x_0 += eml_x[eml_j - 1];
      }

      /*  ---- project to sensor state space ---- */
      /*  FIL_MDL_IR1 */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  Classification: UNCLASSIFIED */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  Classification: UNCLASSIFIED */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  Sensitivity: !SENSITIVITY! */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  !COPYRIGHT! */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /* FIL_MDL_IR1_EXT : generic IR sensor observer model */
      /*    [ z, H ] = fil_ukf_update( x, s, T ) */
      /*  */
      /*    FIL_MDL_IR1_EXT provides the state transition matrix required by */
      /*    the Extended Kalman Filter for FIL_MDL_IR1. */
      /*  */
      /*    /input/ */
      /*       x ( real[ m ][ n ] ) : system state vector; */
      /*       s ( real[ m ] )      : observer state vector; */
      /*       T ( real[ 3 ][ 3 ] ) : observer state direction cosine matrix; */
      /*  */
      /*    /output/ */
      /*       H ( real[ 2 ][ m ][ n ] ) : state transition matrix; */
      /*         */
      /*    /history/ */
      /*       2008.11.19 : jdc : initial release */
      /*  */
      /*    see also FIL_MDL_IR1 */
      /*  */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /* % PROJECTION */
      /*  ---- extract positions ---- */
      for (eml_j = 0; eml_j < 3; eml_j++) {
        eml_obj_r[eml_j] = eml_iv0[eml_j];
      }

      /*  ---- transform to sensor frame ---- */
      eml_obj_r[0] = 1000;
      for (eml_j = 0; eml_j < 3; eml_j++) {
        eml_x[eml_j] = 0.0;
        for (eml_Coffset = 0; eml_Coffset < 3; eml_Coffset++) {
          eml_x[eml_j] += (real_T)eml_bv0[eml_j + 3 * eml_Coffset] * (real_T)
            eml_obj_r[eml_Coffset];
        }

        eml_x_1[eml_j] = pow(eml_x[eml_j], 2.0);
      }

      eml_a = eml_x_1[0];
      for (eml_j = 2; eml_j < 4; eml_j++) {
        eml_a += eml_x_1[eml_j - 1];
      }

      eml_a = sqrt(eml_a);
      eml_x[0] /= eml_a;
      eml_x[1] /= eml_a;
      eml_x[2] /= eml_a;
      eml_a = pow(eml_a, 2.0);
      eml_temp = pow(eml_x[0], 2.0) + pow(eml_x[1], 2.0);
      eml_c3 = sqrt(eml_temp);

      /*  ---- construct jacobian matrix ---- */
      eml_J[0] = (-eml_x[1]) / eml_temp;
      eml_J[2] = eml_x[0] / eml_temp;
      eml_J[4] = 0.0;
      eml_J[1] = (-eml_x[2]) * eml_x[0] / eml_c3 / eml_a;
      eml_J[3] = (-eml_x[2]) * eml_x[1] / eml_c3 / eml_a;
      eml_J[5] = eml_c3 / eml_a;

      /*  ---- evaluate state transition matrix ---- */
      for (eml_j = 0; eml_j < 6; eml_j++) {
        for (eml_Coffset = 0; eml_Coffset < 2; eml_Coffset++) {
          eml_H[eml_Coffset + (eml_j << 1)] = 0.0;
        }
      }

      for (eml_j = 0; eml_j < 2; eml_j++) {
        for (eml_Coffset = 0; eml_Coffset < 3; eml_Coffset++) {
          eml_J_0[eml_j + (eml_Coffset << 1)] = 0.0;
          for (eml_br = 0; eml_br < 3; eml_br++) {
            eml_J_0[eml_j + (eml_Coffset << 1)] += eml_J[eml_bv1[eml_j] +
              (eml_br << 1)] * (real_T)eml_bv0[eml_br + 3 * eml_Coffset];
          }
        }
      }

      for (eml_j = 0; eml_j < 2; eml_j++) {
        for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
          eml_H[eml_bv1[eml_j] + (eml_Coffset << 1)] = 0.0;
          for (eml_br = 0; eml_br < 3; eml_br++) {
            eml_H[eml_bv1[eml_j] + (eml_Coffset << 1)] += eml_J_0[eml_j +
              (eml_br << 1)] * (real_T)eml_bv2[eml_br + 3 * eml_Coffset];
          }
        }
      }

      /*  FIL_MDL_IR1_EXT */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  Classification: UNCLASSIFIED */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  ---- calculate gain ---- */
      for (eml_j = 0; eml_j < 2; eml_j++) {
        for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
          eml_H_0[eml_j + (eml_Coffset << 1)] = 0.0;
          for (eml_br = 0; eml_br < 6; eml_br++) {
            eml_H_0[eml_j + (eml_Coffset << 1)] += eml_H[eml_j + (eml_br << 1)] *
              (real_T)eml_uv0[eml_br + 6 * eml_Coffset];
          }
        }
      }

      for (eml_j = 0; eml_j < 2; eml_j++) {
        for (eml_Coffset = 0; eml_Coffset < 2; eml_Coffset++) {
          eml_a = 0.0;
          for (eml_br = 0; eml_br < 6; eml_br++) {
            eml_a += eml_H_0[eml_j + (eml_br << 1)] * eml_H[eml_Coffset +
              (eml_br << 1)];
          }

          eml_H_1[eml_j + (eml_Coffset << 1)] = (eml_a + eml_R0[eml_j +
            (eml_Coffset << 1)]) + eml_B[eml_j + (eml_Coffset << 1)];
        }
      }

      ekngjmglgdbiohln_mrdivide(eml_dv1, eml_H_1, eml_hoistedExpr);
      for (eml_br = 0; eml_br < 6; eml_br++) {
        for (eml_j = 0; eml_j < 2; eml_j++) {
          eml_dv2[eml_br + 6 * eml_j] = 0.0;
          for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
            eml_dv2[eml_br + 6 * eml_j] += (real_T)eml_uv0[eml_br + 6 *
              eml_Coffset] * eml_H[eml_j + (eml_Coffset << 1)];
          }
        }

        for (eml_j = 0; eml_j < 2; eml_j++) {
          eml_K[eml_br + 6 * eml_j] = 0.0;
          for (eml_Coffset = 0; eml_Coffset < 2; eml_Coffset++) {
            eml_K[eml_br + 6 * eml_j] += eml_dv2[eml_br + 6 * eml_Coffset] *
              eml_hoistedExpr[eml_Coffset + (eml_j << 1)];
          }
        }

        /*  ---- finalize state ---- */
        for (eml_j = 0; eml_j < 6; eml_j++) {
          eml_I[eml_j + 6 * eml_br] = false;
        }

        eml_I[eml_br + 6 * eml_br] = true;
      }

      /*  FIL_EKF_UPDATE */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /*  Classification: UNCLASSIFIED */
      /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
      /* '<S3>:1:32' */
      for (eml_j = 0; eml_j < 2; eml_j++) {
        eml_a = 0.0;
        for (eml_Coffset = 0; eml_Coffset < 2; eml_Coffset++) {
          eml_a += eml_L0[eml_j + (eml_Coffset << 1)] * eml_v[eml_Coffset];
        }

        eml_dv3[eml_j] = eml_a;
      }

      eml_dv4[0] = rt_atan2(eml_r[1], eml_r[0]);
      eml_dv4[1] = asin(eml_r[2] / sqrt(eml_x_0));
      for (eml_j = 0; eml_j < 2; eml_j++) {
        eml_dv0[eml_j] = eml_dv3[eml_j] - eml_dv4[eml_j];
      }

      for (eml_j = 0; eml_j < 6; eml_j++) {
        eml_a = 0.0;
        for (eml_Coffset = 0; eml_Coffset < 2; eml_Coffset++) {
          eml_a += eml_K[eml_j + 6 * eml_Coffset] * eml_dv0[eml_Coffset];
        }

        localB->xk[eml_j] = localB->xk[eml_j] + ((real_T)eml_iv1[eml_j] + eml_a)
          / rtu_0;
      }

      /* '<S3>:1:33' */
      for (eml_j = 0; eml_j < 6; eml_j++) {
        for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
          eml_a = 0.0;
          for (eml_br = 0; eml_br < 2; eml_br++) {
            eml_a += eml_K[eml_j + 6 * eml_br] * eml_H[eml_br + (eml_Coffset <<
              1)];
          }

          eml_I_0[eml_j + 6 * eml_Coffset] = (real_T)eml_I[eml_j + 6 *
            eml_Coffset] - eml_a;
        }
      }

      for (eml_j = 0; eml_j < 6; eml_j++) {
        for (eml_Coffset = 0; eml_Coffset < 6; eml_Coffset++) {
          eml_a = 0.0;
          for (eml_br = 0; eml_br < 6; eml_br++) {
            eml_a += eml_I_0[eml_j + 6 * eml_br] * (real_T)eml_uv0[eml_br + 6 *
              eml_Coffset];
          }

          localB->Pk[eml_j + 6 * eml_Coffset] = localB->Pk[eml_j + 6 *
            eml_Coffset] + eml_a / rtu_0;
        }
      }
    }

    /*  UPDTBENCH */
  }
}

/* Model step function */
void filterbench_ekf_step(BlockIO_filterbench_ekf *filterbench_ekf_B,
  D_Work_filterbench_ekf *filterbench_ekf_DWork, ExternalInputs_filterbench_ekf *
  filterbench_ekf_U, ExternalOutputs_filterbench_ekf *filterbench_ekf_Y)
{
  {
    int32_T i;
    filterbench_ekf_PROPBENCH(filterbench_ekf_U->propbench_n,
      filterbench_ekf_U->propbench_dt, &filterbench_ekf_B->sf_PROPBENCH,
      &filterbench_ekf_DWork->sf_PROPBENCH);
    for (i = 0; i < 6; i++) {
      /* Outport: '<Root>/propbench_xk' */
      filterbench_ekf_Y->propbench_xk[i] = filterbench_ekf_B->sf_PROPBENCH.xk[i];
    }

    for (i = 0; i < 36; i++) {
      /* Outport: '<Root>/propbench_Pk' */
      filterbench_ekf_Y->propbench_Pk[i] = filterbench_ekf_B->sf_PROPBENCH.Pk[i];
    }

    filterbench_ekf_UPDTBENCH(filterbench_ekf_U->updtbench_n,
      &filterbench_ekf_B->sf_UPDTBENCH, &filterbench_ekf_DWork->sf_UPDTBENCH);
    for (i = 0; i < 6; i++) {
      /* Outport: '<Root>/updtbench_xk' */
      filterbench_ekf_Y->updtbench_xk[i] = filterbench_ekf_B->sf_UPDTBENCH.xk[i];
    }

    for (i = 0; i < 36; i++) {
      /* Outport: '<Root>/updtbench_Pk' */
      filterbench_ekf_Y->updtbench_Pk[i] = filterbench_ekf_B->sf_UPDTBENCH.Pk[i];
    }
  }
}

/* Model initialize function */
void filterbench_ekf_initialize(D_Work_filterbench_ekf *filterbench_ekf_DWork,
  ExternalInputs_filterbench_ekf *filterbench_ekf_U,
  ExternalOutputs_filterbench_ekf *filterbench_ekf_Y)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));
  filterbench_ekf_PROPBENCH_Init(&filterbench_ekf_DWork->sf_PROPBENCH);
  filterbench_ekf_UPDTBENCH_Init(&filterbench_ekf_DWork->sf_UPDTBENCH);
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
