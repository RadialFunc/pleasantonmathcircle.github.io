/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *filterbench_ekf_types.h
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/
/*
 * File: filterbench_ekf_types.h
 *
 * Real-Time Workshop code generated for Simulink model filterbench_ekf.
 *
 * Model version                        : 1.225
 * Real-Time Workshop file version      : 7.1  (R2008a)  23-Jan-2008
 * Real-Time Workshop file generated on : Thu Jan 29 15:12:58 2009
 * TLC version                          : 7.1 (Jan 18 2008)
 * C/C++ source code generated on       : Thu Jan 29 15:12:59 2009
 */
#ifndef RTW_HEADER_filterbench_ekf_types_h_
#define RTW_HEADER_filterbench_ekf_types_h_
#include "rtwtypes.h"
#endif                                 /* RTW_HEADER_filterbench_ekf_types_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
