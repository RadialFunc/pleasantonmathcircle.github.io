/*******************************************************************************
 * Classification: UNCLASSIFIED
 *******************************************************************************
 * Sensitivity: !SENSITIVITY!
 *******************************************************************************
 * !COPYRIGHT!
 *******************************************************************************
 *filterbench_main.cpp
 *
 *   /history/
 *      2008.11.19 : jdc : initial release
 *
 ******************************************************************************/

#include "../filterbench_ert_rtw/filterbench.h"         /* Model's header file */
#include "../filterbench_ukf_ert_rtw/filterbench_ukf.h" /* Model's header file */
#include "../filterbench_ekf_ert_rtw/filterbench_ekf.h" /* Model's header file */

#include <rtwtypes.h> /* MathWorks types */

#include <time.h>
#include <stdio.h>


static BlockIO_filterbench filterbench_B;         /* Observable signals */
static D_Work_filterbench filterbench_DWork;      /* Observable states */
static ExternalInputs_filterbench filterbench_U;  /* External inputs */
static ExternalOutputs_filterbench filterbench_Y; /* External outputs */

static BlockIO_filterbench_ukf filterbench_ukf_B;         /* Observable signals */
static D_Work_filterbench_ukf filterbench_ukf_DWork;      /* Observable states */
static ExternalInputs_filterbench_ukf filterbench_ukf_U;  /* External inputs */
static ExternalOutputs_filterbench_ukf filterbench_ukf_Y; /* External outputs */

static BlockIO_filterbench_ekf filterbench_ekf_B;         /* Observable signals */
static D_Work_filterbench_ekf filterbench_ekf_DWork;      /* Observable states */
static ExternalInputs_filterbench_ekf filterbench_ekf_U;  /* External inputs */
static ExternalOutputs_filterbench_ekf filterbench_ekf_Y; /* External outputs */


int_T 
filterbench_main ( int_T filterbench_n,
                int_T tracks_n,
                int_T frame_dt )
{
	int_T i = 0;
    real_T dt = 0.0;
    
    clock_t c0 = 0;
    clock_t c1 = 0;

	printf("----------------- FILTERBENCH ----------------\n");
    
	c0 = clock();
	{
		/* Initialize model */
		filterbench_initialize(&filterbench_DWork, &filterbench_U, &filterbench_Y);

		/* Execute model */
		for ( i = 0 ; i < filterbench_n ; ++i )
		{
			/* Set model inputs here */
			filterbench_U.propbench_n  = tracks_n;
			filterbench_U.propbench_dt = frame_dt / 1000.0;
	        
			filterbench_U.updtbench_n = tracks_n;
	    
			/* Step the model */
			filterbench_step(&filterbench_B, &filterbench_DWork, &filterbench_U, &filterbench_Y);
	        
			/* Get model outputs here */
		}
	}
	c1 = clock();
	dt = (double) (c1 - c0) / (double) CLOCKS_PER_SEC;
	
    printf("  iterations     : %d\n", filterbench_n);
    printf("  tracks         : %d\n", tracks_n);
    printf("  time step (ms) : %d\n", frame_dt);
    printf("---------------------------------------------\n");
	printf("  total time   (s) : %f\n", dt);
    printf("  average time (s) : %f\n", dt / filterbench_n);
    printf("---------------------------------------------\n");

    //getchar();

	return 0;
}

int_T 
filterbench_ukf_main ( int_T filterbench_n,
                    int_T tracks_n,
                    int_T frame_dt )
{
	int_T i = 0;
    real_T dt = 0.0;
    
    clock_t c0 = 0;
    clock_t c1 = 0;

	printf("------------- FILTERBENCH UKF ----------------\n");
    
	c0 = clock();
	{
		/* Initialize model */
		filterbench_ukf_initialize(&filterbench_ukf_DWork, &filterbench_ukf_U, &filterbench_ukf_Y);

		/* Execute model */
		for ( i = 0 ; i < filterbench_n ; ++i )
		{
			/* Set model inputs here */
			filterbench_ukf_U.propbench_n  = tracks_n;
			filterbench_ukf_U.propbench_dt = frame_dt / 1000.0;
	        
			filterbench_ukf_U.updtbench_n = tracks_n;
	    
			/* Step the model */
			filterbench_ukf_step(&filterbench_ukf_B, &filterbench_ukf_DWork, &filterbench_ukf_U, &filterbench_ukf_Y);
	        
			/* Get model outputs here */
		}
	}
	c1 = clock();
	dt = (double) (c1 - c0) / (double) CLOCKS_PER_SEC;
	
    printf("  iterations     : %d\n", filterbench_n);
    printf("  tracks         : %d\n", tracks_n);
    printf("  time step (ms) : %d\n", frame_dt);
    printf("---------------------------------------------\n");
	printf("  total time   (s) : %f\n", dt);
    printf("  average time (s) : %f\n", dt / filterbench_n);
    printf("---------------------------------------------\n");

    //getchar();

	return 0;
}

int_T 
filterbench_ekf_main ( int_T filterbench_n,
                    int_T tracks_n,
                    int_T frame_dt )
{
	int_T i = 0;
    real_T dt = 0.0;
    
    clock_t c0 = 0;
    clock_t c1 = 0;

	printf("------------ FILTERBENCH EKF ----------------\n");
    
	c0 = clock();
	{
		/* Initialize model */
		filterbench_ekf_initialize(&filterbench_ekf_DWork, &filterbench_ekf_U, &filterbench_ekf_Y);

		/* Execute model */
		for ( i = 0 ; i < filterbench_n ; ++i )
		{
			/* Set model inputs here */
			filterbench_ekf_U.propbench_n  = tracks_n;
			filterbench_ekf_U.propbench_dt = frame_dt / 1000.0;
	        
			filterbench_ekf_U.updtbench_n = tracks_n;
	    
			/* Step the model */
			filterbench_ekf_step(&filterbench_ekf_B, &filterbench_ekf_DWork, &filterbench_ekf_U, &filterbench_ekf_Y);
	        
			/* Get model outputs here */
		}
	}
	c1 = clock();
	dt = (double) (c1 - c0) / (double) CLOCKS_PER_SEC;
	
    printf("  iterations     : %d\n", filterbench_n);
    printf("  tracks         : %d\n", tracks_n);
    printf("  time step (ms) : %d\n", frame_dt);
    printf("---------------------------------------------\n");
	printf("  total time   (s) : %f\n", dt);
    printf("  average time (s) : %f\n", dt / filterbench_n);
    printf("---------------------------------------------\n");

    //getchar();

	return 0;
}

int_T 
main ( int_T argc, 
       const char_T * argv[ ] )
{
    filterbench_main(100, 3000, 1500);
	filterbench_ukf_main(100, 3000, 1500);
	filterbench_ekf_main(100, 3000, 1500);
	
	return 0;
}


/*******************************************************************************
 * Classification: UNCLASSIFIED
 ******************************************************************************/
