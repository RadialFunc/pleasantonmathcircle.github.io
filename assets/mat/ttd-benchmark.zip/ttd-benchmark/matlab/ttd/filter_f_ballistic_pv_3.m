%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FILTER_F_BALLISTIC_PV_3 : Generic exoatmospheric ballistic process model
%   [ xk, tk ] = filter_f_ballistic_pv_3( x, t, h, params )
%
%   FILTER_F_BALLISTIC_PV_3 provides a process model for a generic 
%   exo-atmospheric ballistic position-velocity state using a WGS84/EGM96
%   gravity model (spherical earth).
%
%   /notes/
%      - The system state is assumed to be in a non-rotating reference frame.
%      - The system state is assumed to be in a Cartesian coordinate system.
%      - The system state is assumed to be in the form:
%        [ position ; velocity ]
%   
%   /input/
%      x ( real[ m ][ n ] )      : system state vector;
%      t ( real )                : system state time;
%      h ( real )                : propagation time step;
%      params ( struct )         : model-specific parameters;
%
%   /output/
%      xk ( real[ m ][ n ] ) : propagated system state vector;
%      tk ( real )           : propagated time;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%   see also FILTER_F_ODE
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ xk, tk ] = filter_f_ballistic_pv_3( ...
    x, t, h, params ...
)
%#eml
%% CONSTANTS

dynamics_ode = @dynamics_ode_pv_3; % Exo-Atmospheric, Ballistic
numerics_ode = @numerics_ode_rk4;  % Runge-Kutta


%% PROPAGATION

[ xk, tk ] = filter_f_ode(x, t, h, params, dynamics_ode, numerics_ode);


end % FILTER_F_BALLISTIC_PV_3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%