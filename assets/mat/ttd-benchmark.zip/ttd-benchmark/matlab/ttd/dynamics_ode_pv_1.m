%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%DYNAMICS_ODE_PV_1 : Evaluate position-velocity derivative
%   [ k ] = dynamics_ode_pv_1( t, y )
%
%   DYNAMICS_ODE_PV_1 evaluates the position-velocity derivative.
%
%   The position-velocity derivative is evaluated using a constant velocity
%   model. 
%
%   /notes/
%      - The system state is assumed to be in a non-rotating reference frame.
%      - The system state is assumed to be in a Cartesian coordinate system.
%      - The system state is assumed to be in the form:
%        [ position ; velocity ]
%   
%   /input/
%      t ( real )           : independent variable value;
%      y ( real[ 6 ][ n ] ) : dependent variable value;
%
%   /output/
%      k ( real[ 6 ][ n ] ) : final dependent variable value;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ k ] = dynamics_ode_pv_1( ...
    t, y ...
)
%#eml
%% EVALUATION

% ---- initialization ----
k = zeros(size(y), class(y));

% ---- position derivative ----
% (d/dt)(r) = v;
k(1,:) = y(4,:); 
k(2,:) = y(5,:); 
k(3,:) = y(6,:); 

% ---- velocity deriviative ----
% (d/dt)(v) = 0;


end % DYNAMICS_ODE_PV_1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%