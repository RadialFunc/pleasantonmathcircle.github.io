%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%NUMERICS_ODE_RKDP45 : Runge-Kutta Dormand-Prince
%   [ yn ] = numerics_ode_rkdp45( ode, y0, t0, hn )
%
%   NUMERICS_ODE_RKDP45 uses the Runge-Kutta Dormand-Prince method to 
%   numerically approximate the solution to an ordinary differential equation.
%   
%   /references/ 
%      [1] "Runge-Kutta Methods". Wikipedia, 30 January 2009. 
%          http://en.wikipedia.org/wiki/Runge-Kutta_methods
%      [2] "Dormand-Prince Method". Wikipedia, 12 August 2008. 
%          http://en.wikipedia.org/wiki/Dormand-Prince_method
%
%   /input/
%      ode ( function )      : function handle to derivative function;
%      y0 ( real[ m ][ n ] ) : initial dependent variable value;
%      t0 ( real )           : initial independent variable value;
%      h0 ( real )           : initial independent variable step size;
%
%   /output/
%      yn ( real[ m ][ n ] ) : final dependent variable value;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ yn ] = numerics_ode_rkdp45( ...
    ode, y0, t0, h0 ...
)
%#eml
%% CONSTANTS

% iteration parameters
EPS = 1.0e-8; % Slighly better than 32-bit floating point precision...
ITR = 15;     % Arbitrary...
    

%% APPROXIMATION

yn = numerics_ode_rkadapt(@rkdp45, ode, y0, t0, h0, EPS, ITR);


end % NUMERICS_ODE_RKDP45


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%RKDP45 : Runge-Kutta Dormand-Prince integration step
%   [ yt, zt, ht, et ] = rkdp45( ode, yn, tn, hn, epsilon )
%
%   RKDP45 performs a single Runge-Kutta Dormand-Prince integration step.
%   
%   /input/
%      ode ( function )    : function handle to derivative function;
%      yn ( real[ m, n ] ) : initial dependent variable value;
%      tn ( real )         : initial independent variable value;
%      hn ( real )         : initial independent variable step size;
%      epsilon ( real )    : error precision;
%
%   /output/
%      yt ( real[ m, n ] ) : estimated fourth order dependent variable value;
%      zt ( real[ m, n ] ) : estimated fifth order dependent variable value;
%      ht ( real )         : estimated optimal step size;
%      et ( real )         : estimated error;
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ yt, zt, ht, et ] = rkdp45( ode, ...
                                      yn, ...
                                      tn, ...
                                      hn, ...
                                      epsilon )

%% CONSTANTS

% Butcher Tableau
C2 =  1/5  ; A21 =  1/5        ; 
C3 =  3/10 ; A31 =  3/40       ; A32 =  9/40       ; 
C4 =  4/5  ; A41 =  44/45      ; A42 = -56/15      ; A43 =  32/9       ;
C5 =  8/9  ; A51 =  19372/6561 ; A52 = -25360/2187 ; A53 =  64448/6561 ; A54 = -212/729 ;
C6 =  1    ; A61 =  9017/3168  ; A62 = -355/33     ; A63 =  46732/5247 ; A64 =  49/176  ; A65 = -5103/18656   ;
C7 =  1    ; A71 =  35/384                         ; A73 =  500/1113   ; A74 =  125/192 ; A75 = -2187/6784    ; A76 =  11/84    ;
             B51 =  5179/57600                     ; B53 =  7571/16695 ; B54 =  393/640 ; B55 = -92097/339200 ; B56 =  187/2100 ; B57 =  1/40 ;
             B41 =  35/384                         ; B43 =  500/1113   ; B44 =  125/192 ; B45 = -2187/6784    ; B46 =  11/84                  ;

% Safety Factor
S = (1/2)^(1/4);

              
%% APPROXIMATION

hk1 = hn * ode(tn, yn);
hk2 = hn * ode(tn + C2 * hn, yn + A21 * hk1);
hk3 = hn * ode(tn + C3 * hn, yn + A31 * hk1 + A32 * hk2);
hk4 = hn * ode(tn + C4 * hn, yn + A41 * hk1 + A42 * hk2 + A43 * hk3);
hk5 = hn * ode(tn + C5 * hn, yn + A51 * hk1 + A52 * hk2 + A53 * hk3 + A54 * hk4);
hk6 = hn * ode(tn + C6 * hn, yn + A61 * hk1 + A62 * hk2 + A63 * hk3 + A64 * hk4 + A65 * hk5);
hk7 = hn * ode(tn + C7 * hn, yn + A71 * hk1 + A73 * hk3 + A74 * hk4 + A75 * hk5 + A76 * hk6);

yt = yn + ...
     (B41 * hk1) + ...
     (B43 * hk3) + ...
     (B44 * hk4) + ...
     (B45 * hk5) + ...
     (B46 * hk6);
zt = yn + ...
     (B51 * hk1) + ...
     (B53 * hk3) + ...
     (B54 * hk4) + ...
     (B55 * hk5) + ...
     (B56 * hk6) + ...
     (B57 * hk7);

en = epsilon * hn;
et = max(max(abs(zt - yt)));
% et = sum(sum(abs(zt - yt).^2)) / numel(yn);

if ( en >= et )
    sn = (en / et)^(1/5);
else
    sn = (en / et)^(1/4);
end

ht = S * sn * hn;


end % RKDP45
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%