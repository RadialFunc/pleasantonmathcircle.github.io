%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FILTER_UKF_PROJECT : Unscented Kalman Filter projection
%   [ z, R ] = filter_ukf_project( x, P, s, params, hmodel, rmodel, hparam, rparam )
%
%   FILTER_UKF_PROJECT performs the Unscented Kalman Filter projection without
%   update.
%
%   /notes/
%      - The "alpha" parameter is a primary scaling factor. It determines the 
%        spread of sigma points around the prior mean. The range is (0, 3].
%      - The "beta" parameter is a secondary scaling factor. It determines 
%        weighting on the zeroth sigma-point. The optimal value for Gaussian
%        priors is 2.
%      - The "kappa" parameter is a tertiary scaling factor. It provides an 
%        additional degree of freedom.
%    
%   /references/
%      [1] "Kalman Filter". Wikipedia, 3 February 2009. 
%          http://en.wikipedia.org/wiki/Kalman_filter
%      [2] Julier, S.J. and Uhlmann, J.K. "A New Extension of the Kalman Filter
%          to Nonlinear Systems." 
%      [3] van der Merwe, R. and Wan, E.A. "Sigma-Point Kalman Filters for 
%          Nonlinear Estimation and Sensor-Fusion - Applications to Integrated 
%          Navigation".
% 
%   /input/
%      x ( real[ m1 ] )       : system state mean vector;
%      P ( real[ m1 ][ m1 ] ) : system state covariance matrix;
%      s ( real[ m1 ] )       : observer state vector;
%      params ( struct )      : filter-specific parameters;
%      hmodel ( function )    : function handle for observer model;
%      rmodel ( function )    : function handle for noise model;
%      hparam ( struct )      : observer model parameters;
%      rparam ( struct )      : noise model parameters;
%
%   /output/
%      z ( real[ m2 ] )       : projected state mean vector;
%      R ( real[ m2 ][ m2 ] ) : projected state covariance matrix;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ z, R ] = filter_ukf_project( ...
    x, P, s, params, hmodel, rmodel, hparam, rparam ...
)
%#eml
%% PARAMETERS

% Scaled Unscented Transform Parameters
alpha = params.alpha;
beta  = params.beta;
kappa = params.kappa;


%% PROJECTION

% ---- Weights ----
m1 = size(x, 1);

lambda = alpha^2 * (m1 + kappa) - m1;

wy0 = lambda / (m1 + lambda);
wyi = 1.0 / 2.0 / (m1 + lambda);

wyy0 = wy0 + (1.0 - alpha^2 + beta);
wyyi = wyi;

% ---- Sigma Points ----
L = chol(P * (m1 + lambda))';

X0 = x;
Xi = [ +L, -L ];
for ii = 1 : m1
    Xi(ii,:) = Xi(ii,:) + x(ii);
end

% ---- Sigma Point Projection ----
Y0 = hmodel(X0, s, hparam);
Yi = hmodel(Xi, s, hparam);

m2 = size(Y0, 1);

% ---- Statistics ----
uy = wy0 * Y0 + ...
     wyi * sum(Yi, 2);

dy0 = Y0 - uy;
dyi = Yi;
for ii = 1 : m2
    dyi(ii,:) = dyi(ii,:) - uy(ii);
end

Ryy = wyy0 * dy0 * dy0' + ...
      wyyi * dyi * dyi';

% ---- State projection ----
Ry = rmodel(m2, x, s, rparam);

z = uy;
R = Ry + Ryy;


end % FILTER_UKF_PROJECT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%