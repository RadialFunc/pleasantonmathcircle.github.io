%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FILTER_F_BALLISTIC_PV_3_EXT : Generic ballistic process model
%   [ Fk ] = filter_f_ballistic_pv_3_ext( x, t, h, params )
%
%   FILTER_F_BALLISTIC_PV_3_EXT provides the state transition matrix required by
%   the Extended Kalman Filter for FILTER_F_BALLISTIC_PV_3. The gravity 
%   gradient component is simplified for computational convenience.
%
%   /notes/
%      - The system state is assumed to be in a non-rotating reference frame.
%      - The system state is assumed to be in a Cartesian coordinate system.
%      - The system state is assumed to be in the form:
%        [ position ; velocity ]
%      - The gravity gradient is approximated for numerical convenience.
%      - The "order" parameter limits the Taylor Expansion order. A typical 
%        value is 5.
%
%   /references/
%      [1] Kelso, T.S. "Temporal Clustering in the Multi-Target Tracking 
%          Environment". August 1988.
%   
%   /input/
%      x ( real[ m ][ n ] ) : system state vector;
%      t ( real )           : system state time;
%      h ( real )           : propagation time step;
%      params ( struct )    : model-specific parameters;
%
%   /output/
%      Fk ( real[ m ][ m ][ n ] ) : state transition matrix;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%   see also FILTER_F_BALLISTIC_PV_3
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ F ] = filter_f_ballistic_pv_3_ext( ...
    x, t, h, params ...
)
%#eml
%% PARAMETERS

% Taylor Expansion Order
order = params.order;

% WGS84 Parameters
wgs84 = earth_wgs84_ellipsoid();


%% PROPAGATION

m = size(x, 1);
n = size(x, 2);

% ---- Midpoint ----
xm = filter_f_ballistic_pv_3(x, t, h / 2, params);

% ---- Gravity Gradient ----
c0 = xm(1,:).^2 + xm(2,:).^2 + xm(3,:).^2; 
c1 = sqrt(c0); 

c2 = -wgs84.GM ./ c0 ./ c1;

rm1 = xm(1 : 3,:) ./ c1;
rm2 = rm1 .* c2 .* 3;

G = zeros(3, 3, n, class(x));
for ii = 1 : n
    G(:,:,n) = rm1(:,n) * rm2(:,n)';
end

G(1,1,:) = c2 - G(1,1,:);
G(2,2,:) = c2 - G(2,2,:);
G(3,3,:) = c2 - G(3,3,:);

% ---- Linearized Dynamics Matrix ----
J = zeros(m, m, n, class(x));

J(1,4,:) = 1;
J(2,5,:) = 1;
J(3,6,:) = 1;

J(4 : 6,1 : 3,:) = G;

% ---- State Transition Matrix ----
F = zeros(m, m, n, class(x));
for ii = 1 : n
    T = eye(m, class(x));
    F(:,:,ii) = eye(m, class(x));
    for jj = 1 : order
        T = (T * J(:,:,ii)) * abs(h) / jj;
        F(:,:,ii) = F(:,:,ii) + T;
    end
end


end % FILTER_F_BALLISTIC_PV_3_EXT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%