%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%LAP_PROBLEM_FULL : Transform LAP problem from sparse form to full form
%   [ C ] = lap_problem_full( m, n, ci, cn, cj, ce, C )
%
%   LAP_PROBLEM_FULL transforms a LAP problem from sparse cost matrix form to 
%   full cost matrix form.
%
%   /notes/
%      - The cost is infinite for infeasible solutions.
%      - The full cost matrix argument is necessary for EML matrix sizing.
%      - The full cost matrix argument should be initialized to infinities.
%
%   /input/
%      m ( integer )        : number of sources (cost matrix rows);
%      n ( integer )        : number of sinks (cost matrix columns);
%      ci ( integer[ m ] )  : sparse cost matrix row indices;
%      cn ( integer[ m ] )  : sparse cost matrix row lengths;
%      cj ( integer[ s ] )  : sparse cost matrix column values;
%      ce ( real[ s ] )     : sparse cost matrix element values;
%      C ( real[ m ][ n ] ) : full cost matrix;
%
%   /output/
%      C ( real[ m ][ n ] ) : full cost matrix;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%   see also LAP_PROBLEM_SPARSE
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ C ] = lap_problem_full( ...
     m, n, ci, cn, cj, ce, C ...
)
%#eml
%% TRANSFORM

for ii = 1 : m
    for ki = ci(ii) : ci(ii) + cn(ii) - 1
        C(ii,cj(ki)) = ce(ki);
    end
end


end % LAP_PROBLEM_FULL
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%