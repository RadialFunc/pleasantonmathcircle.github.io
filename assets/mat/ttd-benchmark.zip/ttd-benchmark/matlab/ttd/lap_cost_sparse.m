%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%LAP_COST_SPARSE : Calculate the cost for a LAP solution
%   [ c, cx, cy ] = lap_cost_sparse( m, n, ci, cn, cj, ce, x, y, infinity )
%
%   LAP_COST_SPARSE calculates the cost for a LAP solution mapping sources to
%   sinks using a sparse cost matrix.
%
%   /notes/
%      - The cost is infinite for infeasible solutions.
%
%   /input/
%      m ( integer )       : number of sources (cost matrix rows);
%      n ( integer )       : number of sinks (cost matrix columns);
%      ci ( integer[ m ] ) : sparse cost matrix row indices;
%      cn ( integer[ m ] ) : sparse cost matrix row lengths;
%      cj ( integer[ s ] ) : sparse cost matrix column values;
%      ce ( real[ s ] )    : sparse cost matrix element values;
%      x ( integer[ m ] )  : source assignments;
%      y ( integer[ n ] )  : sink assignments;
%      infinity ( real )   : infinity value;
%
%   /output/
%      c  ( real )      : assignment solution cost;
%      cx ( real[ m ] ) : assignment cost by source;
%      cy ( real[ n ] ) : assignment cost by sink;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%   see also LAP_COST_FULL
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ c, cx, cy ] = lap_cost_sparse( ...
     m, n, ci, cn, cj, ce, x, y, infinity ...
)
%#eml
%% CALCULATION

c  = cast(0, class(ce));
cx = ones(size(x)) * infinity;
cy = ones(size(y)) * infinity;

for ii = 1 : m
    % Find assigned sink
    jj = x(ii);
    for ki = ci(ii) : ci(ii) + cn(ii) - 1
        if ( cj(ki) == jj )
            cx(ii) = ce(ki);
            cy(jj) = ce(ki);
            break;
        end
    end
    
    % Increment cost
    if ( cx(ii) < infinity )
        c = c + cx(ii);
    else
        c = infinity;
    end
end


end % LAP_COST_SPARSE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%