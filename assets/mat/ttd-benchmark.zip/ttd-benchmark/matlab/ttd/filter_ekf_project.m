%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FILTER_EKF_PROJECT : Extended Kalman Filter projection
%   [ z, R ] = filter_ekf_project( x, P, s, params, hmodel, hextnd, rmodel, hparam, rparam )
%
%   FILTER_EKF_PROJECT performs the Extended Kalman Filter projection without
%   update.
%   
%   /references/
%      [1] "Kalman Filter". Wikipedia, 3 February 2009. 
%          http://en.wikipedia.org/wiki/Kalman_filter

%   /input/
%      x ( real[ m1 ] )       : system state mean vector;
%      P ( real[ m1 ][ m1 ] ) : system state covariance matrix;
%      s ( real[ m1 ] )       : observer state vector;
%      params ( struct )      : filter-specific parameters;
%      hmodel ( function )    : function handle for observer model;
%      hextnd ( function )    : function handle for observer model extended;
%      rmodel ( function )    : function handle for noise model;
%      hparam ( struct )      : observer model parameters;
%      rparam ( struct )      : noise model parameters;
%
%   /output/
%      z ( real[ m2 ] )       : projected state mean vector;
%      R ( real[ m2 ][ m2 ] ) : projected state covariance matrix;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ z, R ] = filter_ekf_project( ...
    x, P, s, params, hmodel, hextnd, rmodel, hparam, rparam ...
)
%#eml
%% PROJECTION

% ---- Mean Projection ----
u = hmodel(x, s, hparam);
H = hextnd(x, s, hparam);

% ---- State Projection ----
Ru = rmodel(size(u, 1), x, s, rparam);

z = u;
R = Ru + H * P * H';


end % FILTER_EKF_PROJECT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%