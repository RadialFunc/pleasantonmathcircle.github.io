%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FILTER_H_RAE_EXT : Generic Range-Angle-Angle observer model
%   [ z, H ] = filter_h_rae_ext( x, s, params )
%
%   FILTER_H_RAE_EXT provides the state transition matrix required by the
%   Extended Kalman Filter for FILTER_H_RAE.
%
%   /notes/
%      - The "DCM" parameter is assumed to be the Direction Cosine Matrix for
%        rotating from the common reference frame to the observer frame.
%      - The system state and observer state are assumed to be in a common 
%        reference frame.
%      - The system state and observer state are assumed to be in a common 
%        Cartesian coordinate system.
%      - The system state and observer state are assumed to be in the form:
%        [ position ; velocity ]
%
%   /input/
%      x ( real[ m ][ n ] ) : system state vector;
%      s ( real[ m ] )      : observer state vector;
%      params ( struct )    : model-specific parameters;
%
%   /output/
%      H ( real[ 3 ][ m ][ n ] ) : state transition matrix;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%   see also FILTER_H_RAE
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ H ] = filter_h_rae_ext( ...
    x, s, params ...
)
%#eml
%% PARAMETERS

DCM = params.DCM;


%% PROJECTION

% ---- Position ----
obj_r = x(1 : 3,:);
sen_r = s(1 : 3,:);

% ---- Transform to Sensor Frame ----
obj_r(1,:) = obj_r(1,:) - sen_r(1);
obj_r(2,:) = obj_r(2,:) - sen_r(2);
obj_r(3,:) = obj_r(3,:) - sen_r(3);

r = DCM * obj_r;

r_c0 = sum(r.^2, 1);
r_c1 = sqrt(r_c0);
r_c2 = r(1,:).^2 + r(2,:).^2;
r_c3 = sqrt(r_c2);

% ---- Jacobian Matrix ----
m = size(x, 1);
n = size(x, 2);

J = zeros(3, 3, n, class(x));

J(1,1,:) =  r(1,:) ./ r_c1;
J(1,2,:) =  r(2,:) ./ r_c1;
J(1,3,:) =  r(3,:) ./ r_c1;
J(2,1,:) = -r(2,:) ./ r_c2;
J(2,2,:) =  r(1,:) ./ r_c2;
J(2,3,:) =  zeros(size(r_c2), class(x));
J(3,1,:) = -r(3,:) .* r(1,:) ./ r_c3 ./ r_c0;
J(3,2,:) = -r(3,:) .* r(2,:) ./ r_c3 ./ r_c0;
J(3,3,:) =  r_c3 ./ r_c0;

% ---- State Transition Matrix ----
H = zeros(3, m, n, class(x));
for ii = 1 : n
    H(:,:,ii) = J(:,:,ii) * DCM * eye(3, m, class(x));
end


end % FILTER_H_RAE_EXT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%