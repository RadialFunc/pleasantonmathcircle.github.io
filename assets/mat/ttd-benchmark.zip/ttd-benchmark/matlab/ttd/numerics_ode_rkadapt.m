%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%NUMERICS_ODE_RKADAPT : Runge-Kutta with adaptive stepping
%   [ yn ] = numerics_ode_rkadapt( rk, ode, y0, t0, h0 )
%
%   NUMERICS_ODE_RKADAPT uses an adaptive Runge-Kutta method to numerically 
%   approximate the solution to an ordinary differential equation.
%   
%   /references/ 
%      [1] "Runge-Kutta Methods". Wikipedia, 30 January 2009. 
%          http://en.wikipedia.org/wiki/Runge-Kutta_method
%      [2] "Adaptive Stepsize". Wikipedia, 14 January 2009. 
%          http://en.wikipedia.org/wiki/Adaptive_Stepsize
%
%   /input/
%      rk ( function )       : function handle to Runge-Kutta method;
%      ode ( function )      : function handle to derivative function;
%      y0 ( real[ m ][ n ] ) : initial dependent variable value;
%      t0 ( real )           : initial independent variable value;
%      h0 ( real )           : initial independent variable step size;
%      epsilon ( real )      : error precision;
%      iterations ( real )   : iteration limit;
%    
%   /output/
%      yn ( real[ m ][ n ] ) : final dependent variable value;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ yn ] = numerics_ode_rkadapt( ...
    rk, ode, y0, t0, h0, epsilon, iterations ...
)
%#eml
%% ITERATION

tn = t0;
hn = h0;
yn = y0;

for ii = 1 : iterations
	[ yt, zt, ht, et ] = rk(ode, yn, tn, hn, epsilon);
    
    if ( (et < epsilon * abs(hn)) || (abs(ht) == abs(hn)) )
        tn = tn + hn;
        hn = ht;
        yn = yt;
    elseif ( abs(ht) > abs(hn) )
        hn = ht;
    elseif ( abs(ht) < abs(hn) )
        hn = ht;
    end
    
    if ( sign((t0 - tn) + (h0 - hn)) ~= sign(h0) )
        break;
    end
end

yn = rk(ode, yn, tn, (t0 - tn) + h0, epsilon);


end % NUMERICS_ODE_RKADAPT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%