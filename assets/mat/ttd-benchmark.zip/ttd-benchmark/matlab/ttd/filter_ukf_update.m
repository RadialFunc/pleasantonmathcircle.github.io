%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FILTER_UKF_UPDATE : Unscented Kalman Filter update
%   [ xk, Pk ] = filter_ukf_update( x, P, z, R, s, params, hmodel, rmodel, hparam, rparam )
%
%   FILTER_UKF_UPDATE performs the Unscented Kalman Filter update step.
%
%   /notes/
%      - The "alpha" parameter is a primary scaling factor. It determines the 
%        spread of sigma points around the prior mean. The range is (0, 3].
%      - The "beta" parameter is a secondary scaling factor. It determines 
%        weighting on the zeroth sigma-point. The optimal value for Gaussian
%        priors is 2.
%      - The "kappa" parameter is a tertiary scaling factor. It provides an 
%        additional degree of freedom.
%   
%   /references/
%      [1] "Kalman Filter". Wikipedia, 3 February 2009. 
%          http://en.wikipedia.org/wiki/Kalman_filter
%      [2] Julier, S.J. and Uhlmann, J.K. "A New Extension of the Kalman Filter
%          to Nonlinear Systems." 
%      [3] van der Merwe, R. and Wan, E.A. "Sigma-Point Kalman Filters for 
%          Nonlinear Estimation and Sensor-Fusion - Applications to Integrated 
%          Navigation".
%  
%   /input/
%      x ( real[ m1 ] )       : system state mean vector;
%      P ( real[ m1 ][ m1 ] ) : system state covariance matrix;
%      z ( real[ m2 ] )       : measurement state mean vector;
%      R ( real[ m2 ][ m2 ] ) : measurement state covariance matrix;
%      s ( real[ m1 ] )       : observer state vector;
%      params ( struct )      : filter-specific parameters;
%      hmodel ( function )    : function handle for observer model;
%      rmodel ( function )    : function handle for noise model;
%      hparam ( struct )      : observer model parameters;
%      rparam ( struct )      : noise model parameters;
%
%   /output/
%      xk ( real[ m1 ] )       : updated system state mean vector;
%      Pk ( real[ m1 ][ m1 ] ) : updated system state covariance matrix;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ xk, Pk ] = filter_ukf_update( ...
    x, P, z, R, s, params, hmodel, rmodel, hparam, rparam ...
)
%#eml
%% PARAMETERS

% Scaled Unscented Transform Parameters
alpha = params.alpha;
beta  = params.beta;
kappa = params.kappa;


%% UPDATE

% ---- Weights ----
m1 = size(x, 1);

lambda = alpha^2 * (m1 + kappa) - m1;

wy0 = lambda / (m1 + lambda);
wyi = 1.0 / 2.0 / (m1 + lambda);

wyy0 = wy0 + (1.0 - alpha^2 + beta);
wyyi = wyi;

% ---- Sigma Points ----
L = chol(P * (m1 + lambda))';

X0 = x;
Xi = [ +L, -L ];
for ii = 1 : m1
    Xi(ii,:) = Xi(ii,:) + x(ii);
end

% ---- Sigma Point Projection ----
Y0 = hmodel(X0, s, hparam);
Yi = hmodel(Xi, s, hparam);

m2 = size(Y0, 1);

% ---- Statistics ----
ux = wy0 * X0 + ...
     wyi * sum(Xi, 2);

dx0 = X0 - ux;
dxi = Xi;
for ii = 1 : m1
    dxi(ii,:) = dxi(ii,:) - ux(ii);
end

uy = wy0 * Y0 + ...
     wyi * sum(Yi, 2);
 
dy0 = Y0 - uy;
dyi = Yi;
for ii = 1 : m2
    dyi(ii,:) = dyi(ii,:) - uy(ii);
end

Ryy = wyy0 * dy0 * dy0' + ... 
      wyyi * dyi * dyi';
  
Pxy = wyy0 * dx0 * dy0' + ...
      wyyi * dxi * dyi';

% ---- Kalman Gain ----
Ry = rmodel(m2, x, s, rparam);

S = Ry + Ryy + R;
K = Pxy / S;

% ---- State Update ----
xk = x + K * (z - uy);
Pk = P - K * S * K';


end % FILTER_UKF_UPDATE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%