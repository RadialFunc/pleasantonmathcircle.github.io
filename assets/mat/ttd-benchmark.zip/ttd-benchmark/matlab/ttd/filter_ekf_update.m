%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FILTER_EKF_UPDATE : Extended Kalman Filter update
%   [ xk, Pk ] = filter_ekf_update( x, P, z, R, s, params, hmodel, hextnd, rmodel, hparam, rparam )
%
%   FILTER_EKF_UPDATE performs the Extended Kalman Filter update step.
%   
%   /references/
%      [1] "Kalman Filter". Wikipedia, 3 February 2009. 
%          http://en.wikipedia.org/wiki/Kalman_filter
%   
%   /input/
%      x ( real[ m1 ] )       : system state mean vector;
%      P ( real[ m1 ][ m1 ] ) : system state covariance matrix;
%      z ( real[ m2 ] )       : measurement state mean vector;
%      R ( real[ m2 ][ m2 ] ) : measurement state covariance matrix;
%      s ( real[ m1 ] )       : observer state vector;
%      params ( struct )      : filter-specific parameters;
%      hmodel ( function )    : function handle for observer model;
%      hextnd ( function )    : function handle for observer model extended;
%      rmodel ( function )    : function handle for noise model;
%      hparam ( struct )      : observer model parameters;
%      rparam ( struct )      : noise model parameters;
%
%   /output/
%      xk ( real[ m1 ] )       : updated system state mean vector;
%      Pk ( real[ m1 ][ m1 ] ) : updated system state covariance matrix;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ xk, Pk ] = filter_ekf_update( ...
    x, P, z, R, s, params, hmodel, hextnd, rmodel, hparam, rparam ...
)
%#eml
%% UPDATE

% ---- Mean Projection ----
u = hmodel(x, s, hparam);
H = hextnd(x, s, hparam);

% ---- Kalman Gain ----
Ru = rmodel(size(u, 1), x, s, rparam);

S = Ru + H * P * H' + R;
K = P * H' / S;

% ---- State Update ----
xk = x + K * (z - u);
Pk = (eye(size(P), class(P)) - K * H) * P;


end % FILTER_EKF_UPDATE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%