%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FILTER_F_ODE : Generic ordinary differential equation process model
%   [ xk, tk ] = filter_f_ode( x, t, h, , params, dynamics_ode, numerics_ode )
%
%   FILTER_F_ODE provides a process model for a generic ordinary differential
%   equation.
%
%   /notes/
%      - The "hmax" parameter limits the propagation steps.
%   
%   /input/
%      x ( real[ m ][ n ] )      : system state vector;
%      t ( real )                : system state time;
%      h ( real )                : propagation time step;
%      params ( struct )         : model-specific parameters;
%      dynamics_ode ( function ) : function handle for dynamics;
%      numerics_ode ( function ) : function handle for numerics;
%
%   /output/
%      xk ( real[ m ][ n ] ) : propagated system state vector;
%      tk ( real )           : propagated time;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ xk, tk ] = filter_f_ode( ...
    x, t, h, params, dynamics_ode, numerics_ode ...
)
%#eml
%% PARAMETERS

% Propagation Parameters
hmax = params.hmax; % Maximum propation step size      


%% PROPAGATION

% ---- Initialization ----
xn = x;
tn = t;
hn = h;

if ( abs(hn) > hmax )
    hn = hmax * sign(h);
end

hf         = mod(h, hn);
iterations = floor(h / hn);

% ---- Iteration ----
for ii = 1 : iterations
    xn = numerics_ode(dynamics_ode, xn, tn, hn);
    tn = tn + hn;
end

% ---- Finalization ----
xk = numerics_ode(dynamics_ode, xn, tn, hf);
tk = tn + hf;


end % FILTER_F_ODE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%