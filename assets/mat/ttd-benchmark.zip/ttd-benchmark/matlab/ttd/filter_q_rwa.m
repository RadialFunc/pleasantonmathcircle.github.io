%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FILTER_Q_RWA : Random Walk Acceleration disturbance model
%   [ Q ] = filter_q_rwa( m, x, t, h, params )
%
%   FILTER_Q_RWA represents a simple random walk acceleration disturbance
%   model for estimating propagation uncertainty for states with
%   position-velocity-acceleration.
%
%      - The system state is assumed to be in a Cartesian coordinate system.
%      - The system state is assumed to be in the form:
%        [ position ; velocity ; acceleration ]
%
%   /references/
%      [1] Bird, J.S. "Some Applications of Kalman Filtering in Advanced Land
%          Fire Control Systems (U)". Defence Research Establishment Ottawa, 
%          Report No 1172, April 1993, Ottawa.
%
%   /input/
%      m ( integer )     : disturbance dimensions;
%      x  ( real[ m ] )  : system state;
%      t  ( real )       : system state time;
%      h  ( real )       : propagation time step;
%      params ( struct ) : model-specific parameters;
%
%   /output/
%      Q ( real[ m ][ m ] ) : process noise (disturbance) covariance;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ Q ] = filter_q_rwa( ...
    m, x, t, h, params ...
)
%#eml
%% PARAMETERS

% Random Walk Acceleration Parameters
rwa_dQ = params.rwa_dQ;


%% PROPAGATION

% ---- Initial Variance ----
Q = zeros(m, class(x));

% ---- Additive Random Walk Acceleration Variance ----
Q(7,7) = rwa_dQ(1,1) * h;
Q(8,8) = rwa_dQ(2,2) * h;
Q(9,9) = rwa_dQ(3,3) * h;


end % FILTER_Q_RWA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%