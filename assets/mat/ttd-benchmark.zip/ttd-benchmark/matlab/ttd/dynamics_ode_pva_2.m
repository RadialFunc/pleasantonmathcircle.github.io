%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%DYNAMICS_ODE_PVA_2 : Evaluate position-velocity-acceleration derivative
%   [ k ] = dynamics_ode_pva_2( t, y )
%
%   DYNAMICS_ODE_PVA_2 evaluates the position-velocity-acceleration derivative.
%
%   The position-velocity-acceleration derivative is evaluated with acceleration 
%   from a rudimentary WGS84/EGM96 J2 gravity model (oblate earth) and additive
%   constant acceleration (thrust).
%
%   The gravity model is valid only for state positions outside the earth's
%   atmosphere.
%
%   /notes/
%      - The system state is assumed to be in a non-rotating reference frame.
%      - The system state is assumed to be in a Cartesian coordinate system.
%      - The system state is assumed to be in the form:
%        [ position ; velocity ; thrust ]
%   
%   /input/
%      t ( real )           : independent variable value;
%      y ( real[ 9 ][ n ] ) : dependent variable value;
%
%   /output/
%      k ( real[ 9 ][ n ] ) : final dependent variable value;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ k ] = dynamics_ode_pva_2( ...
    t, y ...
)
%#eml
%% CONSTANTS

% WGS84 parameters
wgs84 = earth_wgs84_ellipsoid();
WGS84_A  = wgs84.a;  % WGS84 Semi-major Axis (m)
WGS84_GM = wgs84.GM; % WGS84 Gravitational Const w/ Atmos (m**3/s**2)
WGS84_J2 = wgs84.J2; % WGS84 Second Deg Harmonic Coeff


%% EVALUATION

% ---- initialization ----
k = zeros(size(y), class(y));

% ---- position derivative ----
% (d/dt)(r) = v;
k(1,:) = y(4,:); 
k(2,:) = y(5,:);
k(3,:) = y(6,:); 

% ---- velocity deriviative ----
c0 = y(1,:).^2 + y(2,:).^2 + y(3,:).^2; 
c1 = sqrt(c0); 

c2 = -WGS84_GM ./ c0 ./ c1;
c3 = ((3 / 2) * WGS84_J2 * WGS84_A * WGS84_A) ./ c0;
c4 = 5 .* y(3,:) .* y(3,:) ./ c0;

% g(x, y, z) = [ c2 * (1 + c3 * (1 - c4)) * x ;
%                c2 * (1 + c3 * (1 - c4)) * y ;
%                c2 * (1 + c3 * (3 - c4)) * z ]

c5 = c2 .* (1.0 + 1.0 .* c3 - c3 .* c4);
c6 = c2 .* (1.0 + 3.0 .* c3 - c3 .* c4);

% (d/dt)(v) = a + g(x, y, z);
k(4,:) = c5 .* y(1,:) + y(7,:);
k(5,:) = c5 .* y(2,:) + y(8,:);
k(6,:) = c6 .* y(3,:) + y(9,:);

% ---- acceleration deriviative ----
% (d/dt)(a) = 0;


end % DYNAMICS_ODE_PVA_2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
