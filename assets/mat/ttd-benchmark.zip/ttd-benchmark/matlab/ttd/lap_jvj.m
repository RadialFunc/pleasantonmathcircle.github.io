%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%LAP_JVJ : Solve the Linear Assignment Problem using JVJ
%   [ x, y, u, v ] = lap_jvj( m, n, ci, cn, cj, ce, x, y, u, v, params )
%
%   LAP_JVJ uses the Jonker-Volgenant (JDC) algorithm to solve the 
%   Linear Assignment Problem by finding a feasible matching with minimal cost.
%
%   This variant of the Jonker-Volgenant algorithm includes modifications by
%   JDC:
%      - Removal of the column reduction and reduction transfer steps to allow 
%        (asymmetric) rectangular cost matrices
%      - Reformulation of the cost matrix representation for sparse, 
%        rectangular matrices (Modified Yale Sparse Matrix Format)
%      - Replacement of the original row reduction step with an alternative 
%        (deterministic) row reduction method 
%      - Addition of a step to enforce consistency and minimum cost assignments 
%        for infeasible problems
%
%   /notes/
%      - The assignment arrays use the zero value to represent Not-Assigned.
%      - The assignment and dual variable arrays should be consistent or 
%        initialized to zeros.
%      - The "reduction_epsilon" parameter determines a tolerance for the
%        ROW REDUCTION phase. A typical value is 0.00 or 0.01.
%      - The "reduction_iterations" parameter determines a number of ROW 
%        REDUCTION iterations. A typical value is the number of sinks (cost 
%        matrix columns) or sources (cost matrix rows).
%   
%   /reference/ 
%      [1] "Assignment problem". Wikipedia, 24 October 2008. 
%          http://en.wikipedia.org/wiki/Assignment_problem
%      [2] Jonker, R. and Volgenant, A. "A Shortest Augmenting Path Algorithm
%          for Dense and Sparse Linear Assignment Problems". Computing, Vol 38, 
%          1987, 325-340.
%      [3] Drummond, O.E., Castanon, D.A., and Bellovin, M.S. "Comparison of 2-D
%          Assignment Algorithms for Sparse, Rectangular, Floating Point, Cost
%          Matrices". Journal of the SDI Panels on Tracking, Institute for
%          Defense Analyses, December 1990.
%
%   /input/
%      m ( integer )       : number of sources (cost matrix rows);
%      n ( integer )       : number of sinks (cost matrix columns);
%      ci ( integer[ m ] ) : sparse cost matrix row indices;
%      cn ( integer[ m ] ) : sparse cost matrix row lengths;
%      cj ( integer[ s ] ) : sparse cost matrix column values;
%      ce ( real[ s ] )    : sparse cost matrix element values;
%      x ( integer[ m ] )  : source assignments;
%      y ( integer[ n ] )  : sink assignments;
%      u ( real[ m ] )     : source dual variables;
%      v ( real[ n ] )     : sink dual variables;
%      params ( struct )   : algorithm-specific parameters;
%
%   /output/
%      x ( integer[ m ] ) : source assignments;
%      y ( integer[ n ] ) : sink assignments;
%      u ( real[ m ] )    : source dual variables;
%      v ( real[ n ] )    : sink dual variables;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ x, y, u, v ] = lap_jvj( ...
     m, n, ci, cn, cj, ce, x, y, u, v, params ...
)
%#eml
%% CONSTANTS

NF = cast(n + 1, class(x)); % Not-Feasible value
NA = cast(0, class(x));     % Not-Assigned value

INF = cast(Inf, class(ce)); % Effective infinity value


%% PARAMETERS

reduction_epsilon    = params.reduction_epsilon;
reduction_iterations = params.reduction_iterations;


%% INITIALIZATION

% ---- Not-Feasible/Not-Assigned Sources ----
unassigned_m = cast(0, class(m));        % Count of Not-Assigned sources
unassigned_i = zeros(size(x), class(x)); % Array of Not-Assigned sources
for ii = 1 : m
    if ( cn(ii) == 0 )
        x(ii) = NF;
    elseif ( x(ii) == NA )
        unassigned_m = unassigned_m + 1;
        unassigned_i(unassigned_m) = ii;
    end
end


%% ROW REDUCTION

for iteration = 1 : reduction_iterations
    unassigned_n = cast(0, class(m)); % Count for Not-Assigned sources
    within_epsilon = true;            % Status for relaxation
    for unassigned_ii = 1 : unassigned_m
        ii = unassigned_i(unassigned_ii); % Not-Assigned source
        k0 = ci(ii);                      % Source cost matrix row start index
        kn = ci(ii) + cn(ii) - 1;         % Source cost matrix row end index
                
        % ---- Best/Next-Best Assignment ----
        min_k0 = k0; 
        min_h0 = ce(k0) - v(cj(min_k0));
        min_h1 = INF;
        for ki = k0 + 1 : kn
            jj = cj(ki);
            hj = ce(ki) - v(jj);       
            if ( hj <= min_h1 )
                if ( hj > min_h0 )
                    min_h1 = hj;
                else
                    if ( hj < min_h0 || ...
                         y(cj(min_k0)) ~= NA && y(jj) == NA )
                        min_k0 = ki;
                    end
                    
                    min_h1 = min_h0;
                    min_h0 = hj;
                end
            end
        end
        
        % ----- Update ----
        jj = cj(min_k0);
        ji = y(jj);
        
        if ( min_h0 ~= min_h1 )
            v(jj) = v(jj) + (min_h0 - min_h1);
        end
        
        within_epsilon = within_epsilon && ...
                         ( min_h0 + abs(reduction_epsilon * min_h0) >= min_h1 );
        
        % ---- Replacement ----
        if ( ji ~= NA )
            x(ji) = NA;
            
            unassigned_n = unassigned_n + 1;
            unassigned_i(unassigned_n) = ji;
        end
        
        % ---- Assignment ----
        x(ii) = jj;
        y(jj) = ii;
    end
    
    unassigned_m = unassigned_n;
    
    % ---- Short Circuit ----
    if ( unassigned_m == 0 || within_epsilon )
        break;
    end
end


%% AUGMENTATION

if ( unassigned_m > 0 )
    % ---- Enforce Positivity ----
    for ii = 1 : m
        k0 = ci(ii);              % Source cost matrix row start index
        kn = ci(ii) + cn(ii) - 1; % Source cost matrix row end index

        u(ii) = INF;
        for ki = k0 : kn
            if ( ce(ki) < u(ii) )
                u(ii) = ce(ki);
            end
        end
    end

    % ---- Dijkstra's Algorithm ----
    for unassigned_k = 1 : unassigned_m
        ii = unassigned_i(unassigned_k); % Not-Assigned source
        k0 = ci(ii);                     % Source cost matrix row start index
        kn = ci(ii) + cn(ii) - 1;        % Source cost matrix row end index

        visited = false(size(y)); % Visited status for sinks
        
        cost     = ones(size(y), class(ce)) * INF; % Costs to sinks
        distance = ones(size(y), class(ce)) * INF; % Distances to sinks
        
        previous = ones(size(y), class(x)) * NA;   % Previous sources to sinks
        marginal = ones(size(y), class(ce)) * INF; % Marginal cost to sinks

        % nodes                          := [ set of sink nodes ]
        % nodes(1        : nodes_i1 - 1) := [ subset of visited sink nodes ]
        % nodes(nodes_i1 : nodes_i2 - 1) := [ subset of to-visit sink nodes ]
        % nodes(nodes_i2 : end         ) := [ subset of unvisited sink nodes ]
        nodes    = zeros(size(y), class(x)); % Search nodes (sinks)
        nodes_i1 = cast(1, class(m));
        nodes_i2 = cast(1, class(m));

        % ---- Initialize Search ----
        for visited_ii = 1 : n
            visited(visited_ii) = false;
        end
        
        for ki = k0 : kn
            cost(cj(ki)) = ce(ki);
        end
        
        for ki = k0 : kn
            distance(cj(ki)) = ce(ki) - u(ii) - v(cj(ki));
        end

        for ki = k0 : kn
            previous(cj(ki)) = ii;
        end

        for nodes_ii = 1 : n
            nodes(nodes_ii) = nodes_ii;
        end

        % ---- Search ----
        jn = NF;
        while ( jn == NF && nodes_i1 <= n ) 
            % ---- Minimum Distance ----
            min_distance = INF;
            for nodes_ii = nodes_i1 : n
                jj = nodes(nodes_ii);
                dj = distance(jj);
                pj = previous(jj);
                if ( pj ~= NA )
                    if ( dj <= min_distance )
                        if ( dj < min_distance )
                            min_distance = dj;
                            nodes_i2     = nodes_i1;
                        end

                        nodes(nodes_ii) = nodes(nodes_i2);
                        nodes(nodes_i2) = jj;
                        nodes_i2 = nodes_i2 + 1;
                    end
                end
            end

            % ---- Unassigned Sinks ----
            if ( nodes_i1 == nodes_i2 )
                break;
            else
                for nodes_ii = nodes_i1 : nodes_i2 - 1
                    jj  = nodes(nodes_ii);
                    if ( y(jj) == NA )
                        jn = jj; 
                        break;
                    end
                end
            end

            % ---- Updated Distances ----
            if ( jn == NF )
                for nodes_ii = nodes_i1 : nodes_i2 - 1
                    jj  = nodes(nodes_ii);     % Visited sink
                    ji  = y(jj);               % Assigned source
                    jk0 = ci(ji);              % Assigned source cost matrix row start index
                    jkn = ci(ji) + cn(ji) - 1; % Assigned source cost matrix row end index

                    visited(jj) = true;
                    
                    src_cost     = cost(jj); 
                    src_distance = min_distance;
                    for jki = jk0 : jkn
                        if ( cj(jki) == jj )
                            marginal(jj) = ce(jki);
                            src_cost     = src_cost - ce(jki);
                            src_distance = src_distance - (ce(jki) - u(ji) - v(jj));
                            break;
                        end
                    end 
                    
                    for jki = jk0 : jkn
                        jjj = cj(jki);
                        if ( ~visited(jjj) )
                            djj = src_distance + ce(jki) - u(ji) - v(jjj);
                            if ( djj < distance(jjj) )
                                cost(jjj)     = src_cost + ce(jki);
                                distance(jjj) = djj;
                                previous(jjj) = ji;
                            end
                        end
                    end 
                end

                nodes_i1 = nodes_i2;
            end
        end
        
        % ---- Consistency ----
        if ( jn == NF )
            min_cost = 0;
            for nodes_ii = 1 : nodes_i1 - 1
                jj       = nodes(nodes_ii);
                min_cost = min_cost + marginal(jj);
            end
            
            for nodes_ii = 1 : nodes_i1 - 1
                jj = nodes(nodes_ii);
                if ( cost(jj) < min_cost )
                    jn       = jj;
                    min_cost = cost(jj);
                end
            end

            if ( jn ~= NF )
                x(y(jn)) = NA;
                y(jn)    = NA;
            end
        end

        % ---- Augmentation ----
        if ( jn == NF )
            x(ii) = NF;
        else
            % ---- Update Dual Variables ----
            for nodes_ii = 1 : nodes_i1 - 1
                jj    = nodes(nodes_ii);
                v(jj) = v(jj) + distance(jj) - distance(jn);
            end

            % ---- Update Assignments ----
            while ( previous(jn) ~= ii )
                jj = jn;           % Current sink
                ji = previous(jj); % Assigned source

                jn = x(ji);        % Next sink

                x(ji) = jj;
                y(jj) = ji; 
            end

            x(ii) = jn;
            y(jn) = ii;
        end
    end
end


%% FINALIZATION

% ---- Not-Feasible Sources ----
for ii = 1 : m
    if ( x(ii) == NF )
        x(ii) = NA;
    end
end


end % LAP_JVJ
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%