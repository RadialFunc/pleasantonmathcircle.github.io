%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%LAP_MURTY_1 : Solve the K-Best Linear Assignment Problem using Murty
%   [ x, y, u, v, total, costs, ranking ] = lap_murty_1( m, n, ci, cn, cj, ce, x, y, u, v, k, f, fparams )
%
%   LAP_MURTY_1 uses Murty's Ranked Assignment method combined with a Shortest
%   Augmenting Path method to solve the K-Best Linear Assignment Problem.
%
%   This variant of Murty's algorithm originally implemented an optimization 
%   proposed in [2] for improving the algorithmic complexity by "recycling" 
%   previous solutions. However, it was found that this optimization is only
%   applicable to the Symmetric Linear Assignment Problem.
%
%   /notes/
%      - The assignment arrays use the zero value to represent Not-Assigned.
%      - The assignment and dual variable arrays should be initialized to zeros.
%      - The cost array uses NaN to represent an empty result.
%
%   /reference/ 
%      [1] Cox, I.J. "On Finding Ranked Assignments with Application to
%          Multitarget Tracking and Motion Correspondence". IEEE Transactions on
%          Aerospace and Electronic Systems, Vol 31, No 1, January 1995.
%      [2] Miller, M.L, Stone, H.S., and Cox, I.J. "Optimizing Murty's Ranked
%          Assignment Method". IEEE Transactions on Aerospace and Electronic
%          Systems, Vol 33, No 3, July 1997.     
%
%   /input/
%      m ( integer )            : number of sources (cost matrix rows);
%      n ( integer )            : number of sinks (cost matrix columns);
%      ci ( integer[ m ][ k ] ) : sparse cost matrix row indices;
%      cn ( integer[ m ][ k ] ) : sparse cost matrix row lengths;
%      cj ( integer[ s ][ k ])  : sparse cost matrix column values;
%      ce ( real[ s ][ k ] )    : sparse cost matrix element values;
%      x ( integer[ m ][ k ] )  : source assignments;
%      y ( integer[ n ][ k ] )  : sink assignments;
%      u ( real[ m ][ k ] )     : source dual variables;
%      v ( real[ n ][ k ] )     : sink dual variables;
%      k ( integer )            : number of results;
%      f ( function )           : function handle to SAP LAP solver;
%      fparams ( struct )       : SAP LAP solver parameters;
%
%   /output/
%      x ( integer[ m ][ k ] )  : source assignments;
%      y ( integer[ n ][ k ] )  : sink assignments;
%      u ( real[ m ][ k ] )     : source dual variables;
%      v ( real[ n ][ k ] )     : sink dual variables;
%      total ( integer )        : total results;
%      costs ( integer[ k ] )   : result costs;
%      ranking ( integer[ k ] ) : sorted result indices (best -> worst);
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%   see also LAP_JVC, LAP_JVJ
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ x, y, u, v, total, costs, ranking ] = lap_murty_1( ...
	m, n, ci, cn, cj, ce, x, y, u, v, k, f, fparams ...
)
%#eml
%% CONSTANTS

NA = cast(0, class(x)); % Not-Assigned value

INF = cast(Inf, class(ce)); % Effective infinity value


%% INITIALIZATION

% ---- Workspace ----
total   = cast(0, class(k));                    % Result count
costs   = ones(size(x, 2), 1, class(ce)) * INF; % Result costs
ranking = zeros(size(x, 2), 1, class(k));       % Result ranking

C = ones(size(x, 1), size(y, 1), class(ce)) * INF; % Full cost matrix
C = lap_problem_full(m, n, ci(:,1), cn(:,1), cj(:,1), ce(:,1), C); 

% ---- Initial Solution ----
fout.x = x(:,k);
fout.y = y(:,k);
fout.u = u(:,k);
fout.v = v(:,k);

fout  = f(m, n, ci(:,1), cn(:,1), cj(:,1), ce(:,1), fout.x, fout.y, fout.u, fout.v, fparams);
cfout = lap_cost_full(m, n, C, fout.x, fout.y, INF);
if ( cfout < INF )
    x(:,1) = fout.x;
    y(:,1) = fout.y;
    u(:,1) = fout.u;
    v(:,1) = fout.v;

    total      = cast(1, class(k));
    costs(1)   = cfout;
    ranking(1) = cast(1, class(k));
end


%% SEARCH

if ( total < 1 )
    return;
end

for kk = 2 : k
    % ---- Selection ----
    pk = ranking(kk - 1); % Partition problem index
    if ( pk > total )
        break;
    end

    % Initialize partial solution
    xk = zeros(size(fout.x), class(x)) + NA;
    yk = zeros(size(fout.y), class(y)) + NA;
    uk = zeros(size(fout.u), class(u)); 
    vk = zeros(size(fout.v), class(v));

	for ii = 1 : m
        ij = x(ii,pk); % Partition pivot assignment
        cp = INF;      % Partition pivot cost
        
        % ---- Partition 0 Creation ----
        % Remove assignment from problem
        cik = ci(:,pk); 
        cnk = cn(:,pk); 
        cjk = cj(:,pk);
        cek = ce(:,pk);
        
        k0 = cik(ii);
        kn = cik(ii) + cnk(ii) - 1;
        for ki = k0 : kn
            if ( cjk(ki) == ij )
                cp = cek(ki);
                
                cnk(ii) = cnk(ii) - 1;
                cjk(ki) = cjk(kn);
                cek(ki) = cek(kn);
                
                break;
            end
        end
        
        % ---- Partition 0 Solution ----
        cfout = INF;
        if ( cnk(ii) > 0 )
            fout.x = xk;
            fout.y = yk;
            fout.u = uk;
            fout.v = vk;
            
            fout  = f(m, n, cik, cnk, cjk, cek, fout.x, fout.y, fout.u, fout.v, fparams);
            cfout = lap_cost_full(m, n, C, fout.x, fout.y, INF);
        end

        % ---- Partition 0 Evaluation ----
        if ( cfout < INF )
            idx = NA;
            if ( total < k )
                % Find empty result
                for ki = 1 : k
                    if ( costs(ki) == INF )
                        idx = ki;
                        break;
                    end
                end
                
                % Insert new result
                total = total + 1;
            else
                % Find maximum cost result
                max_idx  =   NA;
                max_cost = -INF;
                for ki = kk : k
                    if ( costs(ki) > max_cost )
                        max_idx  = ki;
                        max_cost = costs(ki);
                    end
                end

                % Replace maximum cost result
                if ( cfout < max_cost )
                    idx = max_idx;
                end
            end
            
            if ( idx ~= NA )
                x(:,idx) = fout.x;
                y(:,idx) = fout.y;
                u(:,idx) = fout.u;
                v(:,idx) = fout.v;  
                
                ci(:,idx) = cik;
                cn(:,idx) = cnk;
                cj(:,idx) = cjk;
                ce(:,idx) = cek;

                costs(idx) = cfout;
                
                [ sorted_costs, sorted_idx ] = sort(costs);
                ranking = cast(sorted_idx, class(ranking));
            end
        end
        
        % ---- Partition 1 Creation ----
        % Fix assignment in problem
        for xi = 1 : m
            k0 = ci(xi,pk);
            kn = ci(xi,pk) + cn(xi,pk) - 1;
            for ki = k0 : kn
                if ( cj(ki,pk) == ij )
                    cn(xi,pk) = cn(xi,pk) - 1;
                    cj(ki,pk) = cj(kn,pk);
                    ce(ki,pk) = ce(kn,pk);

                    break;
                end
            end
        end
        
        cn(ii,pk)        = 1; 
        cj(ci(ii,pk),pk) = ij;
        ce(ci(ii,pk),pk) = cp;
        
        % Update partial solution
        xk(ii) = ij;
        yk(ij) = ii;
        uk(ii) = u(ii,pk);
        vk(ij) = v(ij,pk);
	end
end


end % LAP_MURTY_1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%