%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%EARTH_WGS84_ELLIPSOID : WGS84 Ellipsoid Parameters
%   [ param ] = wgs84_ellipsoid( )
%
%   EARTH_WGS84_ELLIPSOID returns a struct containing WGS84 Ellipsoid Parameters
%   extracted from [1].
%
%   /references/
%      [1] "Department of Defense World Geodetic System 1984, Its Definition and
%          Relationships with Local Geodetic Systems". NIMA TR8350.2, Third 
%          Edition, Amendment 1, 3 January 2000.
%   
%   /input/
%      none
%
%   /output/
%      param ( struct ) : WGS84 Ellipsoid parameters;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ param ] = earth_wgs84_ellipsoid( )
%#eml
%% CONSTANTS

% ---- Defined Parameters ----
param.a  = 6378137.0;       % Semi-major Axis (m)
param.f  = 1/298.257223563; % Flattening
param.w  = 7292115.0e-11;   % Angular Velocity (rad/s)
param.GM = 3986004.418e8;   % Gravitational Const w/ Atmos (m**3/s**2)

% ---- Special Parameters ----
param.GM_prime = 3986000.9e8;      % Gravitational Const w/o Atmos (m**3/s**2)
param.GM_A     = 3.5e8;            % Gravitational Const of Atmos (m**3/s**2)
param.w_star   = 7292115.8553e-11; % Angular Vel in Precessing Ref Frame (rad/s)

% ---- Derived Parameters ----
param.J2      =  1.082629821313305e-3;  % Second Deg Harmonic Coeff
param.C_2_0   = -0.484166774985e-3;     % Normalized Second Deg Zonal Harmonic
param.b       =  6356752.3142;          % Semi-minor Axis (m)
param.e       =  8.1819190842622e-2;    % First Eccentricity
param.e_prime =  8.2094437949696e-2;    % Second Eccentricity
param.E       =  5.2185400842339e5;     % Linear Eccentricity
param.c       =  6399593.6258;          % Polar Radius of Curvature (m)


end % EARTH_WGS84_ELLIPSOID
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%