%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%LAP_PROBLEM_SPARSE : Transform LAP problem from full form to sparse form
%   [ ci, cn, cj, ce ] = lap_problem_sparse( m, n, ci, cn, cj, ce, C )
%
%   LAP_PROBLEM_SPARSE transforms a LAP problem from full cost matrix form to 
%   sparse cost matrix form.
%
%   /notes/
%      - The cost is infinite for infeasible solutions.
%      - The full cost matrix argument is necessary for EML matrix sizing.
%
%   /input/
%      m ( integer )        : number of sources (cost matrix rows);
%      n ( integer )        : number of sinks (cost matrix columns);
%      ci ( integer[ m ] )  : sparse cost matrix row indices;
%      cn ( integer[ m ] )  : sparse cost matrix row lengths;
%      cj ( integer[ s ] )  : sparse cost matrix column values;
%      ce ( real[ s ] )     : sparse cost matrix element values;
%      C ( real[ m ][ n ] ) : full cost matrix;
%      infinity ( real )    : infinity value;
%
%   /output/
%      ci ( integer[ m ] ) : sparse cost matrix row indices;
%      cn ( integer[ m ] ) : sparse cost matrix row lengths;
%      cj ( integer[ s ] ) : sparse cost matrix column values;
%      ce ( real[ s ] )    : sparse cost matrix element values;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%   see also LAP_PROBLEM_FULL
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ ci, cn, cj, ce ] = lap_problem_sparse( ...
     m, n, ci, cn, cj, ce, C, infinity ...
)
%#eml
%% TRANSFORM

kk = 1;
for ii = 1 : m
    ci(ii) = kk;
    for jj = 1 : n
        if ( C(ii,jj) < infinity )
            ce(kk) = C(ii,jj);
            cj(kk) = jj;
            kk = kk + 1;
        end
    end
    cn(ii) = kk - ci(ii);
end


end % LAP_PROBLEM_SPARSE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%