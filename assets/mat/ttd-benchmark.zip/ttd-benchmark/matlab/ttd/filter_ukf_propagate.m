%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FILTER_UKF_PROPAGATE : Unscented Kalman Filter propagation
%   [ xk, Pk, tk ] = filter_ukf_propagate( x, P, t, h, params, fmodel, qmodel, fparam, qparam )
%
%   FILTER_UKF_PROPAGATE performs the Unscented Kalman Filter propagation step.
%
%   /notes/
%      - The "alpha" parameter is a primary scaling factor. It determines the 
%        spread of sigma points around the prior mean. The range is (0, 3].
%      - The "beta" parameter is a secondary scaling factor. It determines 
%        weighting on the zeroth sigma-point. The optimal value for Gaussian
%        priors is 2.
%      - The "kappa" parameter is a tertiary scaling factor. It provides an 
%        additional degree of freedom.
%   
%   /references/
%      [1] "Kalman Filter". Wikipedia, 3 February 2009. 
%          http://en.wikipedia.org/wiki/Kalman_filter
%      [2] Julier, S.J. and Uhlmann, J.K. "A New Extension of the Kalman Filter
%          to Nonlinear Systems." 
%      [3] van der Merwe, R. and Wan, E.A. "Sigma-Point Kalman Filters for 
%          Nonlinear Estimation and Sensor-Fusion - Applications to Integrated 
%          Navigation".
% 
%   /input/
%      x ( real[ m ] )      : system state mean vector;
%      P ( real[ m ][ m ] ) : system state covariance matrix;
%      t ( real )           : system state time;
%      h ( real )           : propagation time step;
%      params ( struct )    : filter-specific parameters;
%      fmodel ( function )  : function handle for process model;
%      qmodel ( function )  : function handle for disturbance model;
%      fparam ( struct )    : process model parameters;
%      qparam ( struct )    : disturbance model parameters;
%
%   /output/
%      xk ( real[ m ] )      : propagated system state mean vector;
%      Pk ( real[ m ][ m ] ) : propagated system state covariance matrix;
%      tk ( real )           : propagated system state time;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ xk, Pk, tk ] = filter_ukf_propagate( ...
    x, P, t, h, params, fmodel, qmodel, fparam, qparam ...
)
%#eml
%% PARAMETERS

% Scaled Unscented Transform Parameters
alpha = params.alpha;
beta  = params.beta;
kappa = params.kappa;


%% PROPAGATION

% ---- Weights ----
m = size(x, 1);

lambda = alpha^2 * (m + kappa) - m;

wy0 = lambda / (m + lambda);
wyi = 1.0 / 2.0 / (m + lambda);

wyy0 = wy0 + (1.0 - alpha^2 + beta);
wyyi = wyi;

% ---- Sigma Points ----
L = chol(P * (m + lambda))';

X0 = x;
Xi = [ +L, -L ];
for ii = 1 : m
    Xi(ii,:) = Xi(ii,:) + x(ii);
end

% ---- Sigma Point Propagation ----
Y0 = fmodel(X0, t, h, fparam);
Yi = fmodel(Xi, t, h, fparam);

% ---- Statistics ----
uy = wy0 * Y0 + ...
     wyi * sum(Yi, 2);

dy0 = Y0 - uy;
dyi = Yi;
for ii = 1 : m
    dyi(ii,:) = dyi(ii,:) - uy(ii);
end

Pyy = wyy0 * dy0 * dy0' + ...
      wyyi * dyi * dyi';

% ---- State Propagation ----
Q = qmodel(m, x, t, h, qparam);

xk = uy;
Pk = Pyy + Q;
tk = t + h;


end % FILTER_UKF_PROPAGATE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%