%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FILTER_EKF_PROPAGATE : Extended Kalman Filter propagation
%   [ xk, Pk, tk ] = filter_ekf_propagate( x, P, t, h, params, fmodel, fextnd, qmodel, fparam, qparam )
%
%   FILTER_EKF_PROPAGATE performs the Extended Kalman Filter propagation step.
%   
%   /references/
%      [1] "Kalman Filter". Wikipedia, 3 February 2009. 
%          http://en.wikipedia.org/wiki/Kalman_filter
%
%   /input/
%      x ( real[ m ] )      : system state mean vector;
%      P ( real[ m ][ m ] ) : system state covariance matrix;
%      t ( real )           : system state time;
%      h ( real )           : propagation time step;
%      params ( struct )    : filter-specific parameters;
%      fmodel ( function )  : function handle for process model;
%      fmodel ( function )  : function handle for process model extended;
%      qmodel ( function )  : function handle for disturbance model;
%      fparam ( struct )    : process model parameters;
%      qparam ( struct )    : disturbance model parameters;
%
%   /output/
%      xk ( real[ m ] )      : propagated system state mean vector;
%      Pk ( real[ m ][ m ] ) : propagated system state covariance matrix;
%      tk ( real )           : propagated system state time;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ xk, Pk, tk ] = filter_ekf_propagate( ...
    x, P, t, h, params, fmodel, fextnd, qmodel, fparam, qparam ...
)
%#eml
%% PROPAGATION

% ---- Mean Propagation ----
u = fmodel(x, t, h, fparam);
F = fextnd(x, t, h, fparam);

% ---- State Propagation ----
Q = qmodel(size(u, 1), x, t, h, qparam);

xk = u;
Pk = F * P * F' + Q;
tk = t + h;


end % FILTER_EKF_PROPAGATE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%