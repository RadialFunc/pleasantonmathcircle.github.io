%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FILTER_Q_RWV : Random Walk Velocity disturbance model
%   [ Q ] = filter_q_rwv( m, x, t, h, params )
%
%   FILTER_Q_RWV represents a simple random walk velocity disturbance model 
%   for estimating propagation uncertainty for states with
%   position-velocity.
%
%
%   /notes/
%      - The system state is assumed to be in a Cartesian coordinate system.
%      - The system state is assumed to be in the form:
%        [ position ; velocity ]
%
%   /references/
%      [1] Bird, J.S. "Some Applications of Kalman Filtering in Advanced Land
%          Fire Control Systems (U)". Defence Research Establishment Ottawa, 
%          Report No 1172, April 1993, Ottawa.
%
%   /input/
%      m ( integer )    : disturbance dimensions;
%      x  ( real[ m ] ) : system state;
%      t  ( real )      : system state time;
%      h  ( real )      : propagation time step;
%
%   /output/
%      Q ( real[ m ][ m ] ) : process noise (disturbance) covariance;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ Q ] = filter_q_rwv( ...
    m, x, t, h, params ...
)
%#eml
%% PARAMETERS

% Random Walk Velocity Parameters
rwv_dQ = params.rwv_dQ;


%% PROPAGATION

% ---- Initial Variance ----
Q = zeros(m, class(x));

% ---- Additive Random Walk Velocity Variance ----
Q(4,4) = rwv_dQ(1,1) * h;
Q(5,5) = rwv_dQ(2,2) * h;
Q(6,6) = rwv_dQ(3,3) * h;


end % FILTER_Q_RWV
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%