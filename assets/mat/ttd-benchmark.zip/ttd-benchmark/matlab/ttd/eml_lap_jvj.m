%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%EML_LAP_JVJ : EML function wrapper for LAP_JVJ
%   [ xk, tk ] = eml_lap_jvj( m, n, ci, cn, cj, ce, x, y, u, v, params )
%
%   EML_LAP_JVJ implements a function wrapper for LAP_JVJ as a workaround for
%   an EML limitation where function handles can only return a single output.
%   
%   /input/
%      ...
%
%   /output/
%      out ( struct ) : wrapped output;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%   see also LAP_JVJ
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ out ] = eml_lap_jvj( ...
     m, n, ci, cn, cj, ce, x, y, u, v, params ...
)
%#eml

[ out.x, out.y, out.u, out.v ] = lap_jvj(m, n, ci, cn, cj, ce, x, y, u, v, params);


end % EML_LAP_JVJ
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%