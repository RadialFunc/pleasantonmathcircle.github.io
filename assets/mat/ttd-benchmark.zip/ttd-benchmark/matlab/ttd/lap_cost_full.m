%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%LAP_COST_FULL : Calculate the cost for a LAP solution
%   [ c, cx, cy ] = lap_cost_full( m, n, C, x, y, infinity )
%
%   LAP_COST_FULL calculates the cost for a LAP solution mapping sources to
%   sinks using a full cost matrix.
%
%   /notes/
%      - The cost is infinite for infeasible solutions.
%
%   /input/
%      m ( integer )        : number of sources (cost matrix rows);
%      n ( integer )        : number of sinks (cost matrix columns);
%      C ( real[ m ][ n ] ) : sparse cost matrix row indices;
%      x ( integer[ m ] )   : source assignments;
%      y ( integer[ n ] )   : sink assignments;
%      infinity ( real )    : infinity value;
%
%   /output/
%      c  ( real )      : assignment solution cost;
%      cx ( real[ m ] ) : assignment cost by source;
%      cy ( real[ n ] ) : assignment cost by sink;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%   see also LAP_COST_SPARSE
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ c, cx, cy ] = lap_cost_full( ...
     m, n, C, x, y, infinity ...
)
%#eml
%% CALCULATION

c  = cast(0, class(C));
cx = ones(size(x), class(C)) * infinity;
cy = ones(size(y), class(C)) * infinity;

for ii = 1 : m
    % Select assigned sink
    jj = x(ii);
    if ( jj > 0 && jj <= n )
        cx(ii) = C(ii,jj);
        cy(jj) = C(ii,jj);
    end

    % Increment cost
    if ( cx(ii) < infinity )
        c = c + cx(ii);
    else
        c = infinity;
    end
end


end % LAP_COST_FULL
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%