%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%DYNAMICS_ODE_PVA_3 : Evaluate position-velocity-acceleration derivative
%   [ k ] = dynamics_ode_pva_3( t, y )
%
%   DYNAMICS_ODE_PVA_3 evaluates the position-velocity-acceleration derivative.
%
%   The position-velocity-acceleration derivative is evaluated with acceleration 
%   from a rudimentary WGS84/EGM96 gravity model (spherical earth) and additive
%   constant acceleration (thrust).
%
%   The gravity model is valid only for state positions outside the earth's
%   atmosphere.
%
%   /notes/
%      - The system state is assumed to be in a non-rotating reference frame.
%      - The system state is assumed to be in a Cartesian coordinate system.
%      - The system state is assumed to be in the form:
%        [ position ; velocity ; thrust ]
%   
%   /input/
%      t ( real )           : independent variable value;
%      y ( real[ 9 ][ n ] ) : dependent variable value;
%
%   /output/
%      k ( real[ 9 ][ n ] ) : final dependent variable value;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ k ] = dynamics_ode_pva_3( ...
    t, y ...
)
%#eml
%% CONSTANTS

% WGS84 parameters
wgs84 = earth_wgs84_ellipsoid();
WGS84_GM = wgs84.GM; % WGS84 Gravitational Const w/ Atmos (m**3/s**2)


%% EVALUATION

% ---- initialization ----
k = zeros(size(y), class(y));

% ---- position derivative ----
% (d/dt)(r) = v;
k(1,:) = y(4,:); 
k(2,:) = y(5,:);
k(3,:) = y(6,:); 

% ---- velocity deriviative ----
c0 = y(1,:).^2 + y(2,:).^2 + y(3,:).^2; 
c1 = sqrt(c0); 

c2 = -WGS84_GM ./ c0 ./ c1;

% (d/dt)(v) = a + g(x, y, z);
k(4,:) = c2 .* y(1,:) + y(7,:);
k(5,:) = c2 .* y(2,:) + y(8,:);
k(6,:) = c2 .* y(3,:) + y(9,:);

% ---- acceleration deriviative ----
% (d/dt)(a) = 0;


end % DYNAMICS_ODE_PVA_3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
