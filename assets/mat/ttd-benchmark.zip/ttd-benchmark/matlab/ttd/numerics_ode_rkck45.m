%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%NUMERICS_ODE_RKCK45 : Runge-Kutta Cash-Karp
%   [ yn ] = numerics_ode_rkck45( f, y0, t0, hn )
%
%   NUMERICS_ODE_RKCK45 uses the Runge-Kutta Cash-Karp method to numerically 
%   approximate the solution to an ordinary differential equation.
%   
%   /references/ 
%      [1] "Runge-Kutta Methods". Wikipedia, 30 January 2009. 
%          http://en.wikipedia.org/wiki/Runge-Kutta_methods
%      [2] "Runge-Kutta-Fehlberg Method". Wikipedia, 12 May 2008. 
%          http://en.wikipedia.org/wiki/Cash-Karp_method
% 
%   /input/
%      ode ( function )    : function handle to derivative function;
%      y0 ( real[ m, n ] ) : initial dependent variable value;
%      t0 ( real )         : initial independent variable value;
%      h0 ( real )         : initial independent variable step size;
%
%   /output/
%      yn ( real[ m, n ] ) : final dependent variable value;
%       
%   /history/
%      2009.MM.D : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ yn ] = numerics_ode_rkck45( ...
    ode, y0, t0, h0 ...
)
%#eml
%% CONSTANTS

% iteration parameters
EPS = 1.0e-8; % Slighly better than 32-bit floating point precision...
ITR = 15;     % Arbitrary...
    

%% APPROXIMATION

yn = numerics_ode_rkadapt(@rkck45, ode, y0, t0, h0, EPS, ITR);


end % NUMERICS_ODE_RKCK45


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%RKCK45 : Runge-Kutta Cash-Karp integration step
%   [ yt, zt, ht, et ] = rkck45( ode, yn, tn, hn, epsilon )
%
%   RKCK45 performs a single Runge-Kutta Cash-Karp integration step.
%   
%   /input/
%      ode ( function )      : function handle to derivative function;
%      yn ( real[ m ][ n ] ) : initial dependent variable value;
%      tn ( real )           : initial independent variable value;
%      hn ( real )           : initial independent variable step size;
%      epsilon ( real )      : error precision;
%
%   /output/
%      yt ( real[ m ][ n ] ) : estimated fourth order dependent variable value;
%      zt ( real[ m ][ n ] ) : estimated fifth order dependent variable value;
%      ht ( real )           : estimated optimal step size;
%      et ( real )           : estimated error;
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ yt, zt, ht, et ] = rkck45( ode, ...
                                      yn, ...
                                      tn, ...
                                      hn, ...
                                      epsilon )

%% CONSTANTS

% Butcher Tableau
C2 =  1/5  ; A21 =  1/5        ; 
C3 =  3/10 ; A31 =  3/40       ; A32 =  9/40    ; 
C4 =  3/5  ; A41 =  3/10       ; A42 = -9/10    ; A43 =  6/5         ;
C5 =  1    ; A51 = -11/54      ; A52 =  5/2     ; A53 = -70/27       ; A54 =  35/27        ;
C6 =  7/8  ; A61 =  1631/55296 ; A62 =  175/512 ; A63 =  575/13824   ; A64 =  44275/110592 ; A65 =  253/4096  ;
             B51 =  37/378                      ; B53 =  250/621     ; B54 =  125/594                         ; B56 =  512/1771 ;
             B41 =  2825/27648                  ; B43 =  18575/48384 ; B44 =  13525/55296  ; B45 =  277/14336 ; B46 =  1/4 ;
             
% Safety Factor
S = (1/2)^(1/4);

              
%% APPROXIMATION

hk1 = hn * ode(tn, yn);
hk2 = hn * ode(tn + C2 * hn, yn + A21 * hk1);
hk3 = hn * ode(tn + C3 * hn, yn + A31 * hk1 + A32 * hk2);
hk4 = hn * ode(tn + C4 * hn, yn + A41 * hk1 + A42 * hk2 + A43 * hk3);
hk5 = hn * ode(tn + C5 * hn, yn + A51 * hk1 + A52 * hk2 + A53 * hk3 + A54 * hk4);
hk6 = hn * ode(tn + C6 * hn, yn + A61 * hk1 + A62 * hk2 + A63 * hk3 + A64 * hk4 + A65 * hk5);

yt = yn + ...
     (B41 * hk1) + ...
     (B43 * hk3) + ...
     (B44 * hk4) + ...
     (B45 * hk5) + ...
     (B46 * hk6);
zt = yn + ...
     (B51 * hk1) + ...
     (B53 * hk3) + ...
     (B54 * hk4) + ...
     (B56 * hk6);

en = epsilon * hn;
et = max(max(abs(zt - yt)));
% et = sum(sum(abs(zt - yt).^2)) / numel(yn);

if ( en >= et )
    sn = (en / et)^(1/5);
else
    sn = (en / et)^(1/4);
end

ht = S * sn * hn;


end % RKCK45
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%