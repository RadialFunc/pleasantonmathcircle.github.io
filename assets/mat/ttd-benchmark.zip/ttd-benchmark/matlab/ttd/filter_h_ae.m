%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FILTER_H_AE : Generic Angle-Angle observer model
%   [ z ] = filter_h_ae( x, s, params )
%
%   FILTER_H_AE provides an observer model for a generic Angle-Angle 
%   observer.
%
%   /notes/
%      - The "DCM" parameter is assumed to be the Direction Cosine Matrix for
%        rotating from the common reference frame to the observer frame.
%      - The system state and observer state are assumed to be in a common 
%        reference frame.
%      - The system state and observer state are assumed to be in a common 
%        Cartesian coordinate system.
%      - The system state and observer state are assumed to be in the form:
%        [ position ; velocity ]
%
%   /input/
%      x ( real[ m ][ n ] ) : system state vector;
%      s ( real[ m ] )      : observer state vector;
%      params ( struct )    : model-specific parameters;
%
%   /output/
%      z ( real[ 2 ][ n ] ) : observed system state vector;
%       
%   /history/
%      2009.MM.DD : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ z ] = filter_h_ae( ...
    x, s, params ...
)
%#eml
%% PARAMETERS

DCM = params.DCM;


%% PROJECTION

% ---- Position ----
obj_r = x(1 : 3,:);
sen_r = s(1 : 3,:);

% ---- Transform to Sensor Frame ----
obj_r(1,:) = obj_r(1,:) - sen_r(1);
obj_r(2,:) = obj_r(2,:) - sen_r(2);
obj_r(3,:) = obj_r(3,:) - sen_r(3);

r = DCM * obj_r;

% ---- Transform to Sensor Coordinate System (Spherical) ----
r_az = atan2(r(2,:), r(1,:));
r_el = atan2(r(3,:), hypot(r(1,:), r(2,:)));

% ---- Projection ----
z = [ r_az ;
      r_el ];


end % FILTER_H_AE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%