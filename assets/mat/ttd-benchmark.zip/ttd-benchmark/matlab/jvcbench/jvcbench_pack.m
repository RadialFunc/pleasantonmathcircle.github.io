%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%JVCBENCH_PACK : packs JVCBENCH
%   mttbench_pack
%
%   JVCBENCH_PACK packs JVCBENCH.
%   
%   /input/
%      none
%
%   /output/
%      none
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

prv_dir = pwd;

try
    cd(fullfile(fileparts(which('jvcbench_ini.m')), 'mdl', 'run', ''));
    
    % ---- JVCBENCH ----
    rtwbuild('jvcbench');

    sims.jvcbench.buildinfo = load(fullfile(fileparts(which('jvcbench_ini.m')), 'mdl', 'run', 'jvcbench_ert_rtw', 'buildInfo.mat'));
    packNGo(sims.jvcbench.buildinfo.buildInfo, { 'packType', 'hierarchical', 'fileName', 'jvcbench_ert_rtw.zip' });
catch ME
    ME.message
end

cd(prv_dir);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%