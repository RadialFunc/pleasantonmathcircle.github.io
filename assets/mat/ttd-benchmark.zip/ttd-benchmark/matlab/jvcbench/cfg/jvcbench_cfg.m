%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%JVCBENCH_CFG : configure MATLAB environment for MTTBENCH Simulink model
%   mttbench_cfg
%
%   JVCBENCH_CFG configures the MATLAB environment for the MTTBENCH Simulink
%   model by defining bus objects, assigning parameters, and setting up inputs.
%   
%   /input/
%      none
%
%   /output/
%      none
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% BUS OBJECTS

jvcbench_bus();


%% PARAMETERS

sims.jvcbench.params.t0 = 0.00; % simulation start time
sims.jvcbench.params.tn = 1.00; % simulation stop time
sims.jvcbench.params.dt = 1.00; % simulation time step


%% INPUTS

sims.jvcbench.inputs.t = (sims.jvcbench.params.t0 : ...
                          sims.jvcbench.params.dt : ...
                          sims.jvcbench.params.tn)';

sims.jvcbench.inputs.u = [ ones(size(sims.jvcbench.inputs.t)) * 10 ...
                           ones(size(sims.jvcbench.inputs.t)) * 100 ...
                           ones(size(sims.jvcbench.inputs.t)) * 1337 ...
                           ones(size(sims.jvcbench.inputs.t)) * 0.30 ...
                           ones(size(sims.jvcbench.inputs.t)) * 5 * 10 * 100 ];
                      

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%