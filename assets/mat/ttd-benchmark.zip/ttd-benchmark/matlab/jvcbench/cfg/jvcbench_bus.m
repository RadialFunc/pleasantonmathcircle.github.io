%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%JVCBENCH_BUS : instantiate bus objects for MTTBENCH Simulink model
%   mttbench_bus
%
%   JVCBENCH_BUS instantiates bus objects for the MTTBENCH Simulink model
%   programmatically.
%   
%   /input/
%      none
%
%   /output/
%      none
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% DESCRIPTION

% instantiate

% format :
%   { < Bus Object Name >, ... 
%     < Header File >, ... 
%     sprintf(< Description >), ...
%     { ...    
%       { < Bus Element Name >, < Dimensions >, < Data Type >, < Sample Time >, < Complexity >, < Sampling Mode > } ;
%     } ...
%   } ... 
sims.jvcbench.buses.info = { ... 

}'; 

% clean


%% INSTANTIATION
Simulink.Bus.cellToObject(sims.jvcbench.buses.info) 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
