%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%LINPROG_LAP_JVC : linear assignment problem algorithm
%   [ x, y, u, v ] = asn_lap_jvc( m, n, ax, ay, ac, x, y, u, v )
%
%   LINPROG_LAP_JVC finds an optimal solution to the linear assignment problem 
%   using the JVC (Jonker-Volgenant-Castanon) method.
%
%   Note that the inputs are not checked for consistency or validity...
%   
%   /input/
%      m ( real ) : number of linear assignment problem sources;
%      n ( real ) : number of linear assignment problem sinks;
%      ax ( real[ m + 1 ] ) : array of pairing source indices;
%      ay ( real[ k ] ) : array of pairing sinks;
%      ac ( real[ k ] ) : array of pairing costs;
%      x ( real[ m ] ) : source assignments;
%      y ( real[ n ] ) : sink assignments;
%      v ( real[ n ] ) : sink dual variables;
%
%   /output/
%      x ( real[ m ] ) : source assignments;
%      y ( real[ n ] ) : sink assignments;
%      u ( real[ m ] ) : source dual variables;
%      v ( real[ n ] ) : sink dual variables;
%       
%   /history/
%      2008.12.05 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ x, y, v ] = linprog_lap_jvc( m, n, ax, ay, ac, x, y, v )
%#eml
%% CONSTANTS

MAX_REDUCTION_PASSES = 2;


%% INITIALIZATION

qm = 0;                  % unassigned sources count
qx = zeros(1, numel(x)); % unassigned sources queue

% initialize unassigned sources
for ii = 1 : m
    % .. if source unassigned
    if ( x(ii) == 0 )
        qm = qm + 1; % increment unassigned sources count
        qx(qm) = ii; % add unassigned source to queue
    end
end


%% REDUCTION

% ..while unassigned sources exist and reduction pass within bounds
reduction_pass = 1;
while ( (qm > 0) && (reduction_pass <= MAX_REDUCTION_PASSES) )
    % ..while queue index within bounds
    queue_count = 0;
    queue_index = 1;
    while ( queue_index <= qm )
        src = qx(queue_index);   % current source
        src_0 = ax(src);         % current source beginning pairing index
        src_n = ax(src + 1) - 1; % current source end pairing index
        
        queue_index = queue_index + 1;
        
        % ..for each assignment
        min_snk1 = 0;   % minimum pairing 1 sink
        min_snk2 = 0;   % minimum pairing 2 sink
        min_cst1 = inf; % minimum pairing 1 cost
        min_cst2 = inf; % minimum pairing 2 cost
        for ii = src_0 : src_n
            cst = ac(ii) - v(ay(ii)); % augmented assigment cost
            
            % ..if cost is less than or equal to minimum pairing 1 cost
            if ( cst <= min_cst2 )
                % ..if cost is larger than minimum pairing 1 cost
                if ( cst > min_cst1 )
                    min_cst2 = cst;
                    min_snk2 = ay(ii);
                % ..otherwise
                else
                    min_cst2 = min_cst1;
                    min_snk2 = min_snk1;
                    min_cst1 = cst;
                    min_snk1 = ay(ii);
                end
            end
        end
        
        % ..if minimum pairing not found
        if ( min_snk1 == 0 )
            x(src) = 0;
        % ..otherwise
        else
            min_src1 = y(min_snk1); % minimum pairing 1 sink assignment
            
            % ..if minimum pairing 1 cost is less than minimum pairing 2 cost
            if ( min_cst1 < min_cst2 )
                v(min_snk1) = v(min_snk1) + (min_cst1 - min_cst2);
            % ..otherwise if minimum pairing 1 sink unassigned
            elseif ( min_src1 ~= 0 )
                % ..if minimum pairing 2 not found
                if ( min_snk2 == 0 )
                    min_snk1 = 0;
                    min_src1 = 0;
                % ..otherwise
                else
                    min_snk1 = min_snk2;
                    min_src1 = y(min_snk2);
                end
            end
            
            % assign source to minimum pairing sink
            x(src) = min_snk1;
            if ( min_snk1 ~= 0 )
                y(min_snk1) = src;
            end
            
            % ..if minimum pairing sink assigned
            if ( min_src1 ~= 0 )
                x(min_src1) = 0;
                
                if ( min_cst1 + eps < min_cst2 )
                    queue_index = queue_index - 1;
                    qx(queue_index) = min_src1;
                else
                    queue_count = queue_count + 1;
                    qx(queue_count) = min_src1;
                end
            end
        end
    end
    
    qm = queue_count;
        
	reduction_pass = reduction_pass + 1;
end


%% AUGMENTATION

% ..if unassigned sources exist
if ( qm > 0 )
	opens = zeros(1, numel(y)); % list of unvisited sinks
   
	% ..for each unassigned source
    for ii = 1 : qm 
        src = qx(ii);            % current source
        src_0 = ax(src);         % current source beginning pairing index
        src_n = ax(src + 1) - 1; % current source end pairing index
        
        % ..if no feasible pairing
        if ( src_0 == src_n )
            x(src) = 0;
            continue;
        end
        
        % initialize graph search data
        dist = zeros(1, numel(y)) + inf;
        pred = zeros(1, numel(y)) + inf;
        
        % initialize reachable sinks
        for jj = src_0 : src_n
            dist(ay(jj)) = ac(jj) - v(ay(jj));
            pred(ay(jj)) = src;
        end
        
        % initialize unvisited sinks
        for jj = 1 : n
            opens(jj) = jj;
        end
        
        lo = 1; % sinks 1..lo-1 ready
        up = 1; % sinks lo..up-1 to scan
        
        min_cst = inf;
        end_snk = 0;
        
        % ..while end not reached and sinks to scan
        while ( (end_snk == 0) && (lo <= n) )
            % ..if need sinks to scan
            if ( up == lo )
                min_cst = inf;
                for jj = up : n
                    snk = opens(jj);
                    cst = dist(snk);
                    if ( cst <= min_cst )
                        if ( cst < min_cst )
                            up = lo;
                            min_cst = cst;
                        end
                        
                        opens(jj) = opens(up);
                        opens(up) = snk;
                        
                        up = up + 1;
                    end
                end
                
                for jj = lo : up - 1
                    if ( y(opens(jj)) == 0 )
                        end_snk = opens(jj);
                        break;
                    end
                end
            end
            
            % ..if end sink not found
            if ( end_snk == 0 )
                etc_snk = opens(lo);
                etc_src = y(etc_snk);
                etc_src_0 = ax(etc_src);
                etc_src_n = ax(etc_src + 1) - 1;
                
                lo = lo + 1;
                
                sinks = zeros(1, numel(y));
                for jj = etc_src_0 : etc_src_n
                    sinks(ay(jj)) = jj;
                end
                
                cst_dif = (ac(sinks(etc_snk)) - v(etc_snk)) - min_cst;
                for jj = up : n
                    snk = opens(jj);
                    if ( sinks(snk) ~= 0 )
                        v2 = (ac(sinks(snk)) - v(snk)) - cst_dif;
                        if ( v2 < dist(snk) )
                            dist(snk) = v2;
                            pred(snk) = etc_src;
                            if ( v2 == min_cst )
                                if ( y(snk) == 0 )
                                    end_snk = snk;
                                    break;
                                else
                                    opens(jj) = opens(up);
                                    opens(up) = snk;
                                    up = up + 1;
                                end
                            end
                        end
                    end
                end
            end
        end
        
        if ( end_snk == 0 )
            x(src) = 0;
        else
            for jj = 1 : lo - 1
                v(opens(jj)) = v(opens(jj)) + dist(opens(jj)) - min_cst;
            end
         
            while ( true )
                srci = pred(end_snk);
                y(end_snk) = srci;

                snki = end_snk;
                end_snk = x(srci);

                x(srci) = snki;
                if ( srci == src )
                    break;
                end
            end
        end
    end
end


end % LINPROG_LAP_JVC
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
