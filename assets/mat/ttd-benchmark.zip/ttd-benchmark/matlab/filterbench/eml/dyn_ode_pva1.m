%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%DYN_ODE_PVA1 : position-velocity-acceleration derivative
%   [ k ] = dyn_ode_pva1( t, y )
%
%   DYN_ODE_PVA1 evaluates the position-velocity-acceleration derivative.
%
%   The position-velocity-acceleration derivative is evaluated using a constant 
%   acceleration model. 
%   
%   /input/
%      t ( real )           : independent variable value;
%      y ( real[ 9 ][ n ] ) : dependent variable value;
%
%   /output/
%      k ( real[ 9 ][ n ] ) : final dependent variable value;
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ k ] = dyn_ode_pva1( t, y )
%#eml
%% EVALUATION

% ---- initialization ----
k = zeros(size(y));

% ---- position derivative ----
% (d/dt)(r) = v;
k(1,:) = y(4,:); 
k(2,:) = y(5,:);
k(3,:) = y(6,:); 

% ---- velocity deriviative ----
% (d/dt)(v) = a;
k(4,:) = y(7,:); 
k(5,:) = y(8,:);
k(6,:) = y(9,:); 

% ---- acceleration deriviative ----
% (d/dt)(a) = 0;


end % DYN_ODE_PVA1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
