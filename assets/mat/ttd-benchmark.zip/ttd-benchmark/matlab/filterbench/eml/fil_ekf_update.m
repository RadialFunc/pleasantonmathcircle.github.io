%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FIL_EKF_UPDATE : Extended Kalman Filter update
%   [ xk, Pk ] = fil_ekf_update( f, B, x, P, z, R, s, T )
%
%   FIL_EKF_UPDATE performs the Extended Kalman Filter update step.
%   
%   /input/
%      f1 ( function )        : function handle to observer model;
%      f2 ( function )        : function handle to observer transition matrix;
%      B ( real[ m1 ][ m1 ] ) : additive independent observer noise;
%      x ( real[ m1 ] )       : system state mean vector;
%      P ( real[ m1 ][ m1 ] ) : system state covariance matrix;
%      z ( real[ m2 ] )       : measurement state mean vector;
%      R ( real[ m2 ][ m2 ] ) : measurement state covariance matrix;
%      s ( real[ m1 ] )       : observer state vector;
%      T ( real[ 3 ][ 3 ] )   : observer state direction cosine matrix;
%
%   /output/
%      xk ( real[ m1 ] )       : updated system state mean vector;
%      Pk ( real[ m1 ][ m1 ] ) : updated system state covariance matrix;
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ xk, Pk ] = fil_ekf_update( f1, f2, B, x, P, z, R, s, T )
%#eml
%% CONSTANTS


%% UPDATE

% ---- project mean ----
u = f1(x, s, T);
H = f2(x, s, T);

% ---- calculate gain ----
S = H * P * H' + R + B;
K = P * H' * (eye(size(S)) / S);

% ---- finalize state ----
xk = x + K * (z - u);
Pk = (eye(size(P)) - K * H) * P;


end % FIL_EKF_UPDATE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
