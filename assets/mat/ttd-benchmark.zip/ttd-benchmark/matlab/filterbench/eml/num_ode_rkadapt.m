%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%NUM_ODE_RKADAPT : Runge-Kutta with adaptive stepping
%   [ yn ] = num_ode_rkadapt( f, y0, t0, h0 )
%
%   NUM_ODE_RKADAPT uses an adaptive Runge-Kutta method to numerically 
%   approximate the solution to an ordinary differential equation.
%   
%   /input/
%      rk ( function )       : function handle to Runge-Kutta method;
%      f ( function )        : function handle to derivative function;
%      y0 ( real[ m ][ n ] ) : initial dependent variable value;
%      t0 ( real )           : initial independent variable value;
%      h0 ( real )           : initial independent variable step size;
%      epsilon ( real )      : error precision;
%      iterations ( real )   : iteration limit;
%    
%   /output/
%      yn ( real[ m ][ n ] ) : final dependent variable value;
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ yn ] = num_ode_rkadapt( rk, f, y0, t0, h0, epsilon, iterations )
%#eml
%% ITERATION

tn = t0;
hn = h0;
yn = y0;

for ii = 1 : iterations
	[ yt, zt, ht, et ] = rk(f, yn, tn, hn, epsilon);
    
    if ( (et < epsilon * hn) || (abs(ht) == abs(hn)) )
        tn = tn + hn;
        hn = ht;
        yn = yt;
    elseif ( abs(ht) > abs(hn) )
        hn = ht;
    elseif ( abs(ht) < abs(hn) )
        hn = ht;
    end
    
    if ( abs(tn + hn) >= abs(t0 + h0) )
        break;
    end
end

yn = rk(f, yn, tn, t0 - tn + h0, epsilon);


end % NUM_ODE_RKADAPT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
