%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FIL_UKF_PROPAGATE : Unscented Kalman Filter propagation
%   [ xk, Pk, tk ] = fil_ukf_propagate( f, Q, x, P, t, h )
%
%   FIL_UKF_PROPAGATE performs the Unscented Kalman Filter propagation step.
%   
%   /input/
%      f ( function )       : function handle to process model;
%      Q ( real[ m ][ m ] ) : additive independent process noise;
%      x ( real[ m ] )      : system state mean vector;
%      P ( real[ m ][ m ] ) : system state covariance matrix;
%      t ( real )           : system state time;
%      h ( real )           : propagation time step;
%
%   /output/
%      xk ( real[ m ] )      : propagated system state mean vector;
%      Pk ( real[ m ][ m ] ) : propagated system state covariance matrix;
%      tk ( real )           : propagated system state time;
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ xk, Pk, tk ] = fil_ukf_propagate( f, Q, x, P, t, h )
%#eml
%% CONSTANTS

% Scaled Unscented Transform parameters
UT_ALPHA = 1.0;
UT_BETA  = 0.0;
UT_KAPPA = 3.0;


%% PROPAGATION

% ---- initialize weights ----
m = size(x, 1);

lambda = UT_ALPHA^2 * (m + UT_KAPPA) - m;

wy = [ zeros(m, 1) + (lambda / (m + lambda)) ...
       zeros(m, 2 * m) + (1.0 / 2.0 / (m + lambda)) ];
wyy = [ zeros(m, 1) + (lambda / (m + lambda) + 1.0 - UT_ALPHA^2 + UT_BETA) ...
        zeros(m, 2 * m) + (1.0 / 2.0 / (m + lambda)) ];

% ---- generate sigma points ----
L = chol(P * (m + lambda));
Xi = [ zeros(m, 1) L -L ];
for ii = 1 : m
    Xi(ii,:) = Xi(ii,:) + x(ii);
end

% ---- propagate sigma points----
Yi = f(Xi, t, h);

% ---- collect statistics ----
uy = sum(Yi .* wy, 2);
dy = Yi;
for ii = 1 : m
    dy(ii,:) = dy(ii,:) - uy(ii);
end

Pyy = (dy .* wyy) * dy';

% ---- finalize state ----
xk = uy;
Pk = Pyy + Q;
tk = t + h;


end % FIL_UKF_PROPAGATE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
