%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FIL_MDL_IR1 : generic IR sensor observer model
%   [ z ] = fil_ukf_update( x, s, T )
%
%   FIL_MDL_IR1 provides an observer model for a generic IR sensor.
%   
%   /input/
%      x ( real[ m ][ n ] ) : system state vector;
%      s ( real[ m ] )      : observer state vector;
%      T ( real[ 3 ][ 3 ] ) : observer state direction cosine matrix;
%
%   /output/
%      z ( real[ 2 ][ n ] ) : observed system state vector;
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ z ] = fil_mdl_ir1( x, s, T )
%#eml
%% PROJECTION

% ---- extract positions ----
obj_r = x(1 : 3,:);
sen_r = s(1 : 3,:);

% ---- transform to sensor frame ----
obj_r(1,:) = obj_r(1,:) - sen_r(1);
obj_r(2,:) = obj_r(2,:) - sen_r(2);
obj_r(3,:) = obj_r(3,:) - sen_r(3);

r = T * obj_r;

% ---- transform to sensor coordinate system (spherical) ----
rng = sqrt(sum(r.^2, 1));
az  = atan2(r(2,:), r(1,:));
el  = asin(r(3,:) ./ rng);

% ---- project to sensor state space ----
z = [ az ;
      el ];


end % FIL_MDL_IR1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
