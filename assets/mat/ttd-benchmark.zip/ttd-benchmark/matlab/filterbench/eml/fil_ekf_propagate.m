%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FIL_EKF_PROPAGATE : Extended Kalman Filter propagation
%   [ xk, Pk, tk ] = fil_ekf_propagate( f, Q, x, P, t, h )
%
%   FIL_EKF_PROPAGATE performs the Extended Kalman Filter propagation step.
%   
%   /input/
%      f1 ( function )      : function handle to process model;
%      f2 ( function )      : function handle to process transition matrix;
%      Q ( real[ m ][ m ] ) : additive independent process noise;
%      x ( real[ m ] )      : system state mean vector;
%      P ( real[ m ][ m ] ) : system state covariance matrix;
%      t ( real )           : system state time;
%      h ( real )           : propagation time step;
%
%   /output/
%      xk ( real[ m ] )      : propagated system state mean vector;
%      Pk ( real[ m ][ m ] ) : propagated system state covariance matrix;
%      tk ( real )           : propagated system state time;
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ xk, Pk, tk ] = fil_ekf_propagate( f1, f2, Q, x, P, t, h )
%#eml
%% CONSTANTS


%% PROPAGATION

% ---- propagate mean ----
u = f1(x, t, h);
F = f2(x, t, h);

% ---- finalize state ----
xk = u;
Pk = F * P * F' + Q;
tk = t + h;


end % FIL_EKF_PROPAGATE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
