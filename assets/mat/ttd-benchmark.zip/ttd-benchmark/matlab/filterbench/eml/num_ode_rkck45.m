%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%NUM_ODE_RKCK45 : Runge-Kutta Cash-Karp
%   [ yn ] = num_ode_rkck45( f, y0, t0, hn )
%
%   NUM_ODE_RKCK45 uses the Runge-Kutta Cash-Karp method to numerically 
%   approximate the solution to an ordinary differential equation.
%   
%   /input/
%      f ( function )        : function handle to derivative function;
%      y0 ( real[ m ][ n ] ) : initial dependent variable value;
%      t0 ( real )           : initial independent variable value;
%      h0 ( real )           : initial independent variable step size;
%
%   /output/
%      yn ( real[ m ][ n ] ) : final dependent variable value;
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ yn ] = num_ode_rkck45( f, y0, t0, h0 )
%#eml
%% CONSTANTS

% iteration parameters
EPS = 1.0e-8;
ITR = 15;
    

%% APPROXIMATION

yn = num_ode_rhkadapt(@sub_rkck45, f, y0, t0, h0, EPS, ITR);


end % NUM_ODE_RKCK45


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SUB_RKCK45 : Runge-Kutta Cash-Karp integration step
%   [ yt, zt, ht, et ] = sub_rkck45( f, yn, tn, hn, epsilon )
%
%   SUB_STEP performs a single Runge-Kutta Cash-Karp integration step.
%   
%   /input/
%      f ( function )        : function handle to derivative function;
%      yn ( real[ m ][ n ] ) : initial dependent variable value;
%      tn ( real )           : initial independent variable value;
%      hn ( real )           : initial independent variable step size;
%      epsilon ( real )      : error precision;
%
%   /output/
%      yt ( real[ m ][ n ] ) : estimated fourth order dependent variable value;
%      zt ( real[ m ][ n ] ) : estimated fifth order dependent variable value;
%      ht ( real )           : estimated optimal step size;
%      et ( real )           : estimated error;
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ yt, zt, ht, et ] = sub_rkck45( f, yn, tn, hn, epsilon )

%% CONSTANTS

% Butcher Tableau
C2 =  1/5  ; A21 =  1/5        ; 
C3 =  3/10 ; A31 =  3/40       ; A32 =  9/40    ; 
C4 =  3/5  ; A41 =  3/10       ; A42 = -9/10    ; A43 =  6/5         ;
C5 =  1    ; A51 = -11/54      ; A52 =  5/2     ; A53 = -70/27       ; A54 =  35/27        ;
C6 =  7/8  ; A61 =  1631/55296 ; A62 =  175/512 ; A63 =  575/13824   ; A64 =  44275/110592 ; A65 =  253/4096  ;
             B51 =  37/378                      ; B53 =  250/621     ; B54 =  125/594                         ; B56 =  512/1771 ;
             B41 =  2825/27648                  ; B43 =  18575/48384 ; B44 =  13525/55296  ; B45 =  277/14336 ; B46 =  1/4 ;
              
              
%% APPROXIMATION

hk1 = hn * f(tn, yn);
hk2 = hn * f(tn + C2 * hn, yn + A21 * hk1);
hk3 = hn * f(tn + C3 * hn, yn + A31 * hk1 + A32 * hk2);
hk4 = hn * f(tn + C4 * hn, yn + A41 * hk1 + A42 * hk2 + A43 * hk3);
hk5 = hn * f(tn + C5 * hn, yn + A51 * hk1 + A52 * hk2 + A53 * hk3 + A54 * hk4);
hk6 = hn * f(tn + C6 * hn, yn + A61 * hk1 + A62 * hk2 + A63 * hk3 + A64 * hk4 + A65 * hk5);

yt = yn + ...
     (B41 * hk1) + ...
     (B43 * hk3) + ...
     (B44 * hk4) + ...
     (B45 * hk5) + ...
     (B46 * hk6);
zt = yn + ...
     (B51 * hk1) + ...
     (B53 * hk3) + ...
     (B54 * hk4) + ...
     (B56 * hk6);

et = max(max(abs(zt - yt)));
% et = sum(sum(abs(zt - yt).^2)) / numel(yn);

sn = sqrt(sqrt(epsilon / et / 2));
ht = sn * hn;


end % SUB_RKCK45
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
