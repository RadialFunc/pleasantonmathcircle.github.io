%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FIL_MDL_BALLISTICMID1_EXT : generic midcourse ballistic process model
%   [ Fk ] = fil_mdl_ballisticmid_ext( x, t, h )
%
%   FIL_MDL_BALLISTICMID1_EXT provides the state transition matrix required by
%   the Extended Kalman Filter for FIL_MDL_BALLLISTICMID1.
%   
%   /input/
%      x ( real[ m ][ n ] ) : system state vector;
%      t ( real )           : system state time;
%      h ( real )           : propagation time step;
%
%   /output/
%      Fk ( real[ m ][ m ][ n ] ) : state transition matrix;
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%   see also FIL_MDL_BALLLISTICMID1
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ F ] = fil_mdl_ballisticmid1_ext( x, t, h )
%#eml
%% CONSTANTS

% WGS84 parameters
WGS84_A  = 6378137.0;            % semi-major axis (m)
WGS84_GM = 3.986004418e14;       % gravitational parameter w/ atmosphere (m**3/s**3)
WGS84_J2 = 1.082629821313305e-3; % J2 zonal gravitational harmonic

% expansion parameters
TAYLOR_ORDER = 9;


%% PROPAGATION

% ---- initialize ----
xF = fil_mdl_ballisticmid1(x, t, h / 2);

% ---- gravity gradient ----
c0 = sqrt(sum(xF(1 : 3,:).^2, 1)); 
c1 = -WGS84_GM ./ c0 ./ c0 ./ c0;
c2 = (3 / 2) * WGS84_J2 * (WGS84_A ./ c0 ./ c0 * WGS84_A).^2;
c3 = 5 * (xF(3,:) ./ c0).^2;

g = [ c1 .* (ones(size(xF(1,:))) + 1.0 * c2 - c2 .* c3) ; 
      c1 .* (ones(size(xF(2,:))) + 1.0 * c2 - c2 .* c3) ; 
      c1 .* (ones(size(xF(3,:))) + 3.0 * c2 - c2 .* c3) ];

% ---- construct jacobian matrix ----
m = size(x, 1);
n = size(x, 2);

J = zeros(m, m, n);

J(1,4,:) = 1;
J(2,5,:) = 1;
J(3,6,:) = 1;

J(4,4,:) = g(1,:);
J(5,5,:) = g(2,:);
J(6,6,:) = g(3,:);

% ---- construct state transition matrix ----
F = zeros(m, m, n);
for ii = 1 : n
    T = eye(m);
    F(:,:,ii) = eye(m);
    for jj = 1 : TAYLOR_ORDER
        T = (T * J(:,:,ii)) * abs(h) / jj;
        F(:,:,ii) = F(:,:,ii) + T;
    end
end


end % FIL_MDL_BALLISTICMID1_EXT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
