%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%NUM_ODE_RK4 : Runge-Kutta fourth order
%   [ yn ] = num_ode_rk4( f, y0, t0, h0 )
%
%   NUM_ODE_RK4 uses a fourth order Runge-Kutta method to numerically 
%   approximate the solution to an ordinary differential equation.
%   
%   /input/
%      f ( function )        : function handle to derivative function;
%      y0 ( real[ m ][ n ] ) : initial dependent variable value;
%      t0 ( real )           : initial independent variable value;
%      h0 ( real )           : initial independent variable step size;
%
%   /output/
%      yn ( real[ m ][ n ] ) : final dependent variable value;
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ yn ] = num_ode_rk4( f, y0, t0, h0 )
%#eml
%% CONSTANTS

% Butcher Tableau
C2 =  1/2 ; A21 =  1/2 ; 
C3 =  1/2 ;              A32 =  1/2 ;
C4 =  1   ;                           A43 =  1   ;
            B1  =  1/6 ; B2  =  1/3 ; B3  =  1/3 ; B4 =  1/6 ;


%% APPROXIMATION

tn = t0;
hn = h0;
yn = y0;

hk1 = hn * f(tn, y0);
hk2 = hn * f(tn + C2 * hn, y0 + A21 * hk1);
hk3 = hn * f(tn + C3 * hn, y0 + A32 * hk2);
hk4 = hn * f(tn + C4 * hn, y0 + A43 * hk3);

yn = yn + ...
     (B1 * hk1) + ...
     (B2 * hk2) + ...
     (B3 * hk3) + ...
     (B4 * hk4);


end % NUM_ODE_RK4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
