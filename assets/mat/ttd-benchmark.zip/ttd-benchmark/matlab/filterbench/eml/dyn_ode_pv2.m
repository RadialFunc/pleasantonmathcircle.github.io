%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%DYN_ODE_PV2 : position-velocity derivative
%   [ k ] = dyn_ode_pv2( t, y )
%
%   DYN_ODE_PV2 evaluates the position-velocity derivative.
%
%   The position-velocity derivative is evaluated with ballistic-only 
%   acceleration from a rudimentary WGS84/EGM96 J2 gravity model. 
%
%   The gravity model is valid only for state positions outside the earth's
%   atmosphere.
%   
%   /input/
%      t ( real )           : independent variable value;
%      y ( real[ 6 ][ n ] ) : dependent variable value;
%
%   /output/
%      k ( real[ 6 ][ n ] ) : final dependent variable value;
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ k ] = dyn_ode_pv2( t, y )
%#eml
%% CONSTANTS

% WGS84 parameters
WGS84_A  = 6378137.0;            % semi-major axis (m)
WGS84_GM = 3.986004418e14;       % gravitational parameter w/ atmosphere (m**3/s**3)
WGS84_J2 = 1.082629821313305e-3; % J2 zonal gravitational harmonic


%% EVALUATION

% ---- initialization ----
k = zeros(size(y));

% ---- position derivative ----
% (d/dt)(r) = v;
k(1,:) = y(4,:); 
k(2,:) = y(5,:); 
k(3,:) = y(6,:); 

% ---- velocity deriviative ----
c0 = y(1,:).^2 + y(2,:).^2 + y(3,:).^2; 
c1 = sqrt(c0); 

c2 = -WGS84_GM ./ c0 ./ c1;
c3 = ((3 / 2) * WGS84_J2 * WGS84_A * WGS84_A) ./ c0;
c4 = 5 .* y(3,:) .* y(3,:) ./ c0;

% g = [ c2 * (1 + c3 * (1 - c4)) * x ;
%       c2 * (1 + c3 * (1 - c4)) * y ;
%       c2 * (1 + c3 * (3 - c4)) * z ]

c5 = c2 .* (1.0 + 1.0 .* c3 - c3 .* c4);
c6 = c2 .* (1.0 + 3.0 .* c3 - c3 .* c4);

% (d/dt)(v) = a = g;
k(4,:) = c5 .* y(1,:);
k(5,:) = c5 .* y(2,:);
k(6,:) = c6 .* y(3,:);


end % DYN_ODE_PV2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
