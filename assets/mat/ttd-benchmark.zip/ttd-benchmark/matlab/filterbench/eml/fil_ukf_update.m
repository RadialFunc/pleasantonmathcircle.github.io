%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FIL_UKF_UPDATE : Unscented Kalman Filter update
%   [ xk, Pk ] = fil_ukf_update( f, B, x, P, z, R, s, T )
%
%   FIL_UKF_UPDATE performs the Unscented Kalman Filter update step.
%   
%   /input/
%      f ( function )         : function handle to observer model;
%      B ( real[ m1 ][ m1 ] ) : additive independent observer noise;
%      x ( real[ m1 ] )       : system state mean vector;
%      P ( real[ m1 ][ m1 ] ) : system state covariance matrix;
%      z ( real[ m2 ] )       : measurement state mean vector;
%      R ( real[ m2 ][ m2 ] ) : measurement state covariance matrix;
%      s ( real[ m1 ] )       : observer state vector;
%      T ( real[ 3 ][ 3 ] )   : observer state direction cosine matrix;
%
%   /output/
%      xk ( real[ m1 ] )       : updated system state mean vector;
%      Pk ( real[ m1 ][ m1 ] ) : updated system state covariance matrix;
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ xk, Pk ] = fil_ukf_update( f, B, x, P, z, R, s, T )
%#eml
%% CONSTANTS

% Scaled Unscented Transform parameters
UT_ALPHA = 1.0;
UT_BETA  = 0.0;
UT_KAPPA = 3.0;


%% UPDATE

% ---- initialize weights ----
m1 = size(x, 1);
m2 = size(z, 1);

lambda = UT_ALPHA^2 * (m1 + UT_KAPPA) - m1;

wx = [ zeros(m1, 1) + (lambda / (m1 + lambda)) ...
       zeros(m1, 2 * m1) + (1.0 / 2.0 / (m1 + lambda)) ];
wxx = [ zeros(m1, 1) + (lambda / (m1 + lambda) + 1.0 - UT_ALPHA^2 + UT_BETA) ...
        zeros(m1, 2 * m1) + (1.0 / 2.0 / (m1 + lambda)) ];
    
wy = [ zeros(m2, 1) + (lambda / (m1 + lambda)) ...
       zeros(m2, 2 * m1) + (1.0 / 2.0 / (m1 + lambda)) ];
wyy = [ zeros(m2, 1) + (lambda / (m1 + lambda) + 1.0 - UT_ALPHA^2 + UT_BETA) ...
        zeros(m2, 2 * m1) + (1.0 / 2.0 / (m1 + lambda)) ];

% ---- generate sigma points ----
L = chol(P * (m1 + lambda));
Xi = [ zeros(m1, 1) L -L ];
for ii = 1 : m1
    Xi(ii,:) = Xi(ii,:) + zeros(1, 2 * m1 + 1) + x(ii);
end

% ---- project sigma points----
Yi = f(Xi, s, T);

% ---- collect statistics ----
ux = sum(Xi .* wx, 2);
dx = Xi;
for ii = 1 : m1
    dx(ii,:) = dx(ii,:) - ux(ii);
end

uy = sum(Yi .* wy, 2);
dy = Yi;
for ii = 1 : m2
    dy(ii,:) = dy(ii,:) - uy(ii);
end

Ryy = (dy .* wyy) * dy';
Pxy = (dx .* wxx) * dy';

% ---- calculate gain ----
S = Ryy + R + B;
K = Pxy * (eye(size(S)) / S);

% ---- finalize state ----
xk = x + K * (z - uy);
Pk = P - K * S * K';


end % FIL_UKF_UPDATE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
