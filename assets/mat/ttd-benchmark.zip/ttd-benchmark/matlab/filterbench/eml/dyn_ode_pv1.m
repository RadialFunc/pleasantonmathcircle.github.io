%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%DYN_ODE_PV1 : position-velocity derivative
%   [ k ] = dyn_ode_pv1( t, y )
%
%   DYN_ODE_PV1 evaluates the position-velocity derivative.
%
%   The position-velocity derivative is evaluated using a constant velocity
%   model. 
%   
%   /input/
%      t ( real )           : independent variable value;
%      y ( real[ 6 ][ n ] ) : dependent variable value;
%
%   /output/
%      k ( real[ 6 ][ n ] ) : final dependent variable value;
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ k ] = dyn_ode_pv1( t, y )
%#eml
%% EVALUATION

% ---- initialization ----
k = zeros(size(y));

% ---- position derivative ----
% (d/dt)(r) = v;
k(1,:) = y(4,:); 
k(2,:) = y(5,:); 
k(3,:) = y(6,:); 

% ---- velocity deriviative ----
% (d/dt)(v) = 0;


end % DYN_ODE_PV1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
