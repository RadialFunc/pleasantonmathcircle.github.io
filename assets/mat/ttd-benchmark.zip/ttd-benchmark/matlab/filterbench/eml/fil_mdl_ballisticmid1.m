%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FIL_MDL_BALLISTICMID1 : generic midcourse ballistic process model
%   [ xk ] = fil_mdl_ballisticmid( x, t, h )
%
%   FIL_MDL_BALLISTICMID1 provides a process model for a generic midcourse
%   ballistic position-velocity state.
%   
%   /input/
%      x ( real[ m ][ n ] ) : system state vector;
%      t ( real )           : system state time;
%      h ( real )           : propagation time step;
%
%   /output/
%      xk ( real[ m ][ n ] ) : propagated system state vector;
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ xk ] = fil_mdl_ballisticmid1( x, t, h )
%#eml
%% CONSTANTS

% propagation parameters
MAX_ABS_H = 1;
DYN_ODE = @dyn_ode_pv2;
DYN_INT = @num_ode_rk4;


%% PROPAGATION

% ---- initialize ----
tk = t + h;

xn = x;
tn = t;
hn = h;

if ( abs(hn) > MAX_ABS_H )
    hn = MAX_ABS_H * sign(h);
end

% ---- iterate ----
while ( abs(tn + hn) < abs(tk) )
    xn = DYN_INT(DYN_ODE, xn, tn, hn);
    tn = tn + hn;
end

% ---- finalize ----
xk = DYN_INT(DYN_ODE, xn, tn, tk - tn);


end % FIL_MDL_BALLISTICMID1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
