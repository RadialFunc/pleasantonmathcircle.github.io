%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%NUM_ODE_RKF45 : Runge-Kutta-Fehlberg
%   [ yn ] = num_ode_rkf45( f, y0, t0, hn )
%
%   NUM_ODE_RKF45 uses the Runge-Kutta-Fehlberg method to numerically 
%   approximate the solution to an ordinary differential equation.
%   
%   /input/
%      f ( function )        : function handle to derivative function;
%      y0 ( real[ m ][ n ] ) : initial dependent variable value;
%      t0 ( real )           : initial independent variable value;
%      h0 ( real )           : initial independent variable step size;
%
%   /output/
%      yn ( real[ m ][ n ] ) : final dependent variable value;
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ yn ] = num_ode_rkf45( f, y0, t0, h0 )
%% CONSTANTS

% iteration parameters
EPS = 1.0e-8;
ITR = 15;
    

%% APPROXIMATION

yn = num_ode_rkadapt(@sub_rkf45, f, y0, t0, h0, EPS, ITR);


end % NUM_ODE_RKF45


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SUB_RKF45 : Runge-Kutta-Fehlberg integration step
%   [ yt, zt, ht, et ] = sub_rkf45( f, yn, tn, hn, epsilon )
%
%   SUB_STEP performs a single Runge-Kutta-Fehlberg integration step.
%   
%   /input/
%      f ( function )        : function handle to derivative function;
%      yn ( real[ m ][ n ] ) : initial dependent variable value;
%      tn ( real )           : initial independent variable value;
%      hn ( real )           : initial independent variable step size;
%      epsilon ( real )      : error precision;
%
%   /output/
%      yt ( real[ m ][ n ] ) : estimated fourth order dependent variable value;
%      zt ( real[ m ][ n ] ) : estimated fifth order dependent variable value;
%      ht ( real )           : estimated optimal step size;
%      et ( real )           : estimated error;
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ yt, zt, ht, et ] = sub_rkf45( f, yn, tn, hn, epsilon )

%% CONSTANTS

% Butcher Tableau
C2 =  1/4   ; A21 =  1/4       ; 
C3 =  3/8   ; A31 =  3/32      ; A32 =  9/32      ; 
C4 =  12/13 ; A41 =  1932/2197 ; A42 = -7200/2197 ; A43 =  7296/2197  ;
C5 =  1     ; A51 =  439/216   ; A52 = -8         ; A53 =  3680/513   ; A54 = -845/4104    ;
C6 =  1/2   ; A61 = -8/27      ; A62 =  2         ; A63 = -3544/2565  ; A64 =  1859/4104   ; A65 = -11/40 ;
              B51 =  16/135                       ; B53 =  6656/12825 ; B54  = 28561/56430 ; B55 = -9/50  ; B56 =  2/55 ;
              B41 =  25/216                       ; B43 =  1408/2565  ; B44  = 2197/4104   ; B45 = -1/5                 ; 
              
              
%% APPROXIMATION

hk1 = hn * f(tn, yn);
hk2 = hn * f(tn + C2 * hn, yn + A21 * hk1);
hk3 = hn * f(tn + C3 * hn, yn + A31 * hk1 + A32 * hk2);
hk4 = hn * f(tn + C4 * hn, yn + A41 * hk1 + A42 * hk2 + A43 * hk3);
hk5 = hn * f(tn + C5 * hn, yn + A51 * hk1 + A52 * hk2 + A53 * hk3 + A54 * hk4);
hk6 = hn * f(tn + C6 * hn, yn + A61 * hk1 + A62 * hk2 + A63 * hk3 + A64 * hk4 + A65 * hk5);

yt = yn + ...
     (B41 * hk1) + ...
     (B43 * hk3) + ...
     (B44 * hk4) + ...
     (B45 * hk5);
zt = yn + ...
     (B51 * hk1) + ...
     (B53 * hk3) + ...
     (B54 * hk4) + ...
     (B55 * hk5) + ...
     (B56 * hk6);

et = max(max(abs(zt - yt)));
% et = sum(sum(abs(zt - yt).^2)) / numel(yn);

sn = sqrt(sqrt(epsilon * hn / et / 2));
ht = sn * hn;


end % SUB_RKF45
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
