%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FIL_MDL_IR1_EXT : generic IR sensor observer model
%   [ z, H ] = fil_ukf_update( x, s, T )
%
%   FIL_MDL_IR1_EXT provides the state transition matrix required by
%   the Extended Kalman Filter for FIL_MDL_IR1.
%
%   /input/
%      x ( real[ m ][ n ] ) : system state vector;
%      s ( real[ m ] )      : observer state vector;
%      T ( real[ 3 ][ 3 ] ) : observer state direction cosine matrix;
%
%   /output/
%      H ( real[ 2 ][ m ][ n ] ) : state transition matrix;
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%   see also FIL_MDL_IR1
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ H ] = fil_mdl_ir1_ext( x, s, T )
%#eml
%% PROJECTION

% ---- extract positions ----
obj_r = x(1 : 3,:);
sen_r = s(1 : 3,:);

% ---- transform to sensor frame ----
obj_r(1,:) = obj_r(1,:) - sen_r(1);
obj_r(2,:) = obj_r(2,:) - sen_r(2);
obj_r(3,:) = obj_r(3,:) - sen_r(3);

r = T * obj_r;

c0 = sqrt(sum(r.^2, 1));
r(1,:) = r(1,:) ./ c0;
r(2,:) = r(2,:) ./ c0;
r(3,:) = r(3,:) ./ c0;

c1 = c0.^2;
c2 = r(1,:).^2 + r(2,:).^2;
c3 = sqrt(c2);

% ---- construct jacobian matrix ----
m = size(x, 1);
n = size(x, 2);

J = zeros(2, 3, n);

J(1,1,:) = -r(2,:) ./ c2;
J(1,2,:) =  r(1,:) ./ c2;
J(1,3,:) =  zeros(size(c2));
J(2,1,:) = -r(3,:) .* r(1,:) ./ c3 ./ c1;
J(2,2,:) = -r(3,:) .* r(2,:) ./ c3 ./ c1;
J(2,3,:) =  c3 ./ c1;

% ---- evaluate state transition matrix ----
H = zeros(2, m, n);
for ii = 1 : n
    H(:,:,ii) = J(:,:,ii) * T * eye(3, m);
end


end % FIL_MDL_IR1_EXT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
