%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FILTERBENCH_BUS : instantiate bus objects for FILTERBENCH Simulink model
%   filterbench_bus
%
%   FILTERBENCH_BUS instantiates bus objects for the FILTERBENCH Simulink model
%   programmatically.
%   
%   /input/
%      none
%
%   /output/
%      none
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% DESCRIPTION

% instantiate

% format :
%   { < Bus Object Name >, ... 
%     < Header File >, ... 
%     sprintf(< Description >), ...
%     { ...    
%       { < Bus Element Name >, < Dimensions >, < Data Type >, < Sample Time >, < Complexity >, < Sampling Mode > } ;
%     } ...
%   } ... 
sims.filterbench.buses.info = { ... 

}'; 

% clean


%% INSTANTIATION
Simulink.Bus.cellToObject(sims.filterbench.buses.info) 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
