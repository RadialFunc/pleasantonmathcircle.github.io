%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FILTERBENCH_CFG : configure MATLAB environment for FILTERBENCH Simulink model
%   filterbench_cfg
%
%   FILTERBENCH_CFG configures the MATLAB environment for the FILTERBENCH Simulink
%   model by defining bus objects, assigning parameters, and setting up inputs.
%   
%   /input/
%      none
%
%   /output/
%      none
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% BUS OBJECTS

filterbench_bus();


%% PARAMETERS

sims.filterbench.params.t0 = 0.00; % simulation start time
sims.filterbench.params.tn = 5.00; % simulation stop time
sims.filterbench.params.dt = 1.00; % simulation time step


%% INPUTS

sims.filterbench.inputs.t = (sims.filterbench.params.t0 : ...
                             sims.filterbench.params.dt : ...
                             sims.filterbench.params.tn)';

sims.filterbench.inputs.u = [ ones(size(sims.filterbench.inputs.t)) * 1000 ...
                              ones(size(sims.filterbench.inputs.t)) * 1.5 ...
                              ones(size(sims.filterbench.inputs.t)) * 1000 ];
                      

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%