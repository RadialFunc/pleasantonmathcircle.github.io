%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FILTERBENCH_PACK : packs FILTERBENCH
%   filterbench_pack
%
%   FILTERBENCH_PACK packs FILTERBENCH.
%   
%   /input/
%      none
%
%   /output/
%      none
%       
%   /history/
%      2008.11.19 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

prv_dir = pwd;

try
    cd(fullfile(fileparts(which('filterbench_ini.m')), 'mdl', 'run', ''));
    
    % ---- FILTERBENCH ----
    rtwbuild('filterbench');

    sims.filterbench.buildinfo = load(fullfile(fileparts(which('filterbench_ini.m')), 'mdl', 'run', 'filterbench_ert_rtw', 'buildInfo.mat'));
    packNGo(sims.filterbench.buildinfo.buildInfo, { 'packType', 'hierarchical', 'fileName', 'filterbench_ert_rtw.zip' });
    
    % ---- FILTERBENCH UKF ----
    rtwbuild('filterbench_ukf');

    sims.filterbench_ukf.buildinfo = load(fullfile(fileparts(which('filterbench_ini.m')), 'mdl', 'run', 'filterbench_ukf_ert_rtw', 'buildInfo.mat'));
    packNGo(sims.filterbench_ukf.buildinfo.buildInfo, { 'packType', 'hierarchical', 'fileName', 'filterbench_ukf_ert_rtw.zip' });
    
    % ---- FILTERBENCH EKF ----
    rtwbuild('filterbench_ekf');

    sims.filterbench_ekf.buildinfo = load(fullfile(fileparts(which('filterbench_ini.m')), 'mdl', 'run', 'filterbench_ekf_ert_rtw', 'buildInfo.mat'));
    packNGo(sims.filterbench_ekf.buildinfo.buildInfo, { 'packType', 'hierarchical', 'fileName', 'filterbench_ekf_ert_rtw.zip' });
catch ME
    ME.message
end

cd(prv_dir);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%