%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTTBENCH_TRACKS_SERIALIZE : serialize MTTBENCH Tracks struct
%   [ tracks_packet ] = mttbench_tracks_serialize( tracks )
%
%   MTTBENCH_TRACKS_SERIALIZE serializes a Tracks struct or bus object into a 
%   Tracks packet.
%   
%   /input/
%      tracks ( struct ) : Tracks struct
%
%   /output/
%      tracks_packet ( real[ ] ) : Tracks packet
%       
%   /history/
%      2008.10.31 : jdc : initial release
%
%   see also MTTBENCH_TRACKS_INSTANTIATE, MTTBENCH_TRACKS_DESERIALIZE
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ tracks_packet ] = mttbench_tracks_serialize( tracks )
%#eml
%% SERIALIZATION

tracks_packet = [ tracks.m ...
                  tracks.track_uid(:)' ...
                  tracks.target_uid(:)' ...
                  tracks.t(:)' ...
                  tracks.x(:)' ...
                  tracks.P(:)' ...
                  tracks.track_status(:)' ...
                  tracks.marginal_score(:)' ...
                  tracks.node_uid(:)' ...
                  tracks.observation_uid(:)' ];


end % MTTBENCH_LOOK_SERIALIZE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
