%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTT_STATE_PROJECT : project state
%   [ z ] = mttb_state_project( x, s_x, s_q )
%
%   MTT_STATE_PROJECT projects a system state vector from the I-frame onto a 
%   sensor in the S-frame the where the system state is 
%   [ x ; y ; z ; xdot ; ydot ; zdot ] and the sensor state is [ az el ].
%   
%   /input/
%      x ( real[ 6 ] ) : system state
%      s_x ( real[ 6 ] ) : sensor state
%      s_dcm ( real[ 3 ][ 3 ] ) : sensor body direction cosine matrix
%
%   /output/
%      z ( real[ 2 ][ 1 ] ) : projected system state
%       
%   /history/
%      2008.10.31 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ z ] = mtt_state_project( x, s_x, s_dcm )
%#eml
%% PROJECTION

% rotate system state from I-frame to S-frame
r_I = x(1 : 3) - s_x(1 : 3); 
r_S = s_dcm * r_I(:);

% project system state in S-frame onto the sensor
rng = norm(r_S);             % range
az  = atan2(r_S(2), r_S(1)); % azimuth
el  = asin(r_S(3) / rng);    % elemevation

z = [ az ; el ];


end % MTT_STATE_PROJECT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%