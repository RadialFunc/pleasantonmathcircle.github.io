%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTT_MATH_QUATNORMALIZE : normalize quaternion
%   [ qout ] = mtt_math_quatnormalize( q )
%
%   MTT_MATH_QUATNORMALIZE normalizes a quaternion.
%   
%   /input/
%      q ( real[ 4 ][ m ] ) : m quaternions
%
%   /output/
%      qout ( real[ 4 ][ m ] ) : m normalized quaternions
%       
%   /history/
%      2008.10.31 : jdc : initial release
% 
%   see also MTT_MATH_QUATMOD, QUATNORMALIZE
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ qout ] = mtt_math_quatnormalize( q )
%#eml
%% NORMALIZATION

qout = q ./ (mtt_math_quatmod( q ) * ones(4, 1));


end % MTT_MATH_QUATNORMALIZE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%