%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTT_MATH_QUATROTATE : rotate vector by a quaternion
%   [ vout ] = mttbench_quatrotate( q, v )
%
%   MTT_MATH_QUATROTATE rotates a vector by a quaternion.
%   
%   /input/
%      q ( real[ 4 ][ 1 ] ) : quaternion
%      r ( real[ 3 ][ m ] ) : m vectors
%
%   /output/
%      rout ( real[ 3 ][ m ] ) : m rotated vectors
%       
%   /history/
%      2008.10.22 : jdc : initial release
%
%   see also MTT_MATH_QUAT2DCM, QUATROTATE
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ rout ] = mtt_math_quatrotate( q, r )
%#eml
%% ROTATION

dcm = mtt_math_quat2dcm(q);

rout = (dcm * r);


end % MTT_MATH_QUATROTATE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%