%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTT_UKF_PROPAGATE : propagate multivariate normal state
%   [ xout, Pout ] = mtt_state_propagate( x, P, dt )
%
%   MTT_UKF_PROPAGATE propagates a multivariate normal state vector through
%   an Unscented Kalman Filter.
%   
%   /input/
%      x ( real[ 6 ] ) : system state mean
%      P ( real[ 6 ][ 6 ] ) : system state covariance
%      dt ( real ) : propagation time
%
%   /output/
%      xout ( real[ 6 ] ) : propagated system state
%      Pout ( real[ 6 ][ 6 ] ) : propagated system state
%       
%   /history/
%      2008.10.31 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ xout, Pout ] = mtt_ukf_propagate( x, P, dt )
%#eml
%% CONSTANTS

% state dimensions
L = 6;

% unscented transform parameters
ALPHA = 1.0;
BETA  = 0.0;
KAPPA = 3.0;

LAMBDA = ALPHA^2 * (L + KAPPA) - L;

% unscented transform weights
W0m = LAMBDA / (L + LAMBDA);
Wim = 1.0 / (2.0 * (L + LAMBDA));

W0c = W0m + (1.0 - ALPHA^2 + BETA);
Wic = Wim;


%% PROPAGATION

% ---- sigma points ----
S = chol(P);
Xi = zeros(L, 2 * L + 1);

Xi(:,1) = x;
for ii = 1 : L
    Xi(:,ii + 1) = x + S(:,ii);
    Xi(:,ii + 1 + L) = x - S(:,ii);
end

% ---- propagate sigma points ----
for ii = 1 : size(Xi, 2)
    Xi(:,ii) = mtt_state_propagate(Xi(:,ii), dt);
end

% ---- reconstruct mean ----
xout = Xi(:,1) * W0m;
for ii = 2 : size(Xi, 2)
    xout = xout + Xi(:,ii) * Wim;
end

% ---- reconstruct covariance ----
dx = Xi(:,1) - xout;
Pout = dx * dx' * W0c;
for ii = 2 : size(Xi, 2)
    dx = Xi(:,ii) - xout;
    Pout = Pout + dx * dx' * Wic;
end


end % MTT_UKF_PROPAGATE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%