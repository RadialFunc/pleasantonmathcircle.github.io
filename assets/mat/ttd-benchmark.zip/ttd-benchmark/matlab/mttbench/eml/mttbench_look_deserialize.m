%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTTBENCH_LOOK_DESERIALIZE : deserialize MTTBENCH Look packet
%   [ look ] = mttbench_look_deserialize( look_packet )
%
%   MTTBENCH_LOOK_DESERIALIZE deserializes a Look packet into a Look struct or
%   bus object.
%   
%   /input/
%      look_packet ( real[ ] ) : Look packet
%
%   /output/
%      look ( struct ) : Look struct
%       
%   /history/
%      2008.10.31 : jdc : initial release
%
%   see also MTTBENCH_LOOK_INSTANTIATE, MTTBENCH_LOOK_SERIALIZE
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ look ] = mttbench_look_deserialize( look_packet )
%#eml
%% CONSTANTS

MAX_NUM_OBSERVATIONS = 128;
LOOK_PACKET_SIZE = ...
  1 ...                        % look.t
+ 1 ...                        % look.sensor.sensor_id
+ 6 ...                        % look.sensor.x
+ 4 ...                        % look.sensor.q
+ 1 ...                        % look.sensor.m
+ MAX_NUM_OBSERVATIONS * 1 ... % sensor.observations.observation_id
+ MAX_NUM_OBSERVATIONS * 2 ... % sensor.observations.z
+ MAX_NUM_OBSERVATIONS * 4;    % sensor.observations.R


%% INITIALIZATION

look = mttbench_look_instantiate;


%% DESERIALIZATION

if ( numel(look_packet) >= LOOK_PACKET_SIZE )
    idx = 1;
    
    look.t = look_packet(idx); idx = idx + 1;

    look.sensor.sensor_id = look_packet(idx);                          idx = idx + 1;
    look.sensor.x         = reshape(look_packet(idx : idx + 5), 6, 1); idx = idx + 6;
    look.sensor.q         = reshape(look_packet(idx : idx + 3), 4, 1); idx = idx + 4;
    
    look.observations.m              = look_packet(idx);                                                                        idx = idx + 1;
    look.observations.observation_id = reshape(look_packet(idx : idx + MAX_NUM_OBSERVATIONS * 1 - 1), 1, MAX_NUM_OBSERVATIONS); idx = idx + MAX_NUM_OBSERVATIONS * 1;
    look.observations.z              = reshape(look_packet(idx : idx + MAX_NUM_OBSERVATIONS * 2 - 1), 2, MAX_NUM_OBSERVATIONS); idx = idx + MAX_NUM_OBSERVATIONS * 2;
    look.observations.R              = reshape(look_packet(idx : idx + MAX_NUM_OBSERVATIONS * 4 - 1), 4, MAX_NUM_OBSERVATIONS); idx = idx + MAX_NUM_OBSERVATIONS * 4;
end


end % MTTBENCH_LOOK_DESERIALIZE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
