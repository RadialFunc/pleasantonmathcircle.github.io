%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTT_MATH_QUAT2DCM : calculate the direction cosine matrix for a quaternion
%   [ dcm ] = mtt_math_quat2dcm( q )
%
%   MTT_MATH_QUAT2DCM calcualtes the diretion cosine matrix for a quaternion.
%   
%   /input/
%      q ( real[ 4 ][ m ] ) : m quaternions
%
%   /output/
%      dcm ( real[ 3 ][ 3 ][ m ] ) : m direction cosine matrices
%       
%   /history/
%      2008.10.31 : jdc : initial release
%
%   see also MTT_MATH_QUATNORMALIZE, QUAT2DCM
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ dcm ] = mtt_math_quat2dcm( q )
%#eml
%% CALCULATION

q = mtt_math_quatnormalize(q);

dcm = zeros(3, 3, size(q, 2));
dcm(1,1,:) = q(1,:).^2 + q(2,:).^2 - q(3,:).^2 - q(4,:).^2;
dcm(1,2,:) = 2 .* (q(2,:) .* q(3,:) + q(1,:) .* q(4,:));
dcm(1,3,:) = 2 .* (q(2,:) .* q(4,:) - q(1,:) .* q(3,:));
dcm(2,1,:) = 2 .* (q(2,:) .* q(3,:) - q(1,:) .* q(4,:));
dcm(2,2,:) = q(1,:).^2 - q(2,:).^2 + q(3,:).^2 - q(4,:).^2;
dcm(2,3,:) = 2 .* (q(3,:) .* q(4,:) + q(1,:) .* q(2,:));
dcm(3,1,:) = 2 .* (q(2,:) .* q(4,:) + q(1,:) .* q(3,:));
dcm(3,2,:) = 2 .* (q(3,:) .* q(4,:) - q(1,:) .* q(2,:));
dcm(3,3,:) = q(1,:).^2 - q(2,:).^2 - q(3,:).^2 + q(4,:).^2;


end % MTT_MATH_QUAT2DCM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%