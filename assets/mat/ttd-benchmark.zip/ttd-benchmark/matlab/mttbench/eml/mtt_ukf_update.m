%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTT_UKF_UPDATE : update multivariate normal state
%   [ xout, Pout ] = mtt_ukf_update( x, P, z, R, s_x, s_q )
%
%   MTT_UKF_UPDATE updates a multivariate normal state vector through
%   an Unscented Kalman Filter.
%   
%   /input/
%      x ( real[ 6 ] ) : system state mean
%      P ( real[ 6 ][ 6 ] ) : system state covariance
%      z ( real[ 2 ] ) : measurement state mean
%      R ( real[ 2 ][ 2 ] ) : measurement state covariance
%      s_x ( real[ 6 ] ) : sensor state
%      s_dcm ( real[ 3 ][ 3 ] ) : sensor body direction cosine matrix
%
%   /output/
%      xout ( real[ 6 ] ) : updated system state
%      Pout ( real[ 6 ][ 6 ] ) : updated system state
%       
%   /history/
%      2008.10.31 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ xout, Pout ] = mtt_ukf_update( x, P, z, R, s_x, s_dcm )
%#eml
%% CONSTANTS

% state dimensions
L = 6;
M = 2;

% unscented transform parameters
ALPHA = 1.0;
BETA  = 0.0;
KAPPA = 3.0;

LAMBDA = ALPHA^2 * (L + KAPPA) - L;

% unscented transform weights
W0m = LAMBDA / (L + LAMBDA);
Wim = 1.0 / (2.0 * (L + LAMBDA));

W0c = W0m + (1.0 - ALPHA^2 + BETA);
Wic = Wim;


%% UPDATE

% ---- sigma points ----
S = chol(P);
Xi = zeros(L, 2 * L + 1);
Yi = zeros(M, 2 * L + 1);

Xi(:,1) = x;
for ii = 1 : L
    Xi(:,ii + 1) = x + S(:,ii);
    Xi(:,ii + 1 + L) = x - S(:,ii);
end

% ---- project sigma points ----
for ii = 1 : size(Xi, 2)
    Yi(:,ii) = mtt_state_project(Xi(:,ii), s_x, s_dcm);
end

% ---- reconstruct means ----
x_ = Xi(:,1) * W0m;
for ii = 2 : size(Xi, 2)
    x_ = x_ + Xi(:,ii) * Wim;
end

z_ = Yi(:,1) * W0m;
for ii = 2 : size(Yi, 2)
    z_ = z_ + Yi(:,ii) * Wim;
end

% ---- reconstruct covariances ----
dz = Yi(:,1) - z_;
Pzz = dz * dz' * W0c;
for ii = 2 : size(Yi, 2)
    dz = Yi(:,ii) - z_;
    Pzz = Pzz + dz * dz' * Wic;
end

dx = Xi(:,1) - x_;
dz = Yi(:,1) - z_;
Pxz = dx * dz' * W0c;
for ii = 2 : size(Yi, 2)
    dx = Xi(:,ii) - x_;
    dz = Yi(:,ii) - z_;
    Pxz = Pxz + dx * dz' * Wic;
end

% ---- kalman update ----
Rzz = Pzz + R;
K = Pxz * inv(Rzz);

xout = x + K * (z - z_);
Pout = P - K * Rzz * K';


end % MTT_UKF_UPDATE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%