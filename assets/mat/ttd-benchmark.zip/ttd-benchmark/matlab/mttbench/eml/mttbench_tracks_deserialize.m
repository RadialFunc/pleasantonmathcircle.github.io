%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTTBENCH_TRACKS_DESERIALIZE : deserialize MTTBENCH Look packet
%   [ look ] = mttbench_tracks_deserialize( tracks_packet )
%
%   MTTBENCH_TRACKS_DESERIALIZE deserializes a Look packet into a Look struct or
%   bus object.
%   
%   /input/
%      tracks_packet ( real[ ] ) : Look packet
%
%   /output/
%      look ( struct ) : Look struct
%       
%   /history/
%      2008.10.31 : jdc : initial release
%
%   see also MTTBENCH_TRACKS_INSTANTIATE, MTTBENCH_TRACKS_SERIALIZE
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ tracks ] = mttbench_tracks_deserialize( tracks_packet )
%#eml
%% CONSTANTS

MAX_NUM_TRACKS = 4096;
TRACKS_PACKET_SIZE = ...
  1 ...                   % tracks.m
+ MAX_NUM_TRACKS *  1 ... % tracks.track_uid
+ MAX_NUM_TRACKS *  1 ... % tracks.target_uid
+ MAX_NUM_TRACKS *  1 ... % tracks.t
+ MAX_NUM_TRACKS *  6 ... % tracks.x
+ MAX_NUM_TRACKS * 36 ... % tracks.P
+ MAX_NUM_TRACKS *  1 ... % tracks.track_status
+ MAX_NUM_TRACKS *  1 ... % tracks.marginal_score
+ MAX_NUM_TRACKS *  1 ... % tracks.cumulative_score
+ MAX_NUM_TRACKS *  1 ... % tracks.node_uid
+ MAX_NUM_TRACKS *  1;    % tracks.observation_uid


%% INITIALIZATION

tracks = mttbench_tracks_instantiate;


%% DESERIALIZATION

if ( numel(tracks_packet) >= TRACKS_PACKET_SIZE )
    idx = 1;
    
    tracks.m = tracks_packet(idx); idx = idx + 1;

    tracks.track_uid  = reshape(tracks_packet(idx : idx + MAX_NUM_TRACKS * 1 - 1), 1, MAX_NUM_TRACKS); idx = idx + MAX_NUM_TRACKS * 1;
    tracks.target_uid = reshape(tracks_packet(idx : idx + MAX_NUM_TRACKS * 1 - 1), 1, MAX_NUM_TRACKS); idx = idx + MAX_NUM_TRACKS * 1;
    
    tracks.t = reshape(tracks_packet(idx : idx + MAX_NUM_TRACKS * 1 - 1), 1, MAX_NUM_TRACKS); idx = idx + MAX_NUM_TRACKS * 1;
    tracks.x = reshape(tracks_packet(idx : idx + MAX_NUM_TRACKS * 6 - 1), 6, MAX_NUM_TRACKS); idx = idx + MAX_NUM_TRACKS * 6;
    tracks.P = reshape(tracks_packet(idx : idx + MAX_NUM_TRACKS * 36 - 1), 36, MAX_NUM_TRACKS); idx = idx + MAX_NUM_TRACKS * 36;
    
    tracks.track_status      = reshape(tracks_packet(idx : idx + MAX_NUM_TRACKS * 1 - 1), 1, MAX_NUM_TRACKS); idx = idx + MAX_NUM_TRACKS * 1;
    tracks.marginal_score    = reshape(tracks_packet(idx : idx + MAX_NUM_TRACKS * 1 - 1), 1, MAX_NUM_TRACKS); idx = idx + MAX_NUM_TRACKS * 1;
    tracks.cumulative_score  = reshape(tracks_packet(idx : idx + MAX_NUM_TRACKS * 1 - 1), 1, MAX_NUM_TRACKS); idx = idx + MAX_NUM_TRACKS * 1;
    
    tracks.node_uid         = reshape(tracks_packet(idx : idx + MAX_NUM_TRACKS * 1 - 1), 1, MAX_NUM_TRACKS); idx = idx + MAX_NUM_TRACKS * 1;
    tracks.observation_uid  = reshape(tracks_packet(idx : idx + MAX_NUM_TRACKS * 1 - 1), 1, MAX_NUM_TRACKS); idx = idx + MAX_NUM_TRACKS * 1;
end


end % MTTBENCH_TRACKS_DESERIALIZE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
