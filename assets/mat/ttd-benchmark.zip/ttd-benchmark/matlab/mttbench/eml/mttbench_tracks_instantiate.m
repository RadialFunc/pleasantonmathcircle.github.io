%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTTBENCH_TRACKS_INSTANTIATE : instantiate MTTBENCH Tracks struct
%   [ tracks ] = mttbench_tracks_instantiate( )
%
%   MTTBENCH_TRACKS_INSTANTIATE instantiates an empty Tracks struct.
%   
%   /input/
%      none
%
%   /output/
%      tracks ( struct ) : Tracks struct
%       
%   /history/
%      2008.10.31 : jdc : initial release
%
%   see also MTTBENCH_TRACKS_SERIALIZE, MTTBENCH_TRACKS_DESERIALIZE
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ tracks ] = mttbench_tracks_instantiate( )
%#eml
%% CONSTANTS

MAX_NUM_TRACKS = 4096;


%% INTANTIATION

tracks.m = 0;

tracks.track_uid = zeros(1, MAX_NUM_TRACKS);
tracks.target_uid = zeros(1, MAX_NUM_TRACKS);

tracks.t = zeros(1, MAX_NUM_TRACKS);
tracks.x = zeros(6, MAX_NUM_TRACKS);
tracks.P = zeros(36, MAX_NUM_TRACKS);

tracks.track_status = zeros(1, MAX_NUM_TRACKS);
tracks.marginal_score = zeros(1, MAX_NUM_TRACKS);
tracks.cumulative_score = zeros(1, MAX_NUM_TRACKS);

tracks.node_uid = zeros(1, MAX_NUM_TRACKS);
tracks.observation_uid = zeros(1, MAX_NUM_TRACKS);


end % MTTBENCH_TRACKS_INSTANTIATE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
