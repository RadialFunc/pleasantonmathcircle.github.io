%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTT_UKF_PROJECT : project multivariate normal state
%   [ xout, Pout ] = mtt_ukf_project( x, P, z, R, s_x, s_q )
%
%   MTT_UKF_PROJECT projects a multivariate normal state vector through
%   an Unscented Kalman Filter.
%   
%   /input/
%      x ( real[ 6 ] ) : system state mean
%      P ( real[ 6 ][ 6 ] ) : system state covariance
%      s_x ( real[ 6 ] ) : sensor state
%      s_dcm ( real[ 3 ][ 3 ] ) : sensor body direction cosine matrix
%
%   /output/
%      z ( real[ 2 ] ) : projected system state mean
%      R ( real[ 2 ][ 2 ] ) : projected system state covariance
%       
%   /history/
%      2008.10.31 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ z, R ] = mtt_ukf_project( x, P, s_x, s_dcm )
%#eml
%% CONSTANTS

% state dimensions
L = 6;
M = 2;

% unscented transform parameters
ALPHA = 1.0;
BETA  = 0.0;
KAPPA = 3.0;

LAMBDA = ALPHA^2 * (L + KAPPA) - L;

% unscented transform weights
W0m = LAMBDA / (L + LAMBDA);
Wim = 1.0 / (2.0 * (L + LAMBDA));

W0c = W0m + (1.0 - ALPHA^2 + BETA);
Wic = Wim;


%% PROJECTION

% ---- sigma points ----
S = chol(P);
Xi = zeros(L, 2 * L + 1);
Yi = zeros(M, 2 * L + 1);

Xi(:,1) = x;
for ii = 1 : L
    Xi(:,ii + 1) = x + S(:,ii);
    Xi(:,ii + 1 + L) = x - S(:,ii);
end

% ---- project sigma points ----
for ii = 1 : size(Xi, 2)
    Yi(:,ii) = mtt_state_project(Xi(:,ii), s_x, s_dcm);
end

% ---- reconstruct mean ----
z = Yi(:,1) * W0m;
for ii = 2 : size(Yi, 2)
    z = z + Yi(:,ii) * Wim;
end

% ---- reconstruct covariance ----
dz = Yi(:,1) - z;
R = dz * dz' * W0c;
for ii = 2 : size(Yi, 2)
    dz = Yi(:,ii) - z;
    R = R + dz * dz' * Wic;
end


end % MTT_UKF_PROJECT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%