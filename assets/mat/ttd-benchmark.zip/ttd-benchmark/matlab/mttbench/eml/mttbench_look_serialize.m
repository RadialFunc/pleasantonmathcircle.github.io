%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTTBENCH_LOOK_SERIALIZE : serialize MTTBENCH Look struct
%   [ look_packet ] = mttbench_look_serialize( look )
%
%   MTTBENCH_LOOK_SERIALIZE serializes a Look struct or bus object into a Look 
%   packet.
%   
%   /input/
%      look ( struct ) : Look struct
%
%   /output/
%      look_packet ( real[ ] ) : Look packet
%       
%   /history/
%      2008.10.31 : jdc : initial release
%
%   see also MTTBENCH_LOOK_INSTANTIATE, MTTBENCH_LOOK_DESERIALIZE
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ look_packet ] = mttbench_look_serialize( look )
%#eml
%% SERIALIZATION

look_packet = [ look.t ...
                look.sensor.sensor_id ...
                look.sensor.x(:)' ...
                look.sensor.q(:)' ...
                look.observations.m ...
                look.observations.observation_id(:)' ...
                look.observations.z(:)' ...
                look.observations.R(:)' ];


end % MTTBENCH_LOOK_SERIALIZE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
