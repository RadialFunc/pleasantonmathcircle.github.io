%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTTBENCH_LOOK_INSTANTIATE : instantiate MTTBENCH Look struct
%   [ look ] = mttbench_look_instantiate( )
%
%   MTTBENCH_LOOK_INSTANTIATE instantiates an empty Look struct.
%   
%   /input/
%      none
%
%   /output/
%      look ( struct ) : Look struct
%       
%   /history/
%      2008.10.31 : jdc : initial release
%
%   see also MTTBENCH_LOOK_SERIALIZE, MTTBENCH_LOOK_DESERIALIZE
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ look ] = mttbench_look_instantiate( )
%#eml
%% CONSTANTS

MAX_NUM_OBSERVATIONS = 128;


%% INTANTIATION

look.t = 0;

look.sensor.sensor_id = 0;
look.sensor.x = zeros(6, 1);
look.sensor.q = zeros(4, 1);

look.observations.m = 0;
look.observations.observation_id = zeros(1, MAX_NUM_OBSERVATIONS);
look.observations.z = zeros(2, MAX_NUM_OBSERVATIONS);
look.observations.R = zeros(4, MAX_NUM_OBSERVATIONS);


end % MTTBENCH_LOOK_INSTANTIATE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
