%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTTBENCH_TRACKS_EXTEND : extend Tracks
%   [ look_record, observations, propagated_tracks, extended_tracks ] ...
%     = mttbench_tracks_extend( look, tracks )
%
%   MTTBENCH_TRACKS_EXTEND extends Tracks with a Look.
%   
%   /input/
%      look ( struct ) : Look struct
%      tracks ( struct ) : Tracks struct
%
%   /output/
%      look_record ( struct ) : new LookRecord struct
%      observations ( struct ) : new Observations struct
%      propagated_tracks ( struct ) : propagated Tracks struct
%      extended_tracks ( struct ) : extended Tracks struct
%       
%   /history/
%      2008.10.31 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ look_record, observations, propagated_tracks, extended_tracks ] = mttbench_tracks_extend( look, tracks )
%#eml
%% CONSTANTS

P_GATE = 0.80;


%% EXTENSION

% ---- initialize ----
look_record = mttbench_lookrecord_instantiate();

observations = mttbench_observations_instantiate();

propagated_tracks = mttbench_tracks_instantiate();
extended_tracks = mttbench_tracks_instantiate();

max_tracks = numel(tracks.track_uid);
max_observations = numel(observations.observation_uid);

% ---- update look record ----
look_record.look_uid = 0; % placeholder uid

look_record.t = look.t;
look_record.x = look.sensor.x;
look_record.dcm = reshape(mtt_math_quat2dcm(look.sensor.q), 9, 1);
look_record.m = look.observations.m;

look_record.sensor_id = look.sensor.sensor_id;

% ---- update observations ----
for ii = 1 : look_record.m
    % ..if "observations" maximum capacity reached
    if ( ii > max_observations )
        break;
    % ..otherwise
    else
        observations.m = observations.m + 1;

        observations.observation_uid(ii) = 0;

        observations.t(ii)   = look.t;
        observations.z(:,ii) = look.observations.z(:,ii);
        observations.R(:,ii) = look.observations.R(:,ii);

        observations.node_uid(ii) = 0; % placeholder uid
        observations.look_uid(ii) = 0; % placeholder uid

        observations.sensor_id(ii)      = look.sensor.sensor_id;
        observations.observation_id(ii) = look.observations.observation_id(ii);
    end
end

% ---- select tracks ----
for ii = 1 : tracks.m
    % select all tracks for now...
    track_selected = true;
    
    % ..if track selected
    if ( track_selected )
        propagated_tracks.m = propagated_tracks.m + 1;

        propagated_tracks.track_uid(propagated_tracks.m)  = 0; % placeholder uid
        propagated_tracks.target_uid(propagated_tracks.m) = tracks.target_uid(ii);

        propagated_tracks.t(propagated_tracks.m)   = tracks.t(ii);
        propagated_tracks.x(:,propagated_tracks.m) = tracks.x(:,ii);
        propagated_tracks.P(:,propagated_tracks.m) = tracks.P(:,ii);

        propagated_tracks.track_status(propagated_tracks.m)     = tracks.track_status(ii);
        propagated_tracks.marginal_score(propagated_tracks.m)   = tracks.marginal_score(ii);
        propagated_tracks.cumulative_score(propagated_tracks.m) = tracks.cumulative_score(ii);

        propagated_tracks.node_uid(propagated_tracks.m)        = 0; % placeholder uid
        propagated_tracks.observation_uid(propagated_tracks.m) = 0; % placeholder uid
    end
end

% ---- propagate tracks ----
for ii = 1 : propagated_tracks.m
    % extract track
    t = propagated_tracks.t(ii);
    x = reshape(propagated_tracks.x(:,ii), 6, 1);
    P = reshape(propagated_tracks.P(:,ii), 6, 6);
    
    % propagate track
    [ x, P ] = mtt_ukf_propagate(x, P, look_record.t - t);
    
    % update propagated track
    propagated_tracks.t(ii)   = look_record.t;
    propagated_tracks.x(:,ii) = x(:)';
    propagated_tracks.P(:,ii) = P(:)';
end

% ---- initiate tracks ----
for ii = 1 : observations.m
    % ..if "tracks" maximum capacity not reached
    if ( extended_tracks.m <= max_tracks )
        % initiate new tracks
        extended_tracks.m = extended_tracks.m + 1;

        extended_tracks.track_uid(extended_tracks.m)  = 0; % placeholder uid
        extended_tracks.target_uid(extended_tracks.m) = 0; % placeholder uid

        extended_tracks.t(extended_tracks.m)   = look_record.t;
        extended_tracks.x(:,extended_tracks.m) = zeros(6, 1);
        extended_tracks.P(:,extended_tracks.m) = reshape(eye(6), 36, 1);

        extended_tracks.track_status(extended_tracks.m)     = 0;
        extended_tracks.marginal_score(extended_tracks.m)   = 0;
        extended_tracks.cumulative_score(extended_tracks.m) = 0;

        extended_tracks.node_uid(extended_tracks.m)        = 0; % placeholder uid
        extended_tracks.observation_uid(extended_tracks.m) = 0; % placeholder uid
    end
end

% ---- extend tracks ----
for ii = 1 : propagated_tracks.m
    for jj = 1 : observations.m
        % random gate for now...
        association_gated = (rand <= P_GATE);
        
        % ..if association not gated
        if ( ~association_gated )
            % extract track
            x = reshape(propagated_tracks.x(:,ii), 6, 1);
            P = reshape(propagated_tracks.P(:,ii), 6, 6);
            
            % extract observation
            z = reshape(observations.z(:,jj), 2, 1);
            R = reshape(observations.R(:,jj), 2, 2);

            % update track
            [ x, P ] = mtt_ukf_update(x, P, z, R, look_record.x, reshape(look_record.dcm, 3, 3));

            % score track
            [ z_trk, R_trk ] = mtt_ukf_project(x, P, look_record.x, reshape(look_record.dcm, 3, 3));
            score = mtt_score_hit(z_trk, R_trk, z, R);
            
            % ..if "tracks" maximum capacity not reached
            if ( extended_tracks.m <= max_tracks )
                extended_tracks.m = extended_tracks.m + 1;

                extended_tracks.track_uid(extended_tracks.m)  = 0; % placeholder uid
                extended_tracks.target_uid(extended_tracks.m) = propagated_tracks.target_uid(ii);

                extended_tracks.t(extended_tracks.m)   = propagated_tracks.t(ii);
                extended_tracks.x(:,extended_tracks.m) = x(:)';
                extended_tracks.P(:,extended_tracks.m) = P(:)';

                extended_tracks.track_status(extended_tracks.m)     = propagated_tracks.track_status(ii);
                extended_tracks.marginal_score(extended_tracks.m)   = score;
                extended_tracks.cumulative_score(extended_tracks.m) = propagated_tracks.cumulative_score(ii) + score;

                extended_tracks.node_uid(extended_tracks.m)        = 0; % placeholder uid
                extended_tracks.observation_uid(extended_tracks.m) = 0; % placeholder uid
            end
        end
    end
end


end % MTTBENCH_TRACKS_EXTEND
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
