%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTTBENCH_OBSERVATIONS_INSTANTIATE : instantiate MTTBENCH Observations struct
%   [ observations ] = mttbench_observations_instantiate( )
%
%   MTTBENCH_OBSERVATIONS_INSTANTIATE instantiates an empty Observations struct.
%   
%   /input/
%      none
%
%   /output/
%      observations ( struct ) : Observations struct
%       
%   /history/
%      2008.10.31 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ observations ] = mttbench_observations_instantiate( )
%#eml
%% CONSTANTS

MAX_NUM_OBSERVATIONS = 128;


%% INTANTIATION

observations.m = 0;

observations.observation_uid = zeros(1, MAX_NUM_OBSERVATIONS);

observations.t = zeros(1, MAX_NUM_OBSERVATIONS);
observations.z = zeros(2, MAX_NUM_OBSERVATIONS);
observations.R = zeros(4, MAX_NUM_OBSERVATIONS);

observations.node_uid = zeros(1, MAX_NUM_OBSERVATIONS);
observations.look_uid = zeros(1, MAX_NUM_OBSERVATIONS);

observations.sensor_id = zeros(1, MAX_NUM_OBSERVATIONS);
observations.observation_id = zeros(1, MAX_NUM_OBSERVATIONS);


end % MTTBENCH_OBSERVATIONS_INSTANTIATE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
