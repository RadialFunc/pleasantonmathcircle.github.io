%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTT_STATE_PROPAGATE : propagate state
%   [ x ] = mtt_state_propagate( x, dt )
%
%   MTT_STATE_PROPAGATE propagates a system state vector in the I-frame where 
%   the system state is [ x ; y ; z ; xdot ; ydot ; zdot ] with MKS units.
%   
%   /input/
%      x ( real[ 6 ] ) : system state
%      dt ( real ) : propagation time
%
%   /output/
%      xout ( real[ 6 ] ) : propagated system state
%       
%   /history/
%      2008.10.31 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ xout ] = mtt_state_propagate( x, dt )
%#eml
%% PROPAGATION

% euler step with constant acceleration for now...
dxdt = [ x(4 : 6) ; zeros(3, 1) ];
xout = x + dxdt * dt;


end % MTT_STATE_PROPAGATE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%