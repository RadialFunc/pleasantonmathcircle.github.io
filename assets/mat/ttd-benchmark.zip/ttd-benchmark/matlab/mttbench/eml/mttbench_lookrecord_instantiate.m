%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTTBENCH_LOOKRECORD_INSTANTIATE : instantiate MTTBENCH LookRecord struct
%   [ look_record ] = mttbench_lookrecord_instantiate( )
%
%   MTTBENCH_LOOKRECORD_INSTANTIATE instantiates an empty LookRecord struct.
%   
%   /input/
%      none
%
%   /output/
%      look_record ( struct ) : LookRecord struct
%       
%   /history/
%      2008.10.31 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ look_record ] = mttbench_lookrecord_instantiate( )
%#eml
%% INTANTIATION

look_record.look_uid = 0;

look_record.t = 0;
look_record.x = zeros(6, 1);
look_record.dcm = zeros(9, 1);
look_record.m = 0;

look_record.sensor_id = 0;


end % MTTBENCH_LOOKRECORD_INSTANTIATE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
