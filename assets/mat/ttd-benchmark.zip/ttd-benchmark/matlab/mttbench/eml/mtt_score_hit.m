%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTT_SCORE_HIT : score hit association
%   [ score ] = mtt_score_hit( x, P, z, R, s_x, s_q )
%
%   MTT_SCORE_HIT scoers a hit association.
%   
%   /input/
%      z_trk ( real[ 2 ] ) : projected track state mean
%      R_trk ( real[ 2 ][ 2 ] ) : projected track state covariance
%      z_obs ( real[ 2 ] ) : measurement state mean
%      R_obs ( real[ 2 ][ 2 ] ) : measurement state covariance
%
%   /output/
%      score ( real ) : score
%       
%   /history/
%      2008.10.31 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ score ] = mtt_score_hit( z_trk, R_trk, z_obs, R_obs )
%#eml
%% SCORE

% use multivariate normal log likelihood for now...
z = z_obs - z_trk;
P = R_obs + R_trk;

e = exp(-0.5 * z' * inv(P) * z);
n = (2 * pi) * sqrt(det(P));

score = log(e / n);


end % MTT_SCORE_HIT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%