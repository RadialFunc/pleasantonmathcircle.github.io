%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTTBENCH_CFG : configure MATLAB environment for MTTBENCH Simulink model
%   mttbench_cfg
%
%   MTTBENCH_CFG configures the MATLAB environment for the MTTBENCH Simulink
%   model by defining bus objects, assigning parameters, and setting up inputs.
%   
%   /input/
%      none
%
%   /output/
%      none
%       
%   /history/
%      2008.10.31 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% BUS OBJECTS
mttbench_bus();


%% PARAMETERS

sim.params.t0 =   0.00; % simulation start time
sim.params.tn = 110.00; % simulation stop time
sim.params.dt =   1.00; % simulation time step


%% INPUTS

% instantiate
tmp.look = mttbench_look_instantiate();
tmp.look.observations.m = 20;
tmp.look_packet = mttbench_look_serialize(tmp.look);

tmp.tracks = mttbench_tracks_instantiate();
tmp.tracks.m = 500;
tmp.tracks_packet = mttbench_tracks_serialize(tmp.tracks);

% insert
sim.in.look_events.time = (sim.params.t0 : sim.params.dt : sim.params.tn)';
sim.in.look_events.signals.values = (rem(sim.in.look_events.time, 1) == 0);
sim.in.look_events.signals.dimensions = 1;

sim.in.look_packets.time = 0.0;
sim.in.look_packets.signals.values = tmp.look_packet;
sim.in.look_packets.signals.dimensions = numel(tmp.look_packet);

sim.in.tracks_packets.time = 0.0;
sim.in.tracks_packets.signals.values = tmp.tracks_packet;
sim.in.tracks_packets.signals.dimensions = numel(tmp.tracks_packet);

% clean
clear tmp;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%