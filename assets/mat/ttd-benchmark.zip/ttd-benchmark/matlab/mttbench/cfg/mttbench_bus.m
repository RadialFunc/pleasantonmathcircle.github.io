%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity: !SENSITIVITY!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !COPYRIGHT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MTTBENCH_BUS : instantiate bus objects for MTTBENCH Simulink model
%   mttbench_bus
%
%   MTTBENCH_BUS instantiates bus objects for the MTTBENCH Simulink model
%   programmatically.
%   
%   /input/
%      none
%
%   /output/
%      none
%       
%   /history/
%      2008.10.31 : jdc : initial release
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% DESCRIPTION

% instantiate
tmp.buses.look = mttbench_look_instantiate();
tmp.buses.look_record = mttbench_lookrecord_instantiate();
tmp.buses.tracks = mttbench_tracks_instantiate();
tmp.buses.observations = mttbench_observations_instantiate();

% format :
%   { < Bus Object Name >, ... 
%     < Header File >, ... 
%     sprintf(< Description >), ...
%     { ...    
%       { < Bus Element Name >, < Dimensions >, < Data Type >, < Sample Time >, < Complexity >, < Sampling Mode > } ;
%     } ...
%   } ... 
sim.buses.info = { ... 

  % ---- LookSensor ----
  { 'LookSensor', ... 
    '', ... 
    sprintf(''), ...
    { ...    
      { 'sensor_id', 1, 'double', -1, 'real', 'Sample' } ;
      { 'x', size(tmp.buses.look.sensor.x), 'double', -1, 'real', 'Sample' } ;
      { 'q', size(tmp.buses.look.sensor.q), 'double', -1, 'real', 'Sample' } ;
    } ...
  } ... % LookSensor
  
  % ---- LookObservations ----
  { 'LookObservations', ... 
    '', ... 
    sprintf(''), ...
    { ...    
      { 'm', 1, 'double', -1, 'real', 'Sample' } ;
      { 'observation_id', size(tmp.buses.look.observations.observation_id), 'double', -1, 'real', 'Sample' } ;
      { 'z', size(tmp.buses.look.observations.z), 'double', -1, 'real', 'Sample' } ;
      { 'R', size(tmp.buses.look.observations.R), 'double', -1, 'real', 'Sample' } ;
    } ...
  } ... % LookObservations
  
  % ---- Look ----
  { 'Look', ... 
    '', ... 
    sprintf(''), ...
    { ...    
      { 't', 1, 'double', -1, 'real', 'Sample' } ;
      { 'sensor', 1, 'LookSensor', -1, 'real', 'Sample' } ;
      { 'observations', 1, 'LookObservations', -1, 'real', 'Sample' } ;
    } ...
  } ... % Look
  
  % ---- LookRecord ----
  { 'LookRecord', ... 
    '', ... 
    sprintf(''), ...
    { ...    
      { 'look_uid', 1, 'double', -1, 'real', 'Sample' } ;
      { 't', 1, 'double', -1, 'real', 'Sample' } ;
      { 'x', size(tmp.buses.look_record.x), 'double', -1, 'real', 'Sample' } ;
      { 'dcm', size(tmp.buses.look_record.dcm), 'double', -1, 'real', 'Sample' } ;
      { 'm', 1, 'double', -1, 'real', 'Sample' } ;
      { 'sensor_id', 1, 'double', -1, 'real', 'Sample' } ;
    } ...
  } ... % LookRecord

  % ---- Tracks ----
  { 'Tracks', ... 
    '', ... 
    sprintf(''), ...
    { ...    
      { 'm', 1, 'double', -1, 'real', 'Sample' } ;
      { 'track_uid', size(tmp.buses.tracks.track_uid), 'double', -1, 'real', 'Sample' } ;
      { 'target_uid', size(tmp.buses.tracks.target_uid), 'double', -1, 'real', 'Sample' } ;
      { 't', size(tmp.buses.tracks.t), 'double', -1, 'real', 'Sample' } ;
      { 'x', size(tmp.buses.tracks.x), 'double', -1, 'real', 'Sample' } ;
      { 'P', size(tmp.buses.tracks.P), 'double', -1, 'real', 'Sample' } ;
      { 'track_status', size(tmp.buses.tracks.track_status), 'double', -1, 'real', 'Sample' } ;
      { 'marginal_score', size(tmp.buses.tracks.marginal_score), 'double', -1, 'real', 'Sample' } ;
      { 'cumulative_score', size(tmp.buses.tracks.cumulative_score), 'double', -1, 'real', 'Sample' } ;
      { 'node_uid', size(tmp.buses.tracks.node_uid), 'double', -1, 'real', 'Sample' } ;
      { 'observation_uid', size(tmp.buses.tracks.observation_uid), 'double', -1, 'real', 'Sample' } ; 
    } ...
  } ... % Tracks
  
  % ---- Observations ----
  { 'Observations', ... 
    '', ... 
    sprintf(''), ...
    { ...   
      { 'm', 1, 'double', -1, 'real', 'Sample' } ;
      { 'observation_uid', size(tmp.buses.observations.observation_uid), 'double', -1, 'real', 'Sample' } ;
      { 't', size(tmp.buses.observations.t), 'double', -1, 'real', 'Sample' } ;
      { 'z', size(tmp.buses.observations.z), 'double', -1, 'real', 'Sample' } ;
      { 'R', size(tmp.buses.observations.R), 'double', -1, 'real', 'Sample' } ;
      { 'node_uid', size(tmp.buses.observations.node_uid), 'double', -1, 'real', 'Sample' } ;
      { 'look_uid', size(tmp.buses.observations.look_uid), 'double', -1, 'real', 'Sample' } ;
      { 'sensor_id', size(tmp.buses.observations.sensor_id), 'double', -1, 'real', 'Sample' } ;
      { 'observation_id', size(tmp.buses.observations.observation_id), 'double', -1, 'real', 'Sample' } ;
    } ...
  } ... % Observations
  
}'; 

% clean
clear tmp;


%% INSTANTIATION
Simulink.Bus.cellToObject(sim.buses.info) 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification: UNCLASSIFIED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
